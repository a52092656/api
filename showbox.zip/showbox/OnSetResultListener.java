package com.tdo.showbox;

import com.tdo.showbox.model.movie.NormalFilmModel;
import java.util.List;
/* loaded from: classes3.dex */
public interface OnSetResultListener {
    void onSetResult(List<NormalFilmModel> list);
}
