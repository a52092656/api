package com.tdo.showbox.utils;

import androidx.lifecycle.LifecycleOwner;
import com.tdo.showbox.http.ApiException;
import com.tdo.showbox.http.ServerException;
import com.uber.autodispose.ObservableSubscribeProxy;
import io.reactivex.Observable;
import io.reactivex.disposables.Disposable;
import io.reactivex.functions.Action;
import io.reactivex.functions.Consumer;
import io.reactivex.internal.functions.Functions;
import java.util.ArrayList;
import java.util.List;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
/* compiled from: RxSubscribers.kt */
@Metadata(bv = {1, 0, 3}, d1 = {"\u0000l\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0003\n\u0000\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010 \n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\n\u001a(\u0010\u000e\u001a\b\u0012\u0004\u0012\u0002H\u00100\u000f\"\b\b\u0000\u0010\u0010*\u00020\t*\u000e\u0012\u0004\u0012\u0002H\u0010\u0012\u0004\u0012\u00020\u00030\u0001H\u0002\u001a\u0012\u0010\u0011\u001a\u00020\u0012*\b\u0012\u0004\u0012\u00020\u00030\u0005H\u0002\u001a\u001e\u0010\u0013\u001a\b\u0012\u0004\u0012\u00020\u00070\u000f*\u000e\u0012\u0004\u0012\u00020\u0007\u0012\u0004\u0012\u00020\u00030\u0001H\u0002\u001a\u001e\u0010\u0014\u001a\b\u0012\u0004\u0012\u00020\r0\u000f*\u000e\u0012\u0004\u0012\u00020\r\u0012\u0004\u0012\u00020\u00030\u0001H\u0002\u001a\u0087\u0001\u0010\u0015\u001a\u00020\u0003\"\n\b\u0000\u0010\u0010\u0018\u0001*\u00020\t*\b\u0012\u0004\u0012\u0002H\u00100\u00162\u0014\b\u0006\u0010\u0017\u001a\u000e\u0012\u0004\u0012\u00020\u0002\u0012\u0004\u0012\u00020\u00030\u00012\u000e\b\u0006\u0010\u0018\u001a\b\u0012\u0004\u0012\u00020\u00030\u00052\u0014\b\u0006\u0010\u0019\u001a\u000e\u0012\u0004\u0012\u0002H\u0010\u0012\u0004\u0012\u00020\u00030\u00012\u0014\b\u0006\u0010\u001a\u001a\u000e\u0012\u0004\u0012\u00020\r\u0012\u0004\u0012\u00020\u00030\u00012\u0014\b\u0006\u0010\u001b\u001a\u000e\u0012\u0004\u0012\u00020\u000b\u0012\u0004\u0012\u00020\u00030\u0001H\u0086\b\u001a\u0082\u0001\u0010\u001c\u001a\u00020\r\"\b\b\u0000\u0010\u0010*\u00020\t*\b\u0012\u0004\u0012\u0002H\u00100\u00162\u0014\b\u0002\u0010\u0017\u001a\u000e\u0012\u0004\u0012\u00020\u0002\u0012\u0004\u0012\u00020\u00030\u00012\u000e\b\u0002\u0010\u0018\u001a\b\u0012\u0004\u0012\u00020\u00030\u00052\u0014\b\u0002\u0010\u001a\u001a\u000e\u0012\u0004\u0012\u00020\r\u0012\u0004\u0012\u00020\u00030\u00012\u0014\b\u0002\u0010\u001b\u001a\u000e\u0012\u0004\u0012\u00020\u000b\u0012\u0004\u0012\u00020\u00030\u00012\u0014\b\u0002\u0010\u0019\u001a\u000e\u0012\u0004\u0012\u0002H\u0010\u0012\u0004\u0012\u00020\u00030\u0001\u001al\u0010\u001c\u001a\u00020\r\"\b\b\u0000\u0010\u0010*\u00020\t*\b\u0012\u0004\u0012\u0002H\u00100\u001d2\u0014\b\u0002\u0010\u0017\u001a\u000e\u0012\u0004\u0012\u00020\u0007\u0012\u0004\u0012\u00020\u00030\u00012\u000e\b\u0002\u0010\u0018\u001a\b\u0012\u0004\u0012\u00020\u00030\u00052\u0014\b\u0002\u0010\u001a\u001a\u000e\u0012\u0004\u0012\u00020\r\u0012\u0004\u0012\u00020\u00030\u00012\u0014\b\u0002\u0010\u0019\u001a\u000e\u0012\u0004\u0012\u0002H\u0010\u0012\u0004\u0012\u00020\u00030\u0001\u001a\u008f\u0001\u0010\u001e\u001a\u00020\u0003\"\n\b\u0000\u0010\u0010\u0018\u0001*\u00020\t*\b\u0012\u0004\u0012\u00020\u001f0\u001d2\u0006\u0010 \u001a\u00020!2\u0014\b\u0006\u0010\u0017\u001a\u000e\u0012\u0004\u0012\u00020\u0002\u0012\u0004\u0012\u00020\u00030\u00012\u000e\b\u0006\u0010\u0018\u001a\b\u0012\u0004\u0012\u00020\u00030\u00052\u0014\b\u0006\u0010\u0019\u001a\u000e\u0012\u0004\u0012\u0002H\u0010\u0012\u0004\u0012\u00020\u00030\u00012\u0014\b\u0006\u0010\u001a\u001a\u000e\u0012\u0004\u0012\u00020\r\u0012\u0004\u0012\u00020\u00030\u00012\u0014\b\u0006\u0010\u001b\u001a\u000e\u0012\u0004\u0012\u00020\u000b\u0012\u0004\u0012\u00020\u00030\u0001H\u0086\b\u001a\u0095\u0001\u0010\"\u001a\u00020\u0003\"\n\b\u0000\u0010\u0010\u0018\u0001*\u00020\t*\b\u0012\u0004\u0012\u00020\u001f0\u001d2\u0006\u0010 \u001a\u00020!2\u0014\b\u0006\u0010\u0017\u001a\u000e\u0012\u0004\u0012\u00020\u0002\u0012\u0004\u0012\u00020\u00030\u00012\u000e\b\u0006\u0010\u0018\u001a\b\u0012\u0004\u0012\u00020\u00030\u00052\u001a\b\u0006\u0010\u0019\u001a\u0014\u0012\n\u0012\b\u0012\u0004\u0012\u0002H\u00100#\u0012\u0004\u0012\u00020\u00030\u00012\u0014\b\u0006\u0010\u001a\u001a\u000e\u0012\u0004\u0012\u00020\r\u0012\u0004\u0012\u00020\u00030\u00012\u0014\b\u0006\u0010\u001b\u001a\u000e\u0012\u0004\u0012\u00020\u000b\u0012\u0004\u0012\u00020\u00030\u0001H\u0086\b\u001a\u0083\u0001\u0010$\u001a\u00020\u0003*\b\u0012\u0004\u0012\u00020\u001f0\u001d2\u0006\u0010 \u001a\u00020!2\u0014\b\u0006\u0010\u0017\u001a\u000e\u0012\u0004\u0012\u00020\u0002\u0012\u0004\u0012\u00020\u00030\u00012\u000e\b\u0006\u0010\u0018\u001a\b\u0012\u0004\u0012\u00020\u00030\u00052\u0014\b\u0006\u0010\u0019\u001a\u000e\u0012\u0004\u0012\u00020\u001f\u0012\u0004\u0012\u00020\u00030\u00012\u0014\b\u0006\u0010\u001a\u001a\u000e\u0012\u0004\u0012\u00020\r\u0012\u0004\u0012\u00020\u00030\u00012\u0014\b\u0006\u0010\u001b\u001a\u000e\u0012\u0004\u0012\u00020\u000b\u0012\u0004\u0012\u00020\u00030\u0001H\u0086\b\u001a!\u0010%\u001a\b\u0012\u0004\u0012\u0002H\u00100\u001d\"\u0006\b\u0000\u0010\u0010\u0018\u0001*\b\u0012\u0004\u0012\u00020\u001f0\u001dH\u0086\b\u001a1\u0010&\u001a\u0018\u0012\u0014\u0012\u0012\u0012\u0004\u0012\u0002H\u00100'j\b\u0012\u0004\u0012\u0002H\u0010`(0\u001d\"\u0006\b\u0000\u0010\u0010\u0018\u0001*\b\u0012\u0004\u0012\u00020\u001f0\u001dH\u0086\b\u001a\u0016\u0010)\u001a\b\u0012\u0004\u0012\u00020\u001f0\u001d*\b\u0012\u0004\u0012\u00020\u001f0\u001d\u001a$\u0010*\u001a\b\u0012\u0004\u0012\u0002H\u00100\u0016\"\u0004\b\u0000\u0010\u0010*\b\u0012\u0004\u0012\u0002H\u00100\u001d2\u0006\u0010+\u001a\u00020!\u001a)\u0010,\u001a\b\u0012\u0004\u0012\u0002H\u00100\u0016\"\u0006\b\u0000\u0010\u0010\u0018\u0001*\b\u0012\u0004\u0012\u00020\u001f0\u001d2\u0006\u0010+\u001a\u00020!H\u0086\b\u001a$\u0010-\u001a\b\u0012\u0004\u0012\u0002H\u00100\u0016\"\u0004\b\u0000\u0010\u0010*\b\u0012\u0004\u0012\u0002H\u00100\u001d2\u0006\u0010+\u001a\u00020!\u001a9\u0010.\u001a\u0018\u0012\u0014\u0012\u0012\u0012\u0004\u0012\u0002H\u00100'j\b\u0012\u0004\u0012\u0002H\u0010`(0\u0016\"\u0006\b\u0000\u0010\u0010\u0018\u0001*\b\u0012\u0004\u0012\u00020\u001f0\u001d2\u0006\u0010+\u001a\u00020!H\u0086\b\u001a\u001e\u0010/\u001a\b\u0012\u0004\u0012\u00020\u001f0\u0016*\b\u0012\u0004\u0012\u00020\u001f0\u001d2\u0006\u0010+\u001a\u00020!\u001a\u008f\u0001\u00100\u001a\u00020\u0003\"\n\b\u0000\u0010\u0010\u0018\u0001*\u00020\t*\b\u0012\u0004\u0012\u0002H\u00100\u001d2\u0006\u0010 \u001a\u00020!2\u0014\b\u0006\u0010\u0017\u001a\u000e\u0012\u0004\u0012\u00020\u0002\u0012\u0004\u0012\u00020\u00030\u00012\u000e\b\u0006\u0010\u0018\u001a\b\u0012\u0004\u0012\u00020\u00030\u00052\u0014\b\u0006\u0010\u0019\u001a\u000e\u0012\u0004\u0012\u0002H\u0010\u0012\u0004\u0012\u00020\u00030\u00012\u0014\b\u0006\u0010\u001a\u001a\u000e\u0012\u0004\u0012\u00020\r\u0012\u0004\u0012\u00020\u00030\u00012\u0014\b\u0006\u0010\u001b\u001a\u000e\u0012\u0004\u0012\u00020\u000b\u0012\u0004\u0012\u00020\u00030\u0001H\u0086\b\u001a\u008f\u0001\u00101\u001a\u00020\u0003\"\n\b\u0000\u0010\u0010\u0018\u0001*\u00020\t*\b\u0012\u0004\u0012\u0002H\u00100\u001d2\u0006\u0010 \u001a\u00020!2\u0014\b\u0006\u0010\u0017\u001a\u000e\u0012\u0004\u0012\u00020\u0002\u0012\u0004\u0012\u00020\u00030\u00012\u000e\b\u0006\u0010\u0018\u001a\b\u0012\u0004\u0012\u00020\u00030\u00052\u0014\b\u0006\u0010\u0019\u001a\u000e\u0012\u0004\u0012\u0002H\u0010\u0012\u0004\u0012\u00020\u00030\u00012\u0014\b\u0006\u0010\u001a\u001a\u000e\u0012\u0004\u0012\u00020\r\u0012\u0004\u0012\u00020\u00030\u00012\u0014\b\u0006\u0010\u001b\u001a\u000e\u0012\u0004\u0012\u00020\u000b\u0012\u0004\u0012\u00020\u00030\u0001H\u0086\b\"\u001a\u0010\u0000\u001a\u000e\u0012\u0004\u0012\u00020\u0002\u0012\u0004\u0012\u00020\u00030\u0001X\u0082\u0004¢\u0006\u0002\n\u0000\"\u0014\u0010\u0004\u001a\b\u0012\u0004\u0012\u00020\u00030\u0005X\u0082\u0004¢\u0006\u0002\n\u0000\"\u001a\u0010\u0006\u001a\u000e\u0012\u0004\u0012\u00020\u0007\u0012\u0004\u0012\u00020\u00030\u0001X\u0082\u0004¢\u0006\u0002\n\u0000\"\u001a\u0010\b\u001a\u000e\u0012\u0004\u0012\u00020\t\u0012\u0004\u0012\u00020\u00030\u0001X\u0082\u0004¢\u0006\u0002\n\u0000\"\u001a\u0010\n\u001a\u000e\u0012\u0004\u0012\u00020\u000b\u0012\u0004\u0012\u00020\u00030\u0001X\u0082\u0004¢\u0006\u0002\n\u0000\"\u001a\u0010\f\u001a\u000e\u0012\u0004\u0012\u00020\r\u0012\u0004\u0012\u00020\u00030\u0001X\u0082\u0004¢\u0006\u0002\n\u0000¨\u00062"}, d2 = {"onApiExceptionErrorStub", "Lkotlin/Function1;", "Lcom/tdo/showbox/http/ApiException;", "", "onCompleteStub", "Lkotlin/Function0;", "onErrorStub", "", "onNextStub", "", "onServerErrorStub", "Lcom/tdo/showbox/http/ServerException;", "onSubscribeStub", "Lio/reactivex/disposables/Disposable;", "asConsumer", "Lio/reactivex/functions/Consumer;", "T", "asOnCompleteAction", "Lio/reactivex/functions/Action;", "asOnErrorConsumer", "asOnSubscribe", "subscribeKt", "Lcom/uber/autodispose/ObservableSubscribeProxy;", "onError", "onComplete", "onSuccess", "onStart", "onServerError", "subscribeTo", "Lio/reactivex/Observable;", "subscribeToBean", "", "lifecycleOwner", "Landroidx/lifecycle/LifecycleOwner;", "subscribeToList", "", "subscribeToMsg", "toBean", "toLists", "Ljava/util/ArrayList;", "Lkotlin/collections/ArrayList;", "toMsg", "transform", "owner", "transformBean", "transformCompute", "transformList", "transformMsg", "transformSubscribe", "transformSubscribeCompute", "app_webRelease"}, k = 2, mv = {1, 1, 16})
/* loaded from: classes3.dex */
public final class RxSubscribersKt {
    private static final Function1<Object, Unit> onNextStub = RxSubscribersKt$onNextStub$1.INSTANCE;
    private static final Function1<Throwable, Unit> onErrorStub = RxSubscribersKt$onErrorStub$1.INSTANCE;
    private static final Function1<ApiException, Unit> onApiExceptionErrorStub = RxSubscribersKt$onApiExceptionErrorStub$1.INSTANCE;
    private static final Function0<Unit> onCompleteStub = RxSubscribersKt$onCompleteStub$1.INSTANCE;
    private static final Function1<Disposable, Unit> onSubscribeStub = RxSubscribersKt$onSubscribeStub$1.INSTANCE;
    private static final Function1<ServerException, Unit> onServerErrorStub = RxSubscribersKt$onServerErrorStub$1.INSTANCE;

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v1, types: [com.tdo.showbox.utils.RxSubscribersKt$sam$io_reactivex_functions_Consumer$0] */
    private static final <T> Consumer<T> asConsumer(Function1<? super T, Unit> function1) {
        if (function1 == onNextStub) {
            Consumer<T> emptyConsumer = Functions.emptyConsumer();
            Intrinsics.checkExpressionValueIsNotNull(emptyConsumer, "Functions.emptyConsumer()");
            return emptyConsumer;
        }
        if (function1 != null) {
            function1 = new RxSubscribersKt$sam$io_reactivex_functions_Consumer$0(function1);
        }
        return (Consumer) function1;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v0, types: [com.tdo.showbox.utils.RxSubscribersKt$sam$io_reactivex_functions_Consumer$0] */
    private static final Consumer<Throwable> asOnErrorConsumer(Function1<? super Throwable, Unit> function1) {
        if (function1 != null) {
            function1 = new RxSubscribersKt$sam$io_reactivex_functions_Consumer$0(function1);
        }
        return (Consumer) function1;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v1, types: [com.tdo.showbox.utils.RxSubscribersKt$sam$io_reactivex_functions_Action$0] */
    private static final Action asOnCompleteAction(final Function0<Unit> function0) {
        if (function0 == onCompleteStub) {
            Action action = Functions.EMPTY_ACTION;
            Intrinsics.checkExpressionValueIsNotNull(action, "Functions.EMPTY_ACTION");
            return action;
        }
        if (function0 != null) {
            function0 = new Action() { // from class: com.tdo.showbox.utils.RxSubscribersKt$sam$io_reactivex_functions_Action$0
                @Override // io.reactivex.functions.Action
                public final /* synthetic */ void run() {
                    Intrinsics.checkExpressionValueIsNotNull(Function0.this.mo1726invoke(), "invoke(...)");
                }
            };
        }
        return (Action) function0;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v0, types: [com.tdo.showbox.utils.RxSubscribersKt$sam$io_reactivex_functions_Consumer$0] */
    private static final Consumer<Disposable> asOnSubscribe(Function1<? super Disposable, Unit> function1) {
        if (function1 != null) {
            function1 = new RxSubscribersKt$sam$io_reactivex_functions_Consumer$0(function1);
        }
        return (Consumer) function1;
    }

    public static /* synthetic */ Disposable subscribeTo$default(Observable observable, Function1 function1, Function0 function0, Function1 function12, Function1 function13, int i, Object obj) {
        if ((i & 1) != 0) {
            function1 = onErrorStub;
        }
        if ((i & 2) != 0) {
            function0 = onCompleteStub;
        }
        if ((i & 4) != 0) {
            function12 = onSubscribeStub;
        }
        if ((i & 8) != 0) {
            function13 = onNextStub;
        }
        return subscribeTo(observable, function1, function0, function12, function13);
    }

    public static final <T> Disposable subscribeTo(Observable<T> subscribeTo, Function1<? super Throwable, Unit> onError, Function0<Unit> onComplete, Function1<? super Disposable, Unit> onStart, Function1<? super T, Unit> onSuccess) {
        Intrinsics.checkParameterIsNotNull(subscribeTo, "$this$subscribeTo");
        Intrinsics.checkParameterIsNotNull(onError, "onError");
        Intrinsics.checkParameterIsNotNull(onComplete, "onComplete");
        Intrinsics.checkParameterIsNotNull(onStart, "onStart");
        Intrinsics.checkParameterIsNotNull(onSuccess, "onSuccess");
        Disposable subscribe = subscribeTo.subscribe(asConsumer(onSuccess), asOnErrorConsumer(onError), asOnCompleteAction(onComplete), asOnSubscribe(onStart));
        Intrinsics.checkExpressionValueIsNotNull(subscribe, "subscribe(\n        onSuc… onStart.asOnSubscribe())");
        return subscribe;
    }

    public static /* synthetic */ Disposable subscribeTo$default(ObservableSubscribeProxy observableSubscribeProxy, Function1 function1, Function0 function0, Function1 function12, Function1 function13, Function1 function14, int i, Object obj) {
        if ((i & 1) != 0) {
            function1 = onApiExceptionErrorStub;
        }
        if ((i & 2) != 0) {
            function0 = onCompleteStub;
        }
        Function0 function02 = function0;
        if ((i & 4) != 0) {
            function12 = onSubscribeStub;
        }
        Function1 function15 = function12;
        if ((i & 8) != 0) {
            function13 = onServerErrorStub;
        }
        Function1 function16 = function13;
        if ((i & 16) != 0) {
            function14 = onNextStub;
        }
        return subscribeTo(observableSubscribeProxy, function1, function02, function15, function16, function14);
    }

    public static final <T> Disposable subscribeTo(ObservableSubscribeProxy<T> subscribeTo, final Function1<? super ApiException, Unit> onError, Function0<Unit> onComplete, Function1<? super Disposable, Unit> onStart, final Function1<? super ServerException, Unit> onServerError, Function1<? super T, Unit> onSuccess) {
        Intrinsics.checkParameterIsNotNull(subscribeTo, "$this$subscribeTo");
        Intrinsics.checkParameterIsNotNull(onError, "onError");
        Intrinsics.checkParameterIsNotNull(onComplete, "onComplete");
        Intrinsics.checkParameterIsNotNull(onStart, "onStart");
        Intrinsics.checkParameterIsNotNull(onServerError, "onServerError");
        Intrinsics.checkParameterIsNotNull(onSuccess, "onSuccess");
        Disposable subscribe = subscribeTo.subscribe(asConsumer(onSuccess), new Consumer<Throwable>() { // from class: com.tdo.showbox.utils.RxSubscribersKt$subscribeTo$1
            @Override // io.reactivex.functions.Consumer
            public final void accept(Throwable th) {
                Function1 function1 = Function1.this;
                ApiException handleException = ApiException.handleException(th);
                Intrinsics.checkExpressionValueIsNotNull(handleException, "ApiException.handleException(it)");
                function1.mo1719invoke(handleException);
                if (th instanceof ServerException) {
                    onServerError.mo1719invoke(th);
                }
            }
        }, asOnCompleteAction(onComplete), asOnSubscribe(onStart));
        Intrinsics.checkExpressionValueIsNotNull(subscribe, "subscribe(\n        onSuc…onStart.asOnSubscribe()\n)");
        return subscribe;
    }

    public static final ObservableSubscribeProxy<String> transformMsg(Observable<String> transformMsg, LifecycleOwner owner) {
        Intrinsics.checkParameterIsNotNull(transformMsg, "$this$transformMsg");
        Intrinsics.checkParameterIsNotNull(owner, "owner");
        return transform(toMsg(transformMsg), owner);
    }

    public static final <T> ObservableSubscribeProxy<T> transform(Observable<T> transform, LifecycleOwner owner) {
        Intrinsics.checkParameterIsNotNull(transform, "$this$transform");
        Intrinsics.checkParameterIsNotNull(owner, "owner");
        Object as = transform.compose(RxUtils.rxSchedulerHelper()).as(RxUtils.bindLifecycleOwner(owner));
        Intrinsics.checkExpressionValueIsNotNull(as, "this.compose(RxUtils.rxS…indLifecycleOwner(owner))");
        return (ObservableSubscribeProxy) as;
    }

    public static final <T> ObservableSubscribeProxy<T> transformCompute(Observable<T> transformCompute, LifecycleOwner owner) {
        Intrinsics.checkParameterIsNotNull(transformCompute, "$this$transformCompute");
        Intrinsics.checkParameterIsNotNull(owner, "owner");
        Object as = transformCompute.compose(RxUtils.rxSchedulerComputeHelper()).as(RxUtils.bindLifecycleOwner(owner));
        Intrinsics.checkExpressionValueIsNotNull(as, "this.compose(RxUtils.rxS…indLifecycleOwner(owner))");
        return (ObservableSubscribeProxy) as;
    }

    public static final /* synthetic */ <T> Observable<T> toBean(Observable<String> toBean) {
        Intrinsics.checkParameterIsNotNull(toBean, "$this$toBean");
        Intrinsics.reifiedOperationMarker(4, "T");
        Observable<T> observable = (Observable<T>) toBean.compose(RxUtils.rxTranslate2Bean(Object.class));
        Intrinsics.checkExpressionValueIsNotNull(observable, "this.compose(RxUtils.rxT…late2Bean(T::class.java))");
        return observable;
    }

    public static final /* synthetic */ <T> Observable<ArrayList<T>> toLists(Observable<String> toLists) {
        Intrinsics.checkParameterIsNotNull(toLists, "$this$toLists");
        Intrinsics.reifiedOperationMarker(4, "T");
        Observable<ArrayList<T>> observable = (Observable<ArrayList<T>>) toLists.compose(RxUtils.rxTranslate2List(Object.class));
        Intrinsics.checkExpressionValueIsNotNull(observable, "this.compose(RxUtils.rxT…late2List(T::class.java))");
        return observable;
    }

    public static final Observable<String> toMsg(Observable<String> toMsg) {
        Intrinsics.checkParameterIsNotNull(toMsg, "$this$toMsg");
        Observable compose = toMsg.compose(RxUtils.rxTranslateMsg());
        Intrinsics.checkExpressionValueIsNotNull(compose, "this.compose(RxUtils.rxTranslateMsg())");
        return compose;
    }

    public static /* synthetic */ void subscribeKt$default(ObservableSubscribeProxy subscribeKt, Function1 onError, Function0 onComplete, Function1 onSuccess, Function1 onStart, Function1 onServerError, int i, Object obj) {
        if ((i & 1) != 0) {
            onError = RxSubscribersKt$subscribeKt$1.INSTANCE;
        }
        if ((i & 2) != 0) {
            onComplete = RxSubscribersKt$subscribeKt$2.INSTANCE;
        }
        if ((i & 4) != 0) {
            onSuccess = RxSubscribersKt$subscribeKt$3.INSTANCE;
        }
        if ((i & 8) != 0) {
            onStart = RxSubscribersKt$subscribeKt$4.INSTANCE;
        }
        if ((i & 16) != 0) {
            onServerError = RxSubscribersKt$subscribeKt$5.INSTANCE;
        }
        Intrinsics.checkParameterIsNotNull(subscribeKt, "$this$subscribeKt");
        Intrinsics.checkParameterIsNotNull(onError, "onError");
        Intrinsics.checkParameterIsNotNull(onComplete, "onComplete");
        Intrinsics.checkParameterIsNotNull(onSuccess, "onSuccess");
        Intrinsics.checkParameterIsNotNull(onStart, "onStart");
        Intrinsics.checkParameterIsNotNull(onServerError, "onServerError");
        subscribeKt.subscribe(new RxSubscribersKt$subscribeKt$6(onSuccess), new RxSubscribersKt$subscribeKt$7(onError, onServerError), new RxSubscribersKt$subscribeKt$8(onComplete), new RxSubscribersKt$subscribeKt$9(onStart));
    }

    public static final /* synthetic */ <T> void subscribeKt(ObservableSubscribeProxy<T> subscribeKt, Function1<? super ApiException, Unit> onError, Function0<Unit> onComplete, Function1<? super T, Unit> onSuccess, Function1<? super Disposable, Unit> onStart, Function1<? super ServerException, Unit> onServerError) {
        Intrinsics.checkParameterIsNotNull(subscribeKt, "$this$subscribeKt");
        Intrinsics.checkParameterIsNotNull(onError, "onError");
        Intrinsics.checkParameterIsNotNull(onComplete, "onComplete");
        Intrinsics.checkParameterIsNotNull(onSuccess, "onSuccess");
        Intrinsics.checkParameterIsNotNull(onStart, "onStart");
        Intrinsics.checkParameterIsNotNull(onServerError, "onServerError");
        subscribeKt.subscribe(new RxSubscribersKt$subscribeKt$6(onSuccess), new RxSubscribersKt$subscribeKt$7(onError, onServerError), new RxSubscribersKt$subscribeKt$8(onComplete), new RxSubscribersKt$subscribeKt$9(onStart));
    }

    public static /* synthetic */ void subscribeToBean$default(Observable subscribeToBean, LifecycleOwner lifecycleOwner, Function1 onError, Function0 onComplete, Function1 onSuccess, Function1 onStart, Function1 onServerError, int i, Object obj) {
        if ((i & 2) != 0) {
            onError = RxSubscribersKt$subscribeToBean$1.INSTANCE;
        }
        if ((i & 4) != 0) {
            onComplete = RxSubscribersKt$subscribeToBean$2.INSTANCE;
        }
        if ((i & 8) != 0) {
            onSuccess = RxSubscribersKt$subscribeToBean$3.INSTANCE;
        }
        if ((i & 16) != 0) {
            onStart = RxSubscribersKt$subscribeToBean$4.INSTANCE;
        }
        if ((i & 32) != 0) {
            onServerError = RxSubscribersKt$subscribeToBean$5.INSTANCE;
        }
        Intrinsics.checkParameterIsNotNull(subscribeToBean, "$this$subscribeToBean");
        Intrinsics.checkParameterIsNotNull(lifecycleOwner, "lifecycleOwner");
        Intrinsics.checkParameterIsNotNull(onError, "onError");
        Intrinsics.checkParameterIsNotNull(onComplete, "onComplete");
        Intrinsics.checkParameterIsNotNull(onSuccess, "onSuccess");
        Intrinsics.checkParameterIsNotNull(onStart, "onStart");
        Intrinsics.checkParameterIsNotNull(onServerError, "onServerError");
        Intrinsics.reifiedOperationMarker(4, "T");
        Observable compose = subscribeToBean.compose(RxUtils.rxTranslate2Bean(Object.class));
        Intrinsics.checkExpressionValueIsNotNull(compose, "this.compose(RxUtils.rxT…late2Bean(T::class.java))");
        transform(compose, lifecycleOwner).subscribe(new RxSubscribersKt$subscribeKt$6(onSuccess), new RxSubscribersKt$subscribeKt$7(onError, onServerError), new RxSubscribersKt$subscribeKt$8(onComplete), new RxSubscribersKt$subscribeKt$9(onStart));
    }

    public static /* synthetic */ void subscribeToList$default(Observable subscribeToList, LifecycleOwner lifecycleOwner, Function1 onError, Function0 onComplete, Function1 onSuccess, Function1 onStart, Function1 onServerError, int i, Object obj) {
        if ((i & 2) != 0) {
            onError = RxSubscribersKt$subscribeToList$1.INSTANCE;
        }
        if ((i & 4) != 0) {
            onComplete = RxSubscribersKt$subscribeToList$2.INSTANCE;
        }
        if ((i & 8) != 0) {
            onSuccess = RxSubscribersKt$subscribeToList$3.INSTANCE;
        }
        if ((i & 16) != 0) {
            onStart = RxSubscribersKt$subscribeToList$4.INSTANCE;
        }
        if ((i & 32) != 0) {
            onServerError = RxSubscribersKt$subscribeToList$5.INSTANCE;
        }
        Intrinsics.checkParameterIsNotNull(subscribeToList, "$this$subscribeToList");
        Intrinsics.checkParameterIsNotNull(lifecycleOwner, "lifecycleOwner");
        Intrinsics.checkParameterIsNotNull(onError, "onError");
        Intrinsics.checkParameterIsNotNull(onComplete, "onComplete");
        Intrinsics.checkParameterIsNotNull(onSuccess, "onSuccess");
        Intrinsics.checkParameterIsNotNull(onStart, "onStart");
        Intrinsics.checkParameterIsNotNull(onServerError, "onServerError");
        Intrinsics.reifiedOperationMarker(4, "T");
        Observable compose = subscribeToList.compose(RxUtils.rxTranslate2List(Object.class));
        Intrinsics.checkExpressionValueIsNotNull(compose, "this.compose(RxUtils.rxT…late2List(T::class.java))");
        transform(compose, lifecycleOwner).subscribe(new RxSubscribersKt$subscribeKt$6(onSuccess), new RxSubscribersKt$subscribeKt$7(onError, onServerError), new RxSubscribersKt$subscribeKt$8(onComplete), new RxSubscribersKt$subscribeKt$9(onStart));
    }

    public static /* synthetic */ void subscribeToMsg$default(Observable subscribeToMsg, LifecycleOwner lifecycleOwner, Function1 onError, Function0 onComplete, Function1 onSuccess, Function1 onStart, Function1 onServerError, int i, Object obj) {
        if ((i & 2) != 0) {
            onError = RxSubscribersKt$subscribeToMsg$1.INSTANCE;
        }
        if ((i & 4) != 0) {
            onComplete = RxSubscribersKt$subscribeToMsg$2.INSTANCE;
        }
        if ((i & 8) != 0) {
            onSuccess = RxSubscribersKt$subscribeToMsg$3.INSTANCE;
        }
        if ((i & 16) != 0) {
            onStart = RxSubscribersKt$subscribeToMsg$4.INSTANCE;
        }
        if ((i & 32) != 0) {
            onServerError = RxSubscribersKt$subscribeToMsg$5.INSTANCE;
        }
        Intrinsics.checkParameterIsNotNull(subscribeToMsg, "$this$subscribeToMsg");
        Intrinsics.checkParameterIsNotNull(lifecycleOwner, "lifecycleOwner");
        Intrinsics.checkParameterIsNotNull(onError, "onError");
        Intrinsics.checkParameterIsNotNull(onComplete, "onComplete");
        Intrinsics.checkParameterIsNotNull(onSuccess, "onSuccess");
        Intrinsics.checkParameterIsNotNull(onStart, "onStart");
        Intrinsics.checkParameterIsNotNull(onServerError, "onServerError");
        transformMsg(subscribeToMsg, lifecycleOwner).subscribe(new RxSubscribersKt$subscribeKt$6(onSuccess), new RxSubscribersKt$subscribeKt$7(onError, onServerError), new RxSubscribersKt$subscribeKt$8(onComplete), new RxSubscribersKt$subscribeKt$9(onStart));
    }

    public static final void subscribeToMsg(Observable<String> subscribeToMsg, LifecycleOwner lifecycleOwner, Function1<? super ApiException, Unit> onError, Function0<Unit> onComplete, Function1<? super String, Unit> onSuccess, Function1<? super Disposable, Unit> onStart, Function1<? super ServerException, Unit> onServerError) {
        Intrinsics.checkParameterIsNotNull(subscribeToMsg, "$this$subscribeToMsg");
        Intrinsics.checkParameterIsNotNull(lifecycleOwner, "lifecycleOwner");
        Intrinsics.checkParameterIsNotNull(onError, "onError");
        Intrinsics.checkParameterIsNotNull(onComplete, "onComplete");
        Intrinsics.checkParameterIsNotNull(onSuccess, "onSuccess");
        Intrinsics.checkParameterIsNotNull(onStart, "onStart");
        Intrinsics.checkParameterIsNotNull(onServerError, "onServerError");
        transformMsg(subscribeToMsg, lifecycleOwner).subscribe(new RxSubscribersKt$subscribeKt$6(onSuccess), new RxSubscribersKt$subscribeKt$7(onError, onServerError), new RxSubscribersKt$subscribeKt$8(onComplete), new RxSubscribersKt$subscribeKt$9(onStart));
    }

    public static /* synthetic */ void transformSubscribe$default(Observable transformSubscribe, LifecycleOwner lifecycleOwner, Function1 onError, Function0 onComplete, Function1 onSuccess, Function1 onStart, Function1 onServerError, int i, Object obj) {
        if ((i & 2) != 0) {
            onError = RxSubscribersKt$transformSubscribe$1.INSTANCE;
        }
        if ((i & 4) != 0) {
            onComplete = RxSubscribersKt$transformSubscribe$2.INSTANCE;
        }
        if ((i & 8) != 0) {
            onSuccess = RxSubscribersKt$transformSubscribe$3.INSTANCE;
        }
        if ((i & 16) != 0) {
            onStart = RxSubscribersKt$transformSubscribe$4.INSTANCE;
        }
        if ((i & 32) != 0) {
            onServerError = RxSubscribersKt$transformSubscribe$5.INSTANCE;
        }
        Intrinsics.checkParameterIsNotNull(transformSubscribe, "$this$transformSubscribe");
        Intrinsics.checkParameterIsNotNull(lifecycleOwner, "lifecycleOwner");
        Intrinsics.checkParameterIsNotNull(onError, "onError");
        Intrinsics.checkParameterIsNotNull(onComplete, "onComplete");
        Intrinsics.checkParameterIsNotNull(onSuccess, "onSuccess");
        Intrinsics.checkParameterIsNotNull(onStart, "onStart");
        Intrinsics.checkParameterIsNotNull(onServerError, "onServerError");
        transform(transformSubscribe, lifecycleOwner).subscribe(new RxSubscribersKt$subscribeKt$6(onSuccess), new RxSubscribersKt$subscribeKt$7(onError, onServerError), new RxSubscribersKt$subscribeKt$8(onComplete), new RxSubscribersKt$subscribeKt$9(onStart));
    }

    public static final /* synthetic */ <T> void transformSubscribe(Observable<T> transformSubscribe, LifecycleOwner lifecycleOwner, Function1<? super ApiException, Unit> onError, Function0<Unit> onComplete, Function1<? super T, Unit> onSuccess, Function1<? super Disposable, Unit> onStart, Function1<? super ServerException, Unit> onServerError) {
        Intrinsics.checkParameterIsNotNull(transformSubscribe, "$this$transformSubscribe");
        Intrinsics.checkParameterIsNotNull(lifecycleOwner, "lifecycleOwner");
        Intrinsics.checkParameterIsNotNull(onError, "onError");
        Intrinsics.checkParameterIsNotNull(onComplete, "onComplete");
        Intrinsics.checkParameterIsNotNull(onSuccess, "onSuccess");
        Intrinsics.checkParameterIsNotNull(onStart, "onStart");
        Intrinsics.checkParameterIsNotNull(onServerError, "onServerError");
        transform(transformSubscribe, lifecycleOwner).subscribe(new RxSubscribersKt$subscribeKt$6(onSuccess), new RxSubscribersKt$subscribeKt$7(onError, onServerError), new RxSubscribersKt$subscribeKt$8(onComplete), new RxSubscribersKt$subscribeKt$9(onStart));
    }

    public static /* synthetic */ void transformSubscribeCompute$default(Observable transformSubscribeCompute, LifecycleOwner lifecycleOwner, Function1 onError, Function0 onComplete, Function1 onSuccess, Function1 onStart, Function1 onServerError, int i, Object obj) {
        if ((i & 2) != 0) {
            onError = RxSubscribersKt$transformSubscribeCompute$1.INSTANCE;
        }
        if ((i & 4) != 0) {
            onComplete = RxSubscribersKt$transformSubscribeCompute$2.INSTANCE;
        }
        if ((i & 8) != 0) {
            onSuccess = RxSubscribersKt$transformSubscribeCompute$3.INSTANCE;
        }
        if ((i & 16) != 0) {
            onStart = RxSubscribersKt$transformSubscribeCompute$4.INSTANCE;
        }
        if ((i & 32) != 0) {
            onServerError = RxSubscribersKt$transformSubscribeCompute$5.INSTANCE;
        }
        Intrinsics.checkParameterIsNotNull(transformSubscribeCompute, "$this$transformSubscribeCompute");
        Intrinsics.checkParameterIsNotNull(lifecycleOwner, "lifecycleOwner");
        Intrinsics.checkParameterIsNotNull(onError, "onError");
        Intrinsics.checkParameterIsNotNull(onComplete, "onComplete");
        Intrinsics.checkParameterIsNotNull(onSuccess, "onSuccess");
        Intrinsics.checkParameterIsNotNull(onStart, "onStart");
        Intrinsics.checkParameterIsNotNull(onServerError, "onServerError");
        transformCompute(transformSubscribeCompute, lifecycleOwner).subscribe(new RxSubscribersKt$subscribeKt$6(onSuccess), new RxSubscribersKt$subscribeKt$7(onError, onServerError), new RxSubscribersKt$subscribeKt$8(onComplete), new RxSubscribersKt$subscribeKt$9(onStart));
    }

    public static final /* synthetic */ <T> void transformSubscribeCompute(Observable<T> transformSubscribeCompute, LifecycleOwner lifecycleOwner, Function1<? super ApiException, Unit> onError, Function0<Unit> onComplete, Function1<? super T, Unit> onSuccess, Function1<? super Disposable, Unit> onStart, Function1<? super ServerException, Unit> onServerError) {
        Intrinsics.checkParameterIsNotNull(transformSubscribeCompute, "$this$transformSubscribeCompute");
        Intrinsics.checkParameterIsNotNull(lifecycleOwner, "lifecycleOwner");
        Intrinsics.checkParameterIsNotNull(onError, "onError");
        Intrinsics.checkParameterIsNotNull(onComplete, "onComplete");
        Intrinsics.checkParameterIsNotNull(onSuccess, "onSuccess");
        Intrinsics.checkParameterIsNotNull(onStart, "onStart");
        Intrinsics.checkParameterIsNotNull(onServerError, "onServerError");
        transformCompute(transformSubscribeCompute, lifecycleOwner).subscribe(new RxSubscribersKt$subscribeKt$6(onSuccess), new RxSubscribersKt$subscribeKt$7(onError, onServerError), new RxSubscribersKt$subscribeKt$8(onComplete), new RxSubscribersKt$subscribeKt$9(onStart));
    }

    public static final /* synthetic */ <T> ObservableSubscribeProxy<T> transformBean(Observable<String> transformBean, LifecycleOwner owner) {
        Intrinsics.checkParameterIsNotNull(transformBean, "$this$transformBean");
        Intrinsics.checkParameterIsNotNull(owner, "owner");
        Intrinsics.reifiedOperationMarker(4, "T");
        Observable<R> compose = transformBean.compose(RxUtils.rxTranslate2Bean(Object.class));
        Intrinsics.checkExpressionValueIsNotNull(compose, "this.compose(RxUtils.rxT…late2Bean(T::class.java))");
        return transform(compose, owner);
    }

    public static final /* synthetic */ <T> ObservableSubscribeProxy<ArrayList<T>> transformList(Observable<String> transformList, LifecycleOwner owner) {
        Intrinsics.checkParameterIsNotNull(transformList, "$this$transformList");
        Intrinsics.checkParameterIsNotNull(owner, "owner");
        Intrinsics.reifiedOperationMarker(4, "T");
        Observable<R> compose = transformList.compose(RxUtils.rxTranslate2List(Object.class));
        Intrinsics.checkExpressionValueIsNotNull(compose, "this.compose(RxUtils.rxT…late2List(T::class.java))");
        return transform(compose, owner);
    }

    public static final /* synthetic */ <T> void subscribeToBean(Observable<String> subscribeToBean, LifecycleOwner lifecycleOwner, Function1<? super ApiException, Unit> onError, Function0<Unit> onComplete, Function1<? super T, Unit> onSuccess, Function1<? super Disposable, Unit> onStart, Function1<? super ServerException, Unit> onServerError) {
        Intrinsics.checkParameterIsNotNull(subscribeToBean, "$this$subscribeToBean");
        Intrinsics.checkParameterIsNotNull(lifecycleOwner, "lifecycleOwner");
        Intrinsics.checkParameterIsNotNull(onError, "onError");
        Intrinsics.checkParameterIsNotNull(onComplete, "onComplete");
        Intrinsics.checkParameterIsNotNull(onSuccess, "onSuccess");
        Intrinsics.checkParameterIsNotNull(onStart, "onStart");
        Intrinsics.checkParameterIsNotNull(onServerError, "onServerError");
        Intrinsics.reifiedOperationMarker(4, "T");
        Observable<R> compose = subscribeToBean.compose(RxUtils.rxTranslate2Bean(Object.class));
        Intrinsics.checkExpressionValueIsNotNull(compose, "this.compose(RxUtils.rxT…late2Bean(T::class.java))");
        transform(compose, lifecycleOwner).subscribe(new RxSubscribersKt$subscribeKt$6(onSuccess), new RxSubscribersKt$subscribeKt$7(onError, onServerError), new RxSubscribersKt$subscribeKt$8(onComplete), new RxSubscribersKt$subscribeKt$9(onStart));
    }

    public static final /* synthetic */ <T> void subscribeToList(Observable<String> subscribeToList, LifecycleOwner lifecycleOwner, Function1<? super ApiException, Unit> onError, Function0<Unit> onComplete, Function1<? super List<? extends T>, Unit> onSuccess, Function1<? super Disposable, Unit> onStart, Function1<? super ServerException, Unit> onServerError) {
        Intrinsics.checkParameterIsNotNull(subscribeToList, "$this$subscribeToList");
        Intrinsics.checkParameterIsNotNull(lifecycleOwner, "lifecycleOwner");
        Intrinsics.checkParameterIsNotNull(onError, "onError");
        Intrinsics.checkParameterIsNotNull(onComplete, "onComplete");
        Intrinsics.checkParameterIsNotNull(onSuccess, "onSuccess");
        Intrinsics.checkParameterIsNotNull(onStart, "onStart");
        Intrinsics.checkParameterIsNotNull(onServerError, "onServerError");
        Intrinsics.reifiedOperationMarker(4, "T");
        Observable<R> compose = subscribeToList.compose(RxUtils.rxTranslate2List(Object.class));
        Intrinsics.checkExpressionValueIsNotNull(compose, "this.compose(RxUtils.rxT…late2List(T::class.java))");
        transform(compose, lifecycleOwner).subscribe(new RxSubscribersKt$subscribeKt$6(onSuccess), new RxSubscribersKt$subscribeKt$7(onError, onServerError), new RxSubscribersKt$subscribeKt$8(onComplete), new RxSubscribersKt$subscribeKt$9(onStart));
    }
}
