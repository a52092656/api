package com.tdo.showbox.utils.unrar.io;

import kotlin.UByte;
/* loaded from: classes3.dex */
public class Raw {
    public static final short readShortBigEndian(byte[] bArr, int i) {
        return (short) ((bArr[i + 1] & UByte.MAX_VALUE) | ((short) (((short) ((bArr[i] & UByte.MAX_VALUE) | 0)) << 8)));
    }

    public static final int readIntBigEndian(byte[] bArr, int i) {
        return (bArr[i + 3] & UByte.MAX_VALUE) | (((((((bArr[i] & UByte.MAX_VALUE) | 0) << 8) | (bArr[i + 1] & UByte.MAX_VALUE)) << 8) | (bArr[i + 2] & UByte.MAX_VALUE)) << 8);
    }

    public static final long readLongBigEndian(byte[] bArr, int i) {
        return (bArr[i + 7] & UByte.MAX_VALUE) | (((((((((((((((bArr[i] & UByte.MAX_VALUE) | 0) << 8) | (bArr[i + 1] & UByte.MAX_VALUE)) << 8) | (bArr[i + 2] & UByte.MAX_VALUE)) << 8) | (bArr[i + 3] & UByte.MAX_VALUE)) << 8) | (bArr[i + 4] & UByte.MAX_VALUE)) << 8) | (bArr[i + 5] & UByte.MAX_VALUE)) << 8) | (bArr[i + 6] & UByte.MAX_VALUE)) << 8);
    }

    public static final short readShortLittleEndian(byte[] bArr, int i) {
        return (short) (((short) (((short) ((bArr[i + 1] & UByte.MAX_VALUE) + 0)) << 8)) + (bArr[i] & UByte.MAX_VALUE));
    }

    public static final int readIntLittleEndian(byte[] bArr, int i) {
        return (bArr[i] & UByte.MAX_VALUE) | ((bArr[i + 3] & UByte.MAX_VALUE) << 24) | ((bArr[i + 2] & UByte.MAX_VALUE) << 16) | ((bArr[i + 1] & UByte.MAX_VALUE) << 8);
    }

    public static final long readIntLittleEndianAsLong(byte[] bArr, int i) {
        return (bArr[i] & 255) | ((bArr[i + 3] & 255) << 24) | ((bArr[i + 2] & 255) << 16) | ((bArr[i + 1] & 255) << 8);
    }

    public static final long readLongLittleEndian(byte[] bArr, int i) {
        return bArr[i] | (((((((((((((((bArr[i + 7] & UByte.MAX_VALUE) | 0) << 8) | (bArr[i + 6] & UByte.MAX_VALUE)) << 8) | (bArr[i + 5] & UByte.MAX_VALUE)) << 8) | (bArr[i + 4] & UByte.MAX_VALUE)) << 8) | (bArr[i + 3] & UByte.MAX_VALUE)) << 8) | (bArr[i + 2] & UByte.MAX_VALUE)) << 8) | (bArr[i + 1] & UByte.MAX_VALUE)) << 8);
    }

    public static final void writeShortBigEndian(byte[] bArr, int i, short s) {
        bArr[i] = (byte) (s >>> 8);
        bArr[i + 1] = (byte) (s & 255);
    }

    public static final void writeIntBigEndian(byte[] bArr, int i, int i2) {
        bArr[i] = (byte) ((i2 >>> 24) & 255);
        bArr[i + 1] = (byte) ((i2 >>> 16) & 255);
        bArr[i + 2] = (byte) ((i2 >>> 8) & 255);
        bArr[i + 3] = (byte) (i2 & 255);
    }

    public static final void writeLongBigEndian(byte[] bArr, int i, long j) {
        bArr[i] = (byte) (j >>> 56);
        bArr[i + 1] = (byte) (j >>> 48);
        bArr[i + 2] = (byte) (j >>> 40);
        bArr[i + 3] = (byte) (j >>> 32);
        bArr[i + 4] = (byte) (j >>> 24);
        bArr[i + 5] = (byte) (j >>> 16);
        bArr[i + 6] = (byte) (j >>> 8);
        bArr[i + 7] = (byte) (j & 255);
    }

    public static final void writeShortLittleEndian(byte[] bArr, int i, short s) {
        bArr[i + 1] = (byte) (s >>> 8);
        bArr[i] = (byte) (s & 255);
    }

    public static final void incShortLittleEndian(byte[] bArr, int i, int i2) {
        int i3 = i2 & 255;
        int i4 = ((bArr[i] & 255) + i3) >>> 8;
        bArr[i] = (byte) (bArr[i] + i3);
        if (i4 > 0 || (65280 & i2) != 0) {
            int i5 = i + 1;
            bArr[i5] = (byte) (bArr[i5] + ((i2 >>> 8) & 255) + i4);
        }
    }

    public static final void writeIntLittleEndian(byte[] bArr, int i, int i2) {
        bArr[i + 3] = (byte) (i2 >>> 24);
        bArr[i + 2] = (byte) (i2 >>> 16);
        bArr[i + 1] = (byte) (i2 >>> 8);
        bArr[i] = (byte) (i2 & 255);
    }

    public static final void writeLongLittleEndian(byte[] bArr, int i, long j) {
        bArr[i + 7] = (byte) (j >>> 56);
        bArr[i + 6] = (byte) (j >>> 48);
        bArr[i + 5] = (byte) (j >>> 40);
        bArr[i + 4] = (byte) (j >>> 32);
        bArr[i + 3] = (byte) (j >>> 24);
        bArr[i + 2] = (byte) (j >>> 16);
        bArr[i + 1] = (byte) (j >>> 8);
        bArr[i] = (byte) (j & 255);
    }
}
