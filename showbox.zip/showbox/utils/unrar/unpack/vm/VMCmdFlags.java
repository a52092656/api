package com.tdo.showbox.utils.unrar.unpack.vm;

import com.hpplay.common.palycontrol.ControlType;
/* loaded from: classes3.dex */
public class VMCmdFlags {
    public static final byte VMCF_BYTEMODE = 4;
    public static final byte VMCF_CHFLAGS = 64;
    public static final byte VMCF_JUMP = 8;
    public static final byte VMCF_OP0 = 0;
    public static final byte VMCF_OP1 = 1;
    public static final byte VMCF_OP2 = 2;
    public static final byte VMCF_OPMASK = 3;
    public static final byte VMCF_PROC = 16;
    public static final byte VMCF_USEFLAGS = 32;
    public static byte[] VM_CmdFlags = {6, ControlType.te_send_state_mute, ControlType.te_send_state_mute, ControlType.te_send_state_mute, ControlType.te_receive_language_getting, ControlType.te_receive_language_getting, ControlType.te_send_state_volume, ControlType.te_send_state_volume, 9, ControlType.te_send_state_mute, ControlType.te_send_state_mute, ControlType.te_send_state_mute, ControlType.te_send_state_mute, ControlType.te_receive_language_getting, ControlType.te_receive_language_getting, ControlType.te_receive_language_getting, ControlType.te_receive_language_getting, ControlType.te_receive_language_getting, ControlType.te_receive_language_getting, 1, 1, ControlType.te_receive_get_film_name, 16, 5, ControlType.te_send_state_mute, ControlType.te_send_state_mute, ControlType.te_send_state_mute, ControlType.te_send_state_volume, 0, 0, 32, 64, 2, 2, 6, 6, 6, 102, 102, 0};
}
