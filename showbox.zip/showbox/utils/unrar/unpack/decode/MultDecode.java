package com.tdo.showbox.utils.unrar.unpack.decode;
/* loaded from: classes3.dex */
public class MultDecode extends Decode {
    public MultDecode() {
        this.decodeNum = new int[257];
    }
}
