package com.tdo.showbox.utils.unrar.unpack.decode;
/* loaded from: classes3.dex */
public class BitDecode extends Decode {
    public BitDecode() {
        this.decodeNum = new int[20];
    }
}
