package com.tdo.showbox.utils.unrar.unpack.decode;
/* loaded from: classes3.dex */
public class LowDistDecode extends Decode {
    public LowDistDecode() {
        this.decodeNum = new int[17];
    }
}
