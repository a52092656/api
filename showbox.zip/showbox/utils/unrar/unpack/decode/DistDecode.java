package com.tdo.showbox.utils.unrar.unpack.decode;
/* loaded from: classes3.dex */
public class DistDecode extends Decode {
    public DistDecode() {
        this.decodeNum = new int[60];
    }
}
