package com.tdo.showbox.utils.unrar.unpack.decode;
/* loaded from: classes3.dex */
public class RepDecode extends Decode {
    public RepDecode() {
        this.decodeNum = new int[28];
    }
}
