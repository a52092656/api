package com.tdo.showbox.utils.unrar.unpack.decode;
/* loaded from: classes3.dex */
public class LitDecode extends Decode {
    public LitDecode() {
        this.decodeNum = new int[Compress.NC];
    }
}
