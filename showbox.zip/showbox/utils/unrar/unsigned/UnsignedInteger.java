package com.tdo.showbox.utils.unrar.unsigned;
/* loaded from: classes3.dex */
public class UnsignedInteger {
}
