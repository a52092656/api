package com.tdo.showbox.utils.unrar.rarfile;

import com.tdo.showbox.utils.unrar.io.Raw;
import kotlin.UByte;
/* loaded from: classes3.dex */
public class ProtectHeader extends BlockHeader {
    public static final int protectHeaderSize = 8;
    private byte mark;
    private short recSectors;
    private int totalBlocks;
    private byte version;

    public ProtectHeader(BlockHeader blockHeader, byte[] bArr) {
        super(blockHeader);
        this.version = (byte) (this.version | (bArr[0] & UByte.MAX_VALUE));
        this.recSectors = Raw.readShortLittleEndian(bArr, 0);
        this.totalBlocks = Raw.readIntLittleEndian(bArr, 2);
        this.mark = (byte) (this.mark | (bArr[6] & UByte.MAX_VALUE));
    }

    public byte getMark() {
        return this.mark;
    }

    public short getRecSectors() {
        return this.recSectors;
    }

    public int getTotalBlocks() {
        return this.totalBlocks;
    }

    public byte getVersion() {
        return this.version;
    }
}
