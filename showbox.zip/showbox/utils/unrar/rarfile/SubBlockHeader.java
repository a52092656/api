package com.tdo.showbox.utils.unrar.rarfile;

import com.tdo.showbox.utils.unrar.io.Raw;
import java.io.PrintStream;
import kotlin.UByte;
/* loaded from: classes3.dex */
public class SubBlockHeader extends BlockHeader {
    public static final short SubBlockHeaderSize = 3;
    private byte level;
    private short subType;

    public SubBlockHeader(SubBlockHeader subBlockHeader) {
        super(subBlockHeader);
        this.subType = subBlockHeader.getSubType().getSubblocktype();
        this.level = subBlockHeader.getLevel();
    }

    public SubBlockHeader(BlockHeader blockHeader, byte[] bArr) {
        super(blockHeader);
        this.subType = Raw.readShortLittleEndian(bArr, 0);
        this.level = (byte) (this.level | (bArr[2] & UByte.MAX_VALUE));
    }

    public byte getLevel() {
        return this.level;
    }

    public SubBlockHeaderType getSubType() {
        return SubBlockHeaderType.findSubblockHeaderType(this.subType);
    }

    @Override // com.tdo.showbox.utils.unrar.rarfile.BlockHeader, com.tdo.showbox.utils.unrar.rarfile.BaseBlock
    public void print() {
        super.print();
        PrintStream printStream = System.out;
        printStream.print("subtype: " + getSubType());
        PrintStream printStream2 = System.out;
        printStream2.print("level: " + ((int) this.level));
    }
}
