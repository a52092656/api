package com.tdo.showbox.utils.unrar.rarfile;

import com.hpplay.common.palycontrol.ControlType;
import java.util.Arrays;
/* loaded from: classes3.dex */
public class NewSubHeaderType {
    private byte[] headerTypes;
    public static final NewSubHeaderType SUBHEAD_TYPE_CMT = new NewSubHeaderType(new byte[]{ControlType.te_send_state_stop, ControlType.te_send_state_play_state, ControlType.te_send_info_update_pro});
    public static final NewSubHeaderType SUBHEAD_TYPE_ACL = new NewSubHeaderType(new byte[]{ControlType.te_send_state_pause, ControlType.te_send_state_stop, ControlType.te_send_state_progress});
    public static final NewSubHeaderType SUBHEAD_TYPE_STREAM = new NewSubHeaderType(new byte[]{ControlType.te_send_info_ver, ControlType.te_send_info_update_pro, ControlType.te_send_state_play_state});
    public static final NewSubHeaderType SUBHEAD_TYPE_UOWNER = new NewSubHeaderType(new byte[]{ControlType.te_send_info_wifi, ControlType.te_send_info_name, 87});
    public static final NewSubHeaderType SUBHEAD_TYPE_AV = new NewSubHeaderType(new byte[]{ControlType.te_send_state_pause, ControlType.te_send_getting_language});
    public static final NewSubHeaderType SUBHEAD_TYPE_RR = new NewSubHeaderType(new byte[]{ControlType.te_send_info_info, ControlType.te_send_info_info});
    public static final NewSubHeaderType SUBHEAD_TYPE_OS2EA = new NewSubHeaderType(new byte[]{ControlType.te_send_state_volume, ControlType.te_send_state_pause, 50});
    public static final NewSubHeaderType SUBHEAD_TYPE_BEOSEA = new NewSubHeaderType(new byte[]{ControlType.te_send_state_volume, ControlType.te_send_state_pause, ControlType.te_send_state_resume, ControlType.te_send_state_volume});

    private NewSubHeaderType(byte[] bArr) {
        this.headerTypes = bArr;
    }

    public boolean byteEquals(byte[] bArr) {
        return Arrays.equals(this.headerTypes, bArr);
    }

    public String toString() {
        return new String(this.headerTypes);
    }
}
