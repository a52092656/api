package com.tdo.showbox.utils;

import io.reactivex.functions.Action;
import kotlin.Metadata;
import kotlin.jvm.functions.Function0;
/* compiled from: RxSubscribers.kt */
@Metadata(bv = {1, 0, 3}, d1 = {"\u0000\u000e\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\u0000\n\u0000\u0010\u0000\u001a\u00020\u0001\"\n\b\u0000\u0010\u0002\u0018\u0001*\u00020\u0003H\n¢\u0006\u0002\b\u0004"}, d2 = {"<anonymous>", "", "T", "", "run"}, k = 3, mv = {1, 1, 16})
/* loaded from: classes3.dex */
public final class RxSubscribersKt$subscribeKt$8 implements Action {
    final /* synthetic */ Function0 $onComplete;

    public RxSubscribersKt$subscribeKt$8(Function0 function0) {
        this.$onComplete = function0;
    }

    @Override // io.reactivex.functions.Action
    public final void run() {
        this.$onComplete.mo1726invoke();
    }
}
