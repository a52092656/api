package com.tdo.showbox.utils;

import java.util.List;
/* loaded from: classes3.dex */
public class ShellUtil {
    public static final String COMMAND_EXIT = "exit\n";
    public static final String COMMAND_LINE_END = "\n";
    public static final String COMMAND_SH = "sh";
    public static final String COMMAND_SU = "su";

    public static boolean hasRootPermission() {
        return execCommand("echo root", true, false).result == 0;
    }

    public static CommandResult execCommand(String str, boolean z) {
        return execCommand(new String[]{str}, z, true);
    }

    public static CommandResult execCommand(String str, boolean z, boolean z2) {
        return execCommand(new String[]{str}, z, z2);
    }

    public static CommandResult execCommand(List<String> list, boolean z, boolean z2) {
        return execCommand(list == null ? null : (String[]) list.toArray(new String[0]), z, z2);
    }

    /* JADX WARN: Code restructure failed: missing block: B:116:0x0159, code lost:
        if (r10 == null) goto L90;
     */
    /* JADX WARN: Code restructure failed: missing block: B:123:0x0162, code lost:
        if (r10 != null) goto L91;
     */
    /* JADX WARN: Code restructure failed: missing block: B:138:0x01cb, code lost:
        if (r9 == null) goto L139;
     */
    /* JADX WARN: Code restructure failed: missing block: B:139:0x01d9, code lost:
        throw r8;
     */
    /* JADX WARN: Code restructure failed: missing block: B:140:0x01d6, code lost:
        r9.destroy();
     */
    /* JADX WARN: Code restructure failed: missing block: B:141:0x01d4, code lost:
        if (r9 == null) goto L139;
     */
    /* JADX WARN: Code restructure failed: missing block: B:31:0x00fb, code lost:
        if (r9 != null) goto L32;
     */
    /* JADX WARN: Code restructure failed: missing block: B:32:0x00fd, code lost:
        r9.destroy();
        r10 = r10;
     */
    /* JADX WARN: Code restructure failed: missing block: B:34:0x019b, code lost:
        if (r8 != null) goto L41;
     */
    /* JADX WARN: Code restructure failed: missing block: B:35:0x019d, code lost:
        r8 = null;
     */
    /* JADX WARN: Code restructure failed: missing block: B:36:0x01a3, code lost:
        if (r10 != 0) goto L37;
     */
    /* JADX WARN: Code restructure failed: missing block: B:37:0x01a6, code lost:
        r0 = r10.toString();
     */
    /* JADX WARN: Code restructure failed: missing block: B:39:0x01ad, code lost:
        return new com.tdo.showbox.utils.ShellUtil.CommandResult(r1, r8, r0);
     */
    /* JADX WARN: Code restructure failed: missing block: B:41:0x019f, code lost:
        r8 = r8.toString();
     */
    /* JADX WARN: Code restructure failed: missing block: B:46:0x0105, code lost:
        if (r9 == null) goto L33;
     */
    /* JADX WARN: Code restructure failed: missing block: B:89:0x0188, code lost:
        if (r10 == null) goto L90;
     */
    /* JADX WARN: Code restructure failed: missing block: B:90:0x0196, code lost:
        r8 = r9;
        r10 = r1;
        r1 = r2;
     */
    /* JADX WARN: Code restructure failed: missing block: B:91:0x0193, code lost:
        r10.destroy();
     */
    /* JADX WARN: Code restructure failed: missing block: B:98:0x0191, code lost:
        if (r10 != null) goto L91;
     */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Not initialized variable reg: 3, insn: 0x01b0: MOVE  (r2 I:??[OBJECT, ARRAY]) = (r3 I:??[OBJECT, ARRAY]), block:B:197:0x01af */
    /* JADX WARN: Not initialized variable reg: 4, insn: 0x01b1: MOVE  (r3 I:??[OBJECT, ARRAY]) = (r4 I:??[OBJECT, ARRAY]), block:B:197:0x01af */
    /* JADX WARN: Not initialized variable reg: 5, insn: 0x01b2: MOVE  (r0 I:??[OBJECT, ARRAY]) = (r5 I:??[OBJECT, ARRAY]), block:B:197:0x01af */
    /* JADX WARN: Removed duplicated region for block: B:109:0x014d A[Catch: all -> 0x0147, IOException -> 0x0149, TryCatch #8 {IOException -> 0x0149, blocks: (B:125:0x0143, B:109:0x014d, B:111:0x0152), top: B:124:0x0143, outer: #18 }] */
    /* JADX WARN: Removed duplicated region for block: B:111:0x0152 A[Catch: all -> 0x0147, IOException -> 0x0149, TRY_LEAVE, TryCatch #8 {IOException -> 0x0149, blocks: (B:125:0x0143, B:109:0x014d, B:111:0x0152), top: B:124:0x0143, outer: #18 }] */
    /* JADX WARN: Removed duplicated region for block: B:124:0x0143 A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:131:0x01bf A[Catch: all -> 0x01b9, IOException -> 0x01bb, TryCatch #15 {IOException -> 0x01bb, blocks: (B:143:0x01b5, B:131:0x01bf, B:133:0x01c4), top: B:142:0x01b5, outer: #12 }] */
    /* JADX WARN: Removed duplicated region for block: B:133:0x01c4 A[Catch: all -> 0x01b9, IOException -> 0x01bb, TRY_LEAVE, TryCatch #15 {IOException -> 0x01bb, blocks: (B:143:0x01b5, B:131:0x01bf, B:133:0x01c4), top: B:142:0x01b5, outer: #12 }] */
    /* JADX WARN: Removed duplicated region for block: B:142:0x01b5 A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:82:0x017c A[Catch: all -> 0x0176, IOException -> 0x0178, TryCatch #0 {IOException -> 0x0178, blocks: (B:100:0x0172, B:82:0x017c, B:84:0x0181), top: B:99:0x0172, outer: #11 }] */
    /* JADX WARN: Removed duplicated region for block: B:84:0x0181 A[Catch: all -> 0x0176, IOException -> 0x0178, TRY_LEAVE, TryCatch #0 {IOException -> 0x0178, blocks: (B:100:0x0172, B:82:0x017c, B:84:0x0181), top: B:99:0x0172, outer: #11 }] */
    /* JADX WARN: Removed duplicated region for block: B:99:0x0172 A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Type inference failed for: r10v24 */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public static com.tdo.showbox.utils.ShellUtil.CommandResult execCommand(java.lang.String[] r8, boolean r9, boolean r10) {
        /*
            Method dump skipped, instructions count: 482
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: com.tdo.showbox.utils.ShellUtil.execCommand(java.lang.String[], boolean, boolean):com.tdo.showbox.utils.ShellUtil$CommandResult");
    }

    /* loaded from: classes3.dex */
    public static class CommandResult {
        public String errorMsg;
        public String responseMsg;
        public int result;

        public CommandResult(int i) {
            this.result = i;
        }

        public CommandResult(int i, String str, String str2) {
            this.result = i;
            this.responseMsg = str;
            this.errorMsg = str2;
        }
    }
}
