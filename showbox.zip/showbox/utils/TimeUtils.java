package com.tdo.showbox.utils;

import com.hpplay.cybergarage.soap.SOAP;
import com.umeng.commonsdk.proguard.g;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import org.fourthline.cling.support.messagebox.parser.MessageElement;
import org.joda.time.DateTime;
import org.joda.time.Days;
import org.joda.time.Hours;
import org.joda.time.LocalDateTime;
import org.joda.time.Minutes;
import org.joda.time.Seconds;
/* loaded from: classes.dex */
public class TimeUtils {
    public static final String DETAULT_PATTERN = "yyyy-MM-dd HH:mm:ss";
    public static final String PATTERN_MINUTE_SECOND = "HH:mm";

    public static long getCurrentTime() {
        return LocalDateTime.now().toDateTime().getMillis();
    }

    public static String getFormatedTime() {
        return getFormatedTime(PATTERN_MINUTE_SECOND);
    }

    public static String getFormatedTime(String str) {
        if (str == null) {
            str = DETAULT_PATTERN;
        }
        return LocalDateTime.now().toDateTime().toString(str);
    }

    public static String formatTime(String str) {
        return formatTime(str, DETAULT_PATTERN);
    }

    public static String formatTime(String str, String str2) {
        try {
            return formatTime(new SimpleDateFormat(str2, Locale.getDefault()).parse(str).getTime());
        } catch (ParseException e) {
            e.printStackTrace();
            return "";
        }
    }

    public static int minutesSinceLastBack(long j) {
        return Minutes.minutesBetween(new LocalDateTime(j).toDateTime(), LocalDateTime.now().toDateTime()).getMinutes();
    }

    public static String formatTime2(long j) {
        LocalDateTime.now().toDateTime();
        return new LocalDateTime(j).toDateTime().toString("yyyy-MM-dd");
    }

    public static String formatTime3(long j) {
        return new SimpleDateFormat("MMM dd,yyyy", Locale.ENGLISH).format(new Date(j));
    }

    public static String formatTime4(long j) {
        return new SimpleDateFormat("HH:mm,MMM dd,yyyy", Locale.ENGLISH).format(new Date(j));
    }

    public static String formatTime(long j) {
        DateTime dateTime = LocalDateTime.now().toDateTime();
        DateTime dateTime2 = new LocalDateTime(j).toDateTime();
        if (dateTime2.getMillis() > dateTime.getMillis()) {
            return dateTime2.toString("HH:mm:ss,MMM dd,yyyy");
        }
        StringBuilder sb = new StringBuilder();
        int seconds = Seconds.secondsBetween(dateTime2, dateTime).getSeconds();
        int minutes = Minutes.minutesBetween(dateTime2, dateTime).getMinutes();
        int hours = Hours.hoursBetween(dateTime2, dateTime).getHours();
        int days = Days.daysBetween(dateTime2, dateTime).getDays();
        if (seconds < 5) {
            sb.append("just now");
            return sb.toString();
        } else if (seconds < 60) {
            sb.append(seconds);
            sb.append(" seconds ago");
            return sb.toString();
        } else if (minutes < 60) {
            sb.append(minutes);
            sb.append(" minutes ago");
            return sb.toString();
        } else if (hours < 24) {
            sb.append(hours);
            sb.append(" hours ago");
            return sb.toString();
        } else if (days <= 10) {
            sb.append(days);
            sb.append(" days ago");
            return sb.toString();
        } else {
            return dateTime2.toString("HH:mm:ss,MMM dd,yyyy");
        }
    }

    public static String formatReviewTime(long j) {
        DateTime dateTime = LocalDateTime.now().toDateTime();
        DateTime dateTime2 = new LocalDateTime(j).toDateTime();
        if (dateTime2.getMillis() > dateTime.getMillis()) {
            return dateTime2.toString(DETAULT_PATTERN);
        }
        StringBuilder sb = new StringBuilder();
        int seconds = Seconds.secondsBetween(dateTime2, dateTime).getSeconds();
        int minutes = Minutes.minutesBetween(dateTime2, dateTime).getMinutes();
        int hours = Hours.hoursBetween(dateTime2, dateTime).getHours();
        int days = Days.daysBetween(dateTime2, dateTime).getDays();
        if (seconds < 60) {
            sb.append(seconds);
            sb.append("s");
            return sb.toString();
        } else if (minutes < 60) {
            sb.append(minutes);
            sb.append(MessageElement.XPATH_PREFIX);
            return sb.toString();
        } else if (hours < 24) {
            sb.append(hours);
            sb.append("h");
            return sb.toString();
        } else if (days <= 10) {
            sb.append(days);
            sb.append(g.am);
            return sb.toString();
        } else if (days > 10) {
            Calendar calendar = Calendar.getInstance();
            calendar.setTimeInMillis(j);
            if (calendar.get(1) == Calendar.getInstance().get(1)) {
                return dateTime2.toString("dd MMM");
            }
            return dateTime2.toString("dd MMM,yyyy");
        } else {
            return dateTime2.toString(DETAULT_PATTERN);
        }
    }

    public static String chatTime(long j) {
        DateTime dateTime = LocalDateTime.now().toDateTime();
        DateTime dateTime2 = new LocalDateTime(j).toDateTime();
        if (dateTime2.getMillis() > dateTime.getMillis()) {
            return dateTime2.toString(DETAULT_PATTERN);
        }
        if (dateTime2.getMillis() / 1000 == dateTime.getMillis() / 1000) {
            return "刚刚";
        }
        StringBuilder sb = new StringBuilder();
        int seconds = Seconds.secondsBetween(dateTime2, dateTime).getSeconds();
        int minutes = Minutes.minutesBetween(dateTime2, dateTime).getMinutes();
        int hours = Hours.hoursBetween(dateTime2, dateTime).getHours();
        int days = Days.daysBetween(dateTime2, dateTime).getDays();
        if (seconds < 60) {
            sb.append(seconds);
            sb.append("秒前");
            return sb.toString();
        } else if (minutes < 60) {
            sb.append(minutes);
            sb.append("分钟前");
            return sb.toString();
        } else if (hours < 24) {
            sb.append(hours);
            sb.append("小时前");
            return sb.toString();
        } else if (days <= 10) {
            sb.append(days);
            sb.append("天前");
            return sb.toString();
        } else {
            return dateTime2.toString("yyyy-MM-dd");
        }
    }

    public static String convertSeconds(int i) {
        if (i <= 0) {
            return "00:00";
        }
        int i2 = i / 60;
        String str = i2 + "";
        if (i2 < 10) {
            str = "0" + i2;
        }
        int i3 = i % 60;
        String str2 = i3 + "";
        if (i3 < 10) {
            str2 = "0" + i3;
        }
        return str + SOAP.DELIM + str2;
    }

    public static String getTime(int i) {
        if (i < 10) {
            return "00:0" + i;
        } else if (i < 60) {
            return "00:" + i;
        } else if (i < 3600) {
            int i2 = i / 60;
            int i3 = i - (i2 * 60);
            if (i2 >= 10) {
                if (i3 < 10) {
                    return i2 + ":0" + i3;
                }
                return i2 + SOAP.DELIM + i3;
            } else if (i3 < 10) {
                return "0" + i2 + ":0" + i3;
            } else {
                return "0" + i2 + SOAP.DELIM + i3;
            }
        } else {
            int i4 = i / 3600;
            int i5 = i - (i4 * 3600);
            int i6 = i5 / 60;
            int i7 = i5 - (i6 * 60);
            if (i4 >= 10) {
                if (i6 < 10) {
                    if (i7 < 10) {
                        return i4 + ":0" + i6 + ":0" + i7;
                    }
                    return i4 + ":0" + i6 + SOAP.DELIM + i7;
                } else if (i7 < 10) {
                    return i4 + SOAP.DELIM + i6 + ":0" + i7;
                } else {
                    return i4 + SOAP.DELIM + i6 + SOAP.DELIM + i7;
                }
            } else if (i6 < 10) {
                if (i7 < 10) {
                    return "0" + i4 + ":0" + i6 + ":0" + i7;
                }
                return "0" + i4 + ":0" + i6 + SOAP.DELIM + i7;
            } else if (i7 < 10) {
                return "0" + i4 + SOAP.DELIM + i6 + ":0" + i7;
            } else {
                return "0" + i4 + SOAP.DELIM + i6 + SOAP.DELIM + i7;
            }
        }
    }
}
