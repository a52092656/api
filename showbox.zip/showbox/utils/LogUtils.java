package com.tdo.showbox.utils;

import com.orhanobut.logger.Logger;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
/* compiled from: LogUtils.kt */
@Metadata(bv = {1, 0, 3}, d1 = {"\u0000\"\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u0002\n\u0002\b\r\bÆ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J\b\u0010\u0006\u001a\u00020\u0007H\u0002J\u0010\u0010\b\u001a\u00020\t2\b\u0010\n\u001a\u0004\u0018\u00010\u0004J\u000e\u0010\u000b\u001a\u00020\t2\u0006\u0010\f\u001a\u00020\u0001J\u0018\u0010\r\u001a\u00020\t2\u0006\u0010\u000e\u001a\u00020\u00042\b\u0010\n\u001a\u0004\u0018\u00010\u0004J\u0010\u0010\r\u001a\u00020\t2\b\u0010\n\u001a\u0004\u0018\u00010\u0004J\u0010\u0010\u000f\u001a\u00020\t2\b\u0010\n\u001a\u0004\u0018\u00010\u0004J\u0010\u0010\u0010\u001a\u00020\t2\b\u0010\u0011\u001a\u0004\u0018\u00010\u0004J\u0010\u0010\u0012\u001a\u00020\t2\b\u0010\u0011\u001a\u0004\u0018\u00010\u0004J\u0010\u0010\u0013\u001a\u00020\t2\b\u0010\u0011\u001a\u0004\u0018\u00010\u0004J\u0010\u0010\u0014\u001a\u00020\t2\b\u0010\u0015\u001a\u0004\u0018\u00010\u0004R\u000e\u0010\u0003\u001a\u00020\u0004X\u0082T¢\u0006\u0002\n\u0000R\u000e\u0010\u0005\u001a\u00020\u0004X\u0082T¢\u0006\u0002\n\u0000¨\u0006\u0016"}, d2 = {"Lcom/tdo/showbox/utils/LogUtils;", "", "()V", LogUtils.INTERFACE_JSON_TAG, "", LogUtils.INTERFACE_PARAM_JSON_TAG, "isLog", "", "loadInterfaceParamData", "", "s", "logCollections", "any", "logD", "tag", "logE", "logInterfaceJson", "json", "logInterfaceParamJson", "logJson", "logXml", "xml", "app_webRelease"}, k = 1, mv = {1, 1, 16})
/* loaded from: classes3.dex */
public final class LogUtils {
    public static final LogUtils INSTANCE = new LogUtils();
    private static final String INTERFACE_JSON_TAG = "INTERFACE_JSON_TAG";
    private static final String INTERFACE_PARAM_JSON_TAG = "INTERFACE_PARAM_JSON_TAG";

    private final boolean isLog() {
        return false;
    }

    private LogUtils() {
    }

    public final void logJson(String str) {
        if (isLog()) {
            Logger.json(str);
        }
    }

    public final void logInterfaceJson(String str) {
        if (isLog()) {
            Logger.t(INTERFACE_JSON_TAG).json(str);
        }
    }

    public final void logInterfaceParamJson(String str) {
        if (isLog()) {
            Logger.t(INTERFACE_PARAM_JSON_TAG).json(str);
        }
    }

    public final void loadInterfaceParamData(String str) {
        if (isLog()) {
            Logger.t(INTERFACE_PARAM_JSON_TAG).d(str);
        }
    }

    public final void logXml(String str) {
        if (isLog()) {
            Logger.xml(str);
        }
    }

    public final void logCollections(Object any) {
        Intrinsics.checkParameterIsNotNull(any, "any");
        if (isLog()) {
            Logger.d(any);
        }
    }

    public final void logD(String str) {
        if (isLog()) {
            Logger.d(str);
        }
    }

    public final void logD(String tag, String str) {
        Intrinsics.checkParameterIsNotNull(tag, "tag");
        if (isLog()) {
            Logger.t(tag).d(str);
        }
    }

    public final void logE(String str) {
        if (isLog()) {
            if (str == null) {
                str = "";
            }
            Logger.e(str, new Object[0]);
        }
    }
}
