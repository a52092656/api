package com.tdo.showbox.utils;

import android.app.Application;
import android.text.TextUtils;
import com.google.android.gms.ads.MobileAds;
import com.mintegral.msdk.out.MIntegralSDKFactory;
import com.mintegral.msdk.system.a;
import com.tdo.showbox.app.Constant;
import com.tdo.showbox.config.ConfigKey;
import com.tdo.showbox.config.ConfigUtils;
import com.zcoup.base.core.ZcoupSDK;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;
/* compiled from: AdInitUtils.kt */
@Metadata(bv = {1, 0, 3}, d1 = {"\u0000\u0018\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\u0018\u00002\u00020\u0001B\u0005¢\u0006\u0002\u0010\u0002J\u000e\u0010\u0003\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\u0006¨\u0006\u0007"}, d2 = {"Lcom/tdo/showbox/utils/AdInitUtils;", "", "()V", "init", "", "application", "Landroid/app/Application;", "app_webRelease"}, k = 1, mv = {1, 1, 16})
/* loaded from: classes.dex */
public final class AdInitUtils {
    public final void init(Application application) {
        Intrinsics.checkParameterIsNotNull(application, "application");
        int i = 0;
        if (ConfigUtils.containsConfig(ConfigKey.AD_INTERSTITIAL_GOOGLE_PORTION)) {
            String google = ConfigUtils.readStringConfig(ConfigKey.AD_INTERSTITIAL_GOOGLE_PORTION);
            String str = google;
            if (!TextUtils.isEmpty(str)) {
                Intrinsics.checkExpressionValueIsNotNull(google, "google");
                if ((StringsKt.isBlank(str) ^ true ? Integer.parseInt(google) : 0) > 0) {
                    MobileAds.initialize(application, Constant.GOOGLE_APP_ID);
                }
            }
        }
        if (ConfigUtils.containsConfig(ConfigKey.AD_INTERSTITIAL_CLOUDMOBI_PORTION_NEW)) {
            String cloudmobi = ConfigUtils.readStringConfig(ConfigKey.AD_INTERSTITIAL_CLOUDMOBI_PORTION_NEW);
            String str2 = cloudmobi;
            if (!TextUtils.isEmpty(str2)) {
                Intrinsics.checkExpressionValueIsNotNull(cloudmobi, "cloudmobi");
                if ((StringsKt.isBlank(str2) ^ true ? Integer.parseInt(cloudmobi) : 0) > 0) {
                    ZcoupSDK.initialize(application, Constant.CLOUDMOBI_INTERSTITIAL_KEY);
                }
            }
        }
        if (ConfigUtils.containsConfig(ConfigKey.AD_INTERSTITIAL_MINTEGRAL_PORTION) || ConfigUtils.containsConfig(ConfigKey.AD_INTERSTITIAL_MINTEGRAL_IMAGE_PORTION)) {
            String mintegralVideo = ConfigUtils.readStringConfig(ConfigKey.AD_INTERSTITIAL_MINTEGRAL_PORTION);
            String mintegralImage = ConfigUtils.readStringConfig(ConfigKey.AD_INTERSTITIAL_MINTEGRAL_IMAGE_PORTION);
            String str3 = mintegralVideo;
            if (TextUtils.isEmpty(str3) && TextUtils.isEmpty(mintegralImage)) {
                return;
            }
            Intrinsics.checkExpressionValueIsNotNull(mintegralVideo, "mintegralVideo");
            int parseInt = StringsKt.isBlank(str3) ^ true ? Integer.parseInt(mintegralVideo) : 0;
            Intrinsics.checkExpressionValueIsNotNull(mintegralImage, "mintegralImage");
            if (!StringsKt.isBlank(mintegralImage)) {
                i = Integer.parseInt(mintegralImage);
            }
            if (parseInt <= 0 && i <= 0) {
                return;
            }
            a mIntegralSDK = MIntegralSDKFactory.getMIntegralSDK();
            Intrinsics.checkExpressionValueIsNotNull(mIntegralSDK, "MIntegralSDKFactory.getMIntegralSDK()");
            a aVar = mIntegralSDK;
            aVar.init(aVar.getMTGConfigurationMap("122477", "7bce02692a38b447607e335cc3b855a3"), application);
        }
    }
}
