package com.tdo.showbox.utils;

import com.tdo.showbox.http.CipherKeys;
/* loaded from: classes3.dex */
public class MiniInstallKeys extends CipherKeys {
    private static final String APP_KEY = "wereader";
    private static final String IV = "wEiphTn!";
    private static final String KEY = "844d6cefc426d38373aa1e55";

    public MiniInstallKeys() {
        super(APP_KEY, KEY, IV);
    }
}
