package com.tdo.showbox.utils;

import android.os.Build;
import android.os.Environment;
import android.os.StatFs;
import com.dd.plist.ASCIIPropertyListParser;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
/* loaded from: classes3.dex */
public class SdCardUtil {
    private static final String TAG = SdCardUtil.class.getSimpleName();

    public boolean isSdCardAvailable() {
        return "mounted".equals(Environment.getExternalStorageState());
    }

    public static StatFs getStatFs(String str) {
        return new StatFs(str);
    }

    public static String getDataPath() {
        return Environment.getDataDirectory().getPath();
    }

    public static String getNormalSDCardPath() {
        return Environment.getExternalStorageDirectory().getPath();
    }

    /* JADX WARN: Code restructure failed: missing block: B:15:0x003f, code lost:
        r0 = r2[1].replace("/.android_secure", "");
     */
    /* JADX WARN: Code restructure failed: missing block: B:17:0x0049, code lost:
        r1.close();
     */
    /* JADX WARN: Code restructure failed: missing block: B:21:0x004d, code lost:
        r1 = move-exception;
     */
    /* JADX WARN: Code restructure failed: missing block: B:22:0x004e, code lost:
        r1.printStackTrace();
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public static java.lang.String getSDCardPath() {
        /*
            java.lang.String r0 = "cat /proc/mounts"
            java.lang.Runtime r1 = java.lang.Runtime.getRuntime()
            r2 = 0
            java.lang.Process r0 = r1.exec(r0)     // Catch: java.lang.Throwable -> L67 java.lang.Exception -> L69
            java.io.BufferedReader r1 = new java.io.BufferedReader     // Catch: java.lang.Throwable -> L67 java.lang.Exception -> L69
            java.io.InputStreamReader r3 = new java.io.InputStreamReader     // Catch: java.lang.Throwable -> L67 java.lang.Exception -> L69
            java.io.BufferedInputStream r4 = new java.io.BufferedInputStream     // Catch: java.lang.Throwable -> L67 java.lang.Exception -> L69
            java.io.InputStream r5 = r0.getInputStream()     // Catch: java.lang.Throwable -> L67 java.lang.Exception -> L69
            r4.<init>(r5)     // Catch: java.lang.Throwable -> L67 java.lang.Exception -> L69
            r3.<init>(r4)     // Catch: java.lang.Throwable -> L67 java.lang.Exception -> L69
            r1.<init>(r3)     // Catch: java.lang.Throwable -> L67 java.lang.Exception -> L69
        L1e:
            java.lang.String r2 = r1.readLine()     // Catch: java.lang.Throwable -> L61 java.lang.Exception -> L64
            if (r2 == 0) goto L5d
            java.lang.String r3 = "sdcard"
            boolean r3 = r2.contains(r3)     // Catch: java.lang.Throwable -> L61 java.lang.Exception -> L64
            r4 = 1
            if (r3 == 0) goto L52
            java.lang.String r3 = ".android_secure"
            boolean r3 = r2.contains(r3)     // Catch: java.lang.Throwable -> L61 java.lang.Exception -> L64
            if (r3 == 0) goto L52
            java.lang.String r3 = " "
            java.lang.String[] r2 = r2.split(r3)     // Catch: java.lang.Throwable -> L61 java.lang.Exception -> L64
            int r3 = r2.length     // Catch: java.lang.Throwable -> L61 java.lang.Exception -> L64
            r5 = 5
            if (r3 < r5) goto L52
            r0 = r2[r4]     // Catch: java.lang.Throwable -> L61 java.lang.Exception -> L64
            java.lang.String r2 = "/.android_secure"
            java.lang.String r3 = ""
            java.lang.String r0 = r0.replace(r2, r3)     // Catch: java.lang.Throwable -> L61 java.lang.Exception -> L64
            r1.close()     // Catch: java.io.IOException -> L4d
            goto L51
        L4d:
            r1 = move-exception
            r1.printStackTrace()
        L51:
            return r0
        L52:
            int r2 = r0.waitFor()     // Catch: java.lang.Throwable -> L61 java.lang.Exception -> L64
            if (r2 == 0) goto L1e
            int r2 = r0.exitValue()     // Catch: java.lang.Throwable -> L61 java.lang.Exception -> L64
            goto L1e
        L5d:
            r1.close()     // Catch: java.io.IOException -> L73
            goto L77
        L61:
            r0 = move-exception
            r2 = r1
            goto L80
        L64:
            r0 = move-exception
            r2 = r1
            goto L6a
        L67:
            r0 = move-exception
            goto L80
        L69:
            r0 = move-exception
        L6a:
            r0.printStackTrace()     // Catch: java.lang.Throwable -> L67
            if (r2 == 0) goto L77
            r2.close()     // Catch: java.io.IOException -> L73
            goto L77
        L73:
            r0 = move-exception
            r0.printStackTrace()
        L77:
            java.io.File r0 = android.os.Environment.getExternalStorageDirectory()
            java.lang.String r0 = r0.getPath()
            return r0
        L80:
            if (r2 == 0) goto L8a
            r2.close()     // Catch: java.io.IOException -> L86
            goto L8a
        L86:
            r1 = move-exception
            r1.printStackTrace()
        L8a:
            goto L8c
        L8b:
            throw r0
        L8c:
            goto L8b
        */
        throw new UnsupportedOperationException("Method not decompiled: com.tdo.showbox.utils.SdCardUtil.getSDCardPath():java.lang.String");
    }

    public static ArrayList<String> getSDCardPathEx() {
        ArrayList<String> arrayList = new ArrayList<>();
        try {
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(Runtime.getRuntime().exec("mount").getInputStream()));
            while (true) {
                String readLine = bufferedReader.readLine();
                if (readLine == null) {
                    break;
                } else if (!readLine.contains("secure") && !readLine.contains("asec")) {
                    if (readLine.contains("fat")) {
                        String[] split = readLine.split(" ");
                        if (split.length > 1) {
                            arrayList.add("*" + split[1]);
                        }
                    } else if (readLine.contains("fuse")) {
                        String[] split2 = readLine.split(" ");
                        if (split2.length > 1) {
                            arrayList.add(split2[1]);
                        }
                    }
                }
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e2) {
            e2.printStackTrace();
        }
        return arrayList;
    }

    public static long getAvailableSize(String str) {
        try {
            StatFs statFs = new StatFs(new File(str).getPath());
            return statFs.getBlockSizeLong() * statFs.getAvailableBlocksLong();
        } catch (Exception e) {
            e.printStackTrace();
            return 0L;
        }
    }

    public static SDCardInfo getSDCardInfo() {
        SDCardInfo sDCardInfo = new SDCardInfo();
        if ("mounted".equals(Environment.getExternalStorageState())) {
            sDCardInfo.isExist = true;
            if (Build.VERSION.SDK_INT >= 18) {
                StatFs statFs = new StatFs(Environment.getExternalStorageDirectory().getPath());
                sDCardInfo.totalBlocks = statFs.getBlockCountLong();
                sDCardInfo.blockByteSize = statFs.getBlockSizeLong();
                sDCardInfo.availableBlocks = statFs.getAvailableBlocksLong();
                sDCardInfo.availableBytes = statFs.getAvailableBytes();
                sDCardInfo.freeBlocks = statFs.getFreeBlocksLong();
                sDCardInfo.freeBytes = statFs.getFreeBytes();
                sDCardInfo.totalBytes = statFs.getTotalBytes();
            }
        }
        return sDCardInfo;
    }

    /* loaded from: classes3.dex */
    public static class SDCardInfo {
        public long availableBlocks;
        public long availableBytes;
        public long blockByteSize;
        public long freeBlocks;
        public long freeBytes;
        public boolean isExist;
        public long totalBlocks;
        public long totalBytes;

        public String toString() {
            return "SDCardInfo{isExist=" + this.isExist + ", totalBlocks=" + this.totalBlocks + ", freeBlocks=" + this.freeBlocks + ", availableBlocks=" + this.availableBlocks + ", blockByteSize=" + this.blockByteSize + ", totalBytes=" + this.totalBytes + ", freeBytes=" + this.freeBytes + ", availableBytes=" + this.availableBytes + ASCIIPropertyListParser.DICTIONARY_END_TOKEN;
        }
    }
}
