package com.tdo.showbox.utils;

import com.tdo.showbox.utils.FileUtils;
/* compiled from: lambda */
/* renamed from: com.tdo.showbox.utils.-$$Lambda$FileUtils$Q52tdvRH0_LY66l0dyEofs6qrJI  reason: invalid class name */
/* loaded from: classes.dex */
public final /* synthetic */ class $$Lambda$FileUtils$Q52tdvRH0_LY66l0dyEofs6qrJI implements FileUtils.OnReplaceListener {
    public static final /* synthetic */ $$Lambda$FileUtils$Q52tdvRH0_LY66l0dyEofs6qrJI INSTANCE = new $$Lambda$FileUtils$Q52tdvRH0_LY66l0dyEofs6qrJI();

    private /* synthetic */ $$Lambda$FileUtils$Q52tdvRH0_LY66l0dyEofs6qrJI() {
    }

    @Override // com.tdo.showbox.utils.FileUtils.OnReplaceListener
    public final boolean onReplace() {
        return FileUtils.lambda$copyFile$0();
    }
}
