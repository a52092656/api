package com.tdo.showbox.utils;

import com.tdo.showbox.http.ApiException;
import com.tdo.showbox.http.ServerException;
import io.reactivex.functions.Consumer;
import kotlin.Metadata;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
/* compiled from: RxSubscribers.kt */
@Metadata(bv = {1, 0, 3}, d1 = {"\u0000\u0016\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u0003\n\u0002\b\u0002\u0010\u0000\u001a\u00020\u0001\"\n\b\u0000\u0010\u0002\u0018\u0001*\u00020\u00032\u000e\u0010\u0004\u001a\n \u0006*\u0004\u0018\u00010\u00050\u0005H\n¢\u0006\u0002\b\u0007"}, d2 = {"<anonymous>", "", "T", "", "it", "", "kotlin.jvm.PlatformType", "accept"}, k = 3, mv = {1, 1, 16})
/* loaded from: classes3.dex */
public final class RxSubscribersKt$subscribeKt$7<T> implements Consumer<Throwable> {
    final /* synthetic */ Function1 $onError;
    final /* synthetic */ Function1 $onServerError;

    public RxSubscribersKt$subscribeKt$7(Function1 function1, Function1 function12) {
        this.$onError = function1;
        this.$onServerError = function12;
    }

    @Override // io.reactivex.functions.Consumer
    public final void accept(Throwable th) {
        Function1 function1 = this.$onError;
        ApiException handleException = ApiException.handleException(th);
        Intrinsics.checkExpressionValueIsNotNull(handleException, "ApiException.handleException(it)");
        function1.mo1719invoke(handleException);
        if (th instanceof ServerException) {
            this.$onServerError.mo1719invoke(th);
        }
    }
}
