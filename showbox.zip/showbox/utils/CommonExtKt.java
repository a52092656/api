package com.tdo.showbox.utils;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Binder;
import android.os.Build;
import android.os.Bundle;
import android.os.IBinder;
import android.os.Parcelable;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Size;
import android.util.SizeF;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.viewholder.BaseViewHolder;
import com.gyf.immersionbar.ImmersionBar;
import com.hpplay.cybergarage.upnp.Action;
import com.mintegral.msdk.base.entity.CampaignEx;
import com.tdo.showbox.R;
import com.tdo.showbox.app.App;
import com.tdo.showbox.view.widget.GridSpacingItemDecoration;
import com.umeng.analytics.MobclickAgent;
import com.umeng.analytics.pro.b;
import java.io.Serializable;
import java.util.List;
import kotlin.Metadata;
import kotlin.Pair;
import kotlin.TypeCastException;
import kotlin.Unit;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function4;
import kotlin.jvm.internal.Intrinsics;
/* compiled from: CommonExt.kt */
@Metadata(bv = {1, 0, 3}, d1 = {"\u0000¨\u0001\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0011\n\u0002\u0018\u0002\n\u0002\u0010\u000e\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\r\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010 \n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\b\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u000b\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\b\u001a;\u0010\u0000\u001a\u00020\u00012.\u0010\u0002\u001a\u0018\u0012\u0014\b\u0001\u0012\u0010\u0012\u0004\u0012\u00020\u0005\u0012\u0006\u0012\u0004\u0018\u00010\u00060\u00040\u0003\"\u0010\u0012\u0004\u0012\u00020\u0005\u0012\u0006\u0012\u0004\u0018\u00010\u00060\u0004¢\u0006\u0002\u0010\u0007\u001a\u001b\u0010\b\u001a\u00020\t\"\u0006\b\u0000\u0010\n\u0018\u00012\b\u0010\u000b\u001a\u0004\u0018\u00010\fH\u0086\b\u001aP\u0010\b\u001a\u00020\t\"\u0006\b\u0000\u0010\n\u0018\u00012\b\u0010\u000b\u001a\u0004\u0018\u00010\f2.\u0010\u0002\u001a\u0018\u0012\u0014\b\u0001\u0012\u0010\u0012\u0004\u0012\u00020\u0005\u0012\u0006\u0012\u0004\u0018\u00010\u00060\u00040\u0003\"\u0010\u0012\u0004\u0012\u00020\u0005\u0012\u0006\u0012\u0004\u0018\u00010\u00060\u0004H\u0086\b¢\u0006\u0002\u0010\r\u001a\"\u0010\u000e\u001a\u00020\u000f*\u00020\u000f2\u0006\u0010\u0010\u001a\u00020\u00052\u0006\u0010\u0011\u001a\u00020\u00122\u0006\u0010\u0013\u001a\u00020\u0012\u001a\u0080\u0002\u0010\u0014\u001a\u00020\u0015*\u00020\u00162d\b\u0006\u0010\u0017\u001a^\u0012\u0015\u0012\u0013\u0018\u00010\u0019¢\u0006\f\b\u001a\u0012\b\b\u001b\u0012\u0004\b\b(\u0010\u0012\u0013\u0012\u00110\u0012¢\u0006\f\b\u001a\u0012\b\b\u001b\u0012\u0004\b\b(\u001c\u0012\u0013\u0012\u00110\u0012¢\u0006\f\b\u001a\u0012\b\b\u001b\u0012\u0004\b\b(\u001d\u0012\u0013\u0012\u00110\u0012¢\u0006\f\b\u001a\u0012\b\b\u001b\u0012\u0004\b\b(\u001e\u0012\u0004\u0012\u00020\u001f0\u00182d\b\u0006\u0010 \u001a^\u0012\u0015\u0012\u0013\u0018\u00010\u0019¢\u0006\f\b\u001a\u0012\b\b\u001b\u0012\u0004\b\b(\u0010\u0012\u0013\u0012\u00110\u0012¢\u0006\f\b\u001a\u0012\b\b\u001b\u0012\u0004\b\b(\u001c\u0012\u0013\u0012\u00110\u0012¢\u0006\f\b\u001a\u0012\b\b\u001b\u0012\u0004\b\b(\u001d\u0012\u0013\u0012\u00110\u0012¢\u0006\f\b\u001a\u0012\b\b\u001b\u0012\u0004\b\b(\u001e\u0012\u0004\u0012\u00020\u001f0\u00182%\b\u0006\u0010!\u001a\u001f\u0012\u0015\u0012\u0013\u0018\u00010#¢\u0006\f\b\u001a\u0012\b\b\u001b\u0012\u0004\b\b(\u0010\u0012\u0004\u0012\u00020\u001f0\"H\u0086\b\u001a\u0018\u0010$\u001a\u00020%*\u00020\u00122\f\u0010&\u001a\b\u0012\u0002\b\u0003\u0018\u00010'\u001a\u0012\u0010(\u001a\u00020\u0012*\u00020\f2\u0006\u0010\u0013\u001a\u00020\u0012\u001a\u0012\u0010(\u001a\u00020\u0012*\u00020\u00062\u0006\u0010\u0013\u001a\u00020\u0012\u001a\n\u0010)\u001a\u00020\u001f*\u00020*\u001a4\u0010+\u001a\u00020\u0015*\u00020\u00162%\b\u0004\u0010,\u001a\u001f\u0012\u0015\u0012\u0013\u0018\u00010#¢\u0006\f\b\u001a\u0012\b\b\u001b\u0012\u0004\b\b(\u0010\u0012\u0004\u0012\u00020\u001f0\"H\u0086\b\u001as\u0010-\u001a\u00020\u0015*\u00020\u00162d\b\u0004\u0010,\u001a^\u0012\u0015\u0012\u0013\u0018\u00010\u0019¢\u0006\f\b\u001a\u0012\b\b\u001b\u0012\u0004\b\b(\u0010\u0012\u0013\u0012\u00110\u0012¢\u0006\f\b\u001a\u0012\b\b\u001b\u0012\u0004\b\b(\u001c\u0012\u0013\u0012\u00110\u0012¢\u0006\f\b\u001a\u0012\b\b\u001b\u0012\u0004\b\b(\u001d\u0012\u0013\u0012\u00110\u0012¢\u0006\f\b\u001a\u0012\b\b\u001b\u0012\u0004\b\b(\u001e\u0012\u0004\u0012\u00020\u001f0\u0018H\u0086\b\u001as\u0010.\u001a\u00020\u0015*\u00020\u00162d\b\u0004\u0010,\u001a^\u0012\u0015\u0012\u0013\u0018\u00010\u0019¢\u0006\f\b\u001a\u0012\b\b\u001b\u0012\u0004\b\b(\u0010\u0012\u0013\u0012\u00110\u0012¢\u0006\f\b\u001a\u0012\b\b\u001b\u0012\u0004\b\b(\u001c\u0012\u0013\u0012\u00110\u0012¢\u0006\f\b\u001a\u0012\b\b\u001b\u0012\u0004\b\b(\u001d\u0012\u0013\u0012\u00110\u0012¢\u0006\f\b\u001a\u0012\b\b\u001b\u0012\u0004\b\b(\u001e\u0012\u0004\u0012\u00020\u001f0\u0018H\u0086\b\u001a\n\u0010/\u001a\u00020\u0012*\u00020\u0012\u001a\n\u00100\u001a\u00020\u0012*\u00020\f\u001a\n\u00101\u001a\u00020\u0012*\u00020\f\u001a\n\u00102\u001a\u00020\u001f*\u000203\u001a\n\u00104\u001a\u00020\u001f*\u000205\u001a\n\u00106\u001a\u00020\u001f*\u000205\u001a.\u00107\u001a\u00020\u001f*\u00020*2\u0006\u0010\u000b\u001a\u00020\f2\u0006\u00108\u001a\u00020\u00122\b\b\u0002\u00109\u001a\u00020\u00122\b\b\u0002\u0010:\u001a\u00020%\u001a\u0014\u0010;\u001a\u00020\u001f*\u00020<2\b\b\u0002\u0010=\u001a\u00020\u0012\u001a2\u0010>\u001a\u00020\u001f*\u00020*2\b\u0010\u000b\u001a\u0004\u0018\u00010\f2\b\b\u0002\u0010?\u001a\u00020%2\b\b\u0002\u00109\u001a\u00020\u00122\b\b\u0002\u0010:\u001a\u00020%\u001a\n\u0010@\u001a\u00020\u001f*\u000203\u001a\u0014\u0010A\u001a\u000203*\u00020B2\b\b\u0001\u0010C\u001a\u00020\u0012\u001a\u0012\u0010D\u001a\u00020\u001f*\u00020\u00062\u0006\u0010E\u001a\u00020\u0006\u001a\u0014\u0010F\u001a\u00020\u001f*\u00020\u00062\b\u0010G\u001a\u0004\u0018\u00010\u0005\u001a\u0014\u0010H\u001a\u00020\u001f*\u00020\u00062\b\u0010I\u001a\u0004\u0018\u00010\u0005\u001a\u0012\u0010J\u001a\u00020\u001f*\u00020\f2\u0006\u0010K\u001a\u00020\u0005\u001a&\u0010L\u001a\u00020\u001f*\u00020*2\u0012\u0010M\u001a\u000e\u0012\u0002\b\u0003\u0012\u0004\u0012\u00020O\u0018\u00010N2\u0006\u00108\u001a\u00020\u0012\u001a\n\u0010P\u001a\u00020\u001f*\u000205\u001a\u0015\u0010Q\u001a\u00020\u001f\"\u0006\b\u0000\u0010\n\u0018\u0001*\u00020\fH\u0086\b\u001a&\u0010R\u001a\u00020\u001f*\u00020\u00162\u0006\u0010\u0010\u001a\u00020\u00052\b\b\u0002\u0010S\u001a\u00020\u00122\b\b\u0002\u0010T\u001a\u00020\u0012\u001a\u0012\u0010T\u001a\u00020\u001f*\u00020\u00162\u0006\u0010\u0013\u001a\u00020\u0012\u001a&\u0010U\u001a\u00020\u001f*\u00020\u00162\u0006\u0010\u0010\u001a\u00020\u00052\b\b\u0002\u0010S\u001a\u00020\u00122\b\b\u0002\u0010T\u001a\u00020\u0012\u001a\n\u0010V\u001a\u00020\u001f*\u000203¨\u0006W"}, d2 = {"bundleOf", "Landroid/os/Bundle;", "pairs", "", "Lkotlin/Pair;", "", "", "([Lkotlin/Pair;)Landroid/os/Bundle;", "intentOf", "Landroid/content/Intent;", "T", b.M, "Landroid/content/Context;", "(Landroid/content/Context;[Lkotlin/Pair;)Landroid/content/Intent;", "addText", "Lcom/tdo/showbox/utils/SpanUtils;", "text", "sizeSp", "", "colorId", "addTextChangedListener", "Landroid/text/TextWatcher;", "Landroid/widget/TextView;", "beforeTextChanged", "Lkotlin/Function4;", "", "Lkotlin/ParameterName;", "name", CampaignEx.JSON_NATIVE_VIDEO_START, "count", "after", "", "onTextChanged", "afterTextChanged", "Lkotlin/Function1;", "Landroid/text/Editable;", "checkIndexLegal", "", "list", "", "colorInt", "disableRefreshAnimation", "Landroidx/recyclerview/widget/RecyclerView;", "doAfterTextChanged", Action.ELEM_NAME, "doBeforeTextChanged", "doOnTextChanged", "dp2Px", "getScreenHeight", "getScreenWidth", "gone", "Landroid/view/View;", "hide", "Landroidx/swiperefreshlayout/widget/SwipeRefreshLayout;", "initColor", "initGridAndMargin", "spanCount", "margin", "includeEdge", "initImmersionBar", "Landroid/app/Activity;", "color", "initLinearAndMargin", "isVertical", "invisible", "layoutInflate", "Landroid/view/ViewGroup;", "layoutResId", "logCollections", "any", "logD", "s", "logXmlD", "xml", "onMobEvent", "event", "resetSpanCount", "adapter", "Lcom/chad/library/adapter/base/BaseQuickAdapter;", "Lcom/chad/library/adapter/base/viewholder/BaseViewHolder;", "show", "startActivity", "textBoldShadow", "textSize", "textColor", "textShadow", "visible", "app_webRelease"}, k = 2, mv = {1, 1, 16})
/* loaded from: classes3.dex */
public final class CommonExtKt {
    public static final void visible(View visible) {
        Intrinsics.checkParameterIsNotNull(visible, "$this$visible");
        visible.setVisibility(0);
    }

    public static final void gone(View gone) {
        Intrinsics.checkParameterIsNotNull(gone, "$this$gone");
        gone.setVisibility(8);
    }

    public static final void invisible(View invisible) {
        Intrinsics.checkParameterIsNotNull(invisible, "$this$invisible");
        invisible.setVisibility(4);
    }

    public static final int colorInt(Context colorInt, int i) {
        Intrinsics.checkParameterIsNotNull(colorInt, "$this$colorInt");
        return ContextCompat.getColor(colorInt, i);
    }

    public static final int colorInt(Object colorInt, int i) {
        Intrinsics.checkParameterIsNotNull(colorInt, "$this$colorInt");
        return ContextCompat.getColor(App.getContext(), i);
    }

    public static final View layoutInflate(ViewGroup layoutInflate, int i) {
        Intrinsics.checkParameterIsNotNull(layoutInflate, "$this$layoutInflate");
        View inflate = LayoutInflater.from(layoutInflate.getContext()).inflate(i, layoutInflate, false);
        Intrinsics.checkExpressionValueIsNotNull(inflate, "LayoutInflater.from(this…layoutResId, this, false)");
        return inflate;
    }

    public static final /* synthetic */ <T> void startActivity(Context startActivity) {
        Intrinsics.checkParameterIsNotNull(startActivity, "$this$startActivity");
        Intrinsics.reifiedOperationMarker(4, "T");
        startActivity.startActivity(new Intent(startActivity, Object.class));
    }

    public static final int dp2Px(int i) {
        return DensityUtils.dp2px(App.getContext(), i);
    }

    public static /* synthetic */ void textShadow$default(TextView textView, String str, int i, int i2, int i3, Object obj) {
        if ((i3 & 2) != 0) {
            i = 12;
        }
        if ((i3 & 4) != 0) {
            i2 = R.color.white;
        }
        textShadow(textView, str, i, i2);
    }

    public static final void textShadow(TextView textShadow, String text, int i, int i2) {
        Intrinsics.checkParameterIsNotNull(textShadow, "$this$textShadow");
        Intrinsics.checkParameterIsNotNull(text, "text");
        SpanUtils.with(textShadow).append(text).setFontSize(i, true).setForegroundColor(ContextCompat.getColor(App.getContext(), i2)).setTypeface(Typeface.DEFAULT_BOLD).setShadow(3.0f, 0.0f, 4.0f, Color.parseColor("#80000000")).create();
    }

    public static /* synthetic */ void textBoldShadow$default(TextView textView, String str, int i, int i2, int i3, Object obj) {
        if ((i3 & 2) != 0) {
            i = 14;
        }
        if ((i3 & 4) != 0) {
            i2 = R.color.white;
        }
        textBoldShadow(textView, str, i, i2);
    }

    public static final void textBoldShadow(TextView textBoldShadow, String text, int i, int i2) {
        Intrinsics.checkParameterIsNotNull(textBoldShadow, "$this$textBoldShadow");
        Intrinsics.checkParameterIsNotNull(text, "text");
        SpanUtils.with(textBoldShadow).append(text).setFontSize(i, true).setForegroundColor(ContextCompat.getColor(App.getContext(), i2)).setTypeface(Typeface.DEFAULT_BOLD).setShadow(3.0f, 0.0f, 4.0f, Color.parseColor("#80000000")).setBold().create();
    }

    public static final void disableRefreshAnimation(RecyclerView disableRefreshAnimation) {
        Intrinsics.checkParameterIsNotNull(disableRefreshAnimation, "$this$disableRefreshAnimation");
        RecyclerView.ItemAnimator itemAnimator = disableRefreshAnimation.getItemAnimator();
        if (itemAnimator instanceof DefaultItemAnimator) {
            ((DefaultItemAnimator) itemAnimator).setSupportsChangeAnimations(false);
        }
    }

    public static final boolean checkIndexLegal(int i, List<?> list) {
        if (i >= 0) {
            return i < (list != null ? list.size() : 0);
        }
        return false;
    }

    public static final SpanUtils addText(SpanUtils addText, String text, int i, int i2) {
        Intrinsics.checkParameterIsNotNull(addText, "$this$addText");
        Intrinsics.checkParameterIsNotNull(text, "text");
        addText.append(text).setFontSize(i, true).setForegroundColor(ContextCompat.getColor(App.getContext(), i2));
        return addText;
    }

    public static final void textColor(TextView textColor, int i) {
        Intrinsics.checkParameterIsNotNull(textColor, "$this$textColor");
        textColor.setTextColor(ContextCompat.getColor(App.getContext(), i));
    }

    public static /* synthetic */ void initLinearAndMargin$default(RecyclerView recyclerView, Context context, boolean z, int i, boolean z2, int i2, Object obj) {
        if ((i2 & 2) != 0) {
            z = true;
        }
        if ((i2 & 4) != 0) {
            i = 10;
        }
        if ((i2 & 8) != 0) {
            z2 = true;
        }
        initLinearAndMargin(recyclerView, context, z, i, z2);
    }

    public static final void initLinearAndMargin(RecyclerView initLinearAndMargin, Context context, boolean z, int i, boolean z2) {
        Intrinsics.checkParameterIsNotNull(initLinearAndMargin, "$this$initLinearAndMargin");
        if (z) {
            initLinearAndMargin.setLayoutManager(new LinearLayoutManager(context, 1, false));
            initLinearAndMargin.addItemDecoration(new LinearItemDecoration(i, z2));
        } else {
            initLinearAndMargin.setLayoutManager(new LinearLayoutManager(context, 0, false));
            initLinearAndMargin.addItemDecoration(new LinearItemDecoration(0, i, z2));
        }
        disableRefreshAnimation(initLinearAndMargin);
    }

    public static /* synthetic */ void initGridAndMargin$default(RecyclerView recyclerView, Context context, int i, int i2, boolean z, int i3, Object obj) {
        if ((i3 & 4) != 0) {
            i2 = 10;
        }
        if ((i3 & 8) != 0) {
            z = true;
        }
        initGridAndMargin(recyclerView, context, i, i2, z);
    }

    public static final void initGridAndMargin(RecyclerView initGridAndMargin, Context context, int i, int i2, boolean z) {
        Intrinsics.checkParameterIsNotNull(initGridAndMargin, "$this$initGridAndMargin");
        Intrinsics.checkParameterIsNotNull(context, "context");
        initGridAndMargin.setLayoutManager(new GridLayoutManager(context, i));
        initGridAndMargin.addItemDecoration(new GridSpacingItemDecoration(i2, z));
        disableRefreshAnimation(initGridAndMargin);
    }

    public static final void resetSpanCount(RecyclerView resetSpanCount, BaseQuickAdapter<?, BaseViewHolder> baseQuickAdapter, int i) {
        Intrinsics.checkParameterIsNotNull(resetSpanCount, "$this$resetSpanCount");
        RecyclerView.LayoutManager layoutManager = resetSpanCount.getLayoutManager();
        if (layoutManager instanceof GridLayoutManager) {
            ((GridLayoutManager) layoutManager).setSpanCount(i);
        }
        if (baseQuickAdapter != null) {
            baseQuickAdapter.notifyDataSetChanged();
        }
    }

    public static final void onMobEvent(Context onMobEvent, String event) {
        Intrinsics.checkParameterIsNotNull(onMobEvent, "$this$onMobEvent");
        Intrinsics.checkParameterIsNotNull(event, "event");
        MobclickAgent.onEvent(onMobEvent, event);
    }

    public static final int getScreenWidth(Context getScreenWidth) {
        Intrinsics.checkParameterIsNotNull(getScreenWidth, "$this$getScreenWidth");
        Resources resources = getScreenWidth.getResources();
        Intrinsics.checkExpressionValueIsNotNull(resources, "this.resources");
        return resources.getDisplayMetrics().widthPixels;
    }

    public static final int getScreenHeight(Context getScreenHeight) {
        Intrinsics.checkParameterIsNotNull(getScreenHeight, "$this$getScreenHeight");
        Resources resources = getScreenHeight.getResources();
        Intrinsics.checkExpressionValueIsNotNull(resources, "this.resources");
        return resources.getDisplayMetrics().heightPixels;
    }

    public static /* synthetic */ void initImmersionBar$default(Activity activity, int i, int i2, Object obj) {
        if ((i2 & 1) != 0) {
            i = R.color.color_main;
        }
        initImmersionBar(activity, i);
    }

    public static final void initImmersionBar(Activity initImmersionBar, int i) {
        Intrinsics.checkParameterIsNotNull(initImmersionBar, "$this$initImmersionBar");
        ImmersionBar.with(initImmersionBar).fitsSystemWindows(true).autoDarkModeEnable(true).statusBarColor(i).init();
    }

    public static final void initColor(SwipeRefreshLayout initColor) {
        Intrinsics.checkParameterIsNotNull(initColor, "$this$initColor");
        initColor.setColorSchemeColors(colorInt(initColor, (int) R.color.main_purple));
        initColor.setProgressBackgroundColorSchemeColor(colorInt(initColor, (int) R.color.white));
    }

    public static final void show(SwipeRefreshLayout show) {
        Intrinsics.checkParameterIsNotNull(show, "$this$show");
        show.setRefreshing(true);
    }

    public static final void hide(SwipeRefreshLayout hide) {
        Intrinsics.checkParameterIsNotNull(hide, "$this$hide");
        hide.setRefreshing(false);
    }

    public static final void logD(Object logD, String str) {
        Intrinsics.checkParameterIsNotNull(logD, "$this$logD");
        LogUtils logUtils = LogUtils.INSTANCE;
        String simpleName = logD.getClass().getSimpleName();
        Intrinsics.checkExpressionValueIsNotNull(simpleName, "this::class.java.simpleName");
        logUtils.logD(simpleName, str);
    }

    public static final void logXmlD(Object logXmlD, String str) {
        Intrinsics.checkParameterIsNotNull(logXmlD, "$this$logXmlD");
        LogUtils logUtils = LogUtils.INSTANCE;
        String simpleName = logXmlD.getClass().getSimpleName();
        Intrinsics.checkExpressionValueIsNotNull(simpleName, "this::class.java.simpleName");
        logUtils.logD(simpleName, str);
    }

    public static final void logCollections(Object logCollections, Object any) {
        Intrinsics.checkParameterIsNotNull(logCollections, "$this$logCollections");
        Intrinsics.checkParameterIsNotNull(any, "any");
        LogUtils.INSTANCE.logCollections(any);
    }

    public static final /* synthetic */ <T> Intent intentOf(Context context, Pair<String, ? extends Object>... pairs) {
        Intrinsics.checkParameterIsNotNull(pairs, "pairs");
        Intrinsics.reifiedOperationMarker(4, "T");
        Intent intent = new Intent(context, Object.class);
        Bundle bundle = new Bundle(pairs.length);
        for (Pair<String, ? extends Object> pair : pairs) {
            String component1 = pair.component1();
            Object component2 = pair.component2();
            if (component2 == null) {
                bundle.putString(component1, null);
            } else if (component2 instanceof Boolean) {
                bundle.putBoolean(component1, ((Boolean) component2).booleanValue());
            } else if (component2 instanceof Byte) {
                bundle.putByte(component1, ((Number) component2).byteValue());
            } else if (component2 instanceof Character) {
                bundle.putChar(component1, ((Character) component2).charValue());
            } else if (component2 instanceof Double) {
                bundle.putDouble(component1, ((Number) component2).doubleValue());
            } else if (component2 instanceof Float) {
                bundle.putFloat(component1, ((Number) component2).floatValue());
            } else if (component2 instanceof Integer) {
                bundle.putInt(component1, ((Number) component2).intValue());
            } else if (component2 instanceof Long) {
                bundle.putLong(component1, ((Number) component2).longValue());
            } else if (component2 instanceof Short) {
                bundle.putShort(component1, ((Number) component2).shortValue());
            } else if (component2 instanceof Bundle) {
                bundle.putBundle(component1, (Bundle) component2);
            } else if (component2 instanceof CharSequence) {
                bundle.putCharSequence(component1, (CharSequence) component2);
            } else if (component2 instanceof Parcelable) {
                bundle.putParcelable(component1, (Parcelable) component2);
            } else if (component2 instanceof boolean[]) {
                bundle.putBooleanArray(component1, (boolean[]) component2);
            } else if (component2 instanceof byte[]) {
                bundle.putByteArray(component1, (byte[]) component2);
            } else if (component2 instanceof char[]) {
                bundle.putCharArray(component1, (char[]) component2);
            } else if (component2 instanceof double[]) {
                bundle.putDoubleArray(component1, (double[]) component2);
            } else if (component2 instanceof float[]) {
                bundle.putFloatArray(component1, (float[]) component2);
            } else if (component2 instanceof int[]) {
                bundle.putIntArray(component1, (int[]) component2);
            } else if (component2 instanceof long[]) {
                bundle.putLongArray(component1, (long[]) component2);
            } else if (component2 instanceof short[]) {
                bundle.putShortArray(component1, (short[]) component2);
            } else if (component2 instanceof Object[]) {
                Class<?> componentType = component2.getClass().getComponentType();
                if (componentType == null) {
                    Intrinsics.throwNpe();
                }
                if (Parcelable.class.isAssignableFrom(componentType)) {
                    if (component2 == null) {
                        throw new TypeCastException("null cannot be cast to non-null type kotlin.Array<android.os.Parcelable>");
                    }
                    bundle.putParcelableArray(component1, (Parcelable[]) component2);
                } else if (String.class.isAssignableFrom(componentType)) {
                    if (component2 == null) {
                        throw new TypeCastException("null cannot be cast to non-null type kotlin.Array<kotlin.String>");
                    }
                    bundle.putStringArray(component1, (String[]) component2);
                } else if (CharSequence.class.isAssignableFrom(componentType)) {
                    if (component2 == null) {
                        throw new TypeCastException("null cannot be cast to non-null type kotlin.Array<kotlin.CharSequence>");
                    }
                    bundle.putCharSequenceArray(component1, (CharSequence[]) component2);
                } else if (Serializable.class.isAssignableFrom(componentType)) {
                    bundle.putSerializable(component1, (Serializable) component2);
                } else {
                    throw new IllegalArgumentException("Illegal value array type " + componentType.getCanonicalName() + " for key \"" + component1 + '\"');
                }
            } else if (component2 instanceof Serializable) {
                bundle.putSerializable(component1, (Serializable) component2);
            } else if (Build.VERSION.SDK_INT >= 18 && (component2 instanceof Binder)) {
                bundle.putBinder(component1, (IBinder) component2);
            } else if (Build.VERSION.SDK_INT >= 21 && (component2 instanceof Size)) {
                bundle.putSize(component1, (Size) component2);
            } else if (Build.VERSION.SDK_INT >= 21 && (component2 instanceof SizeF)) {
                bundle.putSizeF(component1, (SizeF) component2);
            } else {
                throw new IllegalArgumentException("Illegal value type " + component2.getClass().getCanonicalName() + " for key \"" + component1 + '\"');
            }
        }
        intent.putExtras(bundle);
        return intent;
    }

    public static final Bundle bundleOf(Pair<String, ? extends Object>... pairs) {
        Intrinsics.checkParameterIsNotNull(pairs, "pairs");
        Bundle bundle = new Bundle(pairs.length);
        for (Pair<String, ? extends Object> pair : pairs) {
            String component1 = pair.component1();
            Object component2 = pair.component2();
            if (component2 == null) {
                bundle.putString(component1, null);
            } else if (component2 instanceof Boolean) {
                bundle.putBoolean(component1, ((Boolean) component2).booleanValue());
            } else if (component2 instanceof Byte) {
                bundle.putByte(component1, ((Number) component2).byteValue());
            } else if (component2 instanceof Character) {
                bundle.putChar(component1, ((Character) component2).charValue());
            } else if (component2 instanceof Double) {
                bundle.putDouble(component1, ((Number) component2).doubleValue());
            } else if (component2 instanceof Float) {
                bundle.putFloat(component1, ((Number) component2).floatValue());
            } else if (component2 instanceof Integer) {
                bundle.putInt(component1, ((Number) component2).intValue());
            } else if (component2 instanceof Long) {
                bundle.putLong(component1, ((Number) component2).longValue());
            } else if (component2 instanceof Short) {
                bundle.putShort(component1, ((Number) component2).shortValue());
            } else if (component2 instanceof Bundle) {
                bundle.putBundle(component1, (Bundle) component2);
            } else if (component2 instanceof CharSequence) {
                bundle.putCharSequence(component1, (CharSequence) component2);
            } else if (component2 instanceof Parcelable) {
                bundle.putParcelable(component1, (Parcelable) component2);
            } else if (component2 instanceof boolean[]) {
                bundle.putBooleanArray(component1, (boolean[]) component2);
            } else if (component2 instanceof byte[]) {
                bundle.putByteArray(component1, (byte[]) component2);
            } else if (component2 instanceof char[]) {
                bundle.putCharArray(component1, (char[]) component2);
            } else if (component2 instanceof double[]) {
                bundle.putDoubleArray(component1, (double[]) component2);
            } else if (component2 instanceof float[]) {
                bundle.putFloatArray(component1, (float[]) component2);
            } else if (component2 instanceof int[]) {
                bundle.putIntArray(component1, (int[]) component2);
            } else if (component2 instanceof long[]) {
                bundle.putLongArray(component1, (long[]) component2);
            } else if (component2 instanceof short[]) {
                bundle.putShortArray(component1, (short[]) component2);
            } else if (component2 instanceof Object[]) {
                Class<?> componentType = component2.getClass().getComponentType();
                if (componentType == null) {
                    Intrinsics.throwNpe();
                }
                if (Parcelable.class.isAssignableFrom(componentType)) {
                    if (component2 == null) {
                        throw new TypeCastException("null cannot be cast to non-null type kotlin.Array<android.os.Parcelable>");
                    }
                    bundle.putParcelableArray(component1, (Parcelable[]) component2);
                } else if (String.class.isAssignableFrom(componentType)) {
                    if (component2 == null) {
                        throw new TypeCastException("null cannot be cast to non-null type kotlin.Array<kotlin.String>");
                    }
                    bundle.putStringArray(component1, (String[]) component2);
                } else if (CharSequence.class.isAssignableFrom(componentType)) {
                    if (component2 == null) {
                        throw new TypeCastException("null cannot be cast to non-null type kotlin.Array<kotlin.CharSequence>");
                    }
                    bundle.putCharSequenceArray(component1, (CharSequence[]) component2);
                } else if (Serializable.class.isAssignableFrom(componentType)) {
                    bundle.putSerializable(component1, (Serializable) component2);
                } else {
                    throw new IllegalArgumentException("Illegal value array type " + componentType.getCanonicalName() + " for key \"" + component1 + '\"');
                }
            } else if (component2 instanceof Serializable) {
                bundle.putSerializable(component1, (Serializable) component2);
            } else if (Build.VERSION.SDK_INT >= 18 && (component2 instanceof Binder)) {
                bundle.putBinder(component1, (IBinder) component2);
            } else if (Build.VERSION.SDK_INT >= 21 && (component2 instanceof Size)) {
                bundle.putSize(component1, (Size) component2);
            } else if (Build.VERSION.SDK_INT >= 21 && (component2 instanceof SizeF)) {
                bundle.putSizeF(component1, (SizeF) component2);
            } else {
                throw new IllegalArgumentException("Illegal value type " + component2.getClass().getCanonicalName() + " for key \"" + component1 + '\"');
            }
        }
        return bundle;
    }

    public static /* synthetic */ TextWatcher addTextChangedListener$default(TextView addTextChangedListener, Function4 beforeTextChanged, Function4 onTextChanged, Function1 afterTextChanged, int i, Object obj) {
        if ((i & 1) != 0) {
            beforeTextChanged = CommonExtKt$addTextChangedListener$1.INSTANCE;
        }
        if ((i & 2) != 0) {
            onTextChanged = CommonExtKt$addTextChangedListener$2.INSTANCE;
        }
        if ((i & 4) != 0) {
            afterTextChanged = CommonExtKt$addTextChangedListener$3.INSTANCE;
        }
        Intrinsics.checkParameterIsNotNull(addTextChangedListener, "$this$addTextChangedListener");
        Intrinsics.checkParameterIsNotNull(beforeTextChanged, "beforeTextChanged");
        Intrinsics.checkParameterIsNotNull(onTextChanged, "onTextChanged");
        Intrinsics.checkParameterIsNotNull(afterTextChanged, "afterTextChanged");
        CommonExtKt$addTextChangedListener$textWatcher$1 commonExtKt$addTextChangedListener$textWatcher$1 = new CommonExtKt$addTextChangedListener$textWatcher$1(afterTextChanged, beforeTextChanged, onTextChanged);
        addTextChangedListener.addTextChangedListener(commonExtKt$addTextChangedListener$textWatcher$1);
        return commonExtKt$addTextChangedListener$textWatcher$1;
    }

    public static final TextWatcher addTextChangedListener(TextView addTextChangedListener, Function4<? super CharSequence, ? super Integer, ? super Integer, ? super Integer, Unit> beforeTextChanged, Function4<? super CharSequence, ? super Integer, ? super Integer, ? super Integer, Unit> onTextChanged, Function1<? super Editable, Unit> afterTextChanged) {
        Intrinsics.checkParameterIsNotNull(addTextChangedListener, "$this$addTextChangedListener");
        Intrinsics.checkParameterIsNotNull(beforeTextChanged, "beforeTextChanged");
        Intrinsics.checkParameterIsNotNull(onTextChanged, "onTextChanged");
        Intrinsics.checkParameterIsNotNull(afterTextChanged, "afterTextChanged");
        CommonExtKt$addTextChangedListener$textWatcher$1 commonExtKt$addTextChangedListener$textWatcher$1 = new CommonExtKt$addTextChangedListener$textWatcher$1(afterTextChanged, beforeTextChanged, onTextChanged);
        addTextChangedListener.addTextChangedListener(commonExtKt$addTextChangedListener$textWatcher$1);
        return commonExtKt$addTextChangedListener$textWatcher$1;
    }

    public static final TextWatcher doBeforeTextChanged(TextView doBeforeTextChanged, final Function4<? super CharSequence, ? super Integer, ? super Integer, ? super Integer, Unit> action) {
        Intrinsics.checkParameterIsNotNull(doBeforeTextChanged, "$this$doBeforeTextChanged");
        Intrinsics.checkParameterIsNotNull(action, "action");
        TextWatcher textWatcher = new TextWatcher() { // from class: com.tdo.showbox.utils.CommonExtKt$doBeforeTextChanged$$inlined$addTextChangedListener$1
            @Override // android.text.TextWatcher
            public void afterTextChanged(Editable editable) {
            }

            @Override // android.text.TextWatcher
            public void onTextChanged(CharSequence charSequence, int i, int i2, int i3) {
            }

            @Override // android.text.TextWatcher
            public void beforeTextChanged(CharSequence charSequence, int i, int i2, int i3) {
                Function4.this.invoke(charSequence, Integer.valueOf(i), Integer.valueOf(i2), Integer.valueOf(i3));
            }
        };
        doBeforeTextChanged.addTextChangedListener(textWatcher);
        return textWatcher;
    }

    public static final TextWatcher doOnTextChanged(TextView doOnTextChanged, final Function4<? super CharSequence, ? super Integer, ? super Integer, ? super Integer, Unit> action) {
        Intrinsics.checkParameterIsNotNull(doOnTextChanged, "$this$doOnTextChanged");
        Intrinsics.checkParameterIsNotNull(action, "action");
        TextWatcher textWatcher = new TextWatcher() { // from class: com.tdo.showbox.utils.CommonExtKt$doOnTextChanged$$inlined$addTextChangedListener$1
            @Override // android.text.TextWatcher
            public void afterTextChanged(Editable editable) {
            }

            @Override // android.text.TextWatcher
            public void beforeTextChanged(CharSequence charSequence, int i, int i2, int i3) {
            }

            @Override // android.text.TextWatcher
            public void onTextChanged(CharSequence charSequence, int i, int i2, int i3) {
                Function4.this.invoke(charSequence, Integer.valueOf(i), Integer.valueOf(i2), Integer.valueOf(i3));
            }
        };
        doOnTextChanged.addTextChangedListener(textWatcher);
        return textWatcher;
    }

    public static final TextWatcher doAfterTextChanged(TextView doAfterTextChanged, final Function1<? super Editable, Unit> action) {
        Intrinsics.checkParameterIsNotNull(doAfterTextChanged, "$this$doAfterTextChanged");
        Intrinsics.checkParameterIsNotNull(action, "action");
        TextWatcher textWatcher = new TextWatcher() { // from class: com.tdo.showbox.utils.CommonExtKt$doAfterTextChanged$$inlined$addTextChangedListener$1
            @Override // android.text.TextWatcher
            public void beforeTextChanged(CharSequence charSequence, int i, int i2, int i3) {
            }

            @Override // android.text.TextWatcher
            public void onTextChanged(CharSequence charSequence, int i, int i2, int i3) {
            }

            @Override // android.text.TextWatcher
            public void afterTextChanged(Editable editable) {
                Function1.this.mo1719invoke(editable);
            }
        };
        doAfterTextChanged.addTextChangedListener(textWatcher);
        return textWatcher;
    }
}
