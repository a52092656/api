package com.tdo.showbox.utils;

import android.content.Context;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.InterstitialAd;
import com.mintegral.msdk.MIntegralConstans;
import com.mintegral.msdk.base.entity.CampaignEx;
import com.mintegral.msdk.interstitialvideo.out.InterstitialVideoListener;
import com.mintegral.msdk.interstitialvideo.out.MTGInterstitialVideoHandler;
import com.mintegral.msdk.out.InterstitialListener;
import com.mintegral.msdk.out.MTGInterstitialHandler;
import com.tdo.showbox.app.Constant;
import com.tdo.showbox.config.ConfigKey;
import com.tdo.showbox.config.ConfigUtils;
import com.tdo.showbox.model.AdParamModel;
import com.umeng.analytics.MobclickAgent;
import com.umeng.analytics.pro.b;
import com.zcoup.base.callback.AdEventListener;
import com.zcoup.base.core.ZCNative;
import com.zcoup.base.core.ZcoupSDK;
import com.zcoup.base.vo.AdsNativeVO;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Random;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;
/* compiled from: AdManager.kt */
@Metadata(bv = {1, 0, 3}, d1 = {"\u0000`\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u000b\u0018\u0000 (2\u00020\u0001:\u0001(B\r\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0002\u0010\u0004J\b\u0010\u001b\u001a\u00020\u001cH\u0002J\b\u0010\u001d\u001a\u00020\u001eH\u0002J\u0006\u0010\u001f\u001a\u00020\u001eJ\u0006\u0010 \u001a\u00020\u001eJ\u0010\u0010!\u001a\u00020\u001e2\u0006\u0010\"\u001a\u00020\u001cH\u0002J\b\u0010#\u001a\u00020\u001eH\u0002J\b\u0010$\u001a\u00020\u001eH\u0002J\b\u0010%\u001a\u00020\u001eH\u0002J\b\u0010&\u001a\u00020\u001eH\u0002J\u0010\u0010'\u001a\u00020\u001e2\u0006\u0010\"\u001a\u00020\u001cH\u0002R\u0010\u0010\u0005\u001a\u0004\u0018\u00010\u0006X\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010\u0007\u001a\u0004\u0018\u00010\bX\u0082\u000e¢\u0006\u0002\n\u0000R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\t\u0010\nR\u0010\u0010\u000b\u001a\u0004\u0018\u00010\fX\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010\r\u001a\u0004\u0018\u00010\u000eX\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010\u000f\u001a\u0004\u0018\u00010\u0010X\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010\u0011\u001a\u0004\u0018\u00010\u0012X\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010\u0013\u001a\u0004\u0018\u00010\u0014X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0015\u001a\u00020\u0016X\u0082\u000e¢\u0006\u0002\n\u0000R\u001e\u0010\u0017\u001a\u0012\u0012\u0004\u0012\u00020\u00190\u0018j\b\u0012\u0004\u0012\u00020\u0019`\u001aX\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006)"}, d2 = {"Lcom/tdo/showbox/utils/AdManager;", "", b.M, "Landroid/content/Context;", "(Landroid/content/Context;)V", "adListener", "Lcom/google/android/gms/ads/AdListener;", "cloudMobiListener", "Lcom/zcoup/base/callback/AdEventListener;", "getContext", "()Landroid/content/Context;", "googleAd", "Lcom/google/android/gms/ads/InterstitialAd;", "mintegraAd", "Lcom/mintegral/msdk/interstitialvideo/out/MTGInterstitialVideoHandler;", "mintegraImageAd", "Lcom/mintegral/msdk/out/MTGInterstitialHandler;", "mintegraImageListener", "Lcom/mintegral/msdk/out/InterstitialListener;", "mintegraListener", "Lcom/mintegral/msdk/interstitialvideo/out/InterstitialVideoListener;", "total", "", "valueList", "Ljava/util/ArrayList;", "Lcom/tdo/showbox/model/AdParamModel;", "Lkotlin/collections/ArrayList;", "getAdKey", "", "getParams", "", "release", "showAd", "showAdByKey", CampaignEx.LOOPBACK_KEY, "showCloudMobiInterstitialAd", "showGoogleAd", "showMintegralAd", "showMintegralImageAd", "showNextAd", "Companion", "app_webRelease"}, k = 1, mv = {1, 1, 16})
/* loaded from: classes3.dex */
public final class AdManager {
    public static final String Appnext_banner = "Appnext_banner";
    public static final String Appnext_interstitial = "Appnext_interstitial";
    public static final String Appnext_native = "Appnext_native";
    public static final String Cloudmobi_banner = "Cloudmobi_banner";
    public static final String Cloudmobi_interstitial = "Cloudmobi_interstitial";
    public static final String Cloudmobi_native = "Cloudmobi_native";
    public static final Companion Companion = new Companion(null);
    public static final String Google_banner = "Google_banner";
    public static final String Google_interstitial = "Google_interstitial";
    public static final String Google_native = "Google_native";
    public static final String Mintegral_banner = "Mintegral_banner";
    public static final String Mintegral_interstitial = "Mintegral_interstitial";
    public static final String Mintegral_native = "Mintegral_native";
    private AdListener adListener;
    private AdEventListener cloudMobiListener;
    private final Context context;
    private InterstitialAd googleAd;
    private MTGInterstitialVideoHandler mintegraAd;
    private MTGInterstitialHandler mintegraImageAd;
    private InterstitialListener mintegraImageListener;
    private InterstitialVideoListener mintegraListener;
    private int total;
    private final ArrayList<AdParamModel> valueList = new ArrayList<>();

    public AdManager(Context context) {
        Intrinsics.checkParameterIsNotNull(context, "context");
        this.context = context;
    }

    public final Context getContext() {
        return this.context;
    }

    /* compiled from: AdManager.kt */
    @Metadata(bv = {1, 0, 3}, d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\f\b\u0086\u0003\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002R\u000e\u0010\u0003\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0005\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\b\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\t\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\n\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u000b\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\f\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\r\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u000e\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u000f\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000¨\u0006\u0010"}, d2 = {"Lcom/tdo/showbox/utils/AdManager$Companion;", "", "()V", AdManager.Appnext_banner, "", AdManager.Appnext_interstitial, AdManager.Appnext_native, AdManager.Cloudmobi_banner, AdManager.Cloudmobi_interstitial, AdManager.Cloudmobi_native, AdManager.Google_banner, AdManager.Google_interstitial, AdManager.Google_native, AdManager.Mintegral_banner, AdManager.Mintegral_interstitial, AdManager.Mintegral_native, "app_webRelease"}, k = 1, mv = {1, 1, 16})
    /* loaded from: classes3.dex */
    public static final class Companion {
        private Companion() {
        }

        public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }
    }

    public final void showAd() {
        getParams();
        showAdByKey(getAdKey());
    }

    private final void showAdByKey(String str) {
        switch (str.hashCode()) {
            case -1210509302:
                if (!str.equals(ConfigKey.AD_INTERSTITIAL_MINTEGRAL_PORTION)) {
                    return;
                }
                showMintegralAd();
                return;
            case -699336986:
                if (!str.equals(ConfigKey.AD_INTERSTITIAL_MINTEGRAL_IMAGE_PORTION)) {
                    return;
                }
                showMintegralImageAd();
                return;
            case 13545272:
                if (!str.equals(ConfigKey.AD_INTERSTITIAL_GOOGLE_PORTION)) {
                    return;
                }
                showGoogleAd();
                return;
            case 1123211376:
                if (!str.equals(ConfigKey.AD_INTERSTITIAL_CLOUDMOBI_PORTION_NEW)) {
                    return;
                }
                showCloudMobiInterstitialAd();
                return;
            default:
                return;
        }
    }

    public final void release() {
        this.adListener = null;
        this.googleAd = null;
        this.mintegraListener = null;
        this.mintegraAd = null;
        this.mintegraImageAd = null;
        this.mintegraImageListener = null;
        this.cloudMobiListener = null;
    }

    private final void getParams() {
        int parseInt;
        int parseInt2;
        int parseInt3;
        int parseInt4;
        String readStringConfig = ConfigUtils.readStringConfig(ConfigKey.AD_INTERSTITIAL_GOOGLE_PORTION);
        String readStringConfig2 = ConfigUtils.readStringConfig(ConfigKey.AD_INTERSTITIAL_MINTEGRAL_PORTION);
        String readStringConfig3 = ConfigUtils.readStringConfig(ConfigKey.AD_INTERSTITIAL_MINTEGRAL_IMAGE_PORTION);
        String readStringConfig4 = ConfigUtils.readStringConfig(ConfigKey.AD_INTERSTITIAL_CLOUDMOBI_PORTION_NEW);
        String str = readStringConfig;
        boolean z = true;
        if (!(str == null || StringsKt.isBlank(str)) && (parseInt4 = Integer.parseInt(readStringConfig)) != 0) {
            this.valueList.add(new AdParamModel(ConfigKey.AD_INTERSTITIAL_GOOGLE_PORTION, parseInt4));
        }
        String str2 = readStringConfig2;
        if (!(str2 == null || StringsKt.isBlank(str2)) && (parseInt3 = Integer.parseInt(readStringConfig2)) != 0) {
            this.valueList.add(new AdParamModel(ConfigKey.AD_INTERSTITIAL_MINTEGRAL_PORTION, parseInt3));
        }
        String str3 = readStringConfig3;
        if (!(str3 == null || StringsKt.isBlank(str3)) && (parseInt2 = Integer.parseInt(readStringConfig3)) != 0) {
            this.valueList.add(new AdParamModel(ConfigKey.AD_INTERSTITIAL_MINTEGRAL_IMAGE_PORTION, parseInt2));
        }
        String str4 = readStringConfig4;
        if (str4 != null && !StringsKt.isBlank(str4)) {
            z = false;
        }
        if (!z && (parseInt = Integer.parseInt(readStringConfig4)) != 0) {
            this.valueList.add(new AdParamModel(ConfigKey.AD_INTERSTITIAL_CLOUDMOBI_PORTION_NEW, parseInt));
        }
        this.total = 0;
        for (AdParamModel adParamModel : this.valueList) {
            adParamModel.setStart(this.total);
            int num = this.total + adParamModel.getNum();
            this.total = num;
            adParamModel.setEnd(num);
        }
    }

    private final String getAdKey() {
        int nextInt = new Random().nextInt((this.total - 0) + 1) + 0;
        for (AdParamModel adParamModel : this.valueList) {
            if (nextInt >= adParamModel.getStart() && nextInt < adParamModel.getEnd()) {
                String key = adParamModel.getKey();
                Intrinsics.checkExpressionValueIsNotNull(key, "it.key");
                return key;
            }
        }
        if (!this.valueList.isEmpty()) {
            AdParamModel adParamModel2 = this.valueList.get(0);
            Intrinsics.checkExpressionValueIsNotNull(adParamModel2, "valueList[0]");
            String key2 = adParamModel2.getKey();
            Intrinsics.checkExpressionValueIsNotNull(key2, "valueList[0].key");
            return key2;
        }
        return "";
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void showNextAd(String str) {
        Iterator<AdParamModel> it = this.valueList.iterator();
        Intrinsics.checkExpressionValueIsNotNull(it, "valueList.iterator()");
        while (it.hasNext()) {
            AdParamModel next = it.next();
            Intrinsics.checkExpressionValueIsNotNull(next, "iterator.next()");
            if (Intrinsics.areEqual(next.getKey(), str)) {
                it.remove();
            }
        }
        if (this.valueList.isEmpty()) {
            return;
        }
        String adKey = getAdKey();
        String str2 = adKey;
        if (str2 == null || StringsKt.isBlank(str2)) {
            return;
        }
        showAdByKey(adKey);
    }

    private final void showCloudMobiInterstitialAd() {
        AdEventListener adEventListener = new AdEventListener() { // from class: com.tdo.showbox.utils.AdManager$showCloudMobiInterstitialAd$1
            @Override // com.zcoup.base.callback.AdEventListener
            public void onAdClicked(ZCNative zCNative) {
            }

            @Override // com.zcoup.base.callback.AdEventListener
            public void onAdClosed(ZCNative zCNative) {
            }

            @Override // com.zcoup.base.callback.AdEventListener
            public void onInterstitialLoadSucceed(ZCNative zCNative) {
            }

            @Override // com.zcoup.base.callback.AdEventListener
            public void onLandpageShown(ZCNative zCNative) {
            }

            @Override // com.zcoup.base.callback.AdEventListener
            public void onReceiveAdVoSucceed(AdsNativeVO adsNativeVO) {
            }

            @Override // com.zcoup.base.callback.AdEventListener
            public void onReceiveAdSucceed(ZCNative zCNative) {
                if (zCNative == null || !zCNative.isLoaded()) {
                    return;
                }
                if (!ZcoupSDK.isInterstitialAvailable(zCNative)) {
                    AdManager.this.showNextAd(ConfigKey.AD_INTERSTITIAL_CLOUDMOBI_PORTION_NEW);
                    return;
                }
                ZcoupSDK.showInterstitialAd(zCNative);
                MobclickAgent.onEvent(AdManager.this.getContext(), AdManager.Cloudmobi_interstitial);
            }

            @Override // com.zcoup.base.callback.AdEventListener
            public void onReceiveAdFailed(ZCNative zCNative) {
                AdManager.this.showNextAd(ConfigKey.AD_INTERSTITIAL_CLOUDMOBI_PORTION_NEW);
            }
        };
        this.cloudMobiListener = adEventListener;
        ZcoupSDK.preloadInterstitialAd(this.context, Constant.CLOUDMOBI_INTERSTITIAL_KEY, adEventListener);
    }

    private final void showMintegralImageAd() {
        HashMap hashMap = new HashMap();
        hashMap.put(MIntegralConstans.PROPERTIES_UNIT_ID, Constant.MINTEGRAL_IMAGE_INTERSTITIAL_KEY);
        this.mintegraImageAd = new MTGInterstitialHandler(this.context, hashMap);
        InterstitialListener interstitialListener = new InterstitialListener() { // from class: com.tdo.showbox.utils.AdManager$showMintegralImageAd$1
            @Override // com.mintegral.msdk.out.InterstitialListener
            public void onInterstitialAdClick() {
            }

            @Override // com.mintegral.msdk.out.InterstitialListener
            public void onInterstitialShowSuccess() {
            }

            @Override // com.mintegral.msdk.out.InterstitialListener
            public void onInterstitialLoadSuccess() {
                MTGInterstitialHandler mTGInterstitialHandler;
                MTGInterstitialHandler mTGInterstitialHandler2;
                mTGInterstitialHandler = AdManager.this.mintegraImageAd;
                if (mTGInterstitialHandler != null) {
                    mTGInterstitialHandler2 = AdManager.this.mintegraImageAd;
                    if (mTGInterstitialHandler2 == null) {
                        Intrinsics.throwNpe();
                    }
                    mTGInterstitialHandler2.show();
                    MobclickAgent.onEvent(AdManager.this.getContext(), AdManager.Mintegral_interstitial);
                }
            }

            @Override // com.mintegral.msdk.out.InterstitialListener
            public void onInterstitialLoadFail(String str) {
                AdManager.this.showNextAd(ConfigKey.AD_INTERSTITIAL_MINTEGRAL_IMAGE_PORTION);
            }

            @Override // com.mintegral.msdk.out.InterstitialListener
            public void onInterstitialClosed() {
                AdManager.this.mintegraImageAd = null;
            }

            @Override // com.mintegral.msdk.out.InterstitialListener
            public void onInterstitialShowFail(String str) {
                AdManager.this.showNextAd(ConfigKey.AD_INTERSTITIAL_MINTEGRAL_IMAGE_PORTION);
            }
        };
        this.mintegraImageListener = interstitialListener;
        MTGInterstitialHandler mTGInterstitialHandler = this.mintegraImageAd;
        if (mTGInterstitialHandler != null) {
            mTGInterstitialHandler.setInterstitialListener(interstitialListener);
            mTGInterstitialHandler.preload();
        }
    }

    private final void showMintegralAd() {
        this.mintegraAd = new MTGInterstitialVideoHandler(this.context, Constant.MINTEGRAL_VIDEO_INTERSTITIAL_KEY);
        InterstitialVideoListener interstitialVideoListener = new InterstitialVideoListener() { // from class: com.tdo.showbox.utils.AdManager$showMintegralAd$1
            @Override // com.mintegral.msdk.interstitialvideo.out.InterstitialVideoListener
            public void onAdShow() {
            }

            @Override // com.mintegral.msdk.interstitialvideo.out.InterstitialVideoListener
            public void onEndcardShow(String str) {
            }

            @Override // com.mintegral.msdk.interstitialvideo.out.InterstitialVideoListener
            public void onLoadSuccess(String str) {
            }

            @Override // com.mintegral.msdk.interstitialvideo.out.InterstitialVideoListener
            public void onVideoAdClicked(String str) {
            }

            @Override // com.mintegral.msdk.interstitialvideo.out.InterstitialVideoListener
            public void onVideoComplete(String str) {
            }

            @Override // com.mintegral.msdk.interstitialvideo.out.InterstitialVideoListener
            public void onVideoLoadSuccess(String str) {
                MTGInterstitialVideoHandler mTGInterstitialVideoHandler;
                MTGInterstitialVideoHandler mTGInterstitialVideoHandler2;
                MTGInterstitialVideoHandler mTGInterstitialVideoHandler3;
                mTGInterstitialVideoHandler = AdManager.this.mintegraAd;
                if (mTGInterstitialVideoHandler != null) {
                    mTGInterstitialVideoHandler2 = AdManager.this.mintegraAd;
                    if (mTGInterstitialVideoHandler2 == null) {
                        Intrinsics.throwNpe();
                    }
                    if (mTGInterstitialVideoHandler2.isReady()) {
                        mTGInterstitialVideoHandler3 = AdManager.this.mintegraAd;
                        if (mTGInterstitialVideoHandler3 == null) {
                            Intrinsics.throwNpe();
                        }
                        mTGInterstitialVideoHandler3.show();
                        MobclickAgent.onEvent(AdManager.this.getContext(), AdManager.Mintegral_interstitial);
                        return;
                    }
                }
                AdManager.this.showNextAd(ConfigKey.AD_INTERSTITIAL_MINTEGRAL_PORTION);
            }

            @Override // com.mintegral.msdk.interstitialvideo.out.InterstitialVideoListener
            public void onShowFail(String str) {
                AdManager.this.showNextAd(ConfigKey.AD_INTERSTITIAL_MINTEGRAL_PORTION);
            }

            @Override // com.mintegral.msdk.interstitialvideo.out.InterstitialVideoListener
            public void onVideoLoadFail(String str) {
                AdManager.this.showNextAd(ConfigKey.AD_INTERSTITIAL_MINTEGRAL_PORTION);
            }

            @Override // com.mintegral.msdk.interstitialvideo.out.InterstitialVideoListener
            public void onAdClose(boolean z) {
                AdManager.this.mintegraAd = null;
            }
        };
        this.mintegraListener = interstitialVideoListener;
        MTGInterstitialVideoHandler mTGInterstitialVideoHandler = this.mintegraAd;
        if (mTGInterstitialVideoHandler != null) {
            mTGInterstitialVideoHandler.setInterstitialVideoListener(interstitialVideoListener);
            mTGInterstitialVideoHandler.playVideoMute(1);
            mTGInterstitialVideoHandler.load();
        }
    }

    private final void showGoogleAd() {
        final InterstitialAd interstitialAd = new InterstitialAd(this.context);
        this.googleAd = interstitialAd;
        if (interstitialAd != null) {
            interstitialAd.setAdUnitId(Constant.GOOGLE_FULLSCREEN_AD_KEY);
            AdListener adListener = new AdListener() { // from class: com.tdo.showbox.utils.AdManager$showGoogleAd$$inlined$let$lambda$1
                @Override // com.google.android.gms.ads.AdListener
                public void onAdFailedToLoad(int i) {
                    super.onAdFailedToLoad(i);
                    this.showNextAd(ConfigKey.AD_INTERSTITIAL_GOOGLE_PORTION);
                }

                @Override // com.google.android.gms.ads.AdListener
                public void onAdLoaded() {
                    super.onAdLoaded();
                    if (InterstitialAd.this.isLoaded()) {
                        InterstitialAd.this.show();
                        MobclickAgent.onEvent(this.getContext(), AdManager.Google_interstitial);
                    }
                }

                @Override // com.google.android.gms.ads.AdListener
                public void onAdClosed() {
                    super.onAdClosed();
                    this.googleAd = null;
                }
            };
            this.adListener = adListener;
            interstitialAd.setAdListener(adListener);
            interstitialAd.loadAd(new AdRequest.Builder().build());
        }
    }
}
