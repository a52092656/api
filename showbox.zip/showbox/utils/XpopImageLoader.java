package com.tdo.showbox.utils;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.widget.ImageView;
import android.widget.ProgressBar;
import com.bumptech.glide.Glide;
import com.bumptech.glide.RequestBuilder;
import com.bumptech.glide.request.BaseRequestOptions;
import com.bumptech.glide.request.RequestOptions;
import com.bumptech.glide.request.target.SimpleTarget;
import com.bumptech.glide.request.transition.Transition;
import com.lxj.xpopup.interfaces.OnImageLoadCompleteListener;
import com.lxj.xpopup.interfaces.XPopupImageLoader;
import java.io.File;
/* loaded from: classes3.dex */
public class XpopImageLoader implements XPopupImageLoader {
    @Override // com.lxj.xpopup.interfaces.XPopupImageLoader
    public void loadImage(final Context context, int i, final Object obj, final ImageView imageView, ProgressBar progressBar, final OnImageLoadCompleteListener onImageLoadCompleteListener) {
        imageView.post(new Runnable() { // from class: com.tdo.showbox.utils.XpopImageLoader.1
            @Override // java.lang.Runnable
            public void run() {
                Glide.with(context).mo572asDrawable().mo582load(obj).into((RequestBuilder<Drawable>) new SimpleTarget<Drawable>(imageView.getWidth(), imageView.getHeight()) { // from class: com.tdo.showbox.utils.XpopImageLoader.1.1
                    @Override // com.bumptech.glide.request.target.Target
                    public /* bridge */ /* synthetic */ void onResourceReady(Object obj2, Transition transition) {
                        onResourceReady((Drawable) obj2, (Transition<? super Drawable>) transition);
                    }

                    public void onResourceReady(Drawable drawable, Transition<? super Drawable> transition) {
                        imageView.setImageDrawable(drawable);
                        onImageLoadCompleteListener.onImageLoadComplete();
                    }

                    @Override // com.bumptech.glide.request.target.BaseTarget, com.bumptech.glide.request.target.Target
                    public void onLoadStarted(Drawable drawable) {
                        super.onLoadStarted(drawable);
                        onImageLoadCompleteListener.onImageStartLoad();
                    }
                });
            }
        });
    }

    @Override // com.lxj.xpopup.interfaces.XPopupImageLoader
    public void loadImage(int i, Object obj, ImageView imageView) {
        Glide.with(imageView).mo582load(obj).mo507apply((BaseRequestOptions<?>) new RequestOptions().override(imageView.getWidth(), imageView.getHeight())).into(imageView);
    }

    @Override // com.lxj.xpopup.interfaces.XPopupImageLoader
    public File getImageFile(Context context, Object obj) {
        try {
            return Glide.with(context).mo576downloadOnly().mo582load(obj).submit().get();
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}
