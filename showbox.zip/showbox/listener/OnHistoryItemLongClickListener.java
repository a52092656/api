package com.tdo.showbox.listener;
/* loaded from: classes3.dex */
public interface OnHistoryItemLongClickListener {
    void onHistoryItemLongClick(String str, int i, int i2);
}
