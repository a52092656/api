package com.tdo.showbox.listener;
/* loaded from: classes.dex */
public interface OnFavoriteStatusChangedListener {
    void hideLoadLoading();

    void onFavoriteStatusChanged(boolean z);

    void showLoadLoading();

    void showViewToast(String str);
}
