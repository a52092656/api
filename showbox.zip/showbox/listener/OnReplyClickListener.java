package com.tdo.showbox.listener;

import android.view.View;
import com.tdo.showbox.model.ReviewModel;
/* loaded from: classes3.dex */
public interface OnReplyClickListener {
    void goSingleReview(String str);

    void onMoreActionClicked(ReviewModel reviewModel, View view, int i);

    void onReplyClicked(int i, ReviewModel reviewModel);
}
