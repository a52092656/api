package com.tdo.showbox.view.activity;

import io.reactivex.functions.Consumer;
/* compiled from: lambda */
/* renamed from: com.tdo.showbox.view.activity.-$$Lambda$MainActivity$d4pEZlT4iH5JiFsRjT6PDThEh1Q  reason: invalid class name */
/* loaded from: classes.dex */
public final /* synthetic */ class $$Lambda$MainActivity$d4pEZlT4iH5JiFsRjT6PDThEh1Q implements Consumer {
    public static final /* synthetic */ $$Lambda$MainActivity$d4pEZlT4iH5JiFsRjT6PDThEh1Q INSTANCE = new $$Lambda$MainActivity$d4pEZlT4iH5JiFsRjT6PDThEh1Q();

    private /* synthetic */ $$Lambda$MainActivity$d4pEZlT4iH5JiFsRjT6PDThEh1Q() {
    }

    @Override // io.reactivex.functions.Consumer
    public final void accept(Object obj) {
        MainActivity.lambda$statService$2((Throwable) obj);
    }
}
