package com.tdo.showbox.view.activity;

import io.reactivex.functions.Consumer;
/* compiled from: lambda */
/* renamed from: com.tdo.showbox.view.activity.-$$Lambda$MainActivity$8rN3GR4Xf1TkeTv1fHVk-4la8UE  reason: invalid class name */
/* loaded from: classes.dex */
public final /* synthetic */ class $$Lambda$MainActivity$8rN3GR4Xf1TkeTv1fHVk4la8UE implements Consumer {
    public static final /* synthetic */ $$Lambda$MainActivity$8rN3GR4Xf1TkeTv1fHVk4la8UE INSTANCE = new $$Lambda$MainActivity$8rN3GR4Xf1TkeTv1fHVk4la8UE();

    private /* synthetic */ $$Lambda$MainActivity$8rN3GR4Xf1TkeTv1fHVk4la8UE() {
    }

    @Override // io.reactivex.functions.Consumer
    public final void accept(Object obj) {
        MainActivity.lambda$initData$4((Boolean) obj);
    }
}
