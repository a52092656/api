package com.tdo.showbox.view.activity.choose.impl;

import android.view.View;
import android.widget.RelativeLayout;
import android.widget.Switch;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import butterknife.Unbinder;
import butterknife.internal.DebouncingOnClickListener;
import butterknife.internal.Utils;
import com.tdo.showbox.R;
/* loaded from: classes3.dex */
public class ChooseActivity_ViewBinding implements Unbinder {
    private ChooseActivity target;
    private View view7f0900e0;
    private View view7f0900e1;

    public ChooseActivity_ViewBinding(ChooseActivity chooseActivity) {
        this(chooseActivity, chooseActivity.getWindow().getDecorView());
    }

    public ChooseActivity_ViewBinding(final ChooseActivity chooseActivity, View view) {
        this.target = chooseActivity;
        chooseActivity.mRecycler = (RecyclerView) Utils.findRequiredViewAsType(view, R.id.recycler_normal, "field 'mRecycler'", RecyclerView.class);
        chooseActivity.mBackRound = (RelativeLayout) Utils.findRequiredViewAsType(view, R.id.choose_backround, "field 'mBackRound'", RelativeLayout.class);
        View findRequiredView = Utils.findRequiredView(view, R.id.choose_close, "field 'mClose' and method 'onViewClicked'");
        chooseActivity.mClose = (TextView) Utils.castView(findRequiredView, R.id.choose_close, "field 'mClose'", TextView.class);
        this.view7f0900e0 = findRequiredView;
        findRequiredView.setOnClickListener(new DebouncingOnClickListener() { // from class: com.tdo.showbox.view.activity.choose.impl.ChooseActivity_ViewBinding.1
            @Override // butterknife.internal.DebouncingOnClickListener
            public void doClick(View view2) {
                chooseActivity.onViewClicked(view2);
            }
        });
        View findRequiredView2 = Utils.findRequiredView(view, R.id.choose_download, "field 'mDowload' and method 'onViewClicked'");
        chooseActivity.mDowload = (TextView) Utils.castView(findRequiredView2, R.id.choose_download, "field 'mDowload'", TextView.class);
        this.view7f0900e1 = findRequiredView2;
        findRequiredView2.setOnClickListener(new DebouncingOnClickListener() { // from class: com.tdo.showbox.view.activity.choose.impl.ChooseActivity_ViewBinding.2
            @Override // butterknife.internal.DebouncingOnClickListener
            public void doClick(View view2) {
                chooseActivity.onViewClicked(view2);
            }
        });
        chooseActivity.mSize = (TextView) Utils.findRequiredViewAsType(view, R.id.choose_size, "field 'mSize'", TextView.class);
        chooseActivity.mH265 = (Switch) Utils.findRequiredViewAsType(view, R.id.setting_h265_more, "field 'mH265'", Switch.class);
    }

    @Override // butterknife.Unbinder
    public void unbind() {
        ChooseActivity chooseActivity = this.target;
        if (chooseActivity == null) {
            throw new IllegalStateException("Bindings already cleared.");
        }
        this.target = null;
        chooseActivity.mRecycler = null;
        chooseActivity.mBackRound = null;
        chooseActivity.mClose = null;
        chooseActivity.mDowload = null;
        chooseActivity.mSize = null;
        chooseActivity.mH265 = null;
        this.view7f0900e0.setOnClickListener(null);
        this.view7f0900e0 = null;
        this.view7f0900e1.setOnClickListener(null);
        this.view7f0900e1 = null;
    }
}
