package com.tdo.showbox.view.activity.choose.impl;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.Switch;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import butterknife.BindView;
import butterknife.OnClick;
import butterknife.Unbinder;
import butterknife.internal.Utils;
import com.bumptech.glide.Glide;
import com.google.android.gms.cast.MediaInfo;
import com.google.android.gms.cast.MediaMetadata;
import com.google.android.gms.cast.MediaQueueItem;
import com.google.android.gms.cast.framework.CastContext;
import com.google.android.gms.cast.framework.CastSession;
import com.google.android.gms.cast.framework.media.RemoteMediaClient;
import com.google.android.gms.common.api.ResultCallback;
import com.google.android.gms.common.images.WebImage;
import com.tdo.showbox.R;
import com.tdo.showbox.app.App;
import com.tdo.showbox.app.AppManager;
import com.tdo.showbox.app.Constant;
import com.tdo.showbox.app.RxManager;
import com.tdo.showbox.base.BaseActivity;
import com.tdo.showbox.base.BaseAdapter;
import com.tdo.showbox.base.BaseViewHolder;
import com.tdo.showbox.base.OnItemClickListener;
import com.tdo.showbox.http.CallManager;
import com.tdo.showbox.http.HttpUtils;
import com.tdo.showbox.model.BaseMediaModel;
import com.tdo.showbox.model.PlayerStrategy;
import com.tdo.showbox.model.common.Srt;
import com.tdo.showbox.model.movie.MovieDetail;
import com.tdo.showbox.model.tv.TvDetail;
import com.tdo.showbox.presenter.ChromeCastPresenter;
import com.tdo.showbox.presenter.activity.PsChoose;
import com.tdo.showbox.service.SubtitleDownloadService;
import com.tdo.showbox.utils.CommonUtils;
import com.tdo.showbox.utils.MLog;
import com.tdo.showbox.utils.MemoryUtils;
import com.tdo.showbox.utils.Network;
import com.tdo.showbox.utils.PrefsUtils;
import com.tdo.showbox.utils.RxUtils;
import com.tdo.showbox.utils.TimeUtils;
import com.tdo.showbox.utils.ToastUtils;
import com.tdo.showbox.view.activity.choose.IChoose;
import com.tdo.showbox.view.activity.choose.impl.ChooseActivity;
import com.tdo.showbox.view.activity.download.DownloadingActivity;
import com.tdo.showbox.view.activity.movie.MovieChooseActivity;
import com.tdo.showbox.view.activity.user.Login2Activity;
import com.tdo.showbox.view.activity.user.VipActivity;
import com.tdo.showbox.view.dialog.DialogAction;
import com.tdo.showbox.view.dialog.MsgHintDialog;
import com.tdo.showbox.view.dialog.PlayAddToCastDialog;
import com.tdo.showbox.view.widget.MyLinearLayoutManager;
import com.uber.autodispose.ObservableSubscribeProxy;
import com.umeng.analytics.MobclickAgent;
import io.reactivex.Observable;
import io.reactivex.Observer;
import io.reactivex.disposables.Disposable;
import io.reactivex.functions.Function;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import org.eclipse.jetty.http.HttpHeaders;
/* loaded from: classes3.dex */
public class ChooseActivity extends BaseActivity implements IChoose {
    public static final String ISDOWNLOAD = "isDownload";
    private ChooseAdapter mAdapter;
    @BindView(R.id.choose_backround)
    RelativeLayout mBackRound;
    @BindView(R.id.choose_close)
    TextView mClose;
    @BindView(R.id.choose_download)
    TextView mDowload;
    @BindView(R.id.setting_h265_more)
    Switch mH265;
    private PsChoose mPresenter;
    @BindView(R.id.recycler_normal)
    RecyclerView mRecycler;
    @BindView(R.id.choose_size)
    TextView mSize;
    private PlayerStrategy player;
    private boolean isDownload = false;
    public List<BaseMediaModel.DownloadFile> list = new ArrayList();
    public List<BaseMediaModel.DownloadFile> list2 = new ArrayList();
    public List<BaseMediaModel.DownloadFile> H265 = new ArrayList();
    public List<BaseMediaModel.DownloadFile> H264 = new ArrayList();
    public LinkedHashMap<Integer, List<BaseMediaModel.DownloadFile>> download = new LinkedHashMap<>();
    OnItemClickListener onItemClickListener = new AnonymousClass1();

    @Override // com.tdo.showbox.base.BaseActivity
    protected int getStatusTintColor() {
        return R.color.color_main;
    }

    /* loaded from: classes3.dex */
    public class Item1ViewHolder_ViewBinding implements Unbinder {
        private Item1ViewHolder target;

        public Item1ViewHolder_ViewBinding(Item1ViewHolder item1ViewHolder, View view) {
            this.target = item1ViewHolder;
            item1ViewHolder.mTheme = (ImageView) Utils.findRequiredViewAsType(view, R.id.layout_choose_theme, "field 'mTheme'", ImageView.class);
            item1ViewHolder.mFormat = (ImageView) Utils.findRequiredViewAsType(view, R.id.layout_choose_format, "field 'mFormat'", ImageView.class);
            item1ViewHolder.mFormatDark = (ImageView) Utils.findRequiredViewAsType(view, R.id.layout_choose_format_dark, "field 'mFormatDark'", ImageView.class);
            item1ViewHolder.mSize = (TextView) Utils.findRequiredViewAsType(view, R.id.layout_choose_size, "field 'mSize'", TextView.class);
            item1ViewHolder.mTime = (TextView) Utils.findRequiredViewAsType(view, R.id.layout_choose_time, "field 'mTime'", TextView.class);
            item1ViewHolder.mName = (TextView) Utils.findRequiredViewAsType(view, R.id.layout_choose_name, "field 'mName'", TextView.class);
            item1ViewHolder.mDownlaod = (ImageView) Utils.findRequiredViewAsType(view, R.id.layout_choose_download, "field 'mDownlaod'", ImageView.class);
            item1ViewHolder.mSelect = (TextView) Utils.findRequiredViewAsType(view, R.id.layout_choose_select, "field 'mSelect'", TextView.class);
            item1ViewHolder.mVip = (ImageView) Utils.findRequiredViewAsType(view, R.id.layout_choose_vip, "field 'mVip'", ImageView.class);
            item1ViewHolder.tvRate = (TextView) Utils.findRequiredViewAsType(view, R.id.tv_rate, "field 'tvRate'", TextView.class);
        }

        @Override // butterknife.Unbinder
        public void unbind() {
            Item1ViewHolder item1ViewHolder = this.target;
            if (item1ViewHolder == null) {
                throw new IllegalStateException("Bindings already cleared.");
            }
            this.target = null;
            item1ViewHolder.mTheme = null;
            item1ViewHolder.mFormat = null;
            item1ViewHolder.mFormatDark = null;
            item1ViewHolder.mSize = null;
            item1ViewHolder.mTime = null;
            item1ViewHolder.mName = null;
            item1ViewHolder.mDownlaod = null;
            item1ViewHolder.mSelect = null;
            item1ViewHolder.mVip = null;
            item1ViewHolder.tvRate = null;
        }
    }

    public static void start(Context context, boolean z, PlayerStrategy playerStrategy) {
        Intent intent = new Intent(context, ChooseActivity.class);
        intent.putExtra(ISDOWNLOAD, z);
        intent.putExtra(MovieChooseActivity.CHOOSEMOVIE, playerStrategy);
        context.startActivity(intent);
    }

    @OnClick({R.id.choose_download, R.id.choose_close})
    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.choose_close /* 2131296480 */:
                finish();
                return;
            case R.id.choose_download /* 2131296481 */:
                route(DownloadingActivity.class);
                return;
            default:
                return;
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* renamed from: com.tdo.showbox.view.activity.choose.impl.ChooseActivity$1  reason: invalid class name */
    /* loaded from: classes3.dex */
    public class AnonymousClass1 implements OnItemClickListener {
        AnonymousClass1() {
        }

        @Override // com.tdo.showbox.base.OnItemClickListener
        public void onItemClick(final int i) {
            if (i < 0 || i > ChooseActivity.this.mAdapter.getItemCount() - 1) {
                return;
            }
            BaseMediaModel.DownloadFile model = ChooseActivity.this.mAdapter.getModel(i);
            if (!TextUtils.isEmpty(model.path) && model.path != null) {
                if (!ChooseActivity.this.isDownload) {
                    CastSession castSession = null;
                    try {
                        castSession = CastContext.getSharedInstance(ChooseActivity.this.context).getSessionManager().getCurrentCastSession();
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    if (castSession != null && castSession.isConnected()) {
                        ChooseActivity.this.mPresenter.get_DownaloadSrt(ChooseActivity.this.player.getId(), ChooseActivity.this.player.getSeason(), ChooseActivity.this.player.getEpisode(), model.path);
                        return;
                    } else if (PrefsUtils.getInstance().getBoolean(Constant.Prefs.USER_CELLUAR_DOWNLOAD, false) || Network.isWifiConnected(ChooseActivity.this)) {
                        ChooseActivity.this.checkHaveEnoughSpace(i);
                        return;
                    } else {
                        new MsgHintDialog.Builder(ChooseActivity.this).setTitle("Note").setContent("You are using celluar,continue to download?").setActionListener(new DialogAction.ActionListener() { // from class: com.tdo.showbox.view.activity.choose.impl.-$$Lambda$ChooseActivity$1$wQdMX3P4xw9BaeughysQuGUbdLc
                            @Override // com.tdo.showbox.view.dialog.DialogAction.ActionListener
                            public final void onClick() {
                                ChooseActivity.AnonymousClass1.this.lambda$onItemClick$0$ChooseActivity$1(i);
                            }
                        }).create().show();
                        return;
                    }
                } else if (PrefsUtils.getInstance().getBoolean(Constant.Prefs.USER_CELLUAR_DOWNLOAD, false) || Network.isWifiConnected(ChooseActivity.this)) {
                    ChooseActivity.this.checkHaveEnoughSpace(i);
                    return;
                } else {
                    new MsgHintDialog.Builder(ChooseActivity.this).setTitle("Note").setContent("You are using celluar,continue to download?").setActionListener(new DialogAction.ActionListener() { // from class: com.tdo.showbox.view.activity.choose.impl.-$$Lambda$ChooseActivity$1$EG2Nxdh0XHF2JDOeUMPZNl5nrAQ
                        @Override // com.tdo.showbox.view.dialog.DialogAction.ActionListener
                        public final void onClick() {
                            ChooseActivity.AnonymousClass1.this.lambda$onItemClick$1$ChooseActivity$1(i);
                        }
                    }).create().show();
                    return;
                }
            }
            ChooseActivity.this.finish();
            if (App.isLogin()) {
                if (App.getUserData().isvip == 1) {
                    ToastUtils.showShort("no file");
                    return;
                } else {
                    ChooseActivity.this.route(VipActivity.class);
                    return;
                }
            }
            ChooseActivity.this.route(Login2Activity.class);
        }

        public /* synthetic */ void lambda$onItemClick$0$ChooseActivity$1(int i) {
            ChooseActivity.this.checkHaveEnoughSpace(i);
        }

        public /* synthetic */ void lambda$onItemClick$1$ChooseActivity$1(int i) {
            ChooseActivity.this.checkHaveEnoughSpace(i);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void checkHaveEnoughSpace(final int i) {
        ((ObservableSubscribeProxy) Observable.just(Integer.valueOf(i)).map(new Function() { // from class: com.tdo.showbox.view.activity.choose.impl.-$$Lambda$ChooseActivity$YQyspZBBWKz-xYzW50K4wV3CgME
            @Override // io.reactivex.functions.Function
            /* renamed from: apply */
            public final Object mo704apply(Object obj) {
                return ChooseActivity.this.lambda$checkHaveEnoughSpace$0$ChooseActivity(i, (Integer) obj);
            }
        }).compose(RxUtils.rxSchedulerHelper()).as(RxUtils.bindLifecycleOwner(this))).subscribe(new Observer<Boolean>() { // from class: com.tdo.showbox.view.activity.choose.impl.ChooseActivity.2
            @Override // io.reactivex.Observer
            public void onSubscribe(Disposable disposable) {
                ChooseActivity.this.showLoading();
            }

            @Override // io.reactivex.Observer
            public void onNext(Boolean bool) {
                Intent intent = new Intent(ChooseActivity.this, SubtitleDownloadService.class);
                if (bool.booleanValue()) {
                    if (ChooseActivity.this.player.getInstace() instanceof TvDetail) {
                        TvDetail tvDetail = (TvDetail) ChooseActivity.this.player.getInstace();
                        intent.putExtra("id", tvDetail.id);
                        intent.putExtra("name", tvDetail.title);
                        intent.putExtra("episode", ChooseActivity.this.player.getEpisode());
                        intent.putExtra("season", ChooseActivity.this.player.getSeason());
                    } else {
                        MovieDetail movieDetail = (MovieDetail) ChooseActivity.this.player.getInstace();
                        intent.putExtra("id", movieDetail.id);
                        intent.putExtra("name", movieDetail.title);
                    }
                    ChooseActivity.this.startService(intent);
                    ChooseActivity.this.shouldLoad(i);
                    ChooseActivity.this.finish();
                }
            }

            @Override // io.reactivex.Observer
            public void onError(Throwable th) {
                ChooseActivity.this.hideLoading();
                ToastUtils.showShort("Download failed:" + th.getMessage());
            }

            @Override // io.reactivex.Observer
            public void onComplete() {
                ChooseActivity.this.hideLoading();
            }
        });
    }

    public /* synthetic */ Boolean lambda$checkHaveEnoughSpace$0$ChooseActivity(int i, Integer num) throws Exception {
        if (this.player.getDownload() != null) {
            ToastUtils.showShort("Already Download");
            return false;
        } else if (i < 0) {
            ToastUtils.showShort("Path is Empty");
            return false;
        } else {
            PlayerStrategy playerStrategy = this.player;
            if (playerStrategy != null) {
                if (playerStrategy.getSeason() > 0 && this.player.getEpisode() > 0) {
                    MobclickAgent.onEvent(this, "DownloadTV");
                } else {
                    MobclickAgent.onEvent(this, "DownloadMovie");
                }
            }
            HttpURLConnection httpURLConnection = (HttpURLConnection) new URL(this.mAdapter.getModel(i).path).openConnection();
            httpURLConnection.setRequestMethod("GET");
            httpURLConnection.setConnectTimeout(10000);
            httpURLConnection.setRequestProperty(HttpHeaders.ACCEPT_ENCODING, "identity");
            httpURLConnection.connect();
            long contentLength = httpURLConnection.getContentLength();
            if (contentLength < 0) {
                contentLength = Long.parseLong(httpURLConnection.getHeaderField("Content-Length"));
            }
            Log.d("ChooseChoose", "AvaliSpace" + MemoryUtils.getAvailSpaceSize(this) + "FileSize" + contentLength);
            httpURLConnection.disconnect();
            if (MemoryUtils.getAvailSpaceSize(this) > contentLength) {
                return true;
            }
            ToastUtils.showShort("Not enough space");
            return false;
        }
    }

    public void shouldLoad(int i) {
        if (this.player.getDownload() != null) {
            showToast("Already Download");
        } else if (i < 0) {
            showToast("Path is Empty");
        } else {
            this.player.SaveInDao(i, this.activity);
        }
    }

    @Override // com.tdo.showbox.view.listener.IViewController
    public View loadView(LayoutInflater layoutInflater, ViewGroup viewGroup) {
        return layoutInflater.inflate(R.layout.activity_choosemovie, viewGroup, false);
    }

    @Override // com.tdo.showbox.base.BaseActivity, com.tdo.showbox.view.listener.IViewController
    public void initPresenter() {
        this.mPresenter = new PsChoose(this.activity, this);
    }

    @Override // com.tdo.showbox.view.listener.IViewController
    public void initView() {
        boolean z = false;
        setTitleBar(false);
        if (this.mAdapter == null) {
            this.mAdapter = new ChooseAdapter(this.list);
            this.mRecycler.setLayoutManager(new MyLinearLayoutManager(this.context));
            this.mRecycler.setAdapter(this.mAdapter);
            this.mAdapter.setListener(this.onItemClickListener);
        }
        TextView textView = this.mSize;
        StringBuilder sb = new StringBuilder();
        sb.append(MemoryUtils.getAvailSpace(this.context));
        sb.append(" Free");
        textView.setText(sb);
        int i = PrefsUtils.getInstance().getInt(Constant.Prefs.SHOW_H265, 1);
        Switch r3 = this.mH265;
        if (i == 1) {
            z = true;
        }
        r3.setChecked(z);
        this.mH265.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() { // from class: com.tdo.showbox.view.activity.choose.impl.-$$Lambda$ChooseActivity$_Brd407EnnOHpnS7FlY0TByzfv8
            @Override // android.widget.CompoundButton.OnCheckedChangeListener
            public final void onCheckedChanged(CompoundButton compoundButton, boolean z2) {
                ChooseActivity.this.lambda$initView$1$ChooseActivity(compoundButton, z2);
            }
        });
    }

    public /* synthetic */ void lambda$initView$1$ChooseActivity(CompoundButton compoundButton, boolean z) {
        if (z) {
            List<BaseMediaModel.DownloadFile> list = this.H265;
            this.list = list;
            this.mAdapter.setData(list);
            PrefsUtils.getInstance().putInt(Constant.Prefs.SHOW_H265, 1);
            return;
        }
        List<BaseMediaModel.DownloadFile> list2 = this.H264;
        this.list = list2;
        this.mAdapter.setData(list2);
        PrefsUtils.getInstance().putInt(Constant.Prefs.SHOW_H265, 0);
    }

    @Override // com.tdo.showbox.view.listener.IViewController
    public void initData() {
        this.isDownload = ((Boolean) getSerializable(ISDOWNLOAD, false)).booleanValue();
        this.player = (PlayerStrategy) getSerializable(MovieChooseActivity.CHOOSEMOVIE, new PlayerStrategy());
        String str = this.TAG;
        MLog.d(str, "SSSS : " + this.player.getId() + " : " + this.player.getSeason() + " : " + this.player.getEpisode());
        this.mPresenter.setFactory(this.player.switchBean());
        this.mPresenter.getPath(this.player.getId(), this.player.getSeason(), this.player.getEpisode());
    }

    @Override // com.tdo.showbox.view.activity.choose.IChoose
    public void setPath(BaseMediaModel baseMediaModel) {
        String str = this.TAG;
        StringBuilder sb = new StringBuilder();
        sb.append("!!!");
        sb.append(baseMediaModel.list != null && baseMediaModel.list.size() > 0);
        MLog.d(str, sb.toString());
        this.player.addDonwload(baseMediaModel);
        this.list.clear();
        this.list.addAll(baseMediaModel.list);
        this.mAdapter.notifyDataSetChanged();
    }

    @Override // com.tdo.showbox.view.activity.choose.IChoose
    public void getSrt(List<Srt> list, String str) {
        ArrayList arrayList = new ArrayList();
        if (list != null) {
            int i = 1;
            for (Srt srt : list) {
                arrayList.add(ChromeCastPresenter.buildTrack(i, "text", "subtitle", "https://www.showbox.media/api/srttovtt/index?srt_url=" + HttpUtils.toURLEncoded(srt.file_path), srt.file_path.substring(srt.file_path.lastIndexOf("/") + 1), srt.lang));
                i++;
            }
        }
        MediaMetadata mediaMetadata = new MediaMetadata(1);
        mediaMetadata.putString(MediaMetadata.KEY_TITLE, ((BaseMediaModel) this.player.getInstace()).title);
        if (this.player.getSeason() != 0 && this.player.getEpisode() != 0) {
            mediaMetadata.putString(MediaMetadata.KEY_SUBTITLE, String.format("S%s E%s", CommonUtils.formatInteger(this.player.getSeason()), CommonUtils.formatInteger(this.player.getEpisode())));
        }
        mediaMetadata.addImage(new WebImage(Uri.parse(((BaseMediaModel) this.player.getInstace()).poster)));
        mediaMetadata.addImage(new WebImage(Uri.parse(((BaseMediaModel) this.player.getInstace()).poster)));
        MediaInfo build = new MediaInfo.Builder(str).setStreamType(1).setContentType("videos/mp4").setMetadata(mediaMetadata).setMediaTracks(arrayList).build();
        CastSession currentCastSession = CastContext.getSharedInstance(this.activity).getSessionManager().getCurrentCastSession();
        if (currentCastSession == null || !currentCastSession.isConnected()) {
            Log.w(this.TAG, "showQueuePopup(): not connected to a cast device");
            return;
        }
        final RemoteMediaClient remoteMediaClient = currentCastSession.getRemoteMediaClient();
        if (remoteMediaClient == null) {
            Log.w(this.TAG, "showQueuePopup(): null RemoteMediaClient");
            return;
        }
        final MediaQueueItem build2 = new MediaQueueItem.Builder(build).setAutoplay(true).setPreloadTime(20.0d).build();
        PlayAddToCastDialog playAddToCastDialog = new PlayAddToCastDialog(this, new PlayAddToCastDialog.OnPlayAddListener() { // from class: com.tdo.showbox.view.activity.choose.impl.ChooseActivity.3
            @Override // com.tdo.showbox.view.dialog.PlayAddToCastDialog.OnPlayAddListener
            public void onPlay() {
                if (remoteMediaClient.getMediaQueue() != null && remoteMediaClient.getMediaQueue().getItemCount() > 0) {
                    int i2 = -1;
                    if (remoteMediaClient.getCurrentItem() != null) {
                        i2 = remoteMediaClient.getCurrentItem().getItemId();
                    }
                    remoteMediaClient.queueInsertAndPlayItem(build2, i2, null).setResultCallback(new ResultCallback<RemoteMediaClient.MediaChannelResult>() { // from class: com.tdo.showbox.view.activity.choose.impl.ChooseActivity.3.1
                        @Override // com.google.android.gms.common.api.ResultCallback
                        public void onResult(RemoteMediaClient.MediaChannelResult mediaChannelResult) {
                            if (mediaChannelResult.getStatus().isSuccess()) {
                                ChooseActivity.this.finish();
                            } else {
                                ToastUtils.showShort("Play failed");
                            }
                        }
                    });
                    AppManager.finish(MovieChooseActivity.class);
                    return;
                }
                MobclickAgent.onEvent(ChooseActivity.this, "StartChromeCast");
                remoteMediaClient.queueLoad(new MediaQueueItem[]{build2}, 0, 0, null);
                ChooseActivity.this.finish();
            }

            @Override // com.tdo.showbox.view.dialog.PlayAddToCastDialog.OnPlayAddListener
            public void onAdd() {
                if (remoteMediaClient.getMediaQueue() != null && remoteMediaClient.getMediaQueue().getItemCount() > 0) {
                    remoteMediaClient.queueAppendItem(build2, null).setResultCallback(new ResultCallback<RemoteMediaClient.MediaChannelResult>() { // from class: com.tdo.showbox.view.activity.choose.impl.ChooseActivity.3.2
                        @Override // com.google.android.gms.common.api.ResultCallback
                        public void onResult(RemoteMediaClient.MediaChannelResult mediaChannelResult) {
                            if (mediaChannelResult.getStatus().isSuccess()) {
                                ToastUtils.showShort("Add to queue successfully");
                                ChooseActivity.this.finish();
                                return;
                            }
                            ToastUtils.showShort("Play failed");
                        }
                    });
                    AppManager.finish(MovieChooseActivity.class);
                    return;
                }
                MobclickAgent.onEvent(ChooseActivity.this, "StartChromeCast");
                remoteMediaClient.queueLoad(new MediaQueueItem[]{build2}, 0, 0, null);
                ChooseActivity.this.finish();
            }
        });
        if (isFinishing()) {
            return;
        }
        playAddToCastDialog.show();
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // com.tdo.showbox.base.BaseActivity, androidx.appcompat.app.AppCompatActivity, androidx.fragment.app.FragmentActivity, android.app.Activity
    public void onDestroy() {
        RxManager.remove(this.TAG);
        CallManager.cancelAll(this.TAG);
        super.onDestroy();
    }

    /* loaded from: classes3.dex */
    public class ChooseAdapter extends BaseAdapter<BaseMediaModel.DownloadFile> {
        public ChooseAdapter(List<BaseMediaModel.DownloadFile> list) {
            super(list);
        }

        @Override // com.tdo.showbox.base.BaseAdapter
        /* renamed from: getHolder */
        public BaseViewHolder mo613getHolder(LayoutInflater layoutInflater, ViewGroup viewGroup, int i, OnItemClickListener onItemClickListener) {
            return new Item1ViewHolder(layoutInflater.inflate(R.layout.layout_choose_item, viewGroup, false), onItemClickListener);
        }

        @Override // com.tdo.showbox.base.BaseAdapter
        public void setView(BaseViewHolder baseViewHolder, int i) {
            if (i < 0 || i > getItemCount() - 1) {
                return;
            }
            BaseMediaModel.DownloadFile model = getModel(i);
            Item1ViewHolder item1ViewHolder = (Item1ViewHolder) baseViewHolder;
            if (ChooseActivity.this.activity != null && !ChooseActivity.this.activity.isFinishing()) {
                if (model.vip_only == 1) {
                    item1ViewHolder.mVip.setVisibility(0);
                } else {
                    item1ViewHolder.mVip.setVisibility(8);
                }
                if (TextUtils.equals(model.quality, "360p")) {
                    Glide.with(ChooseActivity.this.activity).mo581load(Integer.valueOf((int) R.drawable.ic_choose_sd)).into(item1ViewHolder.mTheme);
                } else if (TextUtils.equals(model.quality, "720p")) {
                    Glide.with(ChooseActivity.this.activity).mo581load(Integer.valueOf((int) R.drawable.ic_choose_hd)).into(item1ViewHolder.mTheme);
                } else if (TextUtils.equals(model.quality, "1080p")) {
                    Glide.with(ChooseActivity.this.activity).mo581load(Integer.valueOf((int) R.drawable.ic_choose_fullhd)).into(item1ViewHolder.mTheme);
                } else if (TextUtils.equals(model.quality, "4K")) {
                    Glide.with(ChooseActivity.this.activity).mo581load(Integer.valueOf((int) R.drawable.ic_choose_4k)).into(item1ViewHolder.mTheme);
                } else if (TextUtils.equals(model.quality, "org")) {
                    Glide.with(ChooseActivity.this.activity).mo581load(Integer.valueOf((int) R.mipmap.ic_origin_rate)).into(item1ViewHolder.mTheme);
                }
            }
            if (TextUtils.isEmpty(model.bitstream)) {
                item1ViewHolder.tvRate.setVisibility(8);
            } else {
                item1ViewHolder.tvRate.setVisibility(0);
                item1ViewHolder.tvRate.setText(model.bitstream);
            }
            item1ViewHolder.mFormatDark.setImageResource(model.h265 == 1 ? R.drawable.ic_choose_fromat : R.mipmap.ic_choose_fromat2);
            item1ViewHolder.mFormat.setVisibility(8);
            item1ViewHolder.mSize.setText(model.size);
            item1ViewHolder.mTime.setText(TimeUtils.formatTime3(model.dateline * 1000));
            item1ViewHolder.mName.setText(model.filename);
            item1ViewHolder.mSelect.setText(String.format("%s Selecet", model.count));
            item1ViewHolder.mSelect.setVisibility(8);
            CastSession currentCastSession = CastContext.getSharedInstance(ChooseActivity.this.context).getSessionManager().getCurrentCastSession();
            if (currentCastSession != null && currentCastSession.isConnected()) {
                item1ViewHolder.mDownlaod.setVisibility(8);
            } else {
                item1ViewHolder.mDownlaod.setVisibility(0);
            }
        }
    }

    /* loaded from: classes3.dex */
    static class Item1ViewHolder extends BaseViewHolder {
        @BindView(R.id.layout_choose_download)
        ImageView mDownlaod;
        @BindView(R.id.layout_choose_format)
        ImageView mFormat;
        @BindView(R.id.layout_choose_format_dark)
        ImageView mFormatDark;
        @BindView(R.id.layout_choose_name)
        TextView mName;
        @BindView(R.id.layout_choose_select)
        TextView mSelect;
        @BindView(R.id.layout_choose_size)
        TextView mSize;
        @BindView(R.id.layout_choose_theme)
        ImageView mTheme;
        @BindView(R.id.layout_choose_time)
        TextView mTime;
        @BindView(R.id.layout_choose_vip)
        ImageView mVip;
        @BindView(R.id.tv_rate)
        TextView tvRate;

        Item1ViewHolder(View view, OnItemClickListener onItemClickListener) {
            super(view, onItemClickListener);
        }
    }
}
