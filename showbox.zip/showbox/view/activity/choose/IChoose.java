package com.tdo.showbox.view.activity.choose;

import com.tdo.showbox.model.BaseMediaModel;
import com.tdo.showbox.model.common.Srt;
import com.tdo.showbox.view.listener.IViewController;
import java.util.List;
/* loaded from: classes3.dex */
public interface IChoose extends IViewController {
    void getSrt(List<Srt> list, String str);

    void setPath(BaseMediaModel baseMediaModel);
}
