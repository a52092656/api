package com.tdo.showbox.view.activity.Video;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import com.google.android.gms.cast.MediaInfo;
import com.google.android.gms.cast.MediaMetadata;
import com.google.android.gms.cast.MediaQueueItem;
import com.google.android.gms.cast.MediaStatus;
import com.google.android.gms.cast.framework.media.ImageHints;
import com.google.android.gms.cast.framework.media.MediaQueue;
import com.google.android.gms.cast.framework.media.RemoteMediaClient;
import com.google.android.gms.cast.framework.media.uicontroller.UIMediaController;
import com.google.android.gms.cast.framework.media.widget.ControlButtonsContainer;
import com.tdo.showbox.R;
import com.tdo.showbox.event.OnCastStartEvent;
import com.tdo.showbox.utils.CommonExtKt;
import com.tdo.showbox.utils.DensityUtils;
import com.tdo.showbox.utils.RxUtils;
import com.tdo.showbox.view.fragment.CastPlayListFragment;
import com.uber.autodispose.ObservableSubscribeProxy;
import io.reactivex.Observable;
import io.reactivex.Observer;
import io.reactivex.disposables.Disposable;
import java.util.Arrays;
import java.util.HashMap;
import java.util.concurrent.TimeUnit;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.StringCompanionObject;
import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;
/* compiled from: MiniControllerFragment.kt */
@Metadata(bv = {1, 0, 3}, d1 = {"\u0000v\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0011\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\b\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0006\u0018\u00002\u00020\u00012\u00020\u0002B\u0005¢\u0006\u0002\u0010\u0003J\u0010\u0010\u0018\u001a\u00020\u00192\u0006\u0010\u001a\u001a\u00020\u001bH\u0002J\u0012\u0010\u001c\u001a\u0004\u0018\u00010\n2\u0006\u0010\u001d\u001a\u00020\u0005H\u0016J\b\u0010\u001e\u001a\u00020\u0005H\u0016J\u0010\u0010\u001f\u001a\u00020\u00052\u0006\u0010\u001d\u001a\u00020\u0005H\u0016J\b\u0010 \u001a\u00020\u0017H\u0016J\b\u0010!\u001a\u00020\u0019H\u0002J\u0010\u0010\"\u001a\u00020\u00192\u0006\u0010#\u001a\u00020$H\u0007J&\u0010%\u001a\u0004\u0018\u00010\u001b2\u0006\u0010&\u001a\u00020'2\b\u0010(\u001a\u0004\u0018\u00010)2\b\u0010*\u001a\u0004\u0018\u00010+H\u0016J\b\u0010,\u001a\u00020\u0019H\u0016J\b\u0010-\u001a\u00020\u0019H\u0016J\u001a\u0010.\u001a\u00020\u00192\u0006\u0010\u001a\u001a\u00020\u001b2\b\u0010*\u001a\u0004\u0018\u00010+H\u0016J\u001c\u0010/\u001a\u00020\u00192\b\u0010\f\u001a\u0004\u0018\u00010\r2\b\u0010\u0014\u001a\u0004\u0018\u00010\u0015H\u0002J\u0012\u00100\u001a\u00020\u00192\b\u0010\u0014\u001a\u0004\u0018\u00010\u0015H\u0002R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010\u0006\u001a\u0004\u0018\u00010\u0007X\u0082\u000e¢\u0006\u0002\n\u0000R\u0018\u0010\b\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010\n0\tX\u0082\u0004¢\u0006\u0004\n\u0002\u0010\u000bR\u0010\u0010\f\u001a\u0004\u0018\u00010\rX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u000e\u001a\u00020\u000fX\u0082.¢\u0006\u0002\n\u0000R\u0010\u0010\u0010\u001a\u0004\u0018\u00010\u0011X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0012\u001a\u00020\u0013X\u0082.¢\u0006\u0002\n\u0000R\u0010\u0010\u0014\u001a\u0004\u0018\u00010\u0015X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0016\u001a\u00020\u0017X\u0082.¢\u0006\u0002\n\u0000¨\u00061"}, d2 = {"Lcom/tdo/showbox/view/activity/Video/MiniControllerFragment;", "Landroidx/fragment/app/Fragment;", "Lcom/google/android/gms/cast/framework/media/widget/ControlButtonsContainer;", "()V", "currId", "", "disposable", "Lio/reactivex/disposables/Disposable;", "imageViews", "", "Landroid/widget/ImageView;", "[Landroid/widget/ImageView;", "mediaQueue", "Lcom/google/android/gms/cast/framework/media/MediaQueue;", "mediaQueueCallback", "Lcom/google/android/gms/cast/framework/media/MediaQueue$Callback;", "mediaStatus", "Lcom/google/android/gms/cast/MediaStatus;", "remoteCallback", "Lcom/google/android/gms/cast/framework/media/RemoteMediaClient$Callback;", "remoteMediaClient", "Lcom/google/android/gms/cast/framework/media/RemoteMediaClient;", "uiMediaController", "Lcom/google/android/gms/cast/framework/media/uicontroller/UIMediaController;", "bindView", "", "view", "Landroid/view/View;", "getButtonImageViewAt", "p0", "getButtonSlotCount", "getButtonTypeAt", "getUIMediaController", "initListener", "onCastStart", "event", "Lcom/tdo/showbox/event/OnCastStartEvent;", "onCreateView", "inflater", "Landroid/view/LayoutInflater;", "container", "Landroid/view/ViewGroup;", "savedInstanceState", "Landroid/os/Bundle;", "onDestroy", "onStart", "onViewCreated", "setCallback", "setControllerUi", "app_webRelease"}, k = 1, mv = {1, 1, 16})
/* loaded from: classes.dex */
public final class MiniControllerFragment extends Fragment implements ControlButtonsContainer {
    private HashMap _$_findViewCache;
    private Disposable disposable;
    private MediaQueue mediaQueue;
    private MediaQueue.Callback mediaQueueCallback;
    private MediaStatus mediaStatus;
    private RemoteMediaClient.Callback remoteCallback;
    private RemoteMediaClient remoteMediaClient;
    private UIMediaController uiMediaController;
    private final ImageView[] imageViews = new ImageView[3];
    private int currId = -1;

    public void _$_clearFindViewByIdCache() {
        HashMap hashMap = this._$_findViewCache;
        if (hashMap != null) {
            hashMap.clear();
        }
    }

    public View _$_findCachedViewById(int i) {
        if (this._$_findViewCache == null) {
            this._$_findViewCache = new HashMap();
        }
        View view = (View) this._$_findViewCache.get(Integer.valueOf(i));
        if (view == null) {
            View view2 = getView();
            if (view2 == null) {
                return null;
            }
            View findViewById = view2.findViewById(i);
            this._$_findViewCache.put(Integer.valueOf(i), findViewById);
            return findViewById;
        }
        return view;
    }

    @Override // com.google.android.gms.cast.framework.media.widget.ControlButtonsContainer
    public int getButtonSlotCount() {
        return 3;
    }

    @Override // com.google.android.gms.cast.framework.media.widget.ControlButtonsContainer
    public int getButtonTypeAt(int i) {
        return 0;
    }

    @Override // androidx.fragment.app.Fragment
    public /* synthetic */ void onDestroyView() {
        super.onDestroyView();
        _$_clearFindViewByIdCache();
    }

    public static final /* synthetic */ UIMediaController access$getUiMediaController$p(MiniControllerFragment miniControllerFragment) {
        UIMediaController uIMediaController = miniControllerFragment.uiMediaController;
        if (uIMediaController == null) {
            Intrinsics.throwUninitializedPropertyAccessException("uiMediaController");
        }
        return uIMediaController;
    }

    @Override // androidx.fragment.app.Fragment
    public View onCreateView(LayoutInflater inflater, ViewGroup viewGroup, Bundle bundle) {
        Intrinsics.checkParameterIsNotNull(inflater, "inflater");
        return inflater.inflate(R.layout.mini_controller, viewGroup, false);
    }

    @Override // androidx.fragment.app.Fragment
    public void onViewCreated(View view, Bundle bundle) {
        Intrinsics.checkParameterIsNotNull(view, "view");
        super.onViewCreated(view, bundle);
        bindView(view);
        initListener();
    }

    private final void initListener() {
        ((ImageView) _$_findCachedViewById(R.id.ivQueue)).setOnClickListener(new View.OnClickListener() { // from class: com.tdo.showbox.view.activity.Video.MiniControllerFragment$initListener$1
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                MediaQueue mediaQueue;
                MediaStatus mediaStatus;
                int i;
                RemoteMediaClient remoteMediaClient;
                CastPlayListFragment castPlayListFragment = new CastPlayListFragment();
                mediaQueue = MiniControllerFragment.this.mediaQueue;
                mediaStatus = MiniControllerFragment.this.mediaStatus;
                i = MiniControllerFragment.this.currId;
                remoteMediaClient = MiniControllerFragment.this.remoteMediaClient;
                castPlayListFragment.setMediaQueue(mediaQueue, mediaStatus, i, remoteMediaClient);
                castPlayListFragment.show(MiniControllerFragment.this.getChildFragmentManager(), "MiniControllerFragment");
            }
        });
    }

    private final void bindView(View view) {
        CommonExtKt.gone(view);
        UIMediaController uIMediaController = new UIMediaController(getActivity());
        this.uiMediaController = uIMediaController;
        if (uIMediaController == null) {
            Intrinsics.throwUninitializedPropertyAccessException("uiMediaController");
        }
        uIMediaController.bindViewVisibilityToMediaSession(view, 8);
        UIMediaController uIMediaController2 = this.uiMediaController;
        if (uIMediaController2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("uiMediaController");
        }
        uIMediaController2.bindTextViewToMetadataOfCurrentItem((TextView) _$_findCachedViewById(R.id.tvTitle), MediaMetadata.KEY_TITLE);
        UIMediaController uIMediaController3 = this.uiMediaController;
        if (uIMediaController3 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("uiMediaController");
        }
        uIMediaController3.bindProgressBar((ProgressBar) _$_findCachedViewById(R.id.progressBar));
        UIMediaController uIMediaController4 = this.uiMediaController;
        if (uIMediaController4 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("uiMediaController");
        }
        uIMediaController4.bindViewToLaunchExpandedController((ConstraintLayout) _$_findCachedViewById(R.id.container));
        if (getContext() != null) {
            Context context = getContext();
            if (context == null) {
                Intrinsics.throwNpe();
            }
            Drawable drawable = ContextCompat.getDrawable(context, R.mipmap.ic_cast_play);
            Context context2 = getContext();
            if (context2 == null) {
                Intrinsics.throwNpe();
            }
            Drawable drawable2 = ContextCompat.getDrawable(context2, R.mipmap.ic_cast_pause);
            Context context3 = getContext();
            if (context3 == null) {
                Intrinsics.throwNpe();
            }
            Drawable drawable3 = ContextCompat.getDrawable(context3, R.mipmap.ic_cast_pause);
            UIMediaController uIMediaController5 = this.uiMediaController;
            if (uIMediaController5 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("uiMediaController");
            }
            ImageView imageView = (ImageView) _$_findCachedViewById(R.id.ivPlayAndPause);
            if (drawable == null) {
                Intrinsics.throwNpe();
            }
            if (drawable2 == null) {
                Intrinsics.throwNpe();
            }
            uIMediaController5.bindImageViewToPlayPauseToggle(imageView, drawable, drawable2, drawable3, (ProgressBar) _$_findCachedViewById(R.id.loading), true);
        }
        ((ObservableSubscribeProxy) Observable.interval(1L, 1L, TimeUnit.SECONDS).compose(RxUtils.rxSchedulerHelper()).as(RxUtils.bindLifecycleOwner(this))).subscribe(new Observer<Long>() { // from class: com.tdo.showbox.view.activity.Video.MiniControllerFragment$bindView$2
            @Override // io.reactivex.Observer
            public void onError(Throwable e) {
                Intrinsics.checkParameterIsNotNull(e, "e");
            }

            @Override // io.reactivex.Observer
            public /* bridge */ /* synthetic */ void onNext(Long l) {
                onNext(l.longValue());
            }

            @Override // io.reactivex.Observer
            public void onComplete() {
                Log.d("MiniControllerFragment", "onComplete");
            }

            @Override // io.reactivex.Observer
            public void onSubscribe(Disposable d) {
                Intrinsics.checkParameterIsNotNull(d, "d");
                MiniControllerFragment.this.disposable = d;
            }

            public void onNext(long j) {
                Disposable disposable;
                RemoteMediaClient remoteMediaClient;
                MediaQueue mediaQueue;
                RemoteMediaClient remoteMediaClient2;
                RemoteMediaClient remoteMediaClient3;
                if (MiniControllerFragment.access$getUiMediaController$p(MiniControllerFragment.this).isActive()) {
                    Log.d("MiniControllerFragment", "uiMediaController isActive");
                    disposable = MiniControllerFragment.this.disposable;
                    if (disposable != null) {
                        disposable.dispose();
                    }
                    MiniControllerFragment miniControllerFragment = MiniControllerFragment.this;
                    miniControllerFragment.remoteMediaClient = MiniControllerFragment.access$getUiMediaController$p(miniControllerFragment).getRemoteMediaClient();
                    MiniControllerFragment miniControllerFragment2 = MiniControllerFragment.this;
                    remoteMediaClient = miniControllerFragment2.remoteMediaClient;
                    miniControllerFragment2.mediaQueue = remoteMediaClient != null ? remoteMediaClient.getMediaQueue() : null;
                    MiniControllerFragment miniControllerFragment3 = MiniControllerFragment.this;
                    mediaQueue = miniControllerFragment3.mediaQueue;
                    remoteMediaClient2 = MiniControllerFragment.this.remoteMediaClient;
                    miniControllerFragment3.setCallback(mediaQueue, remoteMediaClient2);
                    MiniControllerFragment miniControllerFragment4 = MiniControllerFragment.this;
                    remoteMediaClient3 = miniControllerFragment4.remoteMediaClient;
                    miniControllerFragment4.setControllerUi(remoteMediaClient3);
                }
            }
        });
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public final void onCastStart(OnCastStartEvent event) {
        Intrinsics.checkParameterIsNotNull(event, "event");
        UIMediaController uIMediaController = this.uiMediaController;
        if (uIMediaController == null) {
            Intrinsics.throwUninitializedPropertyAccessException("uiMediaController");
        }
        if (uIMediaController.isActive()) {
            Disposable disposable = this.disposable;
            if (disposable != null) {
                disposable.dispose();
            }
            Log.d("MiniControllerFragment", "onCastStart");
            Disposable disposable2 = this.disposable;
            if (disposable2 != null) {
                disposable2.dispose();
            }
            UIMediaController uIMediaController2 = this.uiMediaController;
            if (uIMediaController2 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("uiMediaController");
            }
            RemoteMediaClient remoteMediaClient = uIMediaController2.getRemoteMediaClient();
            this.remoteMediaClient = remoteMediaClient;
            MediaQueue mediaQueue = remoteMediaClient != null ? remoteMediaClient.getMediaQueue() : null;
            this.mediaQueue = mediaQueue;
            setCallback(mediaQueue, this.remoteMediaClient);
            setControllerUi(this.remoteMediaClient);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void setControllerUi(RemoteMediaClient remoteMediaClient) {
        int i;
        int[] itemIds;
        int[] itemIds2;
        int[] itemIds3;
        MediaQueueItem currentItem;
        int[] itemIds4;
        MediaStatus mediaStatus;
        MediaInfo mediaInfo;
        Integer num = null;
        MediaMetadata metadata = (remoteMediaClient == null || (mediaStatus = remoteMediaClient.getMediaStatus()) == null || (mediaInfo = mediaStatus.getMediaInfo()) == null) ? null : mediaInfo.getMetadata();
        this.mediaQueue = remoteMediaClient != null ? remoteMediaClient.getMediaQueue() : null;
        MediaStatus mediaStatus2 = remoteMediaClient != null ? remoteMediaClient.getMediaStatus() : null;
        MediaQueue mediaQueue = this.mediaQueue;
        if (mediaQueue == null || (itemIds4 = mediaQueue.getItemIds()) == null || itemIds4.length != 0) {
            this.mediaStatus = remoteMediaClient != null ? remoteMediaClient.getMediaStatus() : null;
            Integer valueOf = (remoteMediaClient == null || (currentItem = remoteMediaClient.getCurrentItem()) == null) ? null : Integer.valueOf(currentItem.getItemId());
            MediaQueue mediaQueue2 = this.mediaQueue;
            int i2 = -1;
            if (mediaQueue2 != null && (itemIds3 = mediaQueue2.getItemIds()) != null) {
                int length = itemIds3.length;
                int i3 = 0;
                i = 0;
                while (i3 < length) {
                    int i4 = itemIds3[i3];
                    int i5 = i + 1;
                    if (valueOf != null && valueOf.intValue() == i4) {
                        break;
                    }
                    i3++;
                    i = i5;
                }
            }
            i = -1;
            if (mediaStatus2 != null) {
                i2 = mediaStatus2.getCurrentItemId();
            }
            this.currId = i2;
            String string = metadata != null ? metadata.getString(MediaMetadata.KEY_SUBTITLE) : null;
            Context context = getContext();
            if (context != null) {
                UIMediaController uIMediaController = this.uiMediaController;
                if (uIMediaController == null) {
                    Intrinsics.throwUninitializedPropertyAccessException("uiMediaController");
                }
                uIMediaController.bindImageViewToImageOfCurrentItem((ImageView) _$_findCachedViewById(R.id.ivTvImage), new ImageHints(2, DensityUtils.dp2px(context, 96.0f), DensityUtils.dp2px(context, 58.0f)), R.drawable.ic_empty_land_holder);
            }
            if (string != null && (!Intrinsics.areEqual(string, "null"))) {
                TextView textView = (TextView) _$_findCachedViewById(R.id.tvInfo);
                if (textView == null) {
                    return;
                }
                StringCompanionObject stringCompanionObject = StringCompanionObject.INSTANCE;
                Object[] objArr = new Object[3];
                objArr[0] = string;
                objArr[1] = Integer.valueOf(i + 1);
                MediaQueue mediaQueue3 = this.mediaQueue;
                if (mediaQueue3 != null && (itemIds2 = mediaQueue3.getItemIds()) != null) {
                    num = Integer.valueOf(itemIds2.length);
                }
                objArr[2] = num;
                String format = String.format("%s Queue %s/%s", Arrays.copyOf(objArr, 3));
                Intrinsics.checkExpressionValueIsNotNull(format, "java.lang.String.format(format, *args)");
                textView.setText(format);
                return;
            }
            TextView textView2 = (TextView) _$_findCachedViewById(R.id.tvInfo);
            if (textView2 == null) {
                return;
            }
            StringCompanionObject stringCompanionObject2 = StringCompanionObject.INSTANCE;
            Object[] objArr2 = new Object[2];
            objArr2[0] = Integer.valueOf(i + 1);
            MediaQueue mediaQueue4 = this.mediaQueue;
            if (mediaQueue4 != null && (itemIds = mediaQueue4.getItemIds()) != null) {
                num = Integer.valueOf(itemIds.length);
            }
            objArr2[1] = num;
            String format2 = String.format("Queue %s/%s", Arrays.copyOf(objArr2, 2));
            Intrinsics.checkExpressionValueIsNotNull(format2, "java.lang.String.format(format, *args)");
            textView2.setText(format2);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void setCallback(MediaQueue mediaQueue, final RemoteMediaClient remoteMediaClient) {
        RemoteMediaClient.Callback callback = new RemoteMediaClient.Callback() { // from class: com.tdo.showbox.view.activity.Video.MiniControllerFragment$setCallback$1
            @Override // com.google.android.gms.cast.framework.media.RemoteMediaClient.Callback
            public void onQueueStatusUpdated() {
                super.onQueueStatusUpdated();
                MiniControllerFragment.this.setControllerUi(remoteMediaClient);
            }

            @Override // com.google.android.gms.cast.framework.media.RemoteMediaClient.Callback
            public void onStatusUpdated() {
                super.onStatusUpdated();
            }
        };
        this.remoteCallback = callback;
        if (remoteMediaClient != null) {
            if (callback == null) {
                Intrinsics.throwUninitializedPropertyAccessException("remoteCallback");
            }
            remoteMediaClient.registerCallback(callback);
        }
        MediaQueue.Callback callback2 = new MediaQueue.Callback() { // from class: com.tdo.showbox.view.activity.Video.MiniControllerFragment$setCallback$2
            @Override // com.google.android.gms.cast.framework.media.MediaQueue.Callback
            public void mediaQueueChanged() {
                super.mediaQueueChanged();
                MiniControllerFragment.this.setControllerUi(remoteMediaClient);
            }

            @Override // com.google.android.gms.cast.framework.media.MediaQueue.Callback
            public void itemsReloaded() {
                super.itemsReloaded();
            }
        };
        this.mediaQueueCallback = callback2;
        if (mediaQueue != null) {
            if (callback2 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("mediaQueueCallback");
            }
            mediaQueue.registerCallback(callback2);
        }
    }

    @Override // androidx.fragment.app.Fragment
    public void onStart() {
        super.onStart();
        if (!EventBus.getDefault().isRegistered(this)) {
            EventBus.getDefault().register(this);
        }
    }

    @Override // androidx.fragment.app.Fragment
    public void onDestroy() {
        Disposable disposable;
        super.onDestroy();
        if (EventBus.getDefault().isRegistered(this)) {
            EventBus.getDefault().unregister(this);
        }
        Disposable disposable2 = this.disposable;
        if ((disposable2 == null || !disposable2.isDisposed()) && (disposable = this.disposable) != null) {
            disposable.dispose();
        }
        Log.d("MiniControllerFragment", "ondestroy");
        UIMediaController uIMediaController = this.uiMediaController;
        if (uIMediaController == null) {
            Intrinsics.throwUninitializedPropertyAccessException("uiMediaController");
        }
        uIMediaController.dispose();
        MediaQueue mediaQueue = this.mediaQueue;
        if (mediaQueue != null) {
            MediaQueue.Callback callback = this.mediaQueueCallback;
            if (callback == null) {
                Intrinsics.throwUninitializedPropertyAccessException("mediaQueueCallback");
            }
            mediaQueue.unregisterCallback(callback);
        }
        RemoteMediaClient remoteMediaClient = this.remoteMediaClient;
        if (remoteMediaClient != null) {
            RemoteMediaClient.Callback callback2 = this.remoteCallback;
            if (callback2 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("remoteCallback");
            }
            remoteMediaClient.unregisterCallback(callback2);
        }
    }

    @Override // com.google.android.gms.cast.framework.media.widget.ControlButtonsContainer
    public UIMediaController getUIMediaController() {
        UIMediaController uIMediaController = this.uiMediaController;
        if (uIMediaController == null) {
            Intrinsics.throwUninitializedPropertyAccessException("uiMediaController");
        }
        return uIMediaController;
    }

    @Override // com.google.android.gms.cast.framework.media.widget.ControlButtonsContainer
    public ImageView getButtonImageViewAt(int i) throws IndexOutOfBoundsException {
        return this.imageViews[i];
    }
}
