package com.tdo.showbox.view.activity;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import butterknife.BindView;
import com.alibaba.fastjson.JSONObject;
import com.ares.downloader.jarvis.core.StartAllDownloadEvent;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.tabs.TabLayout;
import com.google.firebase.iid.FirebaseInstanceId;
import com.google.firebase.iid.InstanceIdResult;
import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;
import com.gyf.immersionbar.ImmersionBar;
import com.mintegral.msdk.interstitial.view.MTGInterstitialActivity;
import com.tbruyelle.rxpermissions2.RxPermissions;
import com.tdo.showbox.BuildConfig;
import com.tdo.showbox.R;
import com.tdo.showbox.app.App;
import com.tdo.showbox.app.Constant;
import com.tdo.showbox.app.RxManager;
import com.tdo.showbox.base.BaseActivity;
import com.tdo.showbox.base.BaseFragment;
import com.tdo.showbox.base.BaseLazyFragment;
import com.tdo.showbox.base.HttpResponseObserver;
import com.tdo.showbox.config.ConfigKey;
import com.tdo.showbox.config.ConfigUtils;
import com.tdo.showbox.db.entity.Download;
import com.tdo.showbox.event.ChildModeChangedEvent;
import com.tdo.showbox.event.DownloadChangedEvent;
import com.tdo.showbox.event.LoginEvent;
import com.tdo.showbox.event.LogoutEvent;
import com.tdo.showbox.event.OnFeaturedFirstLoadEvent;
import com.tdo.showbox.event.OnScanResultEvent;
import com.tdo.showbox.http.API;
import com.tdo.showbox.http.APIService;
import com.tdo.showbox.http.ApiException;
import com.tdo.showbox.http.CallManager;
import com.tdo.showbox.http.Http;
import com.tdo.showbox.http.HttpUtils;
import com.tdo.showbox.http.ServerException;
import com.tdo.showbox.model.BBsInfoModel;
import com.tdo.showbox.model.UserAgreementModel;
import com.tdo.showbox.model.user.UserModel;
import com.tdo.showbox.service.DownloadService;
import com.tdo.showbox.service.MemoryMonitorService;
import com.tdo.showbox.utils.AdManager;
import com.tdo.showbox.utils.ClickCounter;
import com.tdo.showbox.utils.CommonUtils;
import com.tdo.showbox.utils.DensityUtils;
import com.tdo.showbox.utils.FileUtils;
import com.tdo.showbox.utils.MLog;
import com.tdo.showbox.utils.Network;
import com.tdo.showbox.utils.PrefsUtils;
import com.tdo.showbox.utils.ReviewRecordUtils;
import com.tdo.showbox.utils.RxUtils;
import com.tdo.showbox.utils.SystemUtils;
import com.tdo.showbox.utils.TimeUtils;
import com.tdo.showbox.utils.ToastUtils;
import com.tdo.showbox.utils.Utils;
import com.tdo.showbox.view.activity.detail.MoviesDetailActivity;
import com.tdo.showbox.view.activity.detail.TvShowDetailActivity;
import com.tdo.showbox.view.activity.user.Login2Activity;
import com.tdo.showbox.view.dialog.BottomSheetMsgDialog;
import com.tdo.showbox.view.dialog.DialogAction;
import com.tdo.showbox.view.fragment.CollectFragment;
import com.tdo.showbox.view.fragment.DownloadFragment2;
import com.tdo.showbox.view.fragment.HomeListFragment;
import com.tdo.showbox.view.fragment.movielist.MovieListFragment;
import com.tdo.showbox.view.fragment.userinfo.UserInfoFragment;
import com.tdo.showbox.view.listener.ITabListener;
import com.tdo.showbox.view.widget.UpdateChecker;
import com.uber.autodispose.ObservableSubscribeProxy;
import com.umeng.analytics.MobclickAgent;
import io.reactivex.ObservableEmitter;
import io.reactivex.ObservableOnSubscribe;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.Disposable;
import io.reactivex.functions.Consumer;
import io.reactivex.schedulers.Schedulers;
import java.io.File;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Observable;
import java.util.Observer;
import java.util.concurrent.TimeUnit;
import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;
/* loaded from: classes.dex */
public class MainActivity extends BaseActivity implements Observer, ITabListener {
    private AdManager adManager;
    @BindView(R.id.container)
    LinearLayout container;
    @BindView(R.id.content)
    FrameLayout content;
    private ClickCounter counter;
    private int current;
    private FragmentManager fragmentManager;
    private List<Fragment> fragments;
    private int[] icons;
    @BindView(R.id.main_tabs)
    TabLayout mTab;
    private int[] titles;
    private boolean upgradeChecked = false;
    private long lastHintVipTime = 0;

    /* JADX INFO: Access modifiers changed from: package-private */
    public static /* synthetic */ void lambda$initData$4(Boolean bool) throws Exception {
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static /* synthetic */ void lambda$statService$2(Throwable th) throws Exception {
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void showHintVipDate() {
    }

    @Override // com.tdo.showbox.base.BaseActivity
    protected boolean isRequireNetWork() {
        return false;
    }

    @Override // com.tdo.showbox.base.BaseActivity
    protected boolean isShowWarning() {
        return false;
    }

    @Override // com.tdo.showbox.base.BaseActivity
    protected boolean isStatusBarTint() {
        return false;
    }

    @Override // com.tdo.showbox.base.BaseActivity
    protected boolean isSupportBack() {
        return false;
    }

    @Override // com.tdo.showbox.base.BaseActivity
    protected boolean isTitleBarShow() {
        return false;
    }

    @Override // java.util.Observer
    public void update(Observable observable, Object obj) {
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // com.tdo.showbox.base.BaseActivity, androidx.appcompat.app.AppCompatActivity, androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        if (Build.VERSION.SDK_INT >= 21) {
            ImmersionBar.with(this).statusBarColor(R.color.color_main).autoDarkModeEnable(true).init();
        }
    }

    @Override // com.tdo.showbox.view.listener.IViewController
    public View loadView(LayoutInflater layoutInflater, ViewGroup viewGroup) {
        if (Build.VERSION.SDK_INT >= 21) {
            return layoutInflater.inflate(R.layout.activity_main, viewGroup, false);
        }
        return layoutInflater.inflate(R.layout.activity_main_kitkat, viewGroup, false);
    }

    @Override // com.tdo.showbox.view.listener.IViewController
    public void initView() {
        if (Build.VERSION.SDK_INT < 21 && !isScreenLandscape()) {
            DensityUtils.addMargin(this.container, 0, 0, 0, 40);
        }
        this.app.addObserver(this);
        PrefsUtils.getInstance().putBoolean(Constant.Prefs.IS_FIRST_OPEN, false);
        ClickCounter clickCounter = new ClickCounter(2, MTGInterstitialActivity.WATI_JS_INVOKE);
        this.counter = clickCounter;
        clickCounter.setListener(new ClickCounter.OnCountListener() { // from class: com.tdo.showbox.view.activity.MainActivity.1
            @Override // com.tdo.showbox.utils.ClickCounter.OnCountListener
            public void onCount(int i) {
                ToastUtils.showShort("Press again to quit");
            }

            @Override // com.tdo.showbox.utils.ClickCounter.OnCountListener
            public void onFinish() {
                MainActivity.this.finish();
                App.exit();
            }
        });
        this.fragmentManager = getSupportFragmentManager();
        this.mTab.getViewTreeObserver().addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() { // from class: com.tdo.showbox.view.activity.MainActivity.2
            @Override // android.view.ViewTreeObserver.OnGlobalLayoutListener
            public void onGlobalLayout() {
                MainActivity.this.mTab.getViewTreeObserver().removeOnGlobalLayoutListener(this);
            }
        });
    }

    private void showUpdateAlrt() {
        String readStringConfig = ConfigUtils.readStringConfig(ConfigKey.APK_INFO_MIN);
        final String readStringConfig2 = ConfigUtils.readStringConfig(ConfigKey.APK_URL);
        new BottomSheetMsgDialog.Builder(this).setContent(readStringConfig).setActionListener(new DialogAction.ActionListener() { // from class: com.tdo.showbox.view.activity.-$$Lambda$MainActivity$X1yxf5LkNYHoMI7ojAsFH8l9LtE
            @Override // com.tdo.showbox.view.dialog.DialogAction.ActionListener
            public final void onClick() {
                MainActivity.lambda$showUpdateAlrt$0(readStringConfig2);
            }
        }).setNegativeGone().setCancelable(false).create().show();
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static /* synthetic */ void lambda$showUpdateAlrt$0(String str) {
        SystemUtils.startBrowser(App.getInstance(), str);
        System.exit(0);
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onStartDownload(StartAllDownloadEvent startAllDownloadEvent) {
        io.reactivex.Observable.timer(3L, TimeUnit.SECONDS).compose(RxUtils.rxSchedulerHelper()).subscribe(new io.reactivex.Observer<Long>() { // from class: com.tdo.showbox.view.activity.MainActivity.3
            @Override // io.reactivex.Observer
            public void onError(Throwable th) {
            }

            @Override // io.reactivex.Observer
            public void onNext(Long l) {
            }

            @Override // io.reactivex.Observer
            public void onSubscribe(Disposable disposable) {
            }

            @Override // io.reactivex.Observer
            public void onComplete() {
                if (Utils.isAppForeground()) {
                    Intent intent = new Intent(MainActivity.this, DownloadService.class);
                    intent.setAction(Constant.ACTION.MOVIE_ALLDOWNLOAD);
                    MainActivity.this.startService(intent);
                }
            }
        });
    }

    public void statService() {
        List<Download> findByStatue = App.getDB().downloadDao().findByStatue(1);
        List<Download> findByStatue2 = App.getDB().downloadDao().findByStatue(4);
        List<Download> findByStatue3 = App.getDB().downloadDao().findByStatue(0);
        int size = findByStatue != null ? findByStatue.size() + 0 : 0;
        if (findByStatue2 != null) {
            size += findByStatue2.size();
        }
        if (findByStatue3 != null) {
            size += findByStatue3.size();
        }
        if (PrefsUtils.getInstance().getBoolean(Constant.Prefs.USER_CELLUAR_DOWNLOAD, false)) {
            if (size > 0 && Utils.isAppForeground()) {
                Intent intent = new Intent(this.context, DownloadService.class);
                intent.setAction(Constant.ACTION.MOVIE_ALLDOWNLOAD);
                this.context.startService(intent);
            }
        } else if (Network.isWifiConnected(this) && size > 0 && Utils.isAppForeground()) {
            Intent intent2 = new Intent(this.context, DownloadService.class);
            intent2.setAction(Constant.ACTION.MOVIE_ALLDOWNLOAD);
            this.context.startService(intent2);
        }
        ((ObservableSubscribeProxy) io.reactivex.Observable.timer(5L, TimeUnit.SECONDS).as(RxUtils.bindLifecycleOwner(this))).subscribe(new Consumer() { // from class: com.tdo.showbox.view.activity.-$$Lambda$MainActivity$9f0p10DaAZ73T7lwjcjknIt_hBw
            @Override // io.reactivex.functions.Consumer
            public final void accept(Object obj) {
                MainActivity.this.lambda$statService$1$MainActivity((Long) obj);
            }
        }, $$Lambda$MainActivity$d4pEZlT4iH5JiFsRjT6PDThEh1Q.INSTANCE);
    }

    public /* synthetic */ void lambda$statService$1$MainActivity(Long l) throws Exception {
        getFireBaseToken();
    }

    private void getFireBaseToken() {
        if (!App.isLogin()) {
            return;
        }
        FirebaseInstanceId.getInstance().getInstanceId().addOnCompleteListener(new OnCompleteListener() { // from class: com.tdo.showbox.view.activity.-$$Lambda$MainActivity$qd3fM9Gw-jqkbN_HpHvzryBfouU
            @Override // com.google.android.gms.tasks.OnCompleteListener
            public final void onComplete(Task task) {
                MainActivity.this.lambda$getFireBaseToken$3$MainActivity(task);
            }
        });
    }

    public /* synthetic */ void lambda$getFireBaseToken$3$MainActivity(Task task) {
        if (task.isSuccessful() && task.getResult() != null) {
            updateDevice(((InstanceIdResult) task.getResult()).getToken());
        }
    }

    private void updateDevice(String str) {
        APIService aPIService = this.service;
        String str2 = API.BASE_URL;
        String str3 = App.getUserData().uid;
        String oSType = SystemUtils.getOSType();
        String str4 = Build.MODEL;
        String str5 = App.deviceToken;
        String uniqueId = SystemUtils.getUniqueId(App.getContext());
        ((ObservableSubscribeProxy) aPIService.Device(str2, API.USER.DEVICE, str, str3, oSType, str4, str5, "", uniqueId, BuildConfig.APPLICATION_ID, (TimeUtils.getCurrentTime() / 1000) + "", "1", BuildConfig.VERSION_NAME).subscribeOn(Schedulers.io()).subscribeOn(AndroidSchedulers.mainThread()).as(RxUtils.bindLifecycleOwner(this))).subscribe(new io.reactivex.Observer<String>() { // from class: com.tdo.showbox.view.activity.MainActivity.4
            @Override // io.reactivex.Observer
            public void onComplete() {
            }

            @Override // io.reactivex.Observer
            public void onError(Throwable th) {
            }

            @Override // io.reactivex.Observer
            public void onNext(String str6) {
            }

            @Override // io.reactivex.Observer
            public void onSubscribe(Disposable disposable) {
                RxManager.addDisposable(MainActivity.this.TAG, disposable);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // androidx.appcompat.app.AppCompatActivity, androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    public void onSaveInstanceState(Bundle bundle) {
        super.onSaveInstanceState(bundle);
        bundle.putInt("selectTabPosition", this.mTab.getSelectedTabPosition());
    }

    @Override // com.tdo.showbox.view.listener.IViewController
    public void initData() {
        new RxPermissions(this).request("android.permission.WRITE_EXTERNAL_STORAGE", "android.permission.READ_EXTERNAL_STORAGE").subscribe($$Lambda$MainActivity$8rN3GR4Xf1TkeTv1fHVk4la8UE.INSTANCE);
        Intent intent = getIntent();
        if (intent.getExtras() != null) {
            handleParam(intent);
        }
        if (Network.isConnected(this.context)) {
            for (Download download : App.getDB().downloadDao().findByType(0)) {
                download.setPrivateid(download.getMovieId());
                download.setBox_type(1);
                App.getDB().downloadDao().update(download);
            }
            statService();
            if (!App.isLogin()) {
                CheckNeedInvate();
            }
        }
        this.titles = r3;
        int[] iArr = {R.string.emptytext, R.string.emptytext, R.string.emptytext, R.string.emptytext};
        this.icons = r0;
        int[] iArr2 = {R.drawable.nav_movie, R.drawable.nav_movie_list, R.drawable.nav_favorite, R.drawable.nav_mine};
        if (this.savedInstanceState == null) {
            HomeListFragment homeListFragment = new HomeListFragment();
            CollectFragment collectFragment = new CollectFragment();
            MovieListFragment newInstance = MovieListFragment.newInstance();
            UserInfoFragment userInfoFragment = new UserInfoFragment();
            ArrayList arrayList = new ArrayList(this.titles.length);
            this.fragments = arrayList;
            arrayList.add(homeListFragment);
            this.fragments.add(newInstance);
            this.fragments.add(collectFragment);
            this.fragments.add(userInfoFragment);
            FragmentTransaction beginTransaction = this.fragmentManager.beginTransaction();
            int i = 0;
            for (Fragment fragment : this.fragments) {
                if (fragment instanceof BaseFragment) {
                    BaseFragment baseFragment = (BaseFragment) fragment;
                    baseFragment.setAddIn(true);
                    baseFragment.setName(getString(this.titles[i]));
                    baseFragment.setListener(this);
                }
                beginTransaction.add(R.id.content, fragment, fragment.getClass().getSimpleName()).hide(fragment);
                i++;
            }
            this.current = 0;
            beginTransaction.show(this.fragments.get(0));
            beginTransaction.commit();
            setTitle(getString(this.titles[this.current]));
        } else {
            DownloadFragment2 downloadFragment2 = (DownloadFragment2) getSupportFragmentManager().findFragmentByTag(DownloadFragment2.class.getSimpleName());
            ArrayList arrayList2 = new ArrayList(this.titles.length);
            this.fragments = arrayList2;
            arrayList2.add((HomeListFragment) getSupportFragmentManager().findFragmentByTag(HomeListFragment.class.getSimpleName()));
            this.fragments.add((MovieListFragment) getSupportFragmentManager().findFragmentByTag(MovieListFragment.class.getSimpleName()));
            this.fragments.add((CollectFragment) getSupportFragmentManager().findFragmentByTag(CollectFragment.class.getSimpleName()));
            this.fragments.add((UserInfoFragment) getSupportFragmentManager().findFragmentByTag(UserInfoFragment.class.getSimpleName()));
        }
        if (PrefsUtils.getInstance().getBoolean(Constant.Prefs.CHILD_MODE, false)) {
            this.fragments.remove(1);
        }
        initTabs();
        setDownloadTaskNum();
        if (App.isLogin() && App.getUserData().isvip == 1) {
            getAutoPaymentData(App.getUserData().uid);
        }
        startLowMemoryService();
    }

    private void startLowMemoryService() {
        if (Utils.isAppForeground()) {
            startService(new Intent(this, MemoryMonitorService.class));
        }
    }

    private void getAutoPaymentData(String str) {
        ((ObservableSubscribeProxy) this.service.User_agreement(API.BASE_URL, "User_agreement", str).compose(RxUtils.rxTranslate2Bean(UserAgreementModel.class)).compose(RxUtils.rxSchedulerHelper()).as(RxUtils.bindLifecycleOwner(this))).subscribe(new HttpResponseObserver<UserAgreementModel>() { // from class: com.tdo.showbox.view.activity.MainActivity.5
            @Override // com.tdo.showbox.base.HttpResponseObserver
            public void onStart(Disposable disposable) {
            }

            @Override // com.tdo.showbox.base.HttpResponseObserver
            public void onSuccess(UserAgreementModel userAgreementModel) {
                if ("Active".equals(userAgreementModel.getStatus()) || (App.getUserData().dead_time * 1000) - System.currentTimeMillis() > 604800000) {
                    return;
                }
                MainActivity.this.showHintVipDate();
            }

            @Override // com.tdo.showbox.base.HttpResponseObserver
            public void onError(ApiException apiException) {
                if ((App.getUserData().dead_time * 1000) - System.currentTimeMillis() <= 604800000) {
                    MainActivity.this.showHintVipDate();
                }
            }
        });
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onFeaturedLoadComplete(OnFeaturedFirstLoadEvent onFeaturedFirstLoadEvent) {
        if (App.getUserData().getIsvip() == 1) {
            return;
        }
        AdManager adManager = new AdManager(this);
        this.adManager = adManager;
        adManager.showAd();
    }

    private void deleteExtraFile() {
        ((ObservableSubscribeProxy) io.reactivex.Observable.create(new ObservableOnSubscribe() { // from class: com.tdo.showbox.view.activity.-$$Lambda$MainActivity$smVdDYAn1Y674BnJUkK7VyIOm3A
            @Override // io.reactivex.ObservableOnSubscribe
            public final void subscribe(ObservableEmitter observableEmitter) {
                MainActivity.this.lambda$deleteExtraFile$6$MainActivity(observableEmitter);
            }
        }).compose(RxUtils.rxSchedulerHelper()).as(RxUtils.bindLifecycleOwner(this))).subscribe(new io.reactivex.Observer<String>() { // from class: com.tdo.showbox.view.activity.MainActivity.6
            @Override // io.reactivex.Observer
            public void onComplete() {
            }

            @Override // io.reactivex.Observer
            public void onError(Throwable th) {
            }

            @Override // io.reactivex.Observer
            public void onNext(String str) {
            }

            @Override // io.reactivex.Observer
            public void onSubscribe(Disposable disposable) {
            }
        });
    }

    public /* synthetic */ void lambda$deleteExtraFile$6$MainActivity(ObservableEmitter observableEmitter) throws Exception {
        List<Download> all = App.getDB().downloadDao().getAll();
        List<File> listFilesInDirWithFilter = FileUtils.listFilesInDirWithFilter(new File(Constant.DIR_DOWNLOAD), $$Lambda$MainActivity$L5pd9ZHbQikU3XNValg0OGCE2Q.INSTANCE, false);
        if (listFilesInDirWithFilter != null) {
            for (File file : listFilesInDirWithFilter) {
                if (!findExist(file.getName(), all)) {
                    file.delete();
                }
            }
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:4:0x000a  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    private boolean findExist(java.lang.String r4, java.util.List<com.tdo.showbox.db.entity.Download> r5) {
        /*
            r3 = this;
            java.util.Iterator r5 = r5.iterator()
        L4:
            boolean r0 = r5.hasNext()
            if (r0 == 0) goto L30
            java.lang.Object r0 = r5.next()
            com.tdo.showbox.db.entity.Download r0 = (com.tdo.showbox.db.entity.Download) r0
            java.lang.String r1 = r0.getFileName()
            boolean r1 = r4.equals(r1)
            if (r1 != 0) goto L2e
            java.lang.String r1 = r0.getPath()
            java.lang.String r0 = r0.getTitle()
            java.lang.String r2 = com.tdo.showbox.app.Constant.DIR_DOWNLOAD
            java.lang.String r0 = com.ares.downloader.jarvis.core.RemoteFileUtil.getFileName(r1, r0, r2)
            boolean r0 = r4.equals(r0)
            if (r0 == 0) goto L4
        L2e:
            r4 = 1
            return r4
        L30:
            r4 = 0
            return r4
        */
        throw new UnsupportedOperationException("Method not decompiled: com.tdo.showbox.view.activity.MainActivity.findExist(java.lang.String, java.util.List):boolean");
    }

    private void initTabs() {
        TabLayout.Tab tabAt;
        if (this.titles.length == 1) {
            this.mTab.setVisibility(8);
            return;
        }
        for (int i = 0; i < this.titles.length; i++) {
            TabLayout.Tab newTab = this.mTab.newTab();
            View inflate = View.inflate(this.context, R.layout.layout_tab_image, null);
            if (inflate != null) {
                ImageView imageView = (ImageView) inflate.findViewById(R.id.tab_image);
                if (imageView != null) {
                    imageView.setImageResource(this.icons[i]);
                }
                newTab.setCustomView(inflate);
            }
            this.mTab.addTab(newTab, i);
        }
        if (PrefsUtils.getInstance().getBoolean(Constant.Prefs.CHILD_MODE, false)) {
            this.mTab.removeTabAt(1);
        }
        this.mTab.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() { // from class: com.tdo.showbox.view.activity.MainActivity.7
            @Override // com.google.android.material.tabs.TabLayout.BaseOnTabSelectedListener
            public void onTabReselected(TabLayout.Tab tab) {
            }

            @Override // com.google.android.material.tabs.TabLayout.BaseOnTabSelectedListener
            public void onTabUnselected(TabLayout.Tab tab) {
            }

            @Override // com.google.android.material.tabs.TabLayout.BaseOnTabSelectedListener
            public void onTabSelected(TabLayout.Tab tab) {
                int position = tab.getPosition();
                if (position != MainActivity.this.current) {
                    MainActivity.this.fragmentManager.beginTransaction().hide((Fragment) MainActivity.this.fragments.get(MainActivity.this.current)).show((Fragment) MainActivity.this.fragments.get(position)).commitAllowingStateLoss();
                    MainActivity.this.current = position;
                    MainActivity mainActivity = MainActivity.this;
                    mainActivity.setTitle(mainActivity.getString(mainActivity.titles[MainActivity.this.current]));
                }
            }
        });
        if (this.savedInstanceState != null) {
            int i2 = this.savedInstanceState.getInt("selectTabPosition");
            TabLayout.Tab tabAt2 = this.mTab.getTabAt(i2);
            if (tabAt2 != null) {
                tabAt2.select();
            }
            this.current = i2;
        }
        if (!getIntent().getBooleanExtra("checkDownloaded", false) || (tabAt = this.mTab.getTabAt(2)) == null) {
            return;
        }
        tabAt.select();
    }

    @Override // com.tdo.showbox.base.BaseActivity, com.tdo.showbox.view.listener.IViewController
    public <T> void updateView(T t) {
        super.updateView(t);
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // com.tdo.showbox.base.BaseActivity, androidx.fragment.app.FragmentActivity, android.app.Activity
    public void onResume() {
        super.onResume();
        if (!this.upgradeChecked) {
            if (ConfigUtils.readIntegerConfig(ConfigKey.APK_VERSION_CODE_MIN, 0) > 129) {
                showUpdateAlrt();
            } else {
                UpdateChecker.INSTANCE.checkUpdate(this.context);
                this.upgradeChecked = true;
                Context context = this.context;
                MobclickAgent.onEvent(context, "check_upgrade", App.versionName + com.huantansheng.easyphotos.utils.file.FileUtils.HIDDEN_PREFIX + App.versionCode + "-" + App.channel);
            }
        }
        if (App.isLogin()) {
            updateView(App.getUserData());
            if (Network.isConnected(this.context)) {
                loadData();
            }
        } else {
            updateView(null);
        }
        if (Network.isConnected(this.context)) {
            this.app.updateOnline();
        }
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // com.tdo.showbox.base.BaseActivity, androidx.fragment.app.FragmentActivity, android.app.Activity
    public void onNewIntent(Intent intent) {
        TabLayout tabLayout;
        TabLayout.Tab tabAt;
        super.onNewIntent(intent);
        handleParam(intent);
        if (!intent.getBooleanExtra("checkDownloaded", false) || (tabLayout = this.mTab) == null || (tabAt = tabLayout.getTabAt(4)) == null) {
            return;
        }
        tabAt.select();
    }

    private void handleParam(Intent intent) {
        String string = PrefsUtils.getInstance().getString("google.message_id");
        String stringExtra = intent.getStringExtra("google.message_id");
        if (string == null || !string.equals(stringExtra)) {
            String stringExtra2 = intent.getStringExtra("type");
            String stringExtra3 = intent.getStringExtra("tid");
            String stringExtra4 = intent.getStringExtra("mid");
            String stringExtra5 = intent.getStringExtra("ticket_id");
            String stringExtra6 = intent.getStringExtra("url");
            if (TextUtils.isEmpty(stringExtra2)) {
                return;
            }
            char c = 65535;
            int hashCode = stringExtra2.hashCode();
            if (hashCode != -873960692) {
                if (hashCode != 3714) {
                    if (hashCode != 3377875) {
                        if (hashCode == 104087344 && stringExtra2.equals("movie")) {
                            c = 1;
                        }
                    } else if (stringExtra2.equals("news")) {
                        c = 3;
                    }
                } else if (stringExtra2.equals("tv")) {
                    c = 0;
                }
            } else if (stringExtra2.equals("ticket")) {
                c = 2;
            }
            if (c == 0) {
                TvShowDetailActivity.start(this, stringExtra3);
            } else if (c == 1) {
                MoviesDetailActivity.start(this, stringExtra4);
            } else if (c == 2) {
                SystemUtils.startBrowser((Activity) this, String.format("https://www.showbox.media/index/order/detail?auth=%s&id=%s", buildData(""), stringExtra5));
            } else if (c == 3) {
                SystemUtils.startBrowser((Activity) this, stringExtra6);
            }
            PrefsUtils.getInstance().putString("google.message_id", stringExtra);
        }
    }

    private void loadData() {
        if (App.getUserData().getBbs_bind() != null) {
            ((ObservableSubscribeProxy) io.reactivex.Observable.zip(Http.getService().bbsLogin(API.BBS_URL, "loginByUid", App.getUserData().getBbs_bind().getBbs_uid(), CommonUtils.getBBSApiAPPID()).compose(RxUtils.rxTranslate2Bean(BBsInfoModel.class)), Http.getService().getUserInfo(API.BASE_URL, API.USER.USERINFO, App.getUserData().uid, SystemUtils.getUniqueId(this.context), BuildConfig.VERSION_NAME).compose(RxUtils.rxTranslate2Bean(UserModel.UserData.class)), $$Lambda$MainActivity$L_wZHUHiWyvvBOeGHIDPZafKRA.INSTANCE).compose(RxUtils.rxSchedulerHelper()).as(RxUtils.bindLifecycleOwner(this))).subscribe(new io.reactivex.Observer<UserModel.UserData>() { // from class: com.tdo.showbox.view.activity.MainActivity.8
                @Override // io.reactivex.Observer
                public void onComplete() {
                }

                @Override // io.reactivex.Observer
                public void onSubscribe(Disposable disposable) {
                }

                @Override // io.reactivex.Observer
                public void onNext(UserModel.UserData userData) {
                    App.updateUser(userData);
                    MainActivity.this.updateView(userData);
                }

                @Override // io.reactivex.Observer
                public void onError(Throwable th) {
                    if (th instanceof ServerException) {
                        App.logout();
                        MainActivity.this.route(Login2Activity.class);
                    }
                }
            });
        } else {
            ((ObservableSubscribeProxy) Http.getService().getUserInfo(API.BASE_URL, API.USER.USERINFO, App.getUserData().uid, SystemUtils.getUniqueId(this.context), BuildConfig.VERSION_NAME).compose(RxUtils.rxTranslate2Bean(UserModel.UserData.class)).compose(RxUtils.rxSchedulerHelper()).as(RxUtils.bindLifecycleOwner(this))).subscribe(new HttpResponseObserver<UserModel.UserData>() { // from class: com.tdo.showbox.view.activity.MainActivity.9
                @Override // com.tdo.showbox.base.HttpResponseObserver
                public void onStart(Disposable disposable) {
                }

                @Override // com.tdo.showbox.base.HttpResponseObserver
                public void onSuccess(UserModel.UserData userData) {
                    String str = MainActivity.this.TAG;
                    MLog.d(str, "登录状态 ： " + userData.name);
                    App.updateUser(userData);
                    MainActivity.this.updateView(userData);
                }

                @Override // com.tdo.showbox.base.HttpResponseObserver
                public void onError(ApiException apiException) {
                    if (apiException.getCode() == 0) {
                        App.logout();
                        MainActivity.this.route(Login2Activity.class);
                    }
                }
            });
        }
        if (App.isLogin()) {
            ((ObservableSubscribeProxy) Http.getService().getCollectNum(API.BASE_URL, "Movie_collect_num", App.getUserData().uid).compose(RxUtils.rxTranslate2Bean(Integer.class)).compose(RxUtils.rxSchedulerHelper()).as(RxUtils.bindLifecycleOwner(this))).subscribe(new HttpResponseObserver<Integer>() { // from class: com.tdo.showbox.view.activity.MainActivity.10
                @Override // com.tdo.showbox.base.HttpResponseObserver
                public void onError(ApiException apiException) {
                }

                @Override // com.tdo.showbox.base.HttpResponseObserver
                public void onStart(Disposable disposable) {
                }

                @Override // com.tdo.showbox.base.HttpResponseObserver
                public void onSuccess(Integer num) {
                    MainActivity.this.mTab.getTabAt(PrefsUtils.getInstance().getBoolean(Constant.Prefs.CHILD_MODE, false) ? 1 : 2);
                }
            });
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static /* synthetic */ UserModel.UserData lambda$loadData$7(BBsInfoModel bBsInfoModel, UserModel.UserData userData) throws Exception {
        if (userData.getBbs_bind() != null) {
            if (bBsInfoModel.getLoginInfo() != null) {
                UserModel.BBsInfo bbs_bind = userData.getBbs_bind();
                BBsInfoModel.Variables variables = bBsInfoModel.getLoginInfo().getVariables();
                bbs_bind.setFormhash(variables.getFormhash());
                bbs_bind.setAuth(variables.getAuth());
                bbs_bind.setAuthkey(variables.getAuthkey());
                bbs_bind.setAuthor(bBsInfoModel.getMember().getUsername());
                bbs_bind.setAvatar(bBsInfoModel.getMember().getAvatar());
                bbs_bind.setBbs_uid(variables.getMember_uid());
            } else {
                userData.setBbs_bind(null);
            }
        }
        return userData;
    }

    public void CheckNeedInvate() {
        ((ObservableSubscribeProxy) this.service.Register_NeedCode(API.BASE_URL, API.USER.REGISTER_CODE).compose(RxUtils.rxSchedulerHelper()).as(RxUtils.bindLifecycleOwner(this))).subscribe(new io.reactivex.Observer<String>() { // from class: com.tdo.showbox.view.activity.MainActivity.11
            @Override // io.reactivex.Observer
            public void onComplete() {
            }

            @Override // io.reactivex.Observer
            public void onError(Throwable th) {
            }

            @Override // io.reactivex.Observer
            public void onSubscribe(Disposable disposable) {
                RxManager.addDisposable(MainActivity.this.TAG, disposable);
            }

            @Override // io.reactivex.Observer
            public void onNext(String str) {
                JSONObject jSONObject = (JSONObject) JSONObject.parse(str);
                String str2 = MainActivity.this.TAG;
                MLog.d(str2, "邀请码测试 : " + str);
                if (jSONObject.getInteger("code").intValue() != 1 || !jSONObject.getJSONObject("data").getBoolean("invite_code").booleanValue()) {
                    return;
                }
                MainActivity.this.route(Login2Activity.class);
            }
        });
    }

    @Override // androidx.activity.ComponentActivity, android.app.Activity
    public void onBackPressed() {
        boolean z;
        Iterator<Fragment> it = this.fragments.iterator();
        while (true) {
            if (!it.hasNext()) {
                z = false;
                break;
            }
            Fragment next = it.next();
            if (next instanceof BaseFragment) {
                BaseFragment baseFragment = (BaseFragment) next;
                if (baseFragment.isVisible()) {
                    z = baseFragment.onBackPressed();
                    break;
                }
            } else if (next instanceof BaseLazyFragment) {
                BaseLazyFragment baseLazyFragment = (BaseLazyFragment) next;
                if (baseLazyFragment.isVisible()) {
                    z = baseLazyFragment.onBackPressed();
                    break;
                }
            } else {
                continue;
            }
        }
        if (!z) {
            ClickCounter clickCounter = this.counter;
            if (clickCounter != null) {
                clickCounter.countClick();
            } else {
                super.onBackPressed();
            }
        }
    }

    private String buildData(String str) {
        JSONObject jSONObject = new JSONObject();
        jSONObject.put("env", (Object) str);
        jSONObject.put("uid", (Object) (App.isLogin() ? App.getUserData().uid : ""));
        jSONObject.put("expired_date", (Object) Long.valueOf((TimeUtils.getCurrentTime() / 1000) + 43200));
        return HttpUtils.encodeBody(jSONObject.toJSONString());
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // com.tdo.showbox.base.BaseActivity, androidx.fragment.app.FragmentActivity, android.app.Activity
    public void onActivityResult(int i, int i2, Intent intent) {
        super.onActivityResult(i, i2, intent);
        if (i == 49374 && i2 == -1) {
            IntentResult parseActivityResult = IntentIntegrator.parseActivityResult(i, i2, intent);
            if (parseActivityResult != null) {
                EventBus.getDefault().post(new OnScanResultEvent(parseActivityResult.getContents()));
            } else {
                ToastUtils.showShort("Scan Failed");
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // com.tdo.showbox.base.BaseActivity, androidx.appcompat.app.AppCompatActivity, androidx.fragment.app.FragmentActivity, android.app.Activity
    public void onDestroy() {
        if (this.app != null) {
            this.app.delObserver(this);
        }
        RxManager.remove(this.TAG);
        CallManager.cancelAll(getClass().getSimpleName());
        clearReviewRecord();
        stopMemoryService();
        AdManager adManager = this.adManager;
        if (adManager != null) {
            adManager.release();
        }
        super.onDestroy();
    }

    private void stopMemoryService() {
        stopService(new Intent(this, MemoryMonitorService.class));
    }

    private void clearReviewRecord() {
        FileUtils.deleteAllInDir(new File(Constant.DIR_THUMB));
        ReviewRecordUtils.Companion.get().clearReviewRecord();
    }

    @Override // com.tdo.showbox.view.listener.ITabListener
    public void TabSlect(boolean z) {
        if (z) {
            this.mTab.setVisibility(0);
        } else {
            this.mTab.setVisibility(8);
        }
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onChildModeChanged(ChildModeChangedEvent childModeChangedEvent) {
        if (childModeChangedEvent.isOpen()) {
            this.mTab.removeTabAt(1);
            this.fragments.remove(1);
            int i = this.current;
            if (i <= 1) {
                return;
            }
            this.current = i - 1;
            return;
        }
        TabLayout.Tab newTab = this.mTab.newTab();
        View inflate = View.inflate(this.context, R.layout.layout_tab_image, null);
        if (inflate != null) {
            ImageView imageView = (ImageView) inflate.findViewById(R.id.tab_image);
            if (imageView != null) {
                imageView.setImageResource(this.icons[1]);
            }
            newTab.setCustomView(inflate);
        }
        this.mTab.addTab(newTab, 1);
        MovieListFragment newInstance = MovieListFragment.newInstance();
        this.fragments.add(1, newInstance);
        FragmentTransaction beginTransaction = this.fragmentManager.beginTransaction();
        beginTransaction.add(R.id.content, newInstance, newInstance.getClass().getSimpleName()).hide(newInstance);
        beginTransaction.commitAllowingStateLoss();
        int i2 = this.current;
        if (i2 <= 0) {
            return;
        }
        this.current = i2 + 1;
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onDownloadChanged(DownloadChangedEvent downloadChangedEvent) {
        setDownloadTaskNum();
    }

    private void setDownloadTaskNum() {
        int i;
        View customView;
        Iterator<Download> it = App.getDB().downloadDao().getAll().iterator();
        int i2 = 0;
        while (true) {
            i = 3;
            if (!it.hasNext()) {
                break;
            }
            int statue = it.next().getStatue();
            if (statue == 1 || statue == 3 || statue == 0 || statue == 4) {
                i2++;
            }
        }
        if (!PrefsUtils.getInstance().getBoolean(Constant.Prefs.CHILD_MODE, false)) {
            i = 4;
        }
        TabLayout.Tab tabAt = this.mTab.getTabAt(i);
        if (tabAt == null || (customView = tabAt.getCustomView()) == null) {
            return;
        }
        TextView textView = (TextView) customView.findViewById(R.id.tab_count);
        if (i2 > 0) {
            textView.setVisibility(0);
            if (i2 > 99) {
                textView.setText("99+");
                return;
            } else {
                textView.setText(String.valueOf(i2));
                return;
            }
        }
        textView.setVisibility(8);
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onLoginSuccess(LoginEvent loginEvent) {
        getFireBaseToken();
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onSignOut(LogoutEvent logoutEvent) {
        View customView;
        TabLayout.Tab tabAt = this.mTab.getTabAt(2);
        if (tabAt == null || (customView = tabAt.getCustomView()) == null) {
            return;
        }
        TextView textView = (TextView) customView.findViewById(R.id.tab_count);
        textView.setVisibility(8);
        textView.setText("");
    }
}
