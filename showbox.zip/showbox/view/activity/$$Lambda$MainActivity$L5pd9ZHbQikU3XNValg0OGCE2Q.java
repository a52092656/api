package com.tdo.showbox.view.activity;

import com.tdo.showbox.utils.FileUtils;
import java.io.File;
import java.io.FileFilter;
/* compiled from: lambda */
/* renamed from: com.tdo.showbox.view.activity.-$$Lambda$MainActivity$L5pd9ZHbQikU-3XNValg0OGCE2Q  reason: invalid class name */
/* loaded from: classes.dex */
public final /* synthetic */ class $$Lambda$MainActivity$L5pd9ZHbQikU3XNValg0OGCE2Q implements FileFilter {
    public static final /* synthetic */ $$Lambda$MainActivity$L5pd9ZHbQikU3XNValg0OGCE2Q INSTANCE = new $$Lambda$MainActivity$L5pd9ZHbQikU3XNValg0OGCE2Q();

    private /* synthetic */ $$Lambda$MainActivity$L5pd9ZHbQikU3XNValg0OGCE2Q() {
    }

    @Override // java.io.FileFilter
    public final boolean accept(File file) {
        boolean equalsIgnoreCase;
        equalsIgnoreCase = "mp4".equalsIgnoreCase(FileUtils.getExtensionName(file.getPath()));
        return equalsIgnoreCase;
    }
}
