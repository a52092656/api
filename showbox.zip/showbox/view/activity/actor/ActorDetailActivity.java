package com.tdo.showbox.view.activity.actor;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.graphics.Typeface;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.widget.Toolbar;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.listener.OnItemClickListener;
import com.chad.library.adapter.base.viewholder.BaseViewHolder;
import com.google.android.material.appbar.CollapsingToolbarLayout;
import com.google.android.material.tabs.TabLayout;
import com.mintegral.msdk.base.entity.CampaignEx;
import com.tdo.showbox.R;
import com.tdo.showbox.base.CommBaseAdapter;
import com.tdo.showbox.base.mvp.BaseMvpActivity;
import com.tdo.showbox.model.ActorDetailModel;
import com.tdo.showbox.model.ActorModel;
import com.tdo.showbox.utils.CommonExtKt;
import com.tdo.showbox.utils.CommonUtils;
import com.tdo.showbox.utils.GlideUtils;
import com.tdo.showbox.utils.GridInsetDecoration;
import com.tdo.showbox.utils.SystemUtils;
import com.tdo.showbox.view.activity.actor.ActorDetailContract;
import com.tdo.showbox.view.activity.detail.MoviesDetailActivity;
import com.tdo.showbox.view.activity.detail.TvShowDetailActivity;
import com.umeng.analytics.pro.b;
import de.hdodenhof.circleimageview.CircleImageView;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Objects;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;
/* compiled from: ActorDetailActivity.kt */
@Metadata(bv = {1, 0, 3}, d1 = {"\u0000f\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0007\u0018\u0000 '2\b\u0012\u0004\u0012\u00020\u00020\u00012\u00020\u0003:\u0001'B\u0005¢\u0006\u0002\u0010\u0004J\b\u0010\u0013\u001a\u00020\u0002H\u0014J\b\u0010\u0014\u001a\u00020\u0015H\u0014J\b\u0010\u0016\u001a\u00020\u0015H\u0014J\b\u0010\u0017\u001a\u00020\u0018H\u0014J\b\u0010\u0019\u001a\u00020\u0018H\u0014J\b\u0010\u001a\u001a\u00020\u0018H\u0014J\u0010\u0010\u001b\u001a\u00020\u00182\u0006\u0010\u001c\u001a\u00020\u001dH\u0016J\u0012\u0010\u001e\u001a\u00020\u001f2\b\u0010 \u001a\u0004\u0018\u00010!H\u0016J\b\u0010\"\u001a\u00020\u0018H\u0014J\u0010\u0010#\u001a\u00020\u00182\u0006\u0010$\u001a\u00020\u0006H\u0017J\u0012\u0010%\u001a\u00020\u00182\b\u0010&\u001a\u0004\u0018\u00010\u0010H\u0016R\u0010\u0010\u0005\u001a\u0004\u0018\u00010\u0006X\u0082\u000e¢\u0006\u0002\n\u0000R\u001e\u0010\u0007\u001a\u0012\u0012\u0004\u0012\u00020\t0\bj\b\u0012\u0004\u0012\u00020\t`\nX\u0082\u000e¢\u0006\u0002\n\u0000R\u001e\u0010\u000b\u001a\u0012\u0012\u0004\u0012\u00020\t0\bj\b\u0012\u0004\u0012\u00020\t`\nX\u0082\u000e¢\u0006\u0002\n\u0000R\u0016\u0010\f\u001a\n\u0012\u0004\u0012\u00020\u000e\u0018\u00010\rX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u000f\u001a\u00020\u0010X\u0082.¢\u0006\u0002\n\u0000R\u0014\u0010\u0011\u001a\b\u0012\u0004\u0012\u00020\t0\u0012X\u0082.¢\u0006\u0002\n\u0000¨\u0006("}, d2 = {"Lcom/tdo/showbox/view/activity/actor/ActorDetailActivity;", "Lcom/tdo/showbox/base/mvp/BaseMvpActivity;", "Lcom/tdo/showbox/view/activity/actor/ActorDetailPresenter;", "Lcom/tdo/showbox/view/activity/actor/ActorDetailContract$View;", "()V", "actorModel", "Lcom/tdo/showbox/model/ActorDetailModel;", "movieList", "Ljava/util/ArrayList;", "Lcom/tdo/showbox/model/ActorDetailModel$VideoModel;", "Lkotlin/collections/ArrayList;", "tvList", "tvShowsList", "", "Lcom/tdo/showbox/model/ActorDetailModel$ActorTvShow;", "url", "", "videoAdapter", "Lcom/tdo/showbox/base/CommBaseAdapter;", "bindPresenter", "getLayoutResId", "", "getStatusColor", "initData", "", "initListener", "initView", "onConfigurationChanged", "newConfig", "Landroid/content/res/Configuration;", "onCreateOptionsMenu", "", "menu", "Landroid/view/Menu;", "requestData", "showInfo", "model", "showReviewCount", "num", "Companion", "app_webRelease"}, k = 1, mv = {1, 1, 16})
/* loaded from: classes3.dex */
public final class ActorDetailActivity extends BaseMvpActivity<ActorDetailPresenter> implements ActorDetailContract.View {
    public static final Companion Companion = new Companion(null);
    private HashMap _$_findViewCache;
    private ActorDetailModel actorModel;
    private ArrayList<ActorDetailModel.VideoModel> movieList = new ArrayList<>();
    private ArrayList<ActorDetailModel.VideoModel> tvList = new ArrayList<>();
    private List<? extends ActorDetailModel.ActorTvShow> tvShowsList;
    private String url;
    private CommBaseAdapter<ActorDetailModel.VideoModel> videoAdapter;

    public void _$_clearFindViewByIdCache() {
        HashMap hashMap = this._$_findViewCache;
        if (hashMap != null) {
            hashMap.clear();
        }
    }

    public View _$_findCachedViewById(int i) {
        if (this._$_findViewCache == null) {
            this._$_findViewCache = new HashMap();
        }
        View view = (View) this._$_findViewCache.get(Integer.valueOf(i));
        if (view == null) {
            View findViewById = findViewById(i);
            this._$_findViewCache.put(Integer.valueOf(i), findViewById);
            return findViewById;
        }
        return view;
    }

    @Override // com.tdo.showbox.base.mvp.BaseMvpActivity
    protected int getLayoutResId() {
        return R.layout.activity_actor_detail;
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // com.tdo.showbox.base.mvp.BaseMvpActivity
    public int getStatusColor() {
        return R.color.color_main;
    }

    @Override // com.tdo.showbox.view.activity.actor.ActorDetailContract.View
    public void showReviewCount(String str) {
    }

    public static final /* synthetic */ String access$getUrl$p(ActorDetailActivity actorDetailActivity) {
        String str = actorDetailActivity.url;
        if (str == null) {
            Intrinsics.throwUninitializedPropertyAccessException("url");
        }
        return str;
    }

    public static final /* synthetic */ CommBaseAdapter access$getVideoAdapter$p(ActorDetailActivity actorDetailActivity) {
        CommBaseAdapter<ActorDetailModel.VideoModel> commBaseAdapter = actorDetailActivity.videoAdapter;
        if (commBaseAdapter == null) {
            Intrinsics.throwUninitializedPropertyAccessException("videoAdapter");
        }
        return commBaseAdapter;
    }

    @Override // com.tdo.showbox.base.mvp.BaseMvpActivity
    protected void initListener() {
        ((TabLayout) _$_findCachedViewById(R.id.tabLayout)).addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() { // from class: com.tdo.showbox.view.activity.actor.ActorDetailActivity$initListener$1
            @Override // com.google.android.material.tabs.TabLayout.BaseOnTabSelectedListener
            public void onTabReselected(TabLayout.Tab tab) {
            }

            @Override // com.google.android.material.tabs.TabLayout.BaseOnTabSelectedListener
            public void onTabUnselected(TabLayout.Tab tab) {
            }

            @Override // com.google.android.material.tabs.TabLayout.BaseOnTabSelectedListener
            public void onTabSelected(TabLayout.Tab tab) {
                ArrayList arrayList;
                ArrayList arrayList2;
                ArrayList arrayList3;
                ArrayList arrayList4;
                if (tab != null && tab.getPosition() == 0) {
                    CommBaseAdapter access$getVideoAdapter$p = ActorDetailActivity.access$getVideoAdapter$p(ActorDetailActivity.this);
                    arrayList3 = ActorDetailActivity.this.movieList;
                    access$getVideoAdapter$p.setNewData(arrayList3);
                    arrayList4 = ActorDetailActivity.this.movieList;
                    if (!arrayList4.isEmpty()) {
                        return;
                    }
                    ActorDetailActivity.access$getVideoAdapter$p(ActorDetailActivity.this).setEmptyView(R.layout.empty_view_layout);
                    return;
                }
                CommBaseAdapter access$getVideoAdapter$p2 = ActorDetailActivity.access$getVideoAdapter$p(ActorDetailActivity.this);
                arrayList = ActorDetailActivity.this.tvList;
                access$getVideoAdapter$p2.setNewData(arrayList);
                arrayList2 = ActorDetailActivity.this.tvList;
                if (!arrayList2.isEmpty()) {
                    return;
                }
                ActorDetailActivity.access$getVideoAdapter$p(ActorDetailActivity.this).setEmptyView(R.layout.empty_view_layout);
            }
        });
        CommBaseAdapter<ActorDetailModel.VideoModel> commBaseAdapter = this.videoAdapter;
        if (commBaseAdapter == null) {
            Intrinsics.throwUninitializedPropertyAccessException("videoAdapter");
        }
        commBaseAdapter.setOnItemClickListener(new OnItemClickListener() { // from class: com.tdo.showbox.view.activity.actor.ActorDetailActivity$initListener$2
            @Override // com.chad.library.adapter.base.listener.OnItemClickListener
            public final void onItemClick(BaseQuickAdapter<Object, BaseViewHolder> baseQuickAdapter, View view, int i) {
                Intrinsics.checkParameterIsNotNull(baseQuickAdapter, "<anonymous parameter 0>");
                Intrinsics.checkParameterIsNotNull(view, "<anonymous parameter 1>");
                ActorDetailModel.VideoModel videoModel = (ActorDetailModel.VideoModel) ActorDetailActivity.access$getVideoAdapter$p(ActorDetailActivity.this).getItem(i);
                if (videoModel != null) {
                    if (videoModel.getBoxType() == 1) {
                        MoviesDetailActivity.Companion.start(ActorDetailActivity.this, videoModel.getId(), videoModel.getPoster());
                    } else {
                        TvShowDetailActivity.Companion.start(ActorDetailActivity.this, videoModel.getId(), videoModel.getPoster());
                    }
                }
            }
        });
        ((Toolbar) _$_findCachedViewById(R.id.toolBar)).setNavigationOnClickListener(new View.OnClickListener() { // from class: com.tdo.showbox.view.activity.actor.ActorDetailActivity$initListener$3
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                ActorDetailActivity.this.finish();
            }
        });
        ((Toolbar) _$_findCachedViewById(R.id.toolBar)).setOnMenuItemClickListener(new Toolbar.OnMenuItemClickListener() { // from class: com.tdo.showbox.view.activity.actor.ActorDetailActivity$initListener$4
            @Override // androidx.appcompat.widget.Toolbar.OnMenuItemClickListener
            public final boolean onMenuItemClick(MenuItem item) {
                Intrinsics.checkParameterIsNotNull(item, "item");
                if (item.getItemId() == R.id.more) {
                    ActorDetailActivity actorDetailActivity = ActorDetailActivity.this;
                    SystemUtils.startBrowser((Activity) actorDetailActivity, ActorDetailActivity.access$getUrl$p(actorDetailActivity));
                    return true;
                }
                return true;
            }
        });
    }

    @Override // android.app.Activity
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.actor_detail_menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override // com.tdo.showbox.base.mvp.BaseMvpActivity
    protected void initView() {
        setSupportActionBar((Toolbar) _$_findCachedViewById(R.id.toolBar));
        Object requireNonNull = Objects.requireNonNull(getSupportActionBar());
        if (requireNonNull == null) {
            Intrinsics.throwNpe();
        }
        ((ActionBar) requireNonNull).setDisplayHomeAsUpEnabled(true);
        ((TabLayout) _$_findCachedViewById(R.id.tabLayout)).addTab(((TabLayout) _$_findCachedViewById(R.id.tabLayout)).newTab().setText("Movie"));
        ((TabLayout) _$_findCachedViewById(R.id.tabLayout)).addTab(((TabLayout) _$_findCachedViewById(R.id.tabLayout)).newTab().setText("TV Show"));
        ((CollapsingToolbarLayout) _$_findCachedViewById(R.id.collapsingToolbarLayout)).setExpandedTitleColor(0);
        ((CollapsingToolbarLayout) _$_findCachedViewById(R.id.collapsingToolbarLayout)).setCollapsedTitleTextColor(ContextCompat.getColor(this, R.color.black_text));
        ((CollapsingToolbarLayout) _$_findCachedViewById(R.id.collapsingToolbarLayout)).setExpandedTitleTypeface(Typeface.DEFAULT_BOLD);
        ((CollapsingToolbarLayout) _$_findCachedViewById(R.id.collapsingToolbarLayout)).setCollapsedTitleTypeface(Typeface.DEFAULT_BOLD);
    }

    @Override // com.tdo.showbox.base.mvp.BaseMvpActivity
    protected void initData() {
        this.videoAdapter = new CommBaseAdapter<>(R.layout.adapter_actor_video_item, new ActorDetailActivity$initData$1(this), null, 4, null);
        ActorDetailActivity actorDetailActivity = this;
        if (CommonUtils.isScreenLandscape(actorDetailActivity)) {
            RecyclerView recyclerView = (RecyclerView) _$_findCachedViewById(R.id.recyclerView);
            Intrinsics.checkExpressionValueIsNotNull(recyclerView, "recyclerView");
            recyclerView.setLayoutManager(new GridLayoutManager(actorDetailActivity, 5));
        } else {
            RecyclerView recyclerView2 = (RecyclerView) _$_findCachedViewById(R.id.recyclerView);
            Intrinsics.checkExpressionValueIsNotNull(recyclerView2, "recyclerView");
            recyclerView2.setLayoutManager(new GridLayoutManager(actorDetailActivity, 3));
        }
        ((RecyclerView) _$_findCachedViewById(R.id.recyclerView)).addItemDecoration(new GridInsetDecoration(10, 0, true));
        RecyclerView recyclerView3 = (RecyclerView) _$_findCachedViewById(R.id.recyclerView);
        Intrinsics.checkExpressionValueIsNotNull(recyclerView3, "recyclerView");
        CommonExtKt.disableRefreshAnimation(recyclerView3);
        RecyclerView recyclerView4 = (RecyclerView) _$_findCachedViewById(R.id.recyclerView);
        Intrinsics.checkExpressionValueIsNotNull(recyclerView4, "recyclerView");
        CommBaseAdapter<ActorDetailModel.VideoModel> commBaseAdapter = this.videoAdapter;
        if (commBaseAdapter == null) {
            Intrinsics.throwUninitializedPropertyAccessException("videoAdapter");
        }
        recyclerView4.setAdapter(commBaseAdapter);
    }

    @Override // com.tdo.showbox.view.activity.actor.ActorDetailContract.View
    public void showInfo(ActorDetailModel model) {
        Intrinsics.checkParameterIsNotNull(model, "model");
        this.actorModel = model;
        this.tvShowsList = model.getTv();
        ActorModel actor = model.getActor();
        Intrinsics.checkExpressionValueIsNotNull(actor, "model.actor");
        String imdb_link = actor.getImdb_link();
        Intrinsics.checkExpressionValueIsNotNull(imdb_link, "model.actor.imdb_link");
        this.url = imdb_link;
        TextView textView = (TextView) _$_findCachedViewById(R.id.tvName);
        if (textView != null) {
            ActorModel actor2 = model.getActor();
            Intrinsics.checkExpressionValueIsNotNull(actor2, "model.actor");
            textView.setText(actor2.getName());
        }
        TextView textView2 = (TextView) _$_findCachedViewById(R.id.tvJob);
        if (textView2 != null) {
            ActorModel actor3 = model.getActor();
            Intrinsics.checkExpressionValueIsNotNull(actor3, "model.actor");
            String job = actor3.getJob();
            Intrinsics.checkExpressionValueIsNotNull(job, "model.actor.job");
            textView2.setText(StringsKt.replace$default(job, ",", "|", false, 4, (Object) null));
        }
        ActorModel actor4 = model.getActor();
        Intrinsics.checkExpressionValueIsNotNull(actor4, "model.actor");
        GlideUtils.load((Activity) this, actor4.getAvatar(), (ImageView) ((CircleImageView) _$_findCachedViewById(R.id.ivAvatar)), (int) R.drawable.image_loading_placeholer);
        CollapsingToolbarLayout collapsingToolbarLayout = (CollapsingToolbarLayout) _$_findCachedViewById(R.id.collapsingToolbarLayout);
        Intrinsics.checkExpressionValueIsNotNull(collapsingToolbarLayout, "collapsingToolbarLayout");
        ActorModel actor5 = model.getActor();
        Intrinsics.checkExpressionValueIsNotNull(actor5, "model.actor");
        collapsingToolbarLayout.setTitle(actor5.getName());
        List<ActorDetailModel.ActorTvShow> tv2 = model.getTv();
        Intrinsics.checkExpressionValueIsNotNull(tv2, "model.tv");
        for (ActorDetailModel.ActorTvShow it : tv2) {
            ArrayList<ActorDetailModel.VideoModel> arrayList = this.movieList;
            Intrinsics.checkExpressionValueIsNotNull(it, "it");
            arrayList.add(new ActorDetailModel.VideoModel(it.getId(), it.getPoster(), 2));
        }
        List<ActorDetailModel.ActorMovie> movie = model.getMovie();
        Intrinsics.checkExpressionValueIsNotNull(movie, "model.movie");
        for (ActorDetailModel.ActorMovie it2 : movie) {
            ArrayList<ActorDetailModel.VideoModel> arrayList2 = this.movieList;
            Intrinsics.checkExpressionValueIsNotNull(it2, "it");
            arrayList2.add(new ActorDetailModel.VideoModel(it2.getId(), it2.getPoster(), 1));
        }
        CommBaseAdapter<ActorDetailModel.VideoModel> commBaseAdapter = this.videoAdapter;
        if (commBaseAdapter == null) {
            Intrinsics.throwUninitializedPropertyAccessException("videoAdapter");
        }
        commBaseAdapter.setNewData(this.movieList);
    }

    @Override // androidx.appcompat.app.AppCompatActivity, androidx.fragment.app.FragmentActivity, android.app.Activity, android.content.ComponentCallbacks
    public void onConfigurationChanged(Configuration newConfig) {
        Intrinsics.checkParameterIsNotNull(newConfig, "newConfig");
        super.onConfigurationChanged(newConfig);
        Resources resources = getResources();
        Intrinsics.checkExpressionValueIsNotNull(resources, "this.resources");
        if (resources.getConfiguration().orientation == 2) {
            RecyclerView recyclerView = (RecyclerView) _$_findCachedViewById(R.id.recyclerView);
            Intrinsics.checkExpressionValueIsNotNull(recyclerView, "recyclerView");
            recyclerView.setLayoutManager(new GridLayoutManager(this, 5));
            CommBaseAdapter<ActorDetailModel.VideoModel> commBaseAdapter = this.videoAdapter;
            if (commBaseAdapter == null) {
                Intrinsics.throwUninitializedPropertyAccessException("videoAdapter");
            }
            commBaseAdapter.notifyDataSetChanged();
            return;
        }
        Resources resources2 = getResources();
        Intrinsics.checkExpressionValueIsNotNull(resources2, "this.resources");
        if (resources2.getConfiguration().orientation != 1) {
            return;
        }
        RecyclerView recyclerView2 = (RecyclerView) _$_findCachedViewById(R.id.recyclerView);
        Intrinsics.checkExpressionValueIsNotNull(recyclerView2, "recyclerView");
        recyclerView2.setLayoutManager(new GridLayoutManager(this, 3));
        CommBaseAdapter<ActorDetailModel.VideoModel> commBaseAdapter2 = this.videoAdapter;
        if (commBaseAdapter2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("videoAdapter");
        }
        commBaseAdapter2.notifyDataSetChanged();
    }

    @Override // com.tdo.showbox.base.mvp.BaseMvpActivity
    protected void requestData() {
        String stringExtra = getIntent().getStringExtra("id");
        Intrinsics.checkExpressionValueIsNotNull(stringExtra, "intent.getStringExtra(\"id\")");
        ((ActorDetailPresenter) this.mPresenter).getReviewNum(stringExtra);
        String stringExtra2 = getIntent().getStringExtra("id");
        Intrinsics.checkExpressionValueIsNotNull(stringExtra2, "intent.getStringExtra(\"id\")");
        ((ActorDetailPresenter) this.mPresenter).requestDetail(stringExtra2);
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // com.tdo.showbox.base.mvp.BaseMvpActivity
    public ActorDetailPresenter bindPresenter() {
        return new ActorDetailPresenter(this);
    }

    /* compiled from: ActorDetailActivity.kt */
    @Metadata(bv = {1, 0, 3}, d1 = {"\u0000\u001e\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\b\u0086\u0003\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J\u0018\u0010\u0003\u001a\u00020\u00042\b\u0010\u0005\u001a\u0004\u0018\u00010\u00062\u0006\u0010\u0007\u001a\u00020\b¨\u0006\t"}, d2 = {"Lcom/tdo/showbox/view/activity/actor/ActorDetailActivity$Companion;", "", "()V", CampaignEx.JSON_NATIVE_VIDEO_START, "", b.M, "Landroid/content/Context;", "id", "", "app_webRelease"}, k = 1, mv = {1, 1, 16})
    /* loaded from: classes3.dex */
    public static final class Companion {
        private Companion() {
        }

        public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        public final void start(Context context, String id) {
            Intrinsics.checkParameterIsNotNull(id, "id");
            Intent intent = new Intent(context, ActorDetailActivity.class);
            intent.putExtra("id", id);
            if (context != null) {
                context.startActivity(intent);
            }
        }
    }
}
