package com.tdo.showbox.view.activity.actor;

import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.text.TextUtils;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.listener.OnItemClickListener;
import com.chad.library.adapter.base.viewholder.BaseViewHolder;
import com.mintegral.msdk.base.entity.CampaignEx;
import com.tdo.showbox.R;
import com.tdo.showbox.base.BaseSimpleActivity;
import com.tdo.showbox.model.ActorDetailModel;
import com.tdo.showbox.utils.CommonExtKt;
import com.tdo.showbox.utils.CommonUtils;
import com.tdo.showbox.utils.GlideUtils;
import com.tdo.showbox.view.activity.detail.TvShowDetailActivity;
import com.tdo.showbox.view.widget.GridSpacingItemDecoration;
import com.umeng.analytics.pro.b;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
/* compiled from: ActorAllTvShowsActivity.kt */
@Metadata(bv = {1, 0, 3}, d1 = {"\u00000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0002\u0018\u0000 \u00102\u00020\u0001:\u0001\u0010B\u0005¢\u0006\u0002\u0010\u0002J\b\u0010\u0007\u001a\u00020\bH\u0016J\b\u0010\t\u001a\u00020\nH\u0016J\b\u0010\u000b\u001a\u00020\nH\u0016J\b\u0010\f\u001a\u00020\nH\u0016J\u0010\u0010\r\u001a\u00020\n2\u0006\u0010\u000e\u001a\u00020\u000fH\u0016R\u001c\u0010\u0003\u001a\u0010\u0012\u0004\u0012\u00020\u0005\u0012\u0004\u0012\u00020\u0006\u0018\u00010\u0004X\u0082\u000e¢\u0006\u0002\n\u0000¨\u0006\u0011"}, d2 = {"Lcom/tdo/showbox/view/activity/actor/ActorAllTvShowsActivity;", "Lcom/tdo/showbox/base/BaseSimpleActivity;", "()V", "adapter", "Lcom/chad/library/adapter/base/BaseQuickAdapter;", "Lcom/tdo/showbox/model/ActorDetailModel$ActorTvShow;", "Lcom/chad/library/adapter/base/viewholder/BaseViewHolder;", "getLayoutResId", "", "initData", "", "initListener", "initView", "onConfigurationChanged", "newConfig", "Landroid/content/res/Configuration;", "Companion", "app_webRelease"}, k = 1, mv = {1, 1, 16})
/* loaded from: classes3.dex */
public final class ActorAllTvShowsActivity extends BaseSimpleActivity {
    public static final Companion Companion = new Companion(null);
    private HashMap _$_findViewCache;
    private BaseQuickAdapter<ActorDetailModel.ActorTvShow, BaseViewHolder> adapter;

    @Override // com.tdo.showbox.base.BaseSimpleActivity
    public void _$_clearFindViewByIdCache() {
        HashMap hashMap = this._$_findViewCache;
        if (hashMap != null) {
            hashMap.clear();
        }
    }

    @Override // com.tdo.showbox.base.BaseSimpleActivity
    public View _$_findCachedViewById(int i) {
        if (this._$_findViewCache == null) {
            this._$_findViewCache = new HashMap();
        }
        View view = (View) this._$_findViewCache.get(Integer.valueOf(i));
        if (view == null) {
            View findViewById = findViewById(i);
            this._$_findViewCache.put(Integer.valueOf(i), findViewById);
            return findViewById;
        }
        return view;
    }

    @Override // com.tdo.showbox.base.BaseSimpleActivity
    public int getLayoutResId() {
        return R.layout.activity_actor_all_tv_shows;
    }

    @Override // com.tdo.showbox.base.BaseSimpleActivity
    public void initView() {
    }

    @Override // com.tdo.showbox.base.BaseSimpleActivity
    public void initListener() {
        ((LinearLayout) _$_findCachedViewById(R.id.ll_back)).setOnClickListener(new View.OnClickListener() { // from class: com.tdo.showbox.view.activity.actor.ActorAllTvShowsActivity$initListener$1
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                ActorAllTvShowsActivity.this.finish();
            }
        });
    }

    @Override // com.tdo.showbox.base.BaseSimpleActivity
    public void initData() {
        final ArrayList parcelableArrayListExtra = getIntent().getParcelableArrayListExtra("data");
        final ArrayList arrayList = parcelableArrayListExtra;
        this.adapter = new BaseQuickAdapter<ActorDetailModel.ActorTvShow, BaseViewHolder>(R.layout.simple_tv_item, arrayList) { // from class: com.tdo.showbox.view.activity.actor.ActorAllTvShowsActivity$initData$1
            /* JADX INFO: Access modifiers changed from: protected */
            @Override // com.chad.library.adapter.base.BaseQuickAdapter
            public void convert(BaseViewHolder helper, ActorDetailModel.ActorTvShow item) {
                Intrinsics.checkParameterIsNotNull(helper, "helper");
                Intrinsics.checkParameterIsNotNull(item, "item");
                GlideUtils.loadPortraitGifHolder(getContext(), item.getPoster(), (ImageView) helper.getView(R.id.tv_item_poster));
                TextView textView = (TextView) helper.getView(R.id.tv_item_season);
                if (!TextUtils.isEmpty(item.getSeason_episode())) {
                    textView.setText(item.getSeason_episode());
                    CommonExtKt.visible(textView);
                } else {
                    CommonExtKt.gone(textView);
                }
                TextView textView2 = (TextView) helper.getView(R.id.tvImdbRating);
                String imdb_rating = item.getImdb_rating();
                if (imdb_rating == null || imdb_rating.length() == 0) {
                    CommonExtKt.textShadow$default(textView2, "-.-", 0, 0, 6, null);
                    return;
                }
                String imdb_rating2 = item.getImdb_rating();
                if (imdb_rating2 == null) {
                    imdb_rating2 = "";
                }
                CommonExtKt.textShadow$default(textView2, imdb_rating2, 0, 0, 6, null);
            }
        };
        ActorAllTvShowsActivity actorAllTvShowsActivity = this;
        if (CommonUtils.isScreenLandscape(actorAllTvShowsActivity)) {
            RecyclerView rvTvShows = (RecyclerView) _$_findCachedViewById(R.id.rvTvShows);
            Intrinsics.checkExpressionValueIsNotNull(rvTvShows, "rvTvShows");
            rvTvShows.setLayoutManager(new GridLayoutManager(actorAllTvShowsActivity, 5));
        } else {
            RecyclerView rvTvShows2 = (RecyclerView) _$_findCachedViewById(R.id.rvTvShows);
            Intrinsics.checkExpressionValueIsNotNull(rvTvShows2, "rvTvShows");
            rvTvShows2.setLayoutManager(new GridLayoutManager(actorAllTvShowsActivity, 3));
        }
        ((RecyclerView) _$_findCachedViewById(R.id.rvTvShows)).addItemDecoration(new GridSpacingItemDecoration(10, true));
        RecyclerView rvTvShows3 = (RecyclerView) _$_findCachedViewById(R.id.rvTvShows);
        Intrinsics.checkExpressionValueIsNotNull(rvTvShows3, "rvTvShows");
        rvTvShows3.setAdapter(this.adapter);
        TextView tv_title = (TextView) _$_findCachedViewById(R.id.tv_title);
        Intrinsics.checkExpressionValueIsNotNull(tv_title, "tv_title");
        tv_title.setText(getIntent().getStringExtra(CampaignEx.JSON_KEY_TITLE));
        BaseQuickAdapter<ActorDetailModel.ActorTvShow, BaseViewHolder> baseQuickAdapter = this.adapter;
        if (baseQuickAdapter != null) {
            baseQuickAdapter.setOnItemClickListener(new OnItemClickListener() { // from class: com.tdo.showbox.view.activity.actor.ActorAllTvShowsActivity$initData$2
                @Override // com.chad.library.adapter.base.listener.OnItemClickListener
                public final void onItemClick(BaseQuickAdapter<Object, BaseViewHolder> baseQuickAdapter2, View view, int i) {
                    Intrinsics.checkParameterIsNotNull(baseQuickAdapter2, "<anonymous parameter 0>");
                    Intrinsics.checkParameterIsNotNull(view, "<anonymous parameter 1>");
                    Object obj = parcelableArrayListExtra.get(i);
                    Intrinsics.checkExpressionValueIsNotNull(obj, "list[position]");
                    String id = ((ActorDetailModel.ActorTvShow) obj).getId();
                    Object obj2 = parcelableArrayListExtra.get(i);
                    Intrinsics.checkExpressionValueIsNotNull(obj2, "list[position]");
                    TvShowDetailActivity.Companion.start(ActorAllTvShowsActivity.this, id, ((ActorDetailModel.ActorTvShow) obj2).getPoster());
                }
            });
        }
    }

    @Override // androidx.appcompat.app.AppCompatActivity, androidx.fragment.app.FragmentActivity, android.app.Activity, android.content.ComponentCallbacks
    public void onConfigurationChanged(Configuration newConfig) {
        Intrinsics.checkParameterIsNotNull(newConfig, "newConfig");
        super.onConfigurationChanged(newConfig);
        Resources resources = getResources();
        Intrinsics.checkExpressionValueIsNotNull(resources, "this.resources");
        if (resources.getConfiguration().orientation == 2) {
            RecyclerView rvTvShows = (RecyclerView) _$_findCachedViewById(R.id.rvTvShows);
            Intrinsics.checkExpressionValueIsNotNull(rvTvShows, "rvTvShows");
            rvTvShows.setLayoutManager(new GridLayoutManager(this, 5));
            BaseQuickAdapter<ActorDetailModel.ActorTvShow, BaseViewHolder> baseQuickAdapter = this.adapter;
            if (baseQuickAdapter == null) {
                return;
            }
            baseQuickAdapter.notifyDataSetChanged();
            return;
        }
        Resources resources2 = getResources();
        Intrinsics.checkExpressionValueIsNotNull(resources2, "this.resources");
        if (resources2.getConfiguration().orientation != 1) {
            return;
        }
        RecyclerView rvTvShows2 = (RecyclerView) _$_findCachedViewById(R.id.rvTvShows);
        Intrinsics.checkExpressionValueIsNotNull(rvTvShows2, "rvTvShows");
        rvTvShows2.setLayoutManager(new GridLayoutManager(this, 3));
        BaseQuickAdapter<ActorDetailModel.ActorTvShow, BaseViewHolder> baseQuickAdapter2 = this.adapter;
        if (baseQuickAdapter2 == null) {
            return;
        }
        baseQuickAdapter2.notifyDataSetChanged();
    }

    /* compiled from: ActorAllTvShowsActivity.kt */
    @Metadata(bv = {1, 0, 3}, d1 = {"\u0000(\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0000\b\u0086\u0003\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J$\u0010\u0003\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\u00062\u0006\u0010\u0007\u001a\u00020\b2\f\u0010\t\u001a\b\u0012\u0004\u0012\u00020\u000b0\n¨\u0006\f"}, d2 = {"Lcom/tdo/showbox/view/activity/actor/ActorAllTvShowsActivity$Companion;", "", "()V", CampaignEx.JSON_NATIVE_VIDEO_START, "", b.M, "Landroid/content/Context;", CampaignEx.JSON_KEY_TITLE, "", "list", "", "Lcom/tdo/showbox/model/ActorDetailModel$ActorTvShow;", "app_webRelease"}, k = 1, mv = {1, 1, 16})
    /* loaded from: classes3.dex */
    public static final class Companion {
        private Companion() {
        }

        public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        public final void start(Context context, String title, List<? extends ActorDetailModel.ActorTvShow> list) {
            Intrinsics.checkParameterIsNotNull(context, "context");
            Intrinsics.checkParameterIsNotNull(title, "title");
            Intrinsics.checkParameterIsNotNull(list, "list");
            Intent intent = new Intent(context, ActorAllTvShowsActivity.class);
            intent.putExtra(CampaignEx.JSON_KEY_TITLE, title);
            intent.putParcelableArrayListExtra("data", new ArrayList<>(list));
            context.startActivity(intent);
        }
    }
}
