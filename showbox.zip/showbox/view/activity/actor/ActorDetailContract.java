package com.tdo.showbox.view.activity.actor;

import com.tdo.showbox.base.mvp.BaseContract;
import com.tdo.showbox.model.ActorDetailModel;
import kotlin.Metadata;
/* compiled from: ActorDetailContract.kt */
@Metadata(bv = {1, 0, 3}, d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\bf\u0018\u00002\u00020\u0001:\u0002\u0002\u0003¨\u0006\u0004"}, d2 = {"Lcom/tdo/showbox/view/activity/actor/ActorDetailContract;", "", "Presenter", "View", "app_webRelease"}, k = 1, mv = {1, 1, 16})
/* loaded from: classes3.dex */
public interface ActorDetailContract {

    /* compiled from: ActorDetailContract.kt */
    @Metadata(bv = {1, 0, 3}, d1 = {"\u0000\u001a\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\bf\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001J\u0010\u0010\u0003\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\u0006H&¨\u0006\u0007"}, d2 = {"Lcom/tdo/showbox/view/activity/actor/ActorDetailContract$Presenter;", "Lcom/tdo/showbox/base/mvp/BaseContract$BasePresenter;", "Lcom/tdo/showbox/view/activity/actor/ActorDetailContract$View;", "requestDetail", "", "id", "", "app_webRelease"}, k = 1, mv = {1, 1, 16})
    /* loaded from: classes3.dex */
    public interface Presenter extends BaseContract.BasePresenter<View> {
        void requestDetail(String str);
    }

    /* compiled from: ActorDetailContract.kt */
    @Metadata(bv = {1, 0, 3}, d1 = {"\u0000\u001e\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0000\bf\u0018\u00002\u00020\u0001J\u0010\u0010\u0002\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u0005H&J\u0012\u0010\u0006\u001a\u00020\u00032\b\u0010\u0007\u001a\u0004\u0018\u00010\bH&¨\u0006\t"}, d2 = {"Lcom/tdo/showbox/view/activity/actor/ActorDetailContract$View;", "Lcom/tdo/showbox/base/mvp/BaseContract$BaseView;", "showInfo", "", "model", "Lcom/tdo/showbox/model/ActorDetailModel;", "showReviewCount", "num", "", "app_webRelease"}, k = 1, mv = {1, 1, 16})
    /* loaded from: classes3.dex */
    public interface View extends BaseContract.BaseView {
        void showInfo(ActorDetailModel actorDetailModel);

        void showReviewCount(String str);
    }
}
