package com.tdo.showbox.view.activity.actor;

import androidx.lifecycle.LifecycleOwner;
import com.tdo.showbox.base.HttpResponseObserver;
import com.tdo.showbox.base.mvp.BasePresenter;
import com.tdo.showbox.http.API;
import com.tdo.showbox.http.ApiException;
import com.tdo.showbox.http.Http;
import com.tdo.showbox.model.ActorDetailModel;
import com.tdo.showbox.utils.RxUtils;
import com.tdo.showbox.utils.ToastUtils;
import com.tdo.showbox.view.activity.actor.ActorDetailContract;
import com.uber.autodispose.ObservableSubscribeProxy;
import io.reactivex.disposables.Disposable;
import java.util.HashMap;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
/* compiled from: ActorDetailPresenter.kt */
@Metadata(bv = {1, 0, 3}, d1 = {"\u0000(\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0002\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u00012\u00020\u0003B\r\u0012\u0006\u0010\u0004\u001a\u00020\u0005¢\u0006\u0002\u0010\u0006J\u000e\u0010\u0007\u001a\u00020\b2\u0006\u0010\t\u001a\u00020\nJ\u0010\u0010\u000b\u001a\u00020\b2\u0006\u0010\t\u001a\u00020\nH\u0016¨\u0006\f"}, d2 = {"Lcom/tdo/showbox/view/activity/actor/ActorDetailPresenter;", "Lcom/tdo/showbox/base/mvp/BasePresenter;", "Lcom/tdo/showbox/view/activity/actor/ActorDetailContract$View;", "Lcom/tdo/showbox/view/activity/actor/ActorDetailContract$Presenter;", "lifecycleOwner", "Landroidx/lifecycle/LifecycleOwner;", "(Landroidx/lifecycle/LifecycleOwner;)V", "getReviewNum", "", "id", "", "requestDetail", "app_webRelease"}, k = 1, mv = {1, 1, 16})
/* loaded from: classes3.dex */
public final class ActorDetailPresenter extends BasePresenter<ActorDetailContract.View> implements ActorDetailContract.Presenter {
    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public ActorDetailPresenter(LifecycleOwner lifecycleOwner) {
        super(lifecycleOwner);
        Intrinsics.checkParameterIsNotNull(lifecycleOwner, "lifecycleOwner");
    }

    @Override // com.tdo.showbox.view.activity.actor.ActorDetailContract.Presenter
    public void requestDetail(String id) {
        Intrinsics.checkParameterIsNotNull(id, "id");
        ((ObservableSubscribeProxy) Http.getService().ActorDetail(API.BASE_URL, "Actor", id).compose(RxUtils.rxTranslate2Bean(ActorDetailModel.class)).compose(RxUtils.rxSchedulerHelper()).as(RxUtils.bindLifecycleOwner(this.mLifecycleOwner))).subscribe(new HttpResponseObserver<ActorDetailModel>() { // from class: com.tdo.showbox.view.activity.actor.ActorDetailPresenter$requestDetail$1
            @Override // com.tdo.showbox.base.HttpResponseObserver
            public void onStart(Disposable d) {
                Intrinsics.checkParameterIsNotNull(d, "d");
                ActorDetailPresenter.this.getView().showLoading();
            }

            @Override // com.tdo.showbox.base.HttpResponseObserver
            public void onSuccess(ActorDetailModel model) {
                Intrinsics.checkParameterIsNotNull(model, "model");
                ActorDetailPresenter.this.getView().hideLoading();
                ActorDetailPresenter.this.getView().showInfo(model);
            }

            @Override // com.tdo.showbox.base.HttpResponseObserver
            public void onError(ApiException e) {
                Intrinsics.checkParameterIsNotNull(e, "e");
                ActorDetailPresenter.this.getView().hideLoading();
                ToastUtils.showShort("load failed:" + e.getMessage(), new Object[0]);
            }
        });
    }

    public final void getReviewNum(String id) {
        Intrinsics.checkParameterIsNotNull(id, "id");
        ((ObservableSubscribeProxy) Http.getService().getReviewNum(API.BBS_URL, "get_threadlist_videoid_count", id, 4, 41).compose(RxUtils.rxTranslate2Bean(HashMap.class)).compose(RxUtils.rxSchedulerHelper()).as(RxUtils.bindLifecycleOwner(this.mLifecycleOwner))).subscribe(new HttpResponseObserver<HashMap<?, ?>>() { // from class: com.tdo.showbox.view.activity.actor.ActorDetailPresenter$getReviewNum$1
            @Override // com.tdo.showbox.base.HttpResponseObserver
            public void onError(ApiException e) {
                Intrinsics.checkParameterIsNotNull(e, "e");
            }

            @Override // com.tdo.showbox.base.HttpResponseObserver
            public void onStart(Disposable d) {
                Intrinsics.checkParameterIsNotNull(d, "d");
            }

            @Override // com.tdo.showbox.base.HttpResponseObserver
            public void onSuccess(HashMap<?, ?> model) {
                Intrinsics.checkParameterIsNotNull(model, "model");
                ActorDetailContract.View view = ActorDetailPresenter.this.getView();
                Object obj = model.get("count");
                if (!(obj instanceof String)) {
                    obj = null;
                }
                view.showReviewCount((String) obj);
            }
        });
    }
}
