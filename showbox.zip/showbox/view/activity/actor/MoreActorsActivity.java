package com.tdo.showbox.view.activity.actor;

import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.listener.OnItemClickListener;
import com.chad.library.adapter.base.viewholder.BaseViewHolder;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.hpplay.sdk.source.protocol.f;
import com.mintegral.msdk.base.entity.CampaignEx;
import com.tdo.showbox.R;
import com.tdo.showbox.app.App;
import com.tdo.showbox.base.BaseListActivity;
import com.tdo.showbox.http.API;
import com.tdo.showbox.http.Http;
import com.tdo.showbox.model.ActorModel;
import com.tdo.showbox.utils.CommonExtKt;
import com.tdo.showbox.utils.CommonUtils;
import com.tdo.showbox.utils.DensityUtils;
import com.tdo.showbox.utils.GlideUtils;
import com.tdo.showbox.view.widget.GridSpacingItemDecoration;
import com.umeng.analytics.pro.b;
import io.reactivex.Observable;
import java.util.HashMap;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
/* compiled from: MoreActorsActivity.kt */
@Metadata(bv = {1, 0, 3}, d1 = {"\u0000L\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u000e\n\u0002\b\u0005\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\u0018\u0000 \u001d2\u000e\u0012\u0004\u0012\u00020\u0002\u0012\u0004\u0012\u00020\u00030\u0001:\u0001\u001dB\u0005¢\u0006\u0002\u0010\u0004J\u0012\u0010\b\u001a\u00020\t2\b\u0010\n\u001a\u0004\u0018\u00010\u000bH\u0014J\u000e\u0010\f\u001a\b\u0012\u0004\u0012\u00020\u00030\rH\u0014J\b\u0010\u000e\u001a\u00020\u000fH\u0014J\u001a\u0010\u0010\u001a\u00020\t2\u0006\u0010\u0011\u001a\u00020\u00122\b\u0010\u0013\u001a\u0004\u0018\u00010\u0002H\u0014J\b\u0010\u0014\u001a\u00020\u000fH\u0014J\b\u0010\u0015\u001a\u00020\u0016H\u0014J\b\u0010\u0017\u001a\u00020\u0016H\u0014J\u0010\u0010\u0018\u001a\u00020\t2\u0006\u0010\u0019\u001a\u00020\u001aH\u0016J\b\u0010\u001b\u001a\u00020\u001cH\u0014R\u000e\u0010\u0005\u001a\u00020\u0003X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0003X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\u0003X\u0082\u000e¢\u0006\u0002\n\u0000¨\u0006\u001e"}, d2 = {"Lcom/tdo/showbox/view/activity/actor/MoreActorsActivity;", "Lcom/tdo/showbox/base/BaseListActivity;", "Lcom/tdo/showbox/model/ActorModel;", "", "()V", "id", "keyword", "type", "getIntentData", "", "intent", "Landroid/content/Intent;", "getServiceData", "Lio/reactivex/Observable;", "gridLayoutSpan", "", "initHolder", "helper", "Lcom/chad/library/adapter/base/viewholder/BaseViewHolder;", f.g, "initItemLayout", "isOpenLoadMore", "", "isVerticalLayout", "onConfigurationChanged", "newConfig", "Landroid/content/res/Configuration;", "onItemClick", "Lcom/chad/library/adapter/base/listener/OnItemClickListener;", "Companion", "app_webRelease"}, k = 1, mv = {1, 1, 16})
/* loaded from: classes3.dex */
public final class MoreActorsActivity extends BaseListActivity<ActorModel, String> {
    public static final Companion Companion = new Companion(null);
    private HashMap _$_findViewCache;
    private String type = "";
    private String id = "";
    private String keyword = "";

    public void _$_clearFindViewByIdCache() {
        HashMap hashMap = this._$_findViewCache;
        if (hashMap != null) {
            hashMap.clear();
        }
    }

    public View _$_findCachedViewById(int i) {
        if (this._$_findViewCache == null) {
            this._$_findViewCache = new HashMap();
        }
        View view = (View) this._$_findViewCache.get(Integer.valueOf(i));
        if (view == null) {
            View findViewById = findViewById(i);
            this._$_findViewCache.put(Integer.valueOf(i), findViewById);
            return findViewById;
        }
        return view;
    }

    @Override // com.tdo.showbox.base.BaseListActivity
    protected int initItemLayout() {
        return R.layout.adapter_actor_list_item;
    }

    @Override // com.tdo.showbox.base.BaseListActivity
    protected boolean isOpenLoadMore() {
        return true;
    }

    @Override // com.tdo.showbox.base.BaseListActivity
    protected boolean isVerticalLayout() {
        return false;
    }

    @Override // com.tdo.showbox.base.BaseListActivity
    protected Observable<String> getServiceData() {
        String str = this.type;
        int hashCode = str.hashCode();
        if (hashCode != -906336856) {
            if (hashCode != 3714) {
                if (hashCode == 104087344 && str.equals("movie")) {
                    Observable<String> MovieActors = Http.getService().MovieActors(API.BASE_URL, API.Movie.MOVIE_ACTORS, this.id, this.mCurrentPage, this.mPageSize);
                    Intrinsics.checkExpressionValueIsNotNull(MovieActors, "Http.getService().MovieA… mCurrentPage, mPageSize)");
                    return MovieActors;
                }
            } else if (str.equals("tv")) {
                Observable<String> TvActors = Http.getService().TvActors(API.BASE_URL, API.Tv.TV_ACTORS, this.id, this.mCurrentPage, this.mPageSize);
                Intrinsics.checkExpressionValueIsNotNull(TvActors, "Http.getService().TvActo… mCurrentPage, mPageSize)");
                return TvActors;
            }
        } else if (str.equals(FirebaseAnalytics.Event.SEARCH)) {
            Observable<String> Search = Http.getService().Search(API.BASE_URL, API.Search.SEARCH3, "actor", this.keyword, App.isLogin() ? App.getUserData().uid : "", String.valueOf(this.mCurrentPage), String.valueOf(this.mPageSize));
            Intrinsics.checkExpressionValueIsNotNull(Search, "Http.getService().Search…(), mPageSize.toString())");
            return Search;
        }
        Observable<String> MovieActors2 = Http.getService().MovieActors(API.BASE_URL, API.Movie.MOVIE_ACTORS, this.id, this.mCurrentPage, this.mPageSize);
        Intrinsics.checkExpressionValueIsNotNull(MovieActors2, "Http.getService().MovieA… mCurrentPage, mPageSize)");
        return MovieActors2;
    }

    @Override // com.tdo.showbox.base.BaseListActivity
    protected OnItemClickListener onItemClick() {
        return new OnItemClickListener() { // from class: com.tdo.showbox.view.activity.actor.MoreActorsActivity$onItemClick$1
            @Override // com.chad.library.adapter.base.listener.OnItemClickListener
            public final void onItemClick(BaseQuickAdapter<Object, BaseViewHolder> baseQuickAdapter, View view, int i) {
                BaseQuickAdapter baseQuickAdapter2;
                String actor_id;
                Intrinsics.checkParameterIsNotNull(baseQuickAdapter, "<anonymous parameter 0>");
                Intrinsics.checkParameterIsNotNull(view, "<anonymous parameter 1>");
                baseQuickAdapter2 = MoreActorsActivity.this.mAdapter;
                ActorModel actorModel = (ActorModel) baseQuickAdapter2.getItem(i);
                if (actorModel == null || (actor_id = actorModel.getActor_id()) == null) {
                    return;
                }
                ActorDetailActivity.Companion.start(MoreActorsActivity.this, actor_id);
            }
        };
    }

    @Override // com.tdo.showbox.base.BaseListActivity
    protected void getIntentData(Intent intent) {
        String str;
        String str2;
        String stringExtra;
        MoreActorsActivity moreActorsActivity = this;
        if (CommonUtils.isScreenLandscape(moreActorsActivity)) {
            this.mRecyclerView.addItemDecoration(new GridSpacingItemDecoration(6, DensityUtils.dp2px(moreActorsActivity, 10.0f), true));
        } else {
            this.mRecyclerView.addItemDecoration(new GridSpacingItemDecoration(3, DensityUtils.dp2px(moreActorsActivity, 10.0f), true));
        }
        this.mClass = ActorModel.class;
        String str3 = "";
        if (intent == null || (str = intent.getStringExtra("id")) == null) {
            str = str3;
        }
        this.id = str;
        if (intent == null || (str2 = intent.getStringExtra("type")) == null) {
            str2 = str3;
        }
        this.type = str2;
        if (intent != null && (stringExtra = intent.getStringExtra("keyword")) != null) {
            str3 = stringExtra;
        }
        this.keyword = str3;
        TextView mTvTitle = this.mTvTitle;
        Intrinsics.checkExpressionValueIsNotNull(mTvTitle, "mTvTitle");
        mTvTitle.setText(intent != null ? intent.getStringExtra(CampaignEx.JSON_KEY_TITLE) : null);
    }

    @Override // com.tdo.showbox.base.BaseListActivity
    protected int gridLayoutSpan() {
        return CommonUtils.isScreenLandscape(this) ? 6 : 3;
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // com.tdo.showbox.base.BaseListActivity
    public void initHolder(BaseViewHolder helper, ActorModel actorModel) {
        Intrinsics.checkParameterIsNotNull(helper, "helper");
        if (actorModel != null) {
            helper.setText(R.id.tvName, actorModel.getName());
            GlideUtils.loadCornerPortraitGifHolder(this, actorModel.getAvatar(), (ImageView) helper.getView(R.id.imageView), 8);
        }
    }

    /* compiled from: MoreActorsActivity.kt */
    @Metadata(bv = {1, 0, 3}, d1 = {"\u0000 \n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0004\b\u0086\u0003\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J4\u0010\u0003\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\u00062\u0006\u0010\u0007\u001a\u00020\b2\u0006\u0010\t\u001a\u00020\b2\b\u0010\n\u001a\u0004\u0018\u00010\b2\b\b\u0002\u0010\u000b\u001a\u00020\bH\u0007¨\u0006\f"}, d2 = {"Lcom/tdo/showbox/view/activity/actor/MoreActorsActivity$Companion;", "", "()V", CampaignEx.JSON_NATIVE_VIDEO_START, "", b.M, "Landroid/content/Context;", "id", "", "type", CampaignEx.JSON_KEY_TITLE, "keyword", "app_webRelease"}, k = 1, mv = {1, 1, 16})
    /* loaded from: classes3.dex */
    public static final class Companion {
        public final void start(Context context, String str, String str2, String str3) {
            start$default(this, context, str, str2, str3, null, 16, null);
        }

        private Companion() {
        }

        public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        public static /* synthetic */ void start$default(Companion companion, Context context, String str, String str2, String str3, String str4, int i, Object obj) {
            if ((i & 16) != 0) {
                str4 = "";
            }
            companion.start(context, str, str2, str3, str4);
        }

        public final void start(Context context, String id, String type, String str, String keyword) {
            Intrinsics.checkParameterIsNotNull(context, "context");
            Intrinsics.checkParameterIsNotNull(id, "id");
            Intrinsics.checkParameterIsNotNull(type, "type");
            Intrinsics.checkParameterIsNotNull(keyword, "keyword");
            Intent intent = new Intent(context, MoreActorsActivity.class);
            intent.putExtra("id", id);
            intent.putExtra("type", type);
            intent.putExtra(CampaignEx.JSON_KEY_TITLE, str);
            intent.putExtra("keyword", keyword);
            context.startActivity(intent);
        }
    }

    @Override // androidx.appcompat.app.AppCompatActivity, androidx.fragment.app.FragmentActivity, android.app.Activity, android.content.ComponentCallbacks
    public void onConfigurationChanged(Configuration newConfig) {
        Intrinsics.checkParameterIsNotNull(newConfig, "newConfig");
        super.onConfigurationChanged(newConfig);
        Resources resources = getResources();
        Intrinsics.checkExpressionValueIsNotNull(resources, "this.resources");
        if (resources.getConfiguration().orientation == 2) {
            RecyclerView mRecyclerView = this.mRecyclerView;
            Intrinsics.checkExpressionValueIsNotNull(mRecyclerView, "mRecyclerView");
            CommonExtKt.resetSpanCount(mRecyclerView, this.mAdapter, 6);
            return;
        }
        Resources resources2 = getResources();
        Intrinsics.checkExpressionValueIsNotNull(resources2, "this.resources");
        if (resources2.getConfiguration().orientation != 1) {
            return;
        }
        RecyclerView mRecyclerView2 = this.mRecyclerView;
        Intrinsics.checkExpressionValueIsNotNull(mRecyclerView2, "mRecyclerView");
        CommonExtKt.resetSpanCount(mRecyclerView2, this.mAdapter, 3);
    }
}
