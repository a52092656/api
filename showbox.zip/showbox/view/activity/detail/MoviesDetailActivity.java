package com.tdo.showbox.view.activity.detail;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.os.Binder;
import android.os.Build;
import android.os.Bundle;
import android.os.IBinder;
import android.os.Parcelable;
import android.util.Size;
import android.util.SizeF;
import android.view.View;
import android.view.animation.LinearInterpolator;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.RecyclerView;
import com.bumptech.glide.request.target.SimpleTarget;
import com.bumptech.glide.request.transition.Transition;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.listener.OnItemClickListener;
import com.chad.library.adapter.base.viewholder.BaseViewHolder;
import com.dl7.player.media.MediaPlayerParams;
import com.google.android.gms.cast.framework.CastContext;
import com.google.android.gms.cast.framework.CastSession;
import com.google.android.gms.cast.framework.SessionManager;
import com.lxj.xpopup.XPopup;
import com.lxj.xpopup.interfaces.OnSelectListener;
import com.mintegral.msdk.base.entity.CampaignEx;
import com.tdo.showbox.R;
import com.tdo.showbox.app.App;
import com.tdo.showbox.app.Constant;
import com.tdo.showbox.base.CommBaseAdapter;
import com.tdo.showbox.base.mvp.BaseMvpActivity;
import com.tdo.showbox.event.OnAddToFavoriteEvent;
import com.tdo.showbox.event.OnPlayFinishEvent;
import com.tdo.showbox.model.ActorModel;
import com.tdo.showbox.model.BaseMediaModel;
import com.tdo.showbox.model.common.Feedback;
import com.tdo.showbox.model.movie.MovieDetail;
import com.tdo.showbox.utils.CommonExtKt;
import com.tdo.showbox.utils.CommonUtils;
import com.tdo.showbox.utils.DensityUtils;
import com.tdo.showbox.utils.GlideUtils;
import com.tdo.showbox.utils.PrefsUtils;
import com.tdo.showbox.utils.SpanUtils;
import com.tdo.showbox.utils.SystemUtils;
import com.tdo.showbox.utils.TimeUtils;
import com.tdo.showbox.utils.ToastUtils;
import com.tdo.showbox.view.activity.actor.MoreActorsActivity;
import com.tdo.showbox.view.activity.detail.MoviesDetailContract;
import com.tdo.showbox.view.activity.settings.InputChildModePasswordActivity;
import com.tdo.showbox.view.activity.user.Login2Activity;
import com.tdo.showbox.view.activity.videoplayer.MoviePlayerActivity;
import com.tdo.showbox.view.dialog.ChildModeHintDialog;
import com.tdo.showbox.view.dialog.DialogAction;
import com.tdo.showbox.view.dialog.DiskDownloadDialog;
import com.tdo.showbox.view.dialog.FeedbackDialog;
import com.tdo.showbox.view.dialog.VideoDescTextDialog;
import com.tdo.showbox.view.fragment.AddVideoToFavoriteFragment;
import com.tdo.showbox.view.fragment.ChooseResolutionDialogFragment;
import com.tencent.tinker.android.dx.instruction.Opcodes;
import com.umeng.analytics.pro.b;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import kotlin.Metadata;
import kotlin.Pair;
import kotlin.TuplesKt;
import kotlin.TypeCastException;
import kotlin.jvm.JvmStatic;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Ref;
import kotlin.jvm.internal.StringCompanionObject;
import kotlin.text.StringsKt;
import me.samlss.broccoli.Broccoli;
import me.samlss.broccoli.BroccoliGradientDrawable;
import me.samlss.broccoli.PlaceholderParameter;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;
/* compiled from: MoviesDetailActivity.kt */
@Metadata(bv = {1, 0, 3}, d1 = {"\u0000x\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\u0011\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\u000b\n\u0002\b\u0004\n\u0002\u0010\b\n\u0002\b\n\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010!\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\u0018\u0000 52\b\u0012\u0004\u0012\u00020\u00020\u00012\u00020\u0003:\u00015B\u0005¢\u0006\u0002\u0010\u0004J!\u0010\u0011\u001a\u00020\u00122\u0012\u0010\u0013\u001a\n\u0012\u0006\b\u0001\u0012\u00020\u00150\u0014\"\u00020\u0015H\u0002¢\u0006\u0002\u0010\u0016J\b\u0010\u0017\u001a\u00020\u0002H\u0014J\u0010\u0010\u0018\u001a\u00020\u00122\u0006\u0010\u0019\u001a\u00020\u001aH\u0016J\u0010\u0010\u001b\u001a\u00020\u001a2\u0006\u0010\u001c\u001a\u00020\u000bH\u0002J\b\u0010\u001d\u001a\u00020\u001aH\u0014J\b\u0010\u001e\u001a\u00020\u001fH\u0014J\u0010\u0010 \u001a\u00020\u00122\u0006\u0010\f\u001a\u00020\rH\u0016J\b\u0010!\u001a\u00020\u0012H\u0016J\b\u0010\"\u001a\u00020\u0012H\u0014J\b\u0010#\u001a\u00020\u0012H\u0014J\b\u0010$\u001a\u00020\u0012H\u0014J\b\u0010%\u001a\u00020\u001aH\u0014J\b\u0010&\u001a\u00020\u001aH\u0014J\b\u0010'\u001a\u00020\u0012H\u0016J\u0010\u0010(\u001a\u00020\u00122\u0006\u0010)\u001a\u00020*H\u0007J\u0010\u0010+\u001a\u00020\u00122\u0006\u0010)\u001a\u00020,H\u0007J\b\u0010-\u001a\u00020\u0012H\u0014J\u0016\u0010.\u001a\u00020\u00122\f\u0010/\u001a\b\u0012\u0004\u0012\u00020\u000700H\u0016J\u0010\u00101\u001a\u00020\u00122\u0006\u0010\f\u001a\u00020\rH\u0016J\u0016\u00102\u001a\u00020\u00122\f\u0010/\u001a\b\u0012\u0004\u0012\u00020300H\u0016J\u0010\u00104\u001a\u00020\u00122\u0006\u0010\u0019\u001a\u00020\u001aH\u0002R\u0014\u0010\u0005\u001a\b\u0012\u0004\u0012\u00020\u00070\u0006X\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010\b\u001a\u00020\tX\u0082.¢\u0006\u0002\n\u0000R\u0010\u0010\n\u001a\u0004\u0018\u00010\u000bX\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010\f\u001a\u0004\u0018\u00010\rX\u0082\u000e¢\u0006\u0002\n\u0000R\u0014\u0010\u000e\u001a\b\u0012\u0004\u0012\u00020\u000f0\u0006X\u0082.¢\u0006\u0002\n\u0000R\u0010\u0010\u0010\u001a\u0004\u0018\u00010\u000bX\u0082\u000e¢\u0006\u0002\n\u0000¨\u00066"}, d2 = {"Lcom/tdo/showbox/view/activity/detail/MoviesDetailActivity;", "Lcom/tdo/showbox/base/mvp/BaseMvpActivity;", "Lcom/tdo/showbox/view/activity/detail/MoviesDetailPresenter;", "Lcom/tdo/showbox/view/activity/detail/MoviesDetailContract$View;", "()V", "actorAdapter", "Lcom/tdo/showbox/base/CommBaseAdapter;", "Lcom/tdo/showbox/model/ActorModel;", "broccoli", "Lme/samlss/broccoli/Broccoli;", "id", "", "movieDetail", "Lcom/tdo/showbox/model/movie/MovieDetail;", "movieLikeAdapter", "Lcom/tdo/showbox/model/movie/MovieDetail$Recommend;", "poster", "addHolderView", "", "views", "", "Landroid/view/View;", "([Landroid/view/View;)V", "bindPresenter", "changeFavorite", "isFavorite", "", "checkChildMode", "contentRating", "enableEventBus", "getLayoutResId", "", "goMoviePlayer", "hideLoadingStatus", "initData", "initListener", "initView", "isFullScreen", "isNeedLoadData", "loadingStatus", "onAddFavorite", "event", "Lcom/tdo/showbox/event/OnAddToFavoriteEvent;", "onPlayFinish", "Lcom/tdo/showbox/event/OnPlayFinishEvent;", "requestData", "showActors", "list", "", "showInfo", "showProblemList", "Lcom/tdo/showbox/model/common/Feedback;", "switchFavoriteStatus", "Companion", "app_webRelease"}, k = 1, mv = {1, 1, 16})
/* loaded from: classes.dex */
public final class MoviesDetailActivity extends BaseMvpActivity<MoviesDetailPresenter> implements MoviesDetailContract.View {
    public static final Companion Companion = new Companion(null);
    private HashMap _$_findViewCache;
    private CommBaseAdapter<ActorModel> actorAdapter;
    private Broccoli broccoli;
    private MovieDetail movieDetail;
    private CommBaseAdapter<MovieDetail.Recommend> movieLikeAdapter;
    private String poster = "";
    private String id = "";

    @JvmStatic
    public static final void start(Context context, String str) {
        Companion.start$default(Companion, context, str, null, 4, null);
    }

    @JvmStatic
    public static final void start(Context context, String str, String str2) {
        Companion.start(context, str, str2);
    }

    @JvmStatic
    public static final void startWithFlag(Context context, String str) {
        Companion.startWithFlag$default(Companion, context, str, null, 4, null);
    }

    @JvmStatic
    public static final void startWithFlag(Context context, String str, String str2) {
        Companion.startWithFlag(context, str, str2);
    }

    public void _$_clearFindViewByIdCache() {
        HashMap hashMap = this._$_findViewCache;
        if (hashMap != null) {
            hashMap.clear();
        }
    }

    public View _$_findCachedViewById(int i) {
        if (this._$_findViewCache == null) {
            this._$_findViewCache = new HashMap();
        }
        View view = (View) this._$_findViewCache.get(Integer.valueOf(i));
        if (view == null) {
            View findViewById = findViewById(i);
            this._$_findViewCache.put(Integer.valueOf(i), findViewById);
            return findViewById;
        }
        return view;
    }

    @Override // com.tdo.showbox.base.mvp.BaseMvpActivity
    protected boolean enableEventBus() {
        return true;
    }

    @Override // com.tdo.showbox.base.mvp.BaseMvpActivity
    protected int getLayoutResId() {
        return R.layout.activity_movies_detail;
    }

    @Override // com.tdo.showbox.base.mvp.BaseMvpActivity
    protected boolean isFullScreen() {
        return true;
    }

    @Override // com.tdo.showbox.base.mvp.BaseMvpActivity
    protected boolean isNeedLoadData() {
        return false;
    }

    public static final /* synthetic */ MoviesDetailPresenter access$getMPresenter$p(MoviesDetailActivity moviesDetailActivity) {
        return (MoviesDetailPresenter) moviesDetailActivity.mPresenter;
    }

    public static final /* synthetic */ CommBaseAdapter access$getMovieLikeAdapter$p(MoviesDetailActivity moviesDetailActivity) {
        CommBaseAdapter<MovieDetail.Recommend> commBaseAdapter = moviesDetailActivity.movieLikeAdapter;
        if (commBaseAdapter == null) {
            Intrinsics.throwUninitializedPropertyAccessException("movieLikeAdapter");
        }
        return commBaseAdapter;
    }

    @Override // com.tdo.showbox.base.mvp.BaseMvpActivity
    protected void initListener() {
        ((ImageView) _$_findCachedViewById(R.id.ivBack)).setOnClickListener(new View.OnClickListener() { // from class: com.tdo.showbox.view.activity.detail.MoviesDetailActivity$initListener$1
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                MoviesDetailActivity.this.finish();
            }
        });
        ((TextView) _$_findCachedViewById(R.id.tvDescMore)).setOnClickListener(new View.OnClickListener() { // from class: com.tdo.showbox.view.activity.detail.MoviesDetailActivity$initListener$2
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                LinearLayout llActors = (LinearLayout) MoviesDetailActivity.this._$_findCachedViewById(R.id.llActors);
                Intrinsics.checkExpressionValueIsNotNull(llActors, "llActors");
                if (llActors.getVisibility() == 0) {
                    LinearLayout llActors2 = (LinearLayout) MoviesDetailActivity.this._$_findCachedViewById(R.id.llActors);
                    Intrinsics.checkExpressionValueIsNotNull(llActors2, "llActors");
                    CommonExtKt.gone(llActors2);
                    TextView tvDescMore = (TextView) MoviesDetailActivity.this._$_findCachedViewById(R.id.tvDescMore);
                    Intrinsics.checkExpressionValueIsNotNull(tvDescMore, "tvDescMore");
                    tvDescMore.setText("MORE");
                    return;
                }
                LinearLayout llActors3 = (LinearLayout) MoviesDetailActivity.this._$_findCachedViewById(R.id.llActors);
                Intrinsics.checkExpressionValueIsNotNull(llActors3, "llActors");
                CommonExtKt.visible(llActors3);
                TextView tvDescMore2 = (TextView) MoviesDetailActivity.this._$_findCachedViewById(R.id.tvDescMore);
                Intrinsics.checkExpressionValueIsNotNull(tvDescMore2, "tvDescMore");
                tvDescMore2.setText("LESS");
            }
        });
        ((ImageView) _$_findCachedViewById(R.id.ivHelp)).setOnClickListener(new View.OnClickListener() { // from class: com.tdo.showbox.view.activity.detail.MoviesDetailActivity$initListener$3
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                if (App.isLogin()) {
                    MoviesDetailActivity.access$getMPresenter$p(MoviesDetailActivity.this).getProblemList();
                } else {
                    Login2Activity.start(MoviesDetailActivity.this);
                }
            }
        });
        ((ImageView) _$_findCachedViewById(R.id.ivMore)).setOnClickListener(new View.OnClickListener() { // from class: com.tdo.showbox.view.activity.detail.MoviesDetailActivity$initListener$4
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                String str;
                MovieDetail movieDetail;
                MoreActorsActivity.Companion companion = MoreActorsActivity.Companion;
                MoviesDetailActivity moviesDetailActivity = MoviesDetailActivity.this;
                MoviesDetailActivity moviesDetailActivity2 = moviesDetailActivity;
                str = moviesDetailActivity.id;
                if (str == null) {
                    str = "";
                }
                String str2 = str;
                movieDetail = MoviesDetailActivity.this.movieDetail;
                companion.start(moviesDetailActivity2, str2, "movie", movieDetail != null ? movieDetail.title : null, "");
            }
        });
        ((ImageView) _$_findCachedViewById(R.id.ivShare)).setOnClickListener(new View.OnClickListener() { // from class: com.tdo.showbox.view.activity.detail.MoviesDetailActivity$initListener$5
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                String str;
                Intent intent = new Intent();
                intent.setAction("android.intent.action.SEND");
                intent.setType("text/plain");
                StringBuilder sb = new StringBuilder();
                sb.append("https://www.showbox.media/movie/detail/");
                str = MoviesDetailActivity.this.id;
                sb.append(str);
                intent.putExtra("android.intent.extra.TEXT", sb.toString());
                Intent createChooser = Intent.createChooser(intent, "Share the detail link");
                Intrinsics.checkExpressionValueIsNotNull(createChooser, "Intent.createChooser(sha… \"Share the detail link\")");
                MoviesDetailActivity.this.startActivity(createChooser);
            }
        });
        ((TextView) _$_findCachedViewById(R.id.tvDesc)).setOnClickListener(new View.OnClickListener() { // from class: com.tdo.showbox.view.activity.detail.MoviesDetailActivity$initListener$6
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                VideoDescTextDialog.Builder builder = new VideoDescTextDialog.Builder(MoviesDetailActivity.this);
                TextView tvDesc = (TextView) MoviesDetailActivity.this._$_findCachedViewById(R.id.tvDesc);
                Intrinsics.checkExpressionValueIsNotNull(tvDesc, "tvDesc");
                builder.setContent(tvDesc.getText().toString()).create().show();
            }
        });
        ((LinearLayout) _$_findCachedViewById(R.id.llPlay)).setOnClickListener(new MoviesDetailActivity$initListener$7(this));
        CommBaseAdapter<MovieDetail.Recommend> commBaseAdapter = this.movieLikeAdapter;
        if (commBaseAdapter == null) {
            Intrinsics.throwUninitializedPropertyAccessException("movieLikeAdapter");
        }
        commBaseAdapter.setOnItemClickListener(new OnItemClickListener() { // from class: com.tdo.showbox.view.activity.detail.MoviesDetailActivity$initListener$8
            @Override // com.chad.library.adapter.base.listener.OnItemClickListener
            public final void onItemClick(BaseQuickAdapter<Object, BaseViewHolder> baseQuickAdapter, View view, int i) {
                Intrinsics.checkParameterIsNotNull(baseQuickAdapter, "<anonymous parameter 0>");
                Intrinsics.checkParameterIsNotNull(view, "<anonymous parameter 1>");
                MovieDetail.Recommend recommend = (MovieDetail.Recommend) MoviesDetailActivity.access$getMovieLikeAdapter$p(MoviesDetailActivity.this).getItem(i);
                MoviesDetailActivity.Companion.start(MoviesDetailActivity.this, recommend.mid, recommend.poster);
            }
        });
        ((ImageView) _$_findCachedViewById(R.id.ivFavorite)).setOnClickListener(new View.OnClickListener() { // from class: com.tdo.showbox.view.activity.detail.MoviesDetailActivity$initListener$9
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                MovieDetail movieDetail;
                MovieDetail movieDetail2;
                if (App.isLogin()) {
                    movieDetail = MoviesDetailActivity.this.movieDetail;
                    String str = movieDetail != null ? movieDetail.id : null;
                    movieDetail2 = MoviesDetailActivity.this.movieDetail;
                    AddVideoToFavoriteFragment newInstance = AddVideoToFavoriteFragment.newInstance(str, movieDetail2 != null && movieDetail2.is_collect == 1, 1);
                    FragmentTransaction beginTransaction = MoviesDetailActivity.this.getSupportFragmentManager().beginTransaction();
                    Intrinsics.checkExpressionValueIsNotNull(beginTransaction, "supportFragmentManager.beginTransaction()");
                    AddVideoToFavoriteFragment addVideoToFavoriteFragment = newInstance;
                    beginTransaction.add(addVideoToFavoriteFragment, "AddVideoToFavoriteFragment");
                    beginTransaction.commitAllowingStateLoss();
                    Intrinsics.checkExpressionValueIsNotNull(beginTransaction.show(addVideoToFavoriteFragment), "transaction.show(favoriteFragment)");
                    return;
                }
                Login2Activity.start(MoviesDetailActivity.this);
            }
        });
        ((ImageView) _$_findCachedViewById(R.id.ivDownload)).setOnClickListener(new View.OnClickListener() { // from class: com.tdo.showbox.view.activity.detail.MoviesDetailActivity$initListener$10
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                MovieDetail movieDetail;
                DiskDownloadDialog.Companion companion = DiskDownloadDialog.Companion;
                movieDetail = MoviesDetailActivity.this.movieDetail;
                if (movieDetail == null) {
                    Intrinsics.throwNpe();
                }
                companion.newInstance(movieDetail.id, 1).show(MoviesDetailActivity.this.getSupportFragmentManager(), DiskDownloadDialog.class.getSimpleName());
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final boolean checkChildMode(String str) {
        if (!PrefsUtils.getInstance().getBoolean(Constant.Prefs.CHILD_MODE, false) || !CommonUtils.isChildModeVideo(str)) {
            return false;
        }
        ChildModeHintDialog childModeHintDialog = new ChildModeHintDialog(this);
        childModeHintDialog.setActionListener(new DialogAction.ActionListener() { // from class: com.tdo.showbox.view.activity.detail.MoviesDetailActivity$checkChildMode$1
            @Override // com.tdo.showbox.view.dialog.DialogAction.ActionListener
            public final void onClick() {
                InputChildModePasswordActivity.Companion.start(MoviesDetailActivity.this, 100);
            }
        });
        childModeHintDialog.show();
        return true;
    }

    @Override // com.tdo.showbox.base.mvp.BaseMvpActivity
    protected void initView() {
        DensityUtils.addMarginTopEqualStatusBarHeight((LinearLayout) _$_findCachedViewById(R.id.flTitleBar), this);
    }

    @Override // com.tdo.showbox.base.mvp.BaseMvpActivity
    protected void initData() {
        this.poster = getIntent().getStringExtra("poster");
        this.id = getIntent().getStringExtra("id");
        ((ImageView) _$_findCachedViewById(R.id.ivBlurBg)).post(new Runnable() { // from class: com.tdo.showbox.view.activity.detail.MoviesDetailActivity$initData$1
            @Override // java.lang.Runnable
            public final void run() {
                String str;
                String str2;
                String str3;
                str = MoviesDetailActivity.this.poster;
                String str4 = str;
                if (!(str4 == null || StringsKt.isBlank(str4))) {
                    MoviesDetailActivity moviesDetailActivity = MoviesDetailActivity.this;
                    MoviesDetailActivity moviesDetailActivity2 = moviesDetailActivity;
                    str2 = moviesDetailActivity.poster;
                    GlideUtils.loadCornerPortraitGifHolder(moviesDetailActivity2, str2, (ImageView) MoviesDetailActivity.this._$_findCachedViewById(R.id.ivPoster), 8);
                    final Ref.IntRef intRef = new Ref.IntRef();
                    ImageView ivBlurBg = (ImageView) MoviesDetailActivity.this._$_findCachedViewById(R.id.ivBlurBg);
                    Intrinsics.checkExpressionValueIsNotNull(ivBlurBg, "ivBlurBg");
                    intRef.element = ivBlurBg.getWidth();
                    final Ref.IntRef intRef2 = new Ref.IntRef();
                    ImageView ivBlurBg2 = (ImageView) MoviesDetailActivity.this._$_findCachedViewById(R.id.ivBlurBg);
                    Intrinsics.checkExpressionValueIsNotNull(ivBlurBg2, "ivBlurBg");
                    intRef2.element = ivBlurBg2.getHeight();
                    if (intRef.element == 0) {
                        intRef.element = Opcodes.SHL_INT_LIT8;
                    }
                    if (intRef2.element == 0) {
                        intRef2.element = MediaPlayerParams.STATE_PLAYING;
                    }
                    MoviesDetailActivity moviesDetailActivity3 = MoviesDetailActivity.this;
                    MoviesDetailActivity moviesDetailActivity4 = moviesDetailActivity3;
                    str3 = moviesDetailActivity3.poster;
                    GlideUtils.loadBlur(moviesDetailActivity4, str3, new SimpleTarget<Drawable>(intRef.element, intRef2.element) { // from class: com.tdo.showbox.view.activity.detail.MoviesDetailActivity$initData$1.1
                        @Override // com.bumptech.glide.request.target.Target
                        public /* bridge */ /* synthetic */ void onResourceReady(Object obj, Transition transition) {
                            onResourceReady((Drawable) obj, (Transition<? super Drawable>) transition);
                        }

                        public void onResourceReady(Drawable resource, Transition<? super Drawable> transition) {
                            Intrinsics.checkParameterIsNotNull(resource, "resource");
                            ((ImageView) MoviesDetailActivity.this._$_findCachedViewById(R.id.ivBlurBg)).setImageDrawable(resource);
                        }
                    });
                }
            }
        });
        this.movieLikeAdapter = new CommBaseAdapter<>(R.layout.movie_detail_related_movie_item, new MoviesDetailActivity$initData$2(this), null, 4, null);
        RecyclerView rvLike = (RecyclerView) _$_findCachedViewById(R.id.rvLike);
        Intrinsics.checkExpressionValueIsNotNull(rvLike, "rvLike");
        MoviesDetailActivity moviesDetailActivity = this;
        CommonExtKt.initLinearAndMargin(rvLike, moviesDetailActivity, false, 8, false);
        RecyclerView rvLike2 = (RecyclerView) _$_findCachedViewById(R.id.rvLike);
        Intrinsics.checkExpressionValueIsNotNull(rvLike2, "rvLike");
        CommBaseAdapter<MovieDetail.Recommend> commBaseAdapter = this.movieLikeAdapter;
        if (commBaseAdapter == null) {
            Intrinsics.throwUninitializedPropertyAccessException("movieLikeAdapter");
        }
        rvLike2.setAdapter(commBaseAdapter);
        this.actorAdapter = new CommBaseAdapter<>(R.layout.detail_actor_item, new MoviesDetailActivity$initData$3(this), null, 4, null);
        RecyclerView rvActors = (RecyclerView) _$_findCachedViewById(R.id.rvActors);
        Intrinsics.checkExpressionValueIsNotNull(rvActors, "rvActors");
        CommonExtKt.initGridAndMargin(rvActors, moviesDetailActivity, 4, 10, false);
        RecyclerView rvActors2 = (RecyclerView) _$_findCachedViewById(R.id.rvActors);
        Intrinsics.checkExpressionValueIsNotNull(rvActors2, "rvActors");
        CommBaseAdapter<ActorModel> commBaseAdapter2 = this.actorAdapter;
        if (commBaseAdapter2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("actorAdapter");
        }
        rvActors2.setAdapter(commBaseAdapter2);
        this.broccoli = new Broccoli();
        TextView tvName = (TextView) _$_findCachedViewById(R.id.tvName);
        Intrinsics.checkExpressionValueIsNotNull(tvName, "tvName");
        LinearLayout llInfo = (LinearLayout) _$_findCachedViewById(R.id.llInfo);
        Intrinsics.checkExpressionValueIsNotNull(llInfo, "llInfo");
        TextView tvDesc = (TextView) _$_findCachedViewById(R.id.tvDesc);
        Intrinsics.checkExpressionValueIsNotNull(tvDesc, "tvDesc");
        TextView tvDescMore = (TextView) _$_findCachedViewById(R.id.tvDescMore);
        Intrinsics.checkExpressionValueIsNotNull(tvDescMore, "tvDescMore");
        LinearLayout llPlay = (LinearLayout) _$_findCachedViewById(R.id.llPlay);
        Intrinsics.checkExpressionValueIsNotNull(llPlay, "llPlay");
        ImageView ivDownload = (ImageView) _$_findCachedViewById(R.id.ivDownload);
        Intrinsics.checkExpressionValueIsNotNull(ivDownload, "ivDownload");
        ImageView ivFavorite = (ImageView) _$_findCachedViewById(R.id.ivFavorite);
        Intrinsics.checkExpressionValueIsNotNull(ivFavorite, "ivFavorite");
        TextView tvMoreLike = (TextView) _$_findCachedViewById(R.id.tvMoreLike);
        Intrinsics.checkExpressionValueIsNotNull(tvMoreLike, "tvMoreLike");
        addHolderView(tvName, llInfo, tvDesc, tvDescMore, llPlay, ivDownload, ivFavorite, tvMoreLike);
        ((MoviesDetailPresenter) this.mPresenter).getDetail(this.id);
        ((MoviesDetailPresenter) this.mPresenter).getActors(this.id);
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // com.tdo.showbox.base.mvp.BaseMvpActivity
    public MoviesDetailPresenter bindPresenter() {
        return new MoviesDetailPresenter(this);
    }

    @Override // com.tdo.showbox.base.mvp.BaseMvpActivity
    protected void requestData() {
        ((MoviesDetailPresenter) this.mPresenter).getDetail(this.id);
        ((MoviesDetailPresenter) this.mPresenter).getActors(this.id);
    }

    /* compiled from: MoviesDetailActivity.kt */
    @Metadata(bv = {1, 0, 3}, d1 = {"\u0000 \n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0003\b\u0086\u0003\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J(\u0010\u0003\u001a\u00020\u00042\b\u0010\u0005\u001a\u0004\u0018\u00010\u00062\b\u0010\u0007\u001a\u0004\u0018\u00010\b2\n\b\u0002\u0010\t\u001a\u0004\u0018\u00010\bH\u0007J(\u0010\n\u001a\u00020\u00042\b\u0010\u0005\u001a\u0004\u0018\u00010\u00062\b\u0010\u0007\u001a\u0004\u0018\u00010\b2\n\b\u0002\u0010\t\u001a\u0004\u0018\u00010\bH\u0007¨\u0006\u000b"}, d2 = {"Lcom/tdo/showbox/view/activity/detail/MoviesDetailActivity$Companion;", "", "()V", CampaignEx.JSON_NATIVE_VIDEO_START, "", b.M, "Landroid/content/Context;", "id", "", "poster", "startWithFlag", "app_webRelease"}, k = 1, mv = {1, 1, 16})
    /* loaded from: classes3.dex */
    public static final class Companion {
        @JvmStatic
        public final void start(Context context, String str) {
            start$default(this, context, str, null, 4, null);
        }

        @JvmStatic
        public final void startWithFlag(Context context, String str) {
            startWithFlag$default(this, context, str, null, 4, null);
        }

        private Companion() {
        }

        public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        public static /* synthetic */ void start$default(Companion companion, Context context, String str, String str2, int i, Object obj) {
            if ((i & 4) != 0) {
                str2 = "";
            }
            companion.start(context, str, str2);
        }

        @JvmStatic
        public final void start(Context context, String str, String str2) {
            Pair[] pairArr = {TuplesKt.to("id", str), TuplesKt.to("poster", str2)};
            Intent intent = new Intent(context, MoviesDetailActivity.class);
            Bundle bundle = new Bundle(2);
            for (int i = 0; i < 2; i++) {
                Pair pair = pairArr[i];
                String str3 = (String) pair.component1();
                Object component2 = pair.component2();
                if (component2 == null) {
                    bundle.putString(str3, null);
                } else if (component2 instanceof Boolean) {
                    bundle.putBoolean(str3, ((Boolean) component2).booleanValue());
                } else if (component2 instanceof Byte) {
                    bundle.putByte(str3, ((Number) component2).byteValue());
                } else if (component2 instanceof Character) {
                    bundle.putChar(str3, ((Character) component2).charValue());
                } else if (component2 instanceof Double) {
                    bundle.putDouble(str3, ((Number) component2).doubleValue());
                } else if (component2 instanceof Float) {
                    bundle.putFloat(str3, ((Number) component2).floatValue());
                } else if (component2 instanceof Integer) {
                    bundle.putInt(str3, ((Number) component2).intValue());
                } else if (component2 instanceof Long) {
                    bundle.putLong(str3, ((Number) component2).longValue());
                } else if (component2 instanceof Short) {
                    bundle.putShort(str3, ((Number) component2).shortValue());
                } else if (component2 instanceof Bundle) {
                    bundle.putBundle(str3, (Bundle) component2);
                } else if (component2 instanceof CharSequence) {
                    bundle.putCharSequence(str3, (CharSequence) component2);
                } else if (component2 instanceof Parcelable) {
                    bundle.putParcelable(str3, (Parcelable) component2);
                } else if (component2 instanceof boolean[]) {
                    bundle.putBooleanArray(str3, (boolean[]) component2);
                } else if (component2 instanceof byte[]) {
                    bundle.putByteArray(str3, (byte[]) component2);
                } else if (component2 instanceof char[]) {
                    bundle.putCharArray(str3, (char[]) component2);
                } else if (component2 instanceof double[]) {
                    bundle.putDoubleArray(str3, (double[]) component2);
                } else if (component2 instanceof float[]) {
                    bundle.putFloatArray(str3, (float[]) component2);
                } else if (component2 instanceof int[]) {
                    bundle.putIntArray(str3, (int[]) component2);
                } else if (component2 instanceof long[]) {
                    bundle.putLongArray(str3, (long[]) component2);
                } else if (component2 instanceof short[]) {
                    bundle.putShortArray(str3, (short[]) component2);
                } else if (component2 instanceof Object[]) {
                    Class<?> componentType = component2.getClass().getComponentType();
                    if (componentType == null) {
                        Intrinsics.throwNpe();
                    }
                    if (Parcelable.class.isAssignableFrom(componentType)) {
                        if (component2 == null) {
                            throw new TypeCastException("null cannot be cast to non-null type kotlin.Array<android.os.Parcelable>");
                        }
                        bundle.putParcelableArray(str3, (Parcelable[]) component2);
                    } else if (String.class.isAssignableFrom(componentType)) {
                        if (component2 == null) {
                            throw new TypeCastException("null cannot be cast to non-null type kotlin.Array<kotlin.String>");
                        }
                        bundle.putStringArray(str3, (String[]) component2);
                    } else if (CharSequence.class.isAssignableFrom(componentType)) {
                        if (component2 == null) {
                            throw new TypeCastException("null cannot be cast to non-null type kotlin.Array<kotlin.CharSequence>");
                        }
                        bundle.putCharSequenceArray(str3, (CharSequence[]) component2);
                    } else if (Serializable.class.isAssignableFrom(componentType)) {
                        bundle.putSerializable(str3, (Serializable) component2);
                    } else {
                        String canonicalName = componentType.getCanonicalName();
                        throw new IllegalArgumentException("Illegal value array type " + canonicalName + " for key \"" + str3 + '\"');
                    }
                } else if (component2 instanceof Serializable) {
                    bundle.putSerializable(str3, (Serializable) component2);
                } else if (Build.VERSION.SDK_INT >= 18 && (component2 instanceof Binder)) {
                    bundle.putBinder(str3, (IBinder) component2);
                } else if (Build.VERSION.SDK_INT >= 21 && (component2 instanceof Size)) {
                    bundle.putSize(str3, (Size) component2);
                } else if (Build.VERSION.SDK_INT >= 21 && (component2 instanceof SizeF)) {
                    bundle.putSizeF(str3, (SizeF) component2);
                } else {
                    String canonicalName2 = component2.getClass().getCanonicalName();
                    throw new IllegalArgumentException("Illegal value type " + canonicalName2 + " for key \"" + str3 + '\"');
                }
            }
            intent.putExtras(bundle);
            if (context != null) {
                context.startActivity(intent);
            }
        }

        public static /* synthetic */ void startWithFlag$default(Companion companion, Context context, String str, String str2, int i, Object obj) {
            if ((i & 4) != 0) {
                str2 = "";
            }
            companion.startWithFlag(context, str, str2);
        }

        @JvmStatic
        public final void startWithFlag(Context context, String str, String str2) {
            Pair[] pairArr = {TuplesKt.to("id", str)};
            Intent intent = new Intent(context, MoviesDetailActivity.class);
            Bundle bundle = new Bundle(1);
            for (int i = 0; i < 1; i++) {
                Pair pair = pairArr[i];
                String str3 = (String) pair.component1();
                Object component2 = pair.component2();
                if (component2 == null) {
                    bundle.putString(str3, null);
                } else if (component2 instanceof Boolean) {
                    bundle.putBoolean(str3, ((Boolean) component2).booleanValue());
                } else if (component2 instanceof Byte) {
                    bundle.putByte(str3, ((Number) component2).byteValue());
                } else if (component2 instanceof Character) {
                    bundle.putChar(str3, ((Character) component2).charValue());
                } else if (component2 instanceof Double) {
                    bundle.putDouble(str3, ((Number) component2).doubleValue());
                } else if (component2 instanceof Float) {
                    bundle.putFloat(str3, ((Number) component2).floatValue());
                } else if (component2 instanceof Integer) {
                    bundle.putInt(str3, ((Number) component2).intValue());
                } else if (component2 instanceof Long) {
                    bundle.putLong(str3, ((Number) component2).longValue());
                } else if (component2 instanceof Short) {
                    bundle.putShort(str3, ((Number) component2).shortValue());
                } else if (component2 instanceof Bundle) {
                    bundle.putBundle(str3, (Bundle) component2);
                } else if (component2 instanceof CharSequence) {
                    bundle.putCharSequence(str3, (CharSequence) component2);
                } else if (component2 instanceof Parcelable) {
                    bundle.putParcelable(str3, (Parcelable) component2);
                } else if (component2 instanceof boolean[]) {
                    bundle.putBooleanArray(str3, (boolean[]) component2);
                } else if (component2 instanceof byte[]) {
                    bundle.putByteArray(str3, (byte[]) component2);
                } else if (component2 instanceof char[]) {
                    bundle.putCharArray(str3, (char[]) component2);
                } else if (component2 instanceof double[]) {
                    bundle.putDoubleArray(str3, (double[]) component2);
                } else if (component2 instanceof float[]) {
                    bundle.putFloatArray(str3, (float[]) component2);
                } else if (component2 instanceof int[]) {
                    bundle.putIntArray(str3, (int[]) component2);
                } else if (component2 instanceof long[]) {
                    bundle.putLongArray(str3, (long[]) component2);
                } else if (component2 instanceof short[]) {
                    bundle.putShortArray(str3, (short[]) component2);
                } else if (component2 instanceof Object[]) {
                    Class<?> componentType = component2.getClass().getComponentType();
                    if (componentType == null) {
                        Intrinsics.throwNpe();
                    }
                    if (Parcelable.class.isAssignableFrom(componentType)) {
                        if (component2 == null) {
                            throw new TypeCastException("null cannot be cast to non-null type kotlin.Array<android.os.Parcelable>");
                        }
                        bundle.putParcelableArray(str3, (Parcelable[]) component2);
                    } else if (String.class.isAssignableFrom(componentType)) {
                        if (component2 == null) {
                            throw new TypeCastException("null cannot be cast to non-null type kotlin.Array<kotlin.String>");
                        }
                        bundle.putStringArray(str3, (String[]) component2);
                    } else if (CharSequence.class.isAssignableFrom(componentType)) {
                        if (component2 == null) {
                            throw new TypeCastException("null cannot be cast to non-null type kotlin.Array<kotlin.CharSequence>");
                        }
                        bundle.putCharSequenceArray(str3, (CharSequence[]) component2);
                    } else if (Serializable.class.isAssignableFrom(componentType)) {
                        bundle.putSerializable(str3, (Serializable) component2);
                    } else {
                        String canonicalName = componentType.getCanonicalName();
                        throw new IllegalArgumentException("Illegal value array type " + canonicalName + " for key \"" + str3 + '\"');
                    }
                } else if (component2 instanceof Serializable) {
                    bundle.putSerializable(str3, (Serializable) component2);
                } else if (Build.VERSION.SDK_INT >= 18 && (component2 instanceof Binder)) {
                    bundle.putBinder(str3, (IBinder) component2);
                } else if (Build.VERSION.SDK_INT >= 21 && (component2 instanceof Size)) {
                    bundle.putSize(str3, (Size) component2);
                } else if (Build.VERSION.SDK_INT >= 21 && (component2 instanceof SizeF)) {
                    bundle.putSizeF(str3, (SizeF) component2);
                } else {
                    String canonicalName2 = component2.getClass().getCanonicalName();
                    throw new IllegalArgumentException("Illegal value type " + canonicalName2 + " for key \"" + str3 + '\"');
                }
            }
            intent.putExtras(bundle);
            intent.setFlags(268435456);
            if (context != null) {
                context.startActivity(intent);
            }
        }
    }

    @Override // com.tdo.showbox.view.activity.detail.MoviesDetailContract.View
    public void loadingStatus() {
        Broccoli broccoli = this.broccoli;
        if (broccoli == null) {
            Intrinsics.throwUninitializedPropertyAccessException("broccoli");
        }
        broccoli.show();
    }

    @Override // com.tdo.showbox.view.activity.detail.MoviesDetailContract.View
    public void hideLoadingStatus() {
        Broccoli broccoli = this.broccoli;
        if (broccoli == null) {
            Intrinsics.throwUninitializedPropertyAccessException("broccoli");
        }
        broccoli.removeAllPlaceholders();
        ((ImageView) _$_findCachedViewById(R.id.ivDownload)).setBackgroundResource(R.drawable.detail_like_bg_shape);
        ((ImageView) _$_findCachedViewById(R.id.ivFavorite)).setBackgroundResource(R.drawable.detail_like_bg_shape);
        if (Build.VERSION.SDK_INT >= 21) {
            LinearLayout llPlay = (LinearLayout) _$_findCachedViewById(R.id.llPlay);
            Intrinsics.checkExpressionValueIsNotNull(llPlay, "llPlay");
            llPlay.setElevation(CommonExtKt.dp2Px(3));
        }
    }

    @Override // com.tdo.showbox.view.activity.detail.MoviesDetailContract.View
    public void showInfo(MovieDetail movieDetail) {
        Intrinsics.checkParameterIsNotNull(movieDetail, "movieDetail");
        this.movieDetail = movieDetail;
        ImageView ivPoster = (ImageView) _$_findCachedViewById(R.id.ivPoster);
        Intrinsics.checkExpressionValueIsNotNull(ivPoster, "ivPoster");
        if (ivPoster.getDrawable() == null) {
            GlideUtils.loadCornerPortraitGifHolder(this, movieDetail.poster, (ImageView) _$_findCachedViewById(R.id.ivPoster), 8);
        }
        ImageView ivBlurBg = (ImageView) _$_findCachedViewById(R.id.ivBlurBg);
        Intrinsics.checkExpressionValueIsNotNull(ivBlurBg, "ivBlurBg");
        if (ivBlurBg.getDrawable() == null) {
            final Ref.IntRef intRef = new Ref.IntRef();
            ImageView ivBlurBg2 = (ImageView) _$_findCachedViewById(R.id.ivBlurBg);
            Intrinsics.checkExpressionValueIsNotNull(ivBlurBg2, "ivBlurBg");
            intRef.element = ivBlurBg2.getWidth();
            final Ref.IntRef intRef2 = new Ref.IntRef();
            ImageView ivBlurBg3 = (ImageView) _$_findCachedViewById(R.id.ivBlurBg);
            Intrinsics.checkExpressionValueIsNotNull(ivBlurBg3, "ivBlurBg");
            intRef2.element = ivBlurBg3.getHeight();
            if (intRef.element == 0) {
                intRef.element = Opcodes.SHL_INT_LIT8;
            }
            if (intRef2.element == 0) {
                intRef2.element = MediaPlayerParams.STATE_PLAYING;
            }
            String str = movieDetail.poster;
            final int i = intRef.element;
            final int i2 = intRef2.element;
            GlideUtils.loadBlur(this, str, new SimpleTarget<Drawable>(i, i2) { // from class: com.tdo.showbox.view.activity.detail.MoviesDetailActivity$showInfo$1
                @Override // com.bumptech.glide.request.target.Target
                public /* bridge */ /* synthetic */ void onResourceReady(Object obj, Transition transition) {
                    onResourceReady((Drawable) obj, (Transition<? super Drawable>) transition);
                }

                public void onResourceReady(Drawable resource, Transition<? super Drawable> transition) {
                    Intrinsics.checkParameterIsNotNull(resource, "resource");
                    ((ImageView) MoviesDetailActivity.this._$_findCachedViewById(R.id.ivBlurBg)).setImageDrawable(resource);
                }
            });
        }
        TextView tvName = (TextView) _$_findCachedViewById(R.id.tvName);
        Intrinsics.checkExpressionValueIsNotNull(tvName, "tvName");
        tvName.setText(movieDetail.title);
        SpanUtils span = SpanUtils.with((TextView) _$_findCachedViewById(R.id.tvInfo));
        String str2 = movieDetail.imdb_rating;
        if (!(str2 == null || StringsKt.isBlank(str2))) {
            Intrinsics.checkExpressionValueIsNotNull(span, "span");
            CommonExtKt.addText(span, "IMDB " + movieDetail.imdb_rating + "   ", 12, R.color.gray_999);
        }
        Intrinsics.checkExpressionValueIsNotNull(span, "span");
        String str3 = movieDetail.year;
        if (str3 == null) {
            str3 = "";
        }
        CommonExtKt.addText(span, str3, 12, R.color.gray_999);
        if (!Intrinsics.areEqual(movieDetail.runtime, "0")) {
            CommonExtKt.addText(span, "   " + movieDetail.runtime + "min", 12, R.color.gray_999);
        }
        String str4 = movieDetail.content_rating;
        if (!(str4 == null || StringsKt.isBlank(str4))) {
            StringCompanionObject stringCompanionObject = StringCompanionObject.INSTANCE;
            String format = String.format("   %s", Arrays.copyOf(new Object[]{movieDetail.content_rating}, 1));
            Intrinsics.checkExpressionValueIsNotNull(format, "java.lang.String.format(format, *args)");
            CommonExtKt.addText(span, format, 12, R.color.gray_999);
        }
        span.create();
        TextView tvDesc = (TextView) _$_findCachedViewById(R.id.tvDesc);
        Intrinsics.checkExpressionValueIsNotNull(tvDesc, "tvDesc");
        tvDesc.setText(movieDetail.description);
        if (movieDetail.seconds == 0) {
            TextView tvPlay = (TextView) _$_findCachedViewById(R.id.tvPlay);
            Intrinsics.checkExpressionValueIsNotNull(tvPlay, "tvPlay");
            tvPlay.setText("PLAY NOW");
        } else {
            TextView tvPlay2 = (TextView) _$_findCachedViewById(R.id.tvPlay);
            Intrinsics.checkExpressionValueIsNotNull(tvPlay2, "tvPlay");
            tvPlay2.setText("RESUME " + TimeUtils.getTime(movieDetail.seconds));
        }
        CommBaseAdapter<MovieDetail.Recommend> commBaseAdapter = this.movieLikeAdapter;
        if (commBaseAdapter == null) {
            Intrinsics.throwUninitializedPropertyAccessException("movieLikeAdapter");
        }
        commBaseAdapter.setNewData(movieDetail.recommend);
        if (movieDetail.is_collect == 1) {
            switchFavoriteStatus(true);
        } else {
            switchFavoriteStatus(false);
        }
        TextView tvResolution = (TextView) _$_findCachedViewById(R.id.tvResolution);
        Intrinsics.checkExpressionValueIsNotNull(tvResolution, "tvResolution");
        CommonExtKt.visible(tvResolution);
        TextView tvResolution2 = (TextView) _$_findCachedViewById(R.id.tvResolution);
        Intrinsics.checkExpressionValueIsNotNull(tvResolution2, "tvResolution");
        String str5 = movieDetail.quality_tag;
        Intrinsics.checkExpressionValueIsNotNull(str5, "movieDetail.quality_tag");
        Locale locale = Locale.getDefault();
        Intrinsics.checkExpressionValueIsNotNull(locale, "Locale.getDefault()");
        if (str5 != null) {
            String upperCase = str5.toUpperCase(locale);
            Intrinsics.checkExpressionValueIsNotNull(upperCase, "(this as java.lang.String).toUpperCase(locale)");
            tvResolution2.setText(upperCase);
            return;
        }
        throw new TypeCastException("null cannot be cast to non-null type java.lang.String");
    }

    @Override // com.tdo.showbox.view.activity.detail.MoviesDetailContract.View
    public void showActors(List<ActorModel> list) {
        Intrinsics.checkParameterIsNotNull(list, "list");
        if (list.size() > 4) {
            ImageView ivMore = (ImageView) _$_findCachedViewById(R.id.ivMore);
            Intrinsics.checkExpressionValueIsNotNull(ivMore, "ivMore");
            CommonExtKt.visible(ivMore);
            List<ActorModel> subList = list.subList(0, 4);
            CommBaseAdapter<ActorModel> commBaseAdapter = this.actorAdapter;
            if (commBaseAdapter == null) {
                Intrinsics.throwUninitializedPropertyAccessException("actorAdapter");
            }
            commBaseAdapter.setNewData(subList);
            return;
        }
        CommBaseAdapter<ActorModel> commBaseAdapter2 = this.actorAdapter;
        if (commBaseAdapter2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("actorAdapter");
        }
        commBaseAdapter2.setNewData(list);
    }

    @Override // com.tdo.showbox.view.activity.detail.MoviesDetailContract.View
    public void showProblemList(final List<Feedback> list) {
        Intrinsics.checkParameterIsNotNull(list, "list");
        ArrayList arrayList = new ArrayList();
        for (Feedback feedback : list) {
            arrayList.add(feedback.name);
        }
        XPopup.Builder builder = new XPopup.Builder(this);
        Object[] array = arrayList.toArray(new String[0]);
        if (array != null) {
            builder.asBottomList("", (String[]) array, null, new OnSelectListener() { // from class: com.tdo.showbox.view.activity.detail.MoviesDetailActivity$showProblemList$2
                @Override // com.lxj.xpopup.interfaces.OnSelectListener
                public final void onSelect(int i, String str) {
                    String str2;
                    final Feedback feedback2 = (Feedback) list.get(i);
                    if (feedback2.ftid == 0) {
                        FeedbackDialog feedbackDialog = new FeedbackDialog(MoviesDetailActivity.this, "");
                        feedbackDialog.setMessageListener(new FeedbackDialog.OnMessageListener() { // from class: com.tdo.showbox.view.activity.detail.MoviesDetailActivity$showProblemList$2.1
                            @Override // com.tdo.showbox.view.dialog.FeedbackDialog.OnMessageListener
                            public void onMessage(String message) {
                                String str3;
                                Intrinsics.checkParameterIsNotNull(message, "message");
                                MoviesDetailPresenter access$getMPresenter$p = MoviesDetailActivity.access$getMPresenter$p(MoviesDetailActivity.this);
                                int i2 = feedback2.state;
                                str3 = MoviesDetailActivity.this.id;
                                int i3 = feedback2.ftid;
                                access$getMPresenter$p.sendFeedBack(i2, 1, str3, null, i3, message + SystemUtils.getMsg(), 0, 0);
                            }
                        });
                        feedbackDialog.show();
                        return;
                    }
                    MoviesDetailPresenter access$getMPresenter$p = MoviesDetailActivity.access$getMPresenter$p(MoviesDetailActivity.this);
                    int i2 = feedback2.state;
                    str2 = MoviesDetailActivity.this.id;
                    int i3 = feedback2.ftid;
                    String msg = SystemUtils.getMsg(MoviesDetailActivity.this);
                    Intrinsics.checkExpressionValueIsNotNull(msg, "SystemUtils.getMsg(this)");
                    access$getMPresenter$p.sendFeedBack(i2, 1, str2, null, i3, msg, 0, 0);
                }
            }).show();
            return;
        }
        throw new TypeCastException("null cannot be cast to non-null type kotlin.Array<T>");
    }

    @Override // com.tdo.showbox.view.activity.detail.MoviesDetailContract.View
    public void changeFavorite(boolean z) {
        switchFavoriteStatus(z);
    }

    @Override // com.tdo.showbox.view.activity.detail.MoviesDetailContract.View
    public void goMoviePlayer(MovieDetail movieDetail) {
        Intrinsics.checkParameterIsNotNull(movieDetail, "movieDetail");
        List<BaseMediaModel.DownloadFile> list = movieDetail.list;
        if (list == null || list.isEmpty()) {
            ToastUtils.showShort("No Resource", new Object[0]);
            return;
        }
        MovieDetail movieDetail2 = this.movieDetail;
        if (movieDetail2 != null) {
            movieDetail2.addDonwload(movieDetail);
        }
        ChooseResolutionDialogFragment chooseResolutionDialogFragment = null;
        CastSession castSession = null;
        try {
            CastContext sharedInstance = CastContext.getSharedInstance(this);
            Intrinsics.checkExpressionValueIsNotNull(sharedInstance, "CastContext.getSharedInstance(this)");
            SessionManager sessionManager = sharedInstance.getSessionManager();
            Intrinsics.checkExpressionValueIsNotNull(sessionManager, "CastContext.getSharedInstance(this).sessionManager");
            castSession = sessionManager.getCurrentCastSession();
        } catch (Exception e) {
            e.printStackTrace();
        }
        if (castSession != null && castSession.isConnected()) {
            MovieDetail movieDetail3 = this.movieDetail;
            if (movieDetail3 != null) {
                ChooseResolutionDialogFragment.Companion companion = ChooseResolutionDialogFragment.Companion;
                MovieDetail movieDetail4 = movieDetail3;
                String str = this.id;
                chooseResolutionDialogFragment = ChooseResolutionDialogFragment.Companion.newInstance$default(companion, movieDetail4, str != null ? str : "", 0, 0, false, false, 44, null);
            }
            if (chooseResolutionDialogFragment == null) {
                return;
            }
            chooseResolutionDialogFragment.show(getSupportFragmentManager(), "ChooseResolutionDialogFragment");
            return;
        }
        MoviePlayerActivity.start(this, this.movieDetail, this.id, "");
    }

    private final void switchFavoriteStatus(boolean z) {
        if (z) {
            ((ImageView) _$_findCachedViewById(R.id.ivFavorite)).setImageResource(R.mipmap.ic_added_favorite);
        } else {
            ((ImageView) _$_findCachedViewById(R.id.ivFavorite)).setImageResource(R.mipmap.ic_gray_like);
        }
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public final void onPlayFinish(OnPlayFinishEvent event) {
        Intrinsics.checkParameterIsNotNull(event, "event");
        ((MoviesDetailPresenter) this.mPresenter).getDetail(this.id);
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public final void onAddFavorite(OnAddToFavoriteEvent event) {
        Intrinsics.checkParameterIsNotNull(event, "event");
        if (event.isFavorite()) {
            MovieDetail movieDetail = this.movieDetail;
            if (movieDetail != null) {
                movieDetail.is_collect = 1;
            }
        } else {
            MovieDetail movieDetail2 = this.movieDetail;
            if (movieDetail2 != null) {
                movieDetail2.is_collect = 0;
            }
        }
        switchFavoriteStatus(event.isFavorite());
    }

    private final void addHolderView(View... viewArr) {
        for (View view : viewArr) {
            Broccoli broccoli = this.broccoli;
            if (broccoli == null) {
                Intrinsics.throwUninitializedPropertyAccessException("broccoli");
            }
            broccoli.addPlaceholder(new PlaceholderParameter.Builder().setView(view).setDrawable(new BroccoliGradientDrawable(Color.parseColor("#DDDDDD"), Color.parseColor("#CCCCCC"), CommonExtKt.dp2Px(8), 1000, new LinearInterpolator())).build());
        }
    }
}
