package com.tdo.showbox.view.activity.detail;

import android.widget.ImageView;
import com.chad.library.adapter.base.viewholder.BaseViewHolder;
import com.hpplay.sdk.source.protocol.f;
import com.tdo.showbox.R;
import com.tdo.showbox.model.movie.MovieDetail;
import com.tdo.showbox.utils.GlideUtils;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Lambda;
/* compiled from: MoviesDetailActivity.kt */
@Metadata(bv = {1, 0, 3}, d1 = {"\u0000\u0014\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\u0010\u0000\u001a\u00020\u00012\u0006\u0010\u0002\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u0005H\n¢\u0006\u0002\b\u0006"}, d2 = {"<anonymous>", "", "helper", "Lcom/chad/library/adapter/base/viewholder/BaseViewHolder;", f.g, "Lcom/tdo/showbox/model/movie/MovieDetail$Recommend;", "invoke"}, k = 3, mv = {1, 1, 16})
/* loaded from: classes3.dex */
final class MoviesDetailActivity$initData$2 extends Lambda implements Function2<BaseViewHolder, MovieDetail.Recommend, Unit> {
    final /* synthetic */ MoviesDetailActivity this$0;

    /* JADX INFO: Access modifiers changed from: package-private */
    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public MoviesDetailActivity$initData$2(MoviesDetailActivity moviesDetailActivity) {
        super(2);
        this.this$0 = moviesDetailActivity;
    }

    @Override // kotlin.jvm.functions.Function2
    /* renamed from: invoke */
    public /* bridge */ /* synthetic */ Unit mo1721invoke(BaseViewHolder baseViewHolder, MovieDetail.Recommend recommend) {
        invoke2(baseViewHolder, recommend);
        return Unit.INSTANCE;
    }

    /* renamed from: invoke  reason: avoid collision after fix types in other method */
    public final void invoke2(BaseViewHolder helper, MovieDetail.Recommend item) {
        Intrinsics.checkParameterIsNotNull(helper, "helper");
        Intrinsics.checkParameterIsNotNull(item, "item");
        GlideUtils.loadCornerPortraitGifHolder(this.this$0, item.poster, (ImageView) helper.getView(R.id.favorite_poster), 8);
    }
}
