package com.tdo.showbox.view.activity.detail;

import com.tdo.showbox.model.ActorModel;
import com.tdo.showbox.model.common.Feedback;
import com.tdo.showbox.model.movie.MovieDetail;
import com.tdo.showbox.model.movie.MovieListModel;
import com.tdo.showbox.view.listener.IViewController;
import java.util.List;
/* loaded from: classes.dex */
public interface IMovieDetail extends IViewController {
    void ChoosePlayer(MovieDetail movieDetail);

    void addVideoCallback();

    void getFeedBack(List<Feedback> list);

    void getVideoInfo(MovieDetail movieDetail);

    void setFavorite(boolean z);

    void showActors(List<ActorModel> list);

    void showBottomMovieListDialog(List<MovieListModel.MovieListItem> list);

    void showPoster(String str);

    void showReviewCount(String str);

    void switchPlayButtonStage(int i);
}
