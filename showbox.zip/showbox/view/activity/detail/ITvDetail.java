package com.tdo.showbox.view.activity.detail;

import com.tdo.showbox.model.ActorModel;
import com.tdo.showbox.model.common.Feedback;
import com.tdo.showbox.model.movie.MovieListModel;
import com.tdo.showbox.model.tv.TvDetail;
import com.tdo.showbox.view.listener.IViewController;
import java.util.List;
/* loaded from: classes.dex */
public interface ITvDetail extends IViewController {
    void ChoosePlayer(TvDetail tvDetail, int i, int i2, boolean z);

    void addVideoCallback();

    void getFeedBack(List<Feedback> list);

    void getProblem(List<TvDetail.SeasonDetail> list);

    void getVideoInfo(TvDetail tvDetail);

    void markWatchedComplete();

    void setDateList(List<TvDetail.SeasonDetail> list);

    void setFavorite(boolean z);

    void showActors(List<ActorModel> list);

    void showBottomMovieListDialog(List<MovieListModel.MovieListItem> list);

    void showPoster(String str);

    void showReviewCount(String str);

    void switchPlayButtonStage(int i);
}
