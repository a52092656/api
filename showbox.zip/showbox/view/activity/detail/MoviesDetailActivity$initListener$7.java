package com.tdo.showbox.view.activity.detail;

import android.view.View;
import com.tdo.showbox.model.BaseMediaModel;
import com.tdo.showbox.model.movie.MovieDetail;
import com.tdo.showbox.utils.ToastUtils;
import com.tdo.showbox.view.dialog.DialogAction;
import com.tdo.showbox.view.dialog.ReleasedHintDialog;
import com.tdo.showbox.view.dialog.TsDefinitionHintDialog;
import com.tdo.showbox.view.fragment.ChooseResolutionDialogFragment;
import kotlin.Metadata;
import kotlin.TypeCastException;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;
/* compiled from: MoviesDetailActivity.kt */
@Metadata(bv = {1, 0, 3}, d1 = {"\u0000\u0010\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\u0010\u0000\u001a\u00020\u00012\u000e\u0010\u0002\u001a\n \u0004*\u0004\u0018\u00010\u00030\u0003H\n¢\u0006\u0002\b\u0005"}, d2 = {"<anonymous>", "", "it", "Landroid/view/View;", "kotlin.jvm.PlatformType", "onClick"}, k = 3, mv = {1, 1, 16})
/* loaded from: classes3.dex */
final class MoviesDetailActivity$initListener$7 implements View.OnClickListener {
    final /* synthetic */ MoviesDetailActivity this$0;

    /* JADX INFO: Access modifiers changed from: package-private */
    public MoviesDetailActivity$initListener$7(MoviesDetailActivity moviesDetailActivity) {
        this.this$0 = moviesDetailActivity;
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        MovieDetail movieDetail;
        MovieDetail movieDetail2;
        MovieDetail movieDetail3;
        MovieDetail movieDetail4;
        boolean checkChildMode;
        MovieDetail movieDetail5;
        MovieDetail movieDetail6;
        MovieDetail movieDetail7;
        String str;
        ChooseResolutionDialogFragment newInstance;
        MovieDetail movieDetail8;
        MovieDetail movieDetail9;
        MovieDetail movieDetail10;
        MovieDetail movieDetail11;
        MovieDetail movieDetail12;
        MovieDetail movieDetail13;
        MovieDetail movieDetail14;
        MovieDetail movieDetail15;
        movieDetail = this.this$0.movieDetail;
        if (movieDetail != null) {
            movieDetail2 = this.this$0.movieDetail;
            if (movieDetail2 != null) {
                movieDetail8 = this.this$0.movieDetail;
                if (movieDetail8 == null) {
                    Intrinsics.throwNpe();
                }
                if (movieDetail8.code_file != 1) {
                    movieDetail9 = this.this$0.movieDetail;
                    if (movieDetail9 == null) {
                        Intrinsics.throwNpe();
                    }
                    long j = 1000;
                    final boolean z = false;
                    if (movieDetail9.released_timestamp > System.currentTimeMillis() / j) {
                        movieDetail14 = this.this$0.movieDetail;
                        if (movieDetail14 != null) {
                            movieDetail15 = this.this$0.movieDetail;
                            if (movieDetail15 == null) {
                                Intrinsics.throwNpe();
                            }
                            if (movieDetail15.is_collect == 1) {
                                z = true;
                            }
                        }
                        new ReleasedHintDialog.Builder(this.this$0).setPositiveText(z).setBoxType(1).setActionListener(new DialogAction.ActionListener() { // from class: com.tdo.showbox.view.activity.detail.MoviesDetailActivity$initListener$7$$special$$inlined$let$lambda$1
                            @Override // com.tdo.showbox.view.dialog.DialogAction.ActionListener
                            public final void onClick() {
                                MovieDetail movieDetail16;
                                if (!z) {
                                    MoviesDetailPresenter access$getMPresenter$p = MoviesDetailActivity.access$getMPresenter$p(this.this$0);
                                    movieDetail16 = this.this$0.movieDetail;
                                    if (movieDetail16 == null) {
                                        Intrinsics.throwNpe();
                                    }
                                    access$getMPresenter$p.addFavorite(movieDetail16.id, false);
                                }
                            }
                        }).create().show();
                        return;
                    }
                    movieDetail10 = this.this$0.movieDetail;
                    if (movieDetail10 == null) {
                        Intrinsics.throwNpe();
                    }
                    if (movieDetail10.released_timestamp == 0) {
                        movieDetail13 = this.this$0.movieDetail;
                        if (movieDetail13 == null) {
                            Intrinsics.throwNpe();
                        }
                        if (movieDetail13.is_collect == 1) {
                            z = true;
                        }
                        new ReleasedHintDialog.Builder(this.this$0).setPositiveText(z).setUnknown(true).setBoxType(1).setActionListener(new DialogAction.ActionListener() { // from class: com.tdo.showbox.view.activity.detail.MoviesDetailActivity$initListener$7$$special$$inlined$let$lambda$2
                            @Override // com.tdo.showbox.view.dialog.DialogAction.ActionListener
                            public final void onClick() {
                                MovieDetail movieDetail16;
                                if (!z) {
                                    MoviesDetailPresenter access$getMPresenter$p = MoviesDetailActivity.access$getMPresenter$p(this.this$0);
                                    movieDetail16 = this.this$0.movieDetail;
                                    if (movieDetail16 == null) {
                                        Intrinsics.throwNpe();
                                    }
                                    access$getMPresenter$p.addFavorite(movieDetail16.id, false);
                                }
                            }
                        }).create().show();
                        return;
                    }
                    movieDetail11 = this.this$0.movieDetail;
                    if (movieDetail11 == null) {
                        Intrinsics.throwNpe();
                    }
                    if (movieDetail11.released_timestamp <= 0) {
                        return;
                    }
                    movieDetail12 = this.this$0.movieDetail;
                    if (movieDetail12 == null) {
                        Intrinsics.throwNpe();
                    }
                    if (movieDetail12.released_timestamp >= System.currentTimeMillis() / j) {
                        return;
                    }
                    ToastUtils.showShort("no resource", new Object[0]);
                    return;
                }
            }
            movieDetail3 = this.this$0.movieDetail;
            if (movieDetail3 == null) {
                return;
            }
            MoviesDetailActivity moviesDetailActivity = this.this$0;
            movieDetail4 = moviesDetailActivity.movieDetail;
            if (movieDetail4 == null) {
                Intrinsics.throwNpe();
            }
            String str2 = movieDetail4.content_rating;
            Intrinsics.checkExpressionValueIsNotNull(str2, "movieDetail!!.content_rating");
            checkChildMode = moviesDetailActivity.checkChildMode(str2);
            if (checkChildMode) {
                return;
            }
            movieDetail5 = this.this$0.movieDetail;
            if (movieDetail5 == null) {
                Intrinsics.throwNpe();
            }
            if (!StringsKt.equals("tc", movieDetail5.quality_tag, true)) {
                movieDetail6 = this.this$0.movieDetail;
                if (!(movieDetail6 instanceof BaseMediaModel)) {
                    return;
                }
                movieDetail7 = this.this$0.movieDetail;
                if (movieDetail7 == null) {
                    throw new TypeCastException("null cannot be cast to non-null type com.tdo.showbox.model.BaseMediaModel");
                }
                MovieDetail movieDetail16 = movieDetail7;
                ChooseResolutionDialogFragment.Companion companion = ChooseResolutionDialogFragment.Companion;
                str = this.this$0.id;
                if (str == null) {
                    str = "";
                }
                newInstance = companion.newInstance(movieDetail16, str, (r16 & 4) != 0 ? 0 : 0, (r16 & 8) != 0 ? 0 : 0, (r16 & 16) != 0, (r16 & 32) != 0 ? false : false);
                newInstance.show(this.this$0.getSupportFragmentManager(), ChooseResolutionDialogFragment.class.getSimpleName());
                return;
            }
            new TsDefinitionHintDialog.Builder(this.this$0).setActionListener(new DialogAction.ActionListener() { // from class: com.tdo.showbox.view.activity.detail.MoviesDetailActivity$initListener$7$$special$$inlined$let$lambda$3
                @Override // com.tdo.showbox.view.dialog.DialogAction.ActionListener
                public final void onClick() {
                    MovieDetail movieDetail17;
                    MovieDetail movieDetail18;
                    String str3;
                    ChooseResolutionDialogFragment newInstance2;
                    movieDetail17 = MoviesDetailActivity$initListener$7.this.this$0.movieDetail;
                    if (movieDetail17 instanceof BaseMediaModel) {
                        movieDetail18 = MoviesDetailActivity$initListener$7.this.this$0.movieDetail;
                        if (movieDetail18 == null) {
                            throw new TypeCastException("null cannot be cast to non-null type com.tdo.showbox.model.BaseMediaModel");
                        }
                        MovieDetail movieDetail19 = movieDetail18;
                        ChooseResolutionDialogFragment.Companion companion2 = ChooseResolutionDialogFragment.Companion;
                        str3 = MoviesDetailActivity$initListener$7.this.this$0.id;
                        if (str3 == null) {
                            str3 = "";
                        }
                        newInstance2 = companion2.newInstance(movieDetail19, str3, (r16 & 4) != 0 ? 0 : 0, (r16 & 8) != 0 ? 0 : 0, (r16 & 16) != 0, (r16 & 32) != 0 ? false : false);
                        newInstance2.show(MoviesDetailActivity$initListener$7.this.this$0.getSupportFragmentManager(), ChooseResolutionDialogFragment.class.getSimpleName());
                    }
                }
            }).create().show();
        }
    }
}
