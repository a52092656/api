package com.tdo.showbox.view.activity.detail;

import com.tdo.showbox.base.mvp.BaseContract;
import com.tdo.showbox.model.ActorModel;
import com.tdo.showbox.model.common.Feedback;
import com.tdo.showbox.model.movie.MovieDetail;
import java.util.List;
import kotlin.Metadata;
/* compiled from: MoviesDetailContract.kt */
@Metadata(bv = {1, 0, 3}, d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\bf\u0018\u00002\u00020\u0001:\u0002\u0002\u0003¨\u0006\u0004"}, d2 = {"Lcom/tdo/showbox/view/activity/detail/MoviesDetailContract;", "", "Presenter", "View", "app_webRelease"}, k = 1, mv = {1, 1, 16})
/* loaded from: classes3.dex */
public interface MoviesDetailContract {

    /* compiled from: MoviesDetailContract.kt */
    @Metadata(bv = {1, 0, 3}, d1 = {"\u0000*\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0006\n\u0002\u0010\b\n\u0002\b\b\bf\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001J\u001a\u0010\u0003\u001a\u00020\u00042\b\u0010\u0005\u001a\u0004\u0018\u00010\u00062\u0006\u0010\u0007\u001a\u00020\bH&J\u0012\u0010\t\u001a\u00020\u00042\b\u0010\u0005\u001a\u0004\u0018\u00010\u0006H&J\u0012\u0010\n\u001a\u00020\u00042\b\u0010\u0005\u001a\u0004\u0018\u00010\u0006H&J\u0012\u0010\u000b\u001a\u00020\u00042\b\u0010\u0005\u001a\u0004\u0018\u00010\u0006H&J\b\u0010\f\u001a\u00020\u0004H&JL\u0010\r\u001a\u00020\u00042\u0006\u0010\u000e\u001a\u00020\u000f2\u0006\u0010\u0010\u001a\u00020\u000f2\b\u0010\u0011\u001a\u0004\u0018\u00010\u00062\b\u0010\u0012\u001a\u0004\u0018\u00010\u00062\u0006\u0010\u0013\u001a\u00020\u000f2\u0006\u0010\u0014\u001a\u00020\u00062\u0006\u0010\u0015\u001a\u00020\u000f2\u0006\u0010\u0016\u001a\u00020\u000fH&¨\u0006\u0017"}, d2 = {"Lcom/tdo/showbox/view/activity/detail/MoviesDetailContract$Presenter;", "Lcom/tdo/showbox/base/mvp/BaseContract$BasePresenter;", "Lcom/tdo/showbox/view/activity/detail/MoviesDetailContract$View;", "addFavorite", "", "id", "", "isFavorite", "", "getActors", "getDetail", "getPlayUrl", "getProblemList", "sendFeedBack", "state", "", "box_type", "mid", "sid", "ftid", "text", "season", "episode", "app_webRelease"}, k = 1, mv = {1, 1, 16})
    /* loaded from: classes3.dex */
    public interface Presenter extends BaseContract.BasePresenter<View> {
        void addFavorite(String str, boolean z);

        void getActors(String str);

        void getDetail(String str);

        void getPlayUrl(String str);

        void getProblemList();

        void sendFeedBack(int i, int i2, String str, String str2, int i3, String str3, int i4, int i5);
    }

    /* compiled from: MoviesDetailContract.kt */
    @Metadata(bv = {1, 0, 3}, d1 = {"\u00002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010!\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\bf\u0018\u00002\u00020\u0001J\u0010\u0010\u0002\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u0005H&J\u0010\u0010\u0006\u001a\u00020\u00032\u0006\u0010\u0007\u001a\u00020\bH&J\b\u0010\t\u001a\u00020\u0003H&J\b\u0010\n\u001a\u00020\u0003H&J\u0016\u0010\u000b\u001a\u00020\u00032\f\u0010\f\u001a\b\u0012\u0004\u0012\u00020\u000e0\rH&J\u0010\u0010\u000f\u001a\u00020\u00032\u0006\u0010\u0007\u001a\u00020\bH&J\u0016\u0010\u0010\u001a\u00020\u00032\f\u0010\f\u001a\b\u0012\u0004\u0012\u00020\u00110\rH&¨\u0006\u0012"}, d2 = {"Lcom/tdo/showbox/view/activity/detail/MoviesDetailContract$View;", "Lcom/tdo/showbox/base/mvp/BaseContract$BaseView;", "changeFavorite", "", "isFavorite", "", "goMoviePlayer", "movieDetail", "Lcom/tdo/showbox/model/movie/MovieDetail;", "hideLoadingStatus", "loadingStatus", "showActors", "list", "", "Lcom/tdo/showbox/model/ActorModel;", "showInfo", "showProblemList", "Lcom/tdo/showbox/model/common/Feedback;", "app_webRelease"}, k = 1, mv = {1, 1, 16})
    /* loaded from: classes.dex */
    public interface View extends BaseContract.BaseView {
        void changeFavorite(boolean z);

        void goMoviePlayer(MovieDetail movieDetail);

        void hideLoadingStatus();

        void loadingStatus();

        void showActors(List<ActorModel> list);

        void showInfo(MovieDetail movieDetail);

        void showProblemList(List<Feedback> list);
    }
}
