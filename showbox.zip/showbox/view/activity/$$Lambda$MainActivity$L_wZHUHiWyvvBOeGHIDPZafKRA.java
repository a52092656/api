package com.tdo.showbox.view.activity;

import com.tdo.showbox.model.BBsInfoModel;
import com.tdo.showbox.model.user.UserModel;
import io.reactivex.functions.BiFunction;
/* compiled from: lambda */
/* renamed from: com.tdo.showbox.view.activity.-$$Lambda$MainActivity$L_wZHUHiWyvv-BOeGHIDPZafKRA  reason: invalid class name */
/* loaded from: classes.dex */
public final /* synthetic */ class $$Lambda$MainActivity$L_wZHUHiWyvvBOeGHIDPZafKRA implements BiFunction {
    public static final /* synthetic */ $$Lambda$MainActivity$L_wZHUHiWyvvBOeGHIDPZafKRA INSTANCE = new $$Lambda$MainActivity$L_wZHUHiWyvvBOeGHIDPZafKRA();

    private /* synthetic */ $$Lambda$MainActivity$L_wZHUHiWyvvBOeGHIDPZafKRA() {
    }

    @Override // io.reactivex.functions.BiFunction
    /* renamed from: apply */
    public final Object mo714apply(Object obj, Object obj2) {
        return MainActivity.lambda$loadData$7((BBsInfoModel) obj, (UserModel.UserData) obj2);
    }
}
