package com.tdo.showbox.http;

import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import com.alibaba.fastjson.JSONObject;
import com.franmontiel.persistentcookiejar.PersistentCookieJar;
import com.franmontiel.persistentcookiejar.cache.SetCookieCache;
import com.franmontiel.persistentcookiejar.persistence.SharedPrefsCookiePersistor;
import com.hpplay.cybergarage.xml.XML;
import com.tdo.showbox.BuildConfig;
import com.tdo.showbox.app.App;
import com.tdo.showbox.app.Constant;
import com.tdo.showbox.http.converter.FastJsonConverterFactory;
import com.tdo.showbox.http.converter.ToStringConverterFactory;
import com.tdo.showbox.utils.LogUtils;
import com.tdo.showbox.utils.MLog;
import com.tdo.showbox.utils.PrefsUtils;
import com.tdo.showbox.utils.SSLUtil;
import com.tdo.showbox.utils.TimeUtils;
import com.tencent.bugly.beta.tinker.TinkerUtils;
import java.io.File;
import java.io.IOException;
import java.net.InetAddress;
import java.net.URLDecoder;
import java.net.UnknownHostException;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import okhttp3.Cache;
import okhttp3.CacheControl;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.Dns;
import okhttp3.FormBody;
import okhttp3.Headers;
import okhttp3.HttpUrl;
import okhttp3.Interceptor;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import okhttp3.ResponseBody;
import okhttp3.logging.HttpLoggingInterceptor;
import okio.Buffer;
import org.eclipse.jetty.http.HttpHeaders;
import retrofit2.Retrofit;
import retrofit2.adapter.rxjava2.RxJava2CallAdapterFactory;
/* loaded from: classes.dex */
public class Http {
    private static final String TAG = "Http";
    private static OkHttpClient client;
    private static Handler mHandler = new Handler(Looper.getMainLooper());
    private static APIService service;

    public static APIService getService() {
        if (client == null) {
            initClient();
        }
        if (service == null) {
            createService(API.BASE_URL);
        }
        return service;
    }

    public static OkHttpClient getOkHttpClient() {
        if (client == null) {
            initClient();
        }
        return client;
    }

    public static void baseUrlChanged() {
        createService(API.BASE_URL);
    }

    private static void createService(String str) {
        service = (APIService) new Retrofit.Builder().client(client).baseUrl(str).addCallAdapterFactory(RxJava2CallAdapterFactory.create()).addConverterFactory(new ToStringConverterFactory()).addConverterFactory(FastJsonConverterFactory.create()).build().create(APIService.class);
    }

    private static void initClient() {
        OkHttpClient.Builder builder = new OkHttpClient.Builder();
        if (App.isDebug) {
            setLoggingInterceptor(builder);
        }
        SSLUtil sSLUtil = new SSLUtil();
        sSLUtil.addCertificate();
        builder.sslSocketFactory(sSLUtil.getSSLSocketFactory(), sSLUtil.getMX509TrustManager());
        builder.dns(new HttpDns());
        setCookieJar(builder);
        setHeaderInterceptor(builder);
        setParamsInterceptor(builder);
        setCacheDirectory(builder);
        setTimeout(builder);
        client = builder.build();
    }

    private static void setLoggingInterceptor(OkHttpClient.Builder builder) {
        if (builder != null) {
            HttpLoggingInterceptor httpLoggingInterceptor = new HttpLoggingInterceptor();
            httpLoggingInterceptor.setLevel(HttpLoggingInterceptor.Level.HEADERS);
            builder.addInterceptor(httpLoggingInterceptor);
        }
    }

    private static void setTimeout(OkHttpClient.Builder builder) {
        builder.connectTimeout(60L, TimeUnit.SECONDS);
        builder.readTimeout(60L, TimeUnit.SECONDS);
        builder.writeTimeout(60L, TimeUnit.SECONDS);
        builder.retryOnConnectionFailure(true);
        builder.followRedirects(true);
        builder.followSslRedirects(true);
    }

    private static void setCacheDirectory(OkHttpClient.Builder builder) {
        builder.cache(new Cache(new File(App.getContext().getCacheDir().getPath(), "responses"), 10485760L));
    }

    private static void setCookieJar(OkHttpClient.Builder builder) {
        builder.cookieJar(new PersistentCookieJar(new SetCookieCache(), new SharedPrefsCookiePersistor(App.getContext())));
    }

    private static void setParamsInterceptor(OkHttpClient.Builder builder) {
        if (builder != null) {
            builder.addInterceptor(new Interceptor() { // from class: com.tdo.showbox.http.Http.1
                @Override // okhttp3.Interceptor
                public Response intercept(Interceptor.Chain chain) throws IOException {
                    MediaType contentType;
                    Request request = chain.request();
                    Headers headers = request.headers();
                    String method = request.method();
                    RequestBody body = request.body();
                    String str = null;
                    String mediaType = (body == null || (contentType = body.contentType()) == null) ? null : contentType.toString();
                    if ((method.equalsIgnoreCase("POST") && API.BASE_URL.equalsIgnoreCase(request.url().url().toString())) || API.BBS_URL.equalsIgnoreCase(request.url().url().toString())) {
                        if ("application/x-www-form-urlencoded".equals(mediaType)) {
                            str = Http.addCommonParams(body);
                        } else if ("text/plain; charset=utf-8".equalsIgnoreCase(mediaType)) {
                            str = Http.processText(body);
                        }
                        LogUtils.INSTANCE.logInterfaceParamJson(str);
                        String encodeBody = HttpUtils.encodeBody(str, CipherKeys.getCiperKeys());
                        LogUtils logUtils = LogUtils.INSTANCE;
                        logUtils.logD("API_REQUEST", str + "   " + API.BASE_URL + "?appid=27&data=" + encodeBody + "&DEBUG=1");
                        if (encodeBody != null) {
                            body = RequestBody.create(MediaType.parse("application/x-www-form-urlencoded"), "data=" + encodeBody + "&appid=27&platform=android&version=" + App.versionCode + "&medium=" + App.channel + "&token" + App.deviceToken);
                        }
                    }
                    return chain.proceed(request.newBuilder().headers(headers).method(method, body).url(request.url()).build());
                }
            });
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static String processText(RequestBody requestBody) throws IOException {
        JSONObject parseObject;
        Buffer buffer = new Buffer();
        requestBody.writeTo(buffer);
        String decode = URLDecoder.decode(buffer.readUtf8(), XML.CHARSET_UTF8);
        if (TextUtils.isEmpty(decode)) {
            parseObject = new JSONObject();
        } else {
            parseObject = JSONObject.parseObject(decode);
        }
        parseObject.put("expired_date", (Object) Long.valueOf((TimeUtils.getCurrentTime() / 1000) + 43200));
        parseObject.put("appid", (Object) App.packageName);
        parseObject.put("app_version", (Object) App.versionName);
        parseObject.put("medium ", (Object) App.channel);
        parseObject.put("token ", (Object) App.deviceToken);
        parseObject.put(TinkerUtils.PLATFORM, (Object) "android");
        parseObject.put("channel", (Object) App.channel);
        if (PrefsUtils.getInstance().getBoolean(Constant.Prefs.CHILD_MODE, false)) {
            parseObject.put("childmode", (Object) "1");
        } else {
            parseObject.put("childmode", (Object) "0");
        }
        return parseObject.toJSONString();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static String addCommonParams(RequestBody requestBody) {
        if (requestBody == null || !(requestBody instanceof FormBody)) {
            return "";
        }
        FormBody.Builder builder = new FormBody.Builder();
        builder.add("expired_date", String.valueOf((TimeUtils.getCurrentTime() / 1000) + 43200));
        builder.add(TinkerUtils.PLATFORM, "android");
        builder.add("app_version", BuildConfig.VERSION_NAME);
        builder.add("channel", App.channel);
        if (PrefsUtils.getInstance().getBoolean(Constant.Prefs.CHILD_MODE, false)) {
            builder.add("childmode", "1");
        } else {
            builder.add("childmode", "0");
        }
        builder.add("lang", App.deviceLang);
        builder.add("appid", App.packageName);
        FormBody formBody = (FormBody) requestBody;
        int size = formBody.size();
        for (int i = 0; i < size; i++) {
            builder.add(formBody.name(i), formBody.value(i));
        }
        JSONObject jSONObject = new JSONObject();
        FormBody build = builder.build();
        int size2 = build.size();
        for (int i2 = 0; i2 < size2; i2++) {
            jSONObject.put(build.name(i2), (Object) build.value(i2));
        }
        return jSONObject.toJSONString();
    }

    private static String processBody(RequestBody requestBody) throws IOException {
        String str;
        Buffer buffer = new Buffer();
        requestBody.writeTo(buffer);
        String str2 = (((URLDecoder.decode(buffer.readUtf8(), XML.CHARSET_UTF8) + "&expired_date=" + ((TimeUtils.getCurrentTime() / 1000) + 43200)) + "&platform=android") + "&app_version=" + App.versionName) + "&channel=" + App.channel;
        if (PrefsUtils.getInstance().getBoolean(Constant.Prefs.CHILD_MODE, false)) {
            str = str2 + "&childmode=1";
        } else {
            str = str2 + "&childmode=0";
        }
        MLog.d(TAG, "intercept body:" + str);
        return HttpUtils.formToJson(str);
    }

    private static void setHeaderInterceptor(OkHttpClient.Builder builder) {
        if (builder != null) {
            builder.addInterceptor(new Interceptor() { // from class: com.tdo.showbox.http.Http.2
                @Override // okhttp3.Interceptor
                public Response intercept(Interceptor.Chain chain) throws IOException {
                    Request request = chain.request();
                    return chain.proceed(request.newBuilder().header("Platform", "android").header(HttpHeaders.ACCEPT, "text/plain; charset=utf-8").method(request.method(), request.body()).build());
                }
            });
        }
    }

    public static void get(String str, Map<String, String> map, final RequestCallback<String> requestCallback) {
        OkHttpClient okHttpClient = getOkHttpClient();
        HttpUrl parse = HttpUrl.parse(str);
        if (parse == null) {
            if (requestCallback == null) {
                return;
            }
            mHandler.post(new Runnable() { // from class: com.tdo.showbox.http.Http.4
                @Override // java.lang.Runnable
                public void run() {
                    RequestCallback.this.onFailure(-2, "url错误");
                }
            });
            return;
        }
        HttpUrl.Builder newBuilder = parse.newBuilder();
        if (map != null && !map.isEmpty()) {
            for (Map.Entry<String, String> entry : map.entrySet()) {
                newBuilder.addQueryParameter(entry.getKey(), entry.getValue());
            }
        }
        okHttpClient.newCall(new Request.Builder().url(newBuilder.build()).cacheControl(CacheControl.FORCE_NETWORK).get().build()).enqueue(new Callback() { // from class: com.tdo.showbox.http.Http.3
            @Override // okhttp3.Callback
            public void onFailure(Call call, IOException iOException) {
                if (RequestCallback.this != null) {
                    final String localizedMessage = iOException.getLocalizedMessage();
                    Http.mHandler.post(new Runnable() { // from class: com.tdo.showbox.http.Http.3.1
                        @Override // java.lang.Runnable
                        public void run() {
                            RequestCallback.this.onFailure(-1, localizedMessage);
                        }
                    });
                }
            }

            @Override // okhttp3.Callback
            public void onResponse(Call call, Response response) throws IOException {
                if (response.isSuccessful()) {
                    ResponseBody body = response.body();
                    if (body != null) {
                        final String string = body.string();
                        if (RequestCallback.this == null) {
                            return;
                        }
                        Http.mHandler.post(new Runnable() { // from class: com.tdo.showbox.http.Http.3.2
                            @Override // java.lang.Runnable
                            public void run() {
                                RequestCallback.this.onSuccess(string);
                            }
                        });
                        return;
                    } else if (RequestCallback.this == null) {
                        return;
                    } else {
                        Http.mHandler.post(new Runnable() { // from class: com.tdo.showbox.http.Http.3.3
                            @Override // java.lang.Runnable
                            public void run() {
                                RequestCallback.this.onFailure(-1, "无响应数据");
                            }
                        });
                        return;
                    }
                }
                final int code = response.code();
                final String message = response.message();
                if (RequestCallback.this == null) {
                    return;
                }
                Http.mHandler.post(new Runnable() { // from class: com.tdo.showbox.http.Http.3.4
                    @Override // java.lang.Runnable
                    public void run() {
                        RequestCallback.this.onFailure(code, message);
                    }
                });
            }
        });
    }

    public static void post(String str, Map<String, String> map, final RequestCallback<String> requestCallback) {
        OkHttpClient.Builder builder = new OkHttpClient.Builder();
        if (App.isDebug) {
            setLoggingInterceptor(builder);
        }
        OkHttpClient build = builder.build();
        FormBody.Builder builder2 = new FormBody.Builder();
        if (map != null && !map.isEmpty()) {
            for (Map.Entry<String, String> entry : map.entrySet()) {
                builder2.add(entry.getKey(), entry.getValue());
            }
        }
        build.newCall(new Request.Builder().cacheControl(CacheControl.FORCE_NETWORK).url(str).post(builder2.build()).build()).enqueue(new Callback() { // from class: com.tdo.showbox.http.Http.5
            @Override // okhttp3.Callback
            public void onFailure(Call call, IOException iOException) {
                if (RequestCallback.this != null) {
                    final String localizedMessage = iOException.getLocalizedMessage();
                    Http.mHandler.post(new Runnable() { // from class: com.tdo.showbox.http.Http.5.1
                        @Override // java.lang.Runnable
                        public void run() {
                            RequestCallback.this.onFailure(-1, localizedMessage);
                        }
                    });
                }
            }

            @Override // okhttp3.Callback
            public void onResponse(Call call, Response response) throws IOException {
                if (response.isSuccessful()) {
                    ResponseBody body = response.body();
                    if (body != null) {
                        final String string = body.string();
                        if (RequestCallback.this == null) {
                            return;
                        }
                        Http.mHandler.post(new Runnable() { // from class: com.tdo.showbox.http.Http.5.2
                            @Override // java.lang.Runnable
                            public void run() {
                                RequestCallback.this.onSuccess(string);
                            }
                        });
                    } else if (RequestCallback.this == null) {
                    } else {
                        Http.mHandler.post(new Runnable() { // from class: com.tdo.showbox.http.Http.5.3
                            @Override // java.lang.Runnable
                            public void run() {
                                RequestCallback.this.onFailure(-1, "无响应数据");
                            }
                        });
                    }
                } else if (RequestCallback.this == null) {
                } else {
                    final int code = response.code();
                    final String message = response.message();
                    if (Http.mHandler == null) {
                        return;
                    }
                    Http.mHandler.post(new Runnable() { // from class: com.tdo.showbox.http.Http.5.4
                        @Override // java.lang.Runnable
                        public void run() {
                            RequestCallback.this.onFailure(code, message);
                        }
                    });
                }
            }
        });
    }

    public static void uploadAsync(String str, Map<String, String> map, Map<String, String> map2, final RequestCallback<String> requestCallback) {
        Handler handler;
        Handler handler2;
        Handler handler3;
        OkHttpClient.Builder builder = new OkHttpClient.Builder();
        if (App.isDebug) {
            setLoggingInterceptor(builder);
        }
        OkHttpClient build = builder.build();
        MultipartBody.Builder builder2 = new MultipartBody.Builder();
        if (map != null && !map.isEmpty()) {
            for (Map.Entry<String, String> entry : map.entrySet()) {
                builder2.addFormDataPart(entry.getKey(), entry.getValue());
            }
        }
        if (map2 == null || map2.isEmpty()) {
            if (requestCallback == null || (handler = mHandler) == null) {
                return;
            }
            handler.post(new Runnable() { // from class: com.tdo.showbox.http.Http.8
                @Override // java.lang.Runnable
                public void run() {
                    RequestCallback.this.onFailure(-1, "文件路径未指定");
                }
            });
            return;
        }
        String str2 = null;
        if (map2.containsKey("filePath")) {
            str2 = map2.get("filePath");
        }
        if (str2 == null) {
            if (requestCallback == null || (handler2 = mHandler) == null) {
                return;
            }
            handler2.post(new Runnable() { // from class: com.tdo.showbox.http.Http.7
                @Override // java.lang.Runnable
                public void run() {
                    RequestCallback.this.onFailure(-1, "文件路径未指定");
                }
            });
            return;
        }
        String str3 = map2.containsKey("mimeType") ? map2.get("mimeType") : "image/*";
        File file = new File(str2);
        if (file.exists() && file.isFile()) {
            builder2.addFormDataPart("Filedata", file.getName(), MultipartBody.create(MediaType.parse(str3), file));
            build.newCall(new Request.Builder().cacheControl(CacheControl.FORCE_NETWORK).url(str).post(builder2.build()).build()).enqueue(new Callback() { // from class: com.tdo.showbox.http.Http.9
                @Override // okhttp3.Callback
                public void onFailure(Call call, IOException iOException) {
                    if (RequestCallback.this != null) {
                        final String localizedMessage = iOException.getLocalizedMessage();
                        Http.mHandler.post(new Runnable() { // from class: com.tdo.showbox.http.Http.9.1
                            @Override // java.lang.Runnable
                            public void run() {
                                RequestCallback.this.onFailure(-1, localizedMessage);
                            }
                        });
                    }
                }

                @Override // okhttp3.Callback
                public void onResponse(Call call, Response response) throws IOException {
                    if (response.isSuccessful()) {
                        ResponseBody body = response.body();
                        if (body != null) {
                            final String string = body.string();
                            if (RequestCallback.this == null) {
                                return;
                            }
                            Http.mHandler.post(new Runnable() { // from class: com.tdo.showbox.http.Http.9.2
                                @Override // java.lang.Runnable
                                public void run() {
                                    RequestCallback.this.onSuccess(string);
                                }
                            });
                        } else if (RequestCallback.this == null) {
                        } else {
                            Http.mHandler.post(new Runnable() { // from class: com.tdo.showbox.http.Http.9.3
                                @Override // java.lang.Runnable
                                public void run() {
                                    RequestCallback.this.onFailure(-1, "无响应数据");
                                }
                            });
                        }
                    } else if (RequestCallback.this == null) {
                    } else {
                        final int code = response.code();
                        final String message = response.message();
                        if (Http.mHandler == null) {
                            return;
                        }
                        Http.mHandler.post(new Runnable() { // from class: com.tdo.showbox.http.Http.9.4
                            @Override // java.lang.Runnable
                            public void run() {
                                RequestCallback.this.onFailure(code, message);
                            }
                        });
                    }
                }
            });
        } else if (requestCallback != null && (handler3 = mHandler) != null) {
            handler3.post(new Runnable() { // from class: com.tdo.showbox.http.Http.6
                @Override // java.lang.Runnable
                public void run() {
                    RequestCallback.this.onFailure(-1, "文件不存在");
                }
            });
        }
    }

    public static Call uploadSync(String str, Map<String, String> map, Map<String, String> map2) {
        boolean z = App.isDebug;
        OkHttpClient okHttpClient = getOkHttpClient();
        MultipartBody.Builder builder = new MultipartBody.Builder();
        builder.setType(MediaType.parse("multipart/form-data"));
        if (map != null && !map.isEmpty()) {
            for (Map.Entry<String, String> entry : map.entrySet()) {
                builder.addFormDataPart(entry.getKey(), entry.getValue());
            }
        }
        if (map2 != null && !map2.isEmpty()) {
            String str2 = map2.containsKey("filePath") ? map2.get("filePath") : null;
            if (str2 != null) {
                String str3 = map2.containsKey("mimeType") ? map2.get("mimeType") : "image/*";
                File file = new File(str2);
                if (file.exists() && file.isFile()) {
                    builder.addFormDataPart("Filedata", file.getName(), MultipartBody.create(MediaType.parse(str3), file));
                    return okHttpClient.newCall(new Request.Builder().cacheControl(CacheControl.FORCE_NETWORK).url(str).post(builder.build()).build());
                }
            }
        }
        return null;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: classes3.dex */
    public static class HttpDns implements Dns {
        HttpDns() {
        }

        @Override // okhttp3.Dns
        public List<InetAddress> lookup(String str) throws UnknownHostException {
            if (TextUtils.isEmpty(API.REAL_MOVIE_HOST)) {
                return Dns.SYSTEM.lookup(str);
            }
            if (API.MOVIE_HOST.contains(str)) {
                return Dns.SYSTEM.lookup(API.REAL_MOVIE_HOST);
            }
            return Dns.SYSTEM.lookup(str);
        }
    }
}
