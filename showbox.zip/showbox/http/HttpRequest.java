package com.tdo.showbox.http;

import androidx.lifecycle.LifecycleOwner;
import com.alibaba.fastjson.JSON;
import com.mintegral.msdk.base.entity.CampaignEx;
import com.tdo.showbox.BuildConfig;
import com.tdo.showbox.app.App;
import com.tdo.showbox.app.Constant;
import com.tdo.showbox.base.HttpResponseObserver;
import com.tdo.showbox.model.user.UserModel;
import com.tdo.showbox.utils.PrefsUtils;
import com.tdo.showbox.utils.RxUtils;
import com.tdo.showbox.utils.TimeUtils;
import com.tencent.bugly.beta.tinker.TinkerUtils;
import com.uber.autodispose.ObservableSubscribeProxy;
import com.umeng.commonsdk.proguard.g;
import io.reactivex.Observable;
import io.reactivex.disposables.Disposable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import kotlin.Metadata;
import kotlin.Pair;
import kotlin.jvm.JvmStatic;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import okhttp3.MediaType;
import okhttp3.RequestBody;
/* compiled from: HttpRequest.kt */
@Metadata(bv = {1, 0, 3}, d1 = {"\u0000V\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0011\n\u0002\u0018\u0002\n\u0002\b\u0007\u0018\u0000 %2\u00020\u0001:\u0001%B\u0015\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005¢\u0006\u0002\u0010\u0006J\b\u0010\u000e\u001a\u00020\u000fH\u0002J \u0010\u0010\u001a\b\u0012\u0004\u0012\u0002H\u00120\u0011\"\u0004\b\u0000\u0010\u00122\f\u0010\u0013\u001a\b\u0012\u0004\u0012\u0002H\u00120\u0014J0\u0010\u0015\u001a\u0018\u0012\u0014\u0012\u0012\u0012\u0004\u0012\u0002H\u00120\u0016j\b\u0012\u0004\u0012\u0002H\u0012`\u00170\u0011\"\u0004\b\u0000\u0010\u00122\f\u0010\u0013\u001a\b\u0012\u0004\u0012\u0002H\u00120\u0014J\f\u0010\u0018\u001a\b\u0012\u0004\u0012\u00020\u00030\u0011J\u0006\u0010\u0019\u001a\u00020\u000fJ\u000e\u0010\u001a\u001a\b\u0012\u0004\u0012\u00020\u00030\u001bH\u0002J;\u0010\u001c\u001a\u00020\u00002.\u0010\u001d\u001a\u0018\u0012\u0014\b\u0001\u0012\u0010\u0012\u0004\u0012\u00020\u0003\u0012\u0006\u0012\u0004\u0018\u00010\u00010\u001f0\u001e\"\u0010\u0012\u0004\u0012\u00020\u0003\u0012\u0006\u0012\u0004\u0018\u00010\u00010\u001f¢\u0006\u0002\u0010 J\u0018\u0010\u001c\u001a\u00020\u00002\u0006\u0010!\u001a\u00020\u00032\b\u0010\"\u001a\u0004\u0018\u00010\u0001J\u0018\u0010\u001c\u001a\u00020\u00002\u0006\u0010!\u001a\u00020\u00032\b\u0010\"\u001a\u0004\u0018\u00010\u0003J.\u0010#\u001a\u00020\u00002&\u0010$\u001a\"\u0012\u0004\u0012\u00020\u0003\u0012\u0006\u0012\u0004\u0018\u00010\u00010\fj\u0010\u0012\u0004\u0012\u00020\u0003\u0012\u0006\u0012\u0004\u0018\u00010\u0001`\rR\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0007\u0010\bR\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\t\u0010\nR.\u0010\u000b\u001a\"\u0012\u0004\u0012\u00020\u0003\u0012\u0006\u0012\u0004\u0018\u00010\u00010\fj\u0010\u0012\u0004\u0012\u00020\u0003\u0012\u0006\u0012\u0004\u0018\u00010\u0001`\rX\u0082\u000e¢\u0006\u0002\n\u0000¨\u0006&"}, d2 = {"Lcom/tdo/showbox/http/HttpRequest;", "", g.d, "", "lifecycleOwner", "Landroidx/lifecycle/LifecycleOwner;", "(Ljava/lang/String;Landroidx/lifecycle/LifecycleOwner;)V", "getLifecycleOwner", "()Landroidx/lifecycle/LifecycleOwner;", "getModule", "()Ljava/lang/String;", "paramMap", "Ljava/util/HashMap;", "Lkotlin/collections/HashMap;", "addCommonParams", "", "asBean", "Lcom/uber/autodispose/ObservableSubscribeProxy;", "T", "type", "Ljava/lang/Class;", "asList", "Ljava/util/ArrayList;", "Lkotlin/collections/ArrayList;", "asMsg", "asMsgSubcribe", "getRequest", "Lio/reactivex/Observable;", "param", "pair", "", "Lkotlin/Pair;", "([Lkotlin/Pair;)Lcom/tdo/showbox/http/HttpRequest;", CampaignEx.LOOPBACK_KEY, "value", "params", "map", "Companion", "app_webRelease"}, k = 1, mv = {1, 1, 16})
/* loaded from: classes3.dex */
public final class HttpRequest {
    public static final Companion Companion = new Companion(null);
    private final LifecycleOwner lifecycleOwner;
    private final String module;
    private HashMap<String, Object> paramMap = new HashMap<>();

    @JvmStatic
    public static final HttpRequest post(LifecycleOwner lifecycleOwner, String str) {
        return Companion.post(lifecycleOwner, str);
    }

    public HttpRequest(String module, LifecycleOwner lifecycleOwner) {
        Intrinsics.checkParameterIsNotNull(module, "module");
        Intrinsics.checkParameterIsNotNull(lifecycleOwner, "lifecycleOwner");
        this.module = module;
        this.lifecycleOwner = lifecycleOwner;
        addCommonParams();
    }

    public final LifecycleOwner getLifecycleOwner() {
        return this.lifecycleOwner;
    }

    public final String getModule() {
        return this.module;
    }

    /* compiled from: HttpRequest.kt */
    @Metadata(bv = {1, 0, 3}, d1 = {"\u0000\u001e\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\b\u0086\u0003\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J\u0018\u0010\u0003\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\u00062\u0006\u0010\u0007\u001a\u00020\bH\u0007¨\u0006\t"}, d2 = {"Lcom/tdo/showbox/http/HttpRequest$Companion;", "", "()V", "post", "Lcom/tdo/showbox/http/HttpRequest;", "lifecycleOwner", "Landroidx/lifecycle/LifecycleOwner;", g.d, "", "app_webRelease"}, k = 1, mv = {1, 1, 16})
    /* loaded from: classes3.dex */
    public static final class Companion {
        private Companion() {
        }

        public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        @JvmStatic
        public final HttpRequest post(LifecycleOwner lifecycleOwner, String module) {
            Intrinsics.checkParameterIsNotNull(lifecycleOwner, "lifecycleOwner");
            Intrinsics.checkParameterIsNotNull(module, "module");
            return new HttpRequest(module, lifecycleOwner);
        }
    }

    public final HttpRequest param(String key, String str) {
        Intrinsics.checkParameterIsNotNull(key, "key");
        this.paramMap.put(key, str);
        return this;
    }

    public final HttpRequest param(String key, Object obj) {
        Intrinsics.checkParameterIsNotNull(key, "key");
        this.paramMap.put(key, obj);
        return this;
    }

    public final HttpRequest params(HashMap<String, Object> map) {
        Intrinsics.checkParameterIsNotNull(map, "map");
        for (Map.Entry<String, Object> entry : map.entrySet()) {
            this.paramMap.put(entry.getKey(), entry.getValue());
        }
        return this;
    }

    public final <T> ObservableSubscribeProxy<T> asBean(Class<T> type) {
        Intrinsics.checkParameterIsNotNull(type, "type");
        Object as = getRequest().compose(RxUtils.rxTranslate2Bean(type)).compose(RxUtils.rxSchedulerHelper()).as(RxUtils.bindLifecycleOwner(this.lifecycleOwner));
        Intrinsics.checkExpressionValueIsNotNull(as, "getRequest().compose(RxU…cleOwner(lifecycleOwner))");
        return (ObservableSubscribeProxy) as;
    }

    public final <T> ObservableSubscribeProxy<ArrayList<T>> asList(Class<T> type) {
        Intrinsics.checkParameterIsNotNull(type, "type");
        Object as = getRequest().compose(RxUtils.rxTranslate2List(type)).compose(RxUtils.rxSchedulerHelper()).as(RxUtils.bindLifecycleOwner(this.lifecycleOwner));
        Intrinsics.checkExpressionValueIsNotNull(as, "getRequest().compose(RxU…cleOwner(lifecycleOwner))");
        return (ObservableSubscribeProxy) as;
    }

    public final ObservableSubscribeProxy<String> asMsg() {
        Object as = getRequest().compose(RxUtils.rxTranslateMsg()).compose(RxUtils.rxSchedulerHelper()).as(RxUtils.bindLifecycleOwner(this.lifecycleOwner));
        Intrinsics.checkExpressionValueIsNotNull(as, "getRequest().compose(RxU…cleOwner(lifecycleOwner))");
        return (ObservableSubscribeProxy) as;
    }

    public final void asMsgSubcribe() {
        ((ObservableSubscribeProxy) getRequest().compose(RxUtils.rxTranslateMsg()).compose(RxUtils.rxSchedulerHelper()).as(RxUtils.bindLifecycleOwner(this.lifecycleOwner))).subscribe(new HttpResponseObserver<String>() { // from class: com.tdo.showbox.http.HttpRequest$asMsgSubcribe$1
            @Override // com.tdo.showbox.base.HttpResponseObserver
            public void onError(ApiException e) {
                Intrinsics.checkParameterIsNotNull(e, "e");
            }

            @Override // com.tdo.showbox.base.HttpResponseObserver
            public void onStart(Disposable d) {
                Intrinsics.checkParameterIsNotNull(d, "d");
            }

            @Override // com.tdo.showbox.base.HttpResponseObserver
            public void onSuccess(String model) {
                Intrinsics.checkParameterIsNotNull(model, "model");
            }
        });
    }

    private final Observable<String> getRequest() {
        addCommonParams();
        Observable<String> request = Http.getService().request(API.BASE_URL, RequestBody.create(MediaType.parse("text/plain; charset=utf-8"), JSON.toJSONString(this.paramMap)));
        Intrinsics.checkExpressionValueIsNotNull(request, "Http.getService().reques…PI.BASE_URL, requestBody)");
        return request;
    }

    private final void addCommonParams() {
        this.paramMap.put("expired_date", String.valueOf((TimeUtils.getCurrentTime() / 1000) + 43200));
        this.paramMap.put(TinkerUtils.PLATFORM, "android");
        this.paramMap.put("app_version", BuildConfig.VERSION_NAME);
        this.paramMap.put("channel", App.channel);
        if (PrefsUtils.getInstance().getBoolean(Constant.Prefs.CHILD_MODE, false)) {
            this.paramMap.put("childmode", "1");
        } else {
            this.paramMap.put("childmode", "0");
        }
        this.paramMap.put("lang", App.deviceLang);
        this.paramMap.put("appid", App.packageName);
        this.paramMap.put(g.d, this.module);
        UserModel.UserData userData = App.getUserData();
        Intrinsics.checkExpressionValueIsNotNull(userData, "App.getUserData()");
        if (userData != null) {
            this.paramMap.put("uid", userData.uid);
        }
    }

    public final HttpRequest param(Pair<String, ? extends Object>... pair) {
        Intrinsics.checkParameterIsNotNull(pair, "pair");
        for (Pair<String, ? extends Object> pair2 : pair) {
            this.paramMap.put(pair2.getFirst(), pair2.getSecond());
        }
        return this;
    }
}
