package com.tdo.showbox.http;
/* loaded from: classes3.dex */
public class RequestCallback<T> {
    public void onFailure(int i, String str) {
    }

    public void onSuccess(T t) {
    }
}
