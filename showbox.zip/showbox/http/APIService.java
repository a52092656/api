package com.tdo.showbox.http;

import com.alibaba.fastjson.JSONObject;
import io.reactivex.Observable;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import okhttp3.ResponseBody;
import org.json.JSONArray;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.Multipart;
import retrofit2.http.POST;
import retrofit2.http.Part;
import retrofit2.http.Query;
import retrofit2.http.Streaming;
import retrofit2.http.Url;
/* loaded from: classes3.dex */
public interface APIService {
    @FormUrlEncoded
    @POST
    Observable<String> ActorDetail(@Url String str, @Field("module") String str2, @Field("actor_id") String str3);

    @FormUrlEncoded
    @POST
    Observable<String> AddReview(@Url String str, @Field("module") String str2, @Field("uid") String str3, @Field("auth") String str4, @Field("authkey") String str5, @Field("username") String str6, @Field("fid") int i, @Field("formhash") String str7, @Field("title") String str8, @Field("content") String str9, @Field("videoid") String str10, @Field("type") int i2, @Field("unusefiles") String str11, @Field("usefiles") String str12, @Field("topicsubmit") String str13, @Field("apiappid") String str14, @Field("location") String str15, @Field("tags") String str16, @Field("addfeed") int i3, @Field("video_name") String str17, @Field("video_poster") String str18, @Field("video_year") String str19, @Field("video_score") String str20);

    @FormUrlEncoded
    @POST
    Observable<String> AddWatchedFlag(@Url String str, @Field("module") String str2, @Field("uid") String str3, @Field("over") int i, @Field("tid") String str4, @Field("season") String str5, @Field("episode") String str6);

    @FormUrlEncoded
    @POST
    Observable<String> Advertisement(@Url String str, @Field("module") String str2, @Field("uid") String str3, @Field("adv_id") String str4);

    @FormUrlEncoded
    @POST
    Observable<String> Advertisement_notify(@Url String str, @Field("module") String str2, @Field("id") String str3);

    @FormUrlEncoded
    @POST
    Observable<String> Agreement_status(@Url String str, @Field("module") String str2, @Field("uid") String str3, @Field("status") String str4, @Field("agreement_id") String str5, @Field("reason") String str6);

    @FormUrlEncoded
    @POST
    Observable<String> Agreement_transactions(@Url String str, @Field("module") String str2, @Field("uid") String str3, @Field("agreement_id") String str4);

    @FormUrlEncoded
    @POST
    Observable<String> Autocomplate(@Url String str, @Field("module") String str2, @Field("keyword") String str3, @Field("pagelimit") String str4);

    @FormUrlEncoded
    @POST
    Call<String> Autocomplate2(@Url String str, @Field("module") String str2, @Field("keyword") String str3, @Field("pagelimit") String str4);

    @FormUrlEncoded
    @POST
    Observable<String> Bind_bbs_user(@Url String str, @Field("module") String str2, @Field("uid") String str3, @Field("bbs_uid") String str4, @Field("auth") String str5, @Field("authkey") String str6, @Field("formhash") String str7);

    @FormUrlEncoded
    @POST
    Observable<String> Cat_list(@Url String str, @Field("module") String str2);

    @FormUrlEncoded
    @POST
    Observable<String> Device(@Url String str, @Field("module") String str2, @Field("firebase_token") String str3, @Field("uid") String str4, @Field("device_name") String str5, @Field("device_model") String str6, @Field("devicetoken") String str7, @Field("udid") String str8, @Field("open_udid") String str9, @Field("appid") String str10, @Field("start_time") String str11, @Field("receive") String str12, @Field("app_version") String str13);

    @FormUrlEncoded
    @POST
    Observable<String> Device_list(@Url String str, @Field("module") String str2, @Field("uid") String str3);

    @FormUrlEncoded
    @POST
    Observable<String> Encoding_list(@Url String str, @Field("module") String str2);

    @FormUrlEncoded
    @POST
    Observable<String> GetAltMovieListImage(@Url String str, @Field("module") String str2, @Field("id") String str3, @Field("name") String str4, @Field("username") String str5, @Field("img") String str6, @Field("avatar") String str7);

    @FormUrlEncoded
    @POST
    Observable<String> GetAltVideos(@Url String str, @Field("module") String str2, @Field("id") String str3, @Field("name") String str4, @Field("poster") String str5, @Field("score") String str6, @Field("lang") String str7, @Field("type") int i, @Field("year") int i2);

    @FormUrlEncoded
    @POST
    Observable<String> GetReviewListById(@Url String str, @Field("module") String str2, @Field("uid") String str3, @Field("videoid") String str4, @Field("type") int i, @Field("fid") int i2, @Field("discuss") int i3, @Field("page") int i4, @Field("tpp") int i5, @Field("order") int i6);

    @FormUrlEncoded
    @POST
    Observable<String> Home_list(@Url String str, @Field("module") String str2, @Field("uid") String str3, @Field("type") String str4, @Field("page") String str5, @Field("pagelimit") String str6, @Field("app_version") String str7, @Field("lang") String str8);

    @FormUrlEncoded
    @POST
    Observable<String> Invite_active(@Url String str, @Field("module") String str2, @Field("type") String str3, @Field("email") String str4, @Field("invite_code") String str5, @Field("openid") String str6);

    @FormUrlEncoded
    @POST
    Observable<String> MovieActors(@Url String str, @Field("module") String str2, @Field("mid") String str3, @Field("page") int i, @Field("pagelimit") int i2);

    @FormUrlEncoded
    @POST
    Observable<String> MovieRecord(@Url String str, @Field("module") String str2, @Field("uid") String str3, @Field("type") String str4, @Field("mid") String str5, @Field("page") String str6, @Field("pagelimit") String str7);

    @FormUrlEncoded
    @POST
    Observable<String> MovieRecord(@Url String str, @Field("module") String str2, @Field("uid") String str3, @Field("type") String str4, @Field("mid") String str5, @Field("page") String str6, @Field("pagelimit") String str7, @Field("box_type") int i);

    @FormUrlEncoded
    @POST
    Observable<String> Movie_detail(@Url String str, @Field("module") String str2, @Field("uid") String str3, @Field("mid") String str4, @Field("lang") String str5, @Field("oss") String str6, @Field("group") String str7);

    @FormUrlEncoded
    @POST
    Observable<String> Movie_download(@Url String str, @Field("module") String str2, @Field("uid") String str3, @Field("mid") String str4);

    @FormUrlEncoded
    @POST
    Observable<String> Movie_feedback(@Url String str, @Field("module") String str2, @Field("uid") String str3, @Field("box_type") int i, @Field("mid") String str4, @Field("state") int i2, @Field("sid") String str5, @Field("ftid") int i3, @Field("text") String str6, @Field("season") int i4, @Field("episode") int i5);

    @FormUrlEncoded
    @POST
    Observable<String> Movie_feedback2(@Url String str, @Field("module") String str2, @Field("uid") String str3, @Field("box_type") int i, @Field("mid") String str4, @Field("state") int i2, @Field("sid") String str5, @Field("ftid") String str6, @Field("text") String str7, @Field("season") int i3, @Field("episode") int i4, @Field("subject") String str8);

    @FormUrlEncoded
    @POST
    Observable<String> Movie_feedback_type(@Url String str, @Field("module") String str2, @Field("state") int i);

    @FormUrlEncoded
    @POST
    Observable<String> Movie_list(@Url String str, @Field("module") String str2, @Field("uid") String str3, @Field("year") String str4, @Field("cid") String str5, @Field("orderby") String str6, @Field("page") String str7, @Field("pagelimit") String str8, @Field("app_version") String str9);

    @FormUrlEncoded
    @POST
    Observable<String> Movie_play(@Url String str, @Field("module") String str2, @Field("uid") String str3, @Field("mid") String str4, @Field("seconds") String str5, @Field("mmfid") String str6);

    @FormUrlEncoded
    @POST
    Observable<String> Movie_srt_auto(@Url String str, @Field("module") String str2, @Field("mid") String str3, @Field("lang") String str4, @Field("uid") String str5);

    @FormUrlEncoded
    @POST
    Observable<String> Movie_srt_list(@Url String str, @Field("module") String str2, @Field("uid") String str3, @Field("mid") String str4, @Field("lang") String str5, @Field("app_version") String str6);

    @FormUrlEncoded
    @POST
    Observable<String> Movie_srt_list_v2(@Url String str, @Field("module") String str2, @Field("uid") String str3, @Field("mid") String str4, @Field("fid") String str5, @Field("lang") String str6, @Field("app_version") String str7);

    @FormUrlEncoded
    @POST
    Observable<String> Movie_srt_select(@Url String str, @Field("module") String str2, @Field("uid") String str3, @Field("sid") String str4, @Field("mid") String str5, @Field("app_version") String str6);

    @FormUrlEncoded
    @POST
    Observable<String> Movie_update_remind(@Url String str, @Field("module") String str2, @Field("uid") String str3, @Field("reminder") int i);

    @FormUrlEncoded
    @POST
    Observable<String> Moviecollect(@Url String str, @Field("module") String str2, @Field("uid") String str3, @Field("mids") JSONObject jSONObject, @Field("tids") JSONObject jSONObject2, @Field("type") String str4, @Field("page") String str5, @Field("pagelimit") String str6);

    @FormUrlEncoded
    @POST
    Observable<String> Moviecollect2(@Url String str, @Field("module") String str2, @Field("uid") String str3, @Field("mids") JSONArray jSONArray, @Field("tids") String[] strArr, @Field("type") String str4, @Field("page") String str5, @Field("pagelimit") String str6);

    @FormUrlEncoded
    @POST
    Observable<String> MySearch_Record(@Url String str, @Field("module") String str2, @Field("type") String str3, @Field("uid") String str4, @Field("page") String str5, @Field("pagelimit") String str6, @Field("id") String str7, @Field("app_version") String str8);

    @FormUrlEncoded
    @POST
    Observable<String> Orderlist(@Url String str, @Field("module") String str2, @Field("uid") String str3);

    @FormUrlEncoded
    @POST
    Observable<String> Playlists_collect(@Url String str, @Field("module") String str2, @Field("uid") String str3, @Field("lid") String str4, @Field("type") String str5, @Field("app_version") String str6);

    @FormUrlEncoded
    @POST
    Observable<String> Playlists_compilations_detail(@Url String str, @Field("module") String str2, @Field("cid") String str3, @Field("page") int i, @Field("pagelimit") int i2);

    @FormUrlEncoded
    @POST
    Observable<String> Playlists_create(@Url String str, @Field("module") String str2, @Field("uid") String str3, @Field("name") String str4, @Field("desc") String str5, @Field("isshare") String str6, @Field("lid") String str7, @Field("videos") String str8, @Field("app_version") String str9);

    @POST
    Observable<String> Playlists_create(@Url String str, @Body RequestBody requestBody);

    @FormUrlEncoded
    @POST
    Observable<String> Playlists_delete(@Url String str, @Field("module") String str2, @Field("type") String str3, @Field("uid") String str4, @Field("lid") String str5, @Field("app_version") String str6);

    @FormUrlEncoded
    @POST
    Observable<String> Playlists_get(@Url String str, @Field("module") String str2, @Field("uid") String str3, @Field("lid") String str4, @Field("page") int i, @Field("pagelimit") int i2, @Field("app_version") String str5);

    @FormUrlEncoded
    @POST
    Observable<String> Playlists_list(@Url String str, @Field("module") String str2, @Field("uid") String str3, @Field("type") String str4, @Field("page") int i, @Field("pagelimit") int i2, @Field("app_version") String str5);

    @FormUrlEncoded
    @POST
    Observable<String> Playlists_ranking(@Url String str, @Field("module") String str2, @Field("type") String str3, @Field("page") int i, @Field("pagelimit") int i2);

    @FormUrlEncoded
    @POST
    Observable<String> Playlists_video_add(@Url String str, @Field("module") String str2, @Field("uid") String str3, @Field("lid") String str4, @Field("box_type") int i, @Field("mid") String str5);

    @FormUrlEncoded
    @POST
    Observable<String> Recommend_username(@Url String str, @Field("module") String str2, @Field("username") String str3, @Field("app_version") String str4);

    @FormUrlEncoded
    @POST
    Observable<String> Register(@Url String str, @Field("module") String str2, @Field("username") String str3, @Field("password") String str4, @Field("email") String str5, @Field("app_version") String str6);

    @FormUrlEncoded
    @POST
    Observable<String> Register2(@Url String str, @Field("module") String str2, @Field("username") String str3, @Field("password") String str4, @Field("email") String str5, @Field("invite_code") String str6, @Field("app_version") String str7, @Field("type") String str8, @Field("accesstoken") String str9, @Field("name") String str10, @Field("nick") String str11, @Field("openid") String str12);

    @FormUrlEncoded
    @POST
    Observable<String> Register_NeedCode(@Url String str, @Field("module") String str2);

    @FormUrlEncoded
    @POST
    Observable<String> Scan_qrcode(@Url String str, @Field("module") String str2, @Field("uid") String str3, @Field("openudid") String str4, @Field("app_version") String str5);

    @FormUrlEncoded
    @POST
    Observable<String> Search(@Url String str, @Field("module") String str2, @Field("type") String str3, @Field("keyword") String str4, @Field("uid") String str5, @Field("page") String str6, @Field("pagelimit") String str7);

    @FormUrlEncoded
    @POST
    Observable<String> Search_Hot(@Url String str, @Field("module") String str2, @Field("type") String str3, @Field("pagelimit") String str4);

    @POST
    @Multipart
    Observable<String> Srt_convert_encoding(@Url String str, @Part("data") String str2, @Part("appid") String str3, @Part MultipartBody.Part part);

    @FormUrlEncoded
    @POST
    Observable<String> Srt_md5_check(@Url String str, @Field("module") String str2, @Field("type") String str3, @Field("md5") String str4);

    @FormUrlEncoded
    @POST
    Observable<String> Srt_vote(@Url String str, @Field("module") String str2, @Field("uid") String str3, @Field("sid") String str4, @Field("type") int i, @Field("app_version") String str5);

    @FormUrlEncoded
    @POST
    Observable<String> Srt_vote_data(@Url String str, @Field("module") String str2, @Field("uid") String str3, @Field("sid") String str4, @Field("app_version") String str5);

    @FormUrlEncoded
    @POST
    Observable<String> TV_downloadurl(@Url String str, @Field("module") String str2, @Field("uid") String str3, @Field("tid") String str4, @Field("season") String str5, @Field("episode") String str6, @Field("oss") String str7, @Field("group") String str8);

    @FormUrlEncoded
    @POST
    Observable<String> TV_episode(@Url String str, @Field("module") String str2, @Field("tid") String str3, @Field("season") String str4, @Field("year") String str5, @Field("uid") String str6, @Field("display_all") String str7);

    @FormUrlEncoded
    @POST
    Observable<String> TV_guide(@Url String str, @Field("module") String str2, @Field("day") String str3, @Field("pagelimit") int i, @Field("page") int i2);

    @FormUrlEncoded
    @POST
    Observable<String> TV_play_progress(@Url String str, @Field("module") String str2, @Field("uid") String str3, @Field("tid") String str4, @Field("mp4_id") String str5, @Field("season") String str6, @Field("episode") String str7, @Field("seconds") String str8, @Field("over") int i, @Field("app_version") String str9);

    @FormUrlEncoded
    @POST
    Observable<String> TV_srt_list_v2(@Url String str, @Field("module") String str2, @Field("uid") String str3, @Field("tid") String str4, @Field("fid") String str5, @Field("season") String str6, @Field("episode") String str7, @Field("lang") String str8, @Field("app_version") String str9);

    @FormUrlEncoded
    @POST
    Observable<String> Top_list(@Url String str, @Field("module") String str2, @Field("box_type") int i);

    @FormUrlEncoded
    @POST
    Observable<String> Top_list_movie(@Url String str, @Field("module") String str2, @Field("id") String str3, @Field("page") int i, @Field("pagelimit") int i2);

    @FormUrlEncoded
    @POST
    Observable<String> TvActors(@Url String str, @Field("module") String str2, @Field("tid") String str3, @Field("page") int i, @Field("pagelimit") int i2);

    @FormUrlEncoded
    @POST
    Observable<String> Tv_detail(@Url String str, @Field("module") String str2, @Field("uid") String str3, @Field("tid") String str4, @Field("lang") String str5, @Field("display_all") String str6);

    @FormUrlEncoded
    @POST
    Observable<String> Tv_downloadurl(@Url String str, @Field("module") String str2, @Field("uid") String str3, @Field("tid") String str4, @Field("season") int i, @Field("episode") int i2);

    @FormUrlEncoded
    @POST
    Observable<String> Tv_play(@Url String str, @Field("module") String str2, @Field("uid") String str3, @Field("tid") String str4, @Field("season") String str5, @Field("episode") String str6, @Field("seconds") String str7, @Field("tmfid") String str8, @Field("app_version") String str9);

    @FormUrlEncoded
    @POST
    Observable<String> Tv_srt_auto(@Url String str, @Field("module") String str2, @Field("tid") String str3, @Field("season") int i, @Field("episode") int i2, @Field("lang") String str4, @Field("uid") String str5);

    @FormUrlEncoded
    @POST
    Observable<String> Tv_srt_list(@Url String str, @Field("module") String str2, @Field("uid") String str3, @Field("tid") String str4, @Field("season") String str5, @Field("episode") String str6, @Field("lang") String str7, @Field("app_version") String str8);

    @FormUrlEncoded
    @POST
    Observable<String> Tv_srt_select(@Url String str, @Field("module") String str2, @Field("uid") String str3, @Field("tid") String str4, @Field("season") String str5, @Field("episode") String str6, @Field("sid") String str7, @Field("app_version") String str8);

    @FormUrlEncoded
    @POST
    Observable<String> Unbind_bbs_user(@Url String str, @Field("module") String str2, @Field("uid") String str3, @Field("bbs_uid") String str4);

    @FormUrlEncoded
    @POST
    Observable<String> UploadSrt_DELAY_INFO(@Url String str, @Field("module") String str2, @Field("uid") String str3, @Field("sid") String str4, @Field("fid") String str5, @Field("delay") int i, @Field("app_version") String str6);

    @POST
    @Multipart
    Observable<String> Upload_Request(@Url String str, @Part("data") String str2, @Part("appid") String str3, @Part MultipartBody.Part part);

    @POST
    @Multipart
    Observable<String> Upload_Request(@Url String str, @Part MultipartBody.Part part, @Part MultipartBody.Part part2, @Part MultipartBody.Part part3);

    @FormUrlEncoded
    @POST
    Observable<String> User_agreement(@Url String str, @Field("module") String str2, @Field("uid") String str3);

    @FormUrlEncoded
    @POST
    Call<String> Userinfo(@Url String str, @Field("module") String str2, @Field("uid") String str3, @Field("open_udid") String str4, @Field("app_version") String str5);

    @FormUrlEncoded
    @POST
    Observable<String> VideoList(@Url String str, @Field("module") String str2, @Field("uid") String str3, @Field("year") String str4, @Field("cid") String str5, @Field("orderby") String str6, @Field("rating") String str7, @Field("quality") String str8, @Field("page") String str9, @Field("pagelimit") String str10, @Field("app_version") String str11);

    @FormUrlEncoded
    @POST
    Observable<String> Year_list(@Url String str, @Field("module") String str2, @Field("type") String str3);

    @FormUrlEncoded
    @POST
    Observable<String> addMovieListNotice(@Url String str, @Field("module") String str2, @Field("uid") String str3, @Field("username") String str4, @Field("authorid") String str5, @Field("listid") String str6);

    @FormUrlEncoded
    @POST
    Observable<String> bbsLogin(@Url String str, @Field("module") String str2, @Field("uid") String str3, @Field("apiappid") String str4);

    @FormUrlEncoded
    @POST
    Observable<String> bindthirdpart(@Url String str, @Field("module") String str2, @Field("uid") String str3, @Field("action") String str4, @Field("type") String str5, @Field("accesstoken") String str6, @Field("name") String str7, @Field("openid") String str8, @Field("nick") String str9, @Field("email") String str10, @Field("app_version") String str11);

    @FormUrlEncoded
    @POST
    Observable<String> doLike(@Url String str, @Field("module") String str2, @Field("tid") String str3, @Field("pid") String str4, @Field("do") String str5, @Field("auth") String str6, @Field("authkey") String str7, @Field("formhash") String str8);

    @Streaming
    @GET
    Call<ResponseBody> download(@Url String str);

    @Streaming
    @GET
    Observable<ResponseBody> download2(@Url String str);

    @FormUrlEncoded
    @POST
    Observable<String> feedbackSpeedTest(@Url String str, @Field("module") String str2, @Field("speed") String str3, @Field("gpsLocation") String str4, @Field("ip") String str5, @Field("ipLocation") String str6);

    @FormUrlEncoded
    @POST
    Observable<String> getAllReviewByUid(@Url String str, @Field("module") String str2, @Field("uid") String str3, @Field("isdiscuss") String str4, @Field("page") int i, @Field("ppp") int i2);

    @FormUrlEncoded
    @POST
    Observable<String> getChatMsg(@Url String str, @Field("module") String str2, @Field("uid") String str3, @Field("username") String str4, @Field("subop") String str5, @Field("touid") String str6, @Field("auth") String str7, @Field("authkey") String str8, @Field("formhash") String str9, @Field("apiappid") String str10, @Field("page") int i, @Field("ppp") int i2);

    @FormUrlEncoded
    @POST
    Observable<String> getCollectNum(@Url String str, @Field("module") String str2, @Field("uid") String str3);

    @FormUrlEncoded
    @POST
    Observable<String> getCommentPage(@Url String str, @Field("module") String str2, @Field("pid") String str3, @Field("tid") String str4, @Field("perPage") int i);

    @FormUrlEncoded
    @POST
    Observable<String> getEditContent(@Url String str, @Field("module") String str2, @Field("uid") String str3, @Field("pid") String str4);

    @FormUrlEncoded
    @POST
    Observable<String> getMsgNotice(@Url String str, @Field("module") String str2, @Field("uid") String str3, @Field("username") String str4, @Field("auth") String str5, @Field("authkey") String str6, @Field("formhash") String str7, @Field("apiappid") String str8, @Field("filter") String str9, @Field("page") int i, @Field("ppp") int i2);

    @FormUrlEncoded
    @POST
    Observable<String> getNotice(@Url String str, @Field("module") String str2, @Field("uid") String str3, @Field("username") String str4, @Field("auth") String str5, @Field("authkey") String str6, @Field("formhash") String str7, @Field("apiappid") String str8, @Field("view") String str9, @Field("type") String str10, @Field("page") int i, @Field("ppp") int i2);

    @FormUrlEncoded
    @POST
    Observable<String> getNoticeCount(@Url String str, @Field("module") String str2, @Field("uid") String str3, @Field("type") String str4);

    @Streaming
    @GET
    Observable<ResponseBody> getOpenSubtitle(@Url String str);

    @FormUrlEncoded
    @POST
    Observable<String> getProfile(@Url String str, @Field("module") String str2, @Field("auth") String str3, @Field("authkey") String str4, @Field("checkuid") String str5, @Field("checkusername") String str6, @Field("my_uid") String str7);

    @FormUrlEncoded
    @POST
    Observable<String> getReportReason(@Url String str, @Field("module") String str2, @Field("auth") String str3, @Field("authkey") String str4);

    @FormUrlEncoded
    @POST
    Observable<String> getReviewByPid(@Url String str, @Field("module") String str2, @Field("pid") String str3, @Field("uid") String str4);

    @FormUrlEncoded
    @POST
    Observable<String> getReviewNum(@Url String str, @Field("module") String str2, @Field("videoid") String str3, @Field("type") int i, @Field("fid") int i2);

    @FormUrlEncoded
    @POST
    Observable<String> getUserInfo(@Url String str, @Field("module") String str2, @Field("uid") String str3, @Field("open_udid") String str4, @Field("app_version") String str5);

    @FormUrlEncoded
    @POST
    Observable<String> getUserInfoByUid(@Url String str, @Field("module") String str2, @Field("uid") String str3);

    @FormUrlEncoded
    @POST
    Observable<String> login(@Url String str, @Field("module") String str2, @Field("username") String str3, @Field("password") String str4, @Field("open_udid") String str5, @Field("app_version") String str6);

    @FormUrlEncoded
    @POST
    Observable<String> loginToPandaForum(@Url String str, @Field("module") String str2, @Field("name") String str3, @Field("email") String str4, @Field("openid") String str5, @Field("userId") String str6, @Field("avatar") String str7);

    @FormUrlEncoded
    @POST
    Observable<String> login_out(@Url String str, @Field("module") String str2, @Field("open_udid") String str3, @Field("app_version") String str4);

    @FormUrlEncoded
    @POST
    Observable<String> loginthirdpart(@Url String str, @Field("module") String str2, @Field("type") String str3, @Field("openid") String str4, @Field("open_udid") String str5, @Field("email") String str6);

    @FormUrlEncoded
    @POST
    Observable<String> movieListReply(@Url String str, @Field("module") String str2, @Field("username") String str3, @Field("uid") String str4, @Field("tid") String str5, @Field("htmlon") int i, @Field("auth") String str6, @Field("authkey") String str7, @Field("formhash") String str8, @Field("location") String str9, @Field("replysubmit") String str10, @Field("title") String str11, @Field("content") String str12, @Field("unusefiles") String str13, @Field("usefiles") String str14, @Field("repquote") String str15, @Field("authorid") String str16, @Field("apiappid") String str17, @Field("pid") String str18, @Field("authorUsername") String str19, @Field("authorAvatar") String str20, @Field("authorTime") String str21, @Field("authorContent") String str22, @Field("reply") int i2, @Field("name") String str23, @Field("lid") String str24, @Field("desc") String str25, @Field("email") String str26, @Field("openid") String str27, @Field("listUid") String str28, @Field("video_name") String str29, @Field("video_poster") String str30, @Field("video_username") String str31, @Field("video_avatar") String str32);

    @FormUrlEncoded
    @POST
    Observable<String> movieListReviewDetail(@Url String str, @Field("module") String str2, @Field("auth") String str3, @Field("authkey") String str4, @Field("lid") String str5, @Field("page") int i, @Field("ppp") int i2, @Field("formhash") String str6);

    @FormUrlEncoded
    @POST
    Call<String> phoneregister(@Url String str, @Field("module") String str2, @Field("phone") String str3, @Field("appid") String str4, @Field("app_version") String str5);

    @FormUrlEncoded
    @POST
    Observable<String> reply(@Url String str, @Field("module") String str2, @Field("username") String str3, @Field("uid") String str4, @Field("tid") String str5, @Field("htmlon") int i, @Field("auth") String str6, @Field("authkey") String str7, @Field("formhash") String str8, @Field("location") String str9, @Field("replysubmit") String str10, @Field("title") String str11, @Field("content") String str12, @Field("unusefiles") String str13, @Field("usefiles") String str14, @Field("repquote") String str15, @Field("authorid") String str16, @Field("apiappid") String str17, @Field("pid") String str18, @Field("authorUsername") String str19, @Field("authorAvatar") String str20, @Field("authorTime") String str21, @Field("authorContent") String str22, @Field("reply") int i2, @Field("addfeed") int i3);

    @POST
    Observable<String> request(@Url String str);

    @POST
    Observable<String> request(@Url String str, @Body RequestBody requestBody);

    @FormUrlEncoded
    @POST
    Observable<String> reviewDetail(@Url String str, @Field("module") String str2, @Field("auth") String str3, @Field("authkey") String str4, @Field("tid") String str5, @Field("page") int i, @Field("ppp") int i2, @Field("formhash") String str6);

    @FormUrlEncoded
    @POST
    Observable<String> sendMsg(@Url String str, @Field("module") String str2, @Field("uid") String str3, @Field("auth") String str4, @Field("authkey") String str5, @Field("formhash") String str6, @Field("message") String str7, @Field("type") int i, @Field("users") String str8, @Field("pmid") String str9, @Field("apiappid") String str10);

    @FormUrlEncoded
    @POST
    Observable<String> sendReport(@Url String str, @Field("module") String str2, @Field("auth") String str3, @Field("authkey") String str4, @Field("formhash") String str5, @Field("message") String str6, @Field("rtype") String str7, @Field("rid") String str8, @Field("tid") String str9, @Field("fid") String str10);

    @FormUrlEncoded
    @POST
    Observable<String> simple(@Url String str, @Field("module") String str2);

    @POST
    Observable<String> sortFavorite(@Url String str, @Body RequestBody requestBody);

    @FormUrlEncoded
    @POST
    Observable<String> sortFavorite2(@Url String str, @Field("module") String str2, @Field("uid") String str3, @Field("sort") String str4);

    @Streaming
    @GET
    Observable<ResponseBody> strlist(@Url String str);

    @FormUrlEncoded
    @POST
    Observable<String> translate(@Url String str, @Query("from") String str2, @Query("to") String str3, @Field("content") String str4);

    @GET
    Observable<String> translateMovie(@Url String str, @Query("from") String str2, @Query("to") String str3, @Query("movie_sid") String str4);

    @GET
    Observable<String> translateTv(@Url String str, @Query("from") String str2, @Query("to") String str3, @Query("tv_sid") String str4);

    @FormUrlEncoded
    @POST
    Observable<String> updateReview(@Url String str, @Field("module") String str2, @Field("auth") String str3, @Field("authkey") String str4, @Field("formhash") String str5, @Field("fid") String str6, @Field("tid") String str7, @Field("pid") String str8, @Field("title") String str9, @Field("content") String str10, @Field("unusefiles") String str11, @Field("usefiles") String str12, @Field("editsubmit") String str13, @Field("location") String str14);

    @FormUrlEncoded
    @POST
    Observable<String> uploadAvatar(@Url String str, @Field("module") String str2, @Field("uid") String str3, @Field("type") String str4, @Field("upload_avatar ") String str5);

    @POST
    @Multipart
    Call<String> uploadAvatar(@Url String str, @Part("data") String str2, @Part("appid") String str3, @Part("version") int i, @Part MultipartBody.Part part);

    @POST
    @Multipart
    Observable<String> uploadAvatar2(@Url String str, @Part("data") String str2, @Part("appid") String str3, @Part("version") int i, @Part MultipartBody.Part part);

    @POST
    @Multipart
    Observable<String> uploadMovieListCover(@Url String str, @Part("data") String str2, @Part("appid") String str3, @Part("version") int i, @Part MultipartBody.Part part);

    @POST
    @Multipart
    Call<String> uploadSubttitle(@Url String str, @Part("data") String str2, @Part("appid") String str3, @Part("version") int i, @Part MultipartBody.Part part);

    @FormUrlEncoded
    @POST
    Observable<String> userprofile(@Url String str, @Field("module") String str2, @Field("uid") String str3, @Field("type") String str4, @Field("newname") String str5, @Field("newpw") String str6, @Field("oldpw") String str7, @Field("nickname") String str8, @Field("email") String str9, @Field("app_version") String str10);
}
