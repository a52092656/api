package com.tdo.showbox.http;
/* loaded from: classes3.dex */
public class FengCipherKeys extends CipherKeys {
    private static final String APP_KEY = "bbsweiphone";
    private static final String IV = "wEiphTn!";
    private static final String KEY = "844d6cefc426d38373aa1e51";

    public FengCipherKeys() {
        super(APP_KEY, KEY, IV);
    }
}
