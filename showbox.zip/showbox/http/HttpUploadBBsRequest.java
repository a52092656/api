package com.tdo.showbox.http;

import androidx.lifecycle.LifecycleOwner;
import com.alibaba.fastjson.JSONObject;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.mintegral.msdk.base.entity.CampaignEx;
import com.tdo.showbox.app.App;
import com.tdo.showbox.base.BaseObserver;
import com.tdo.showbox.model.user.UserModel;
import com.tdo.showbox.utils.RxUtils;
import com.tdo.showbox.utils.TimeUtils;
import com.tencent.bugly.beta.tinker.TinkerUtils;
import com.uber.autodispose.ObservableSubscribeProxy;
import com.umeng.commonsdk.proguard.g;
import io.reactivex.Observable;
import io.reactivex.disposables.Disposable;
import java.io.File;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.HashMap;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import master.flame.danmaku.danmaku.parser.IDataSource;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
/* compiled from: HttpUploadBBsRequest.kt */
@Metadata(bv = {1, 0, 3}, d1 = {"\u00008\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u000e\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u000e\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\u0018\u00002\u00020\u0001B+\u0012$\b\u0002\u0010\u0002\u001a\u001e\u0012\u0004\u0012\u00020\u0004\u0012\u0004\u0012\u00020\u00010\u0003j\u000e\u0012\u0004\u0012\u00020\u0004\u0012\u0004\u0012\u00020\u0001`\u0005¢\u0006\u0002\u0010\u0006J,\u0010\r\u001a\u00020\u00002\u0006\u0010\u000e\u001a\u00020\u00042\b\b\u0002\u0010\u000f\u001a\u00020\u00042\u0006\u0010\u0010\u001a\u00020\f2\b\b\u0002\u0010\u0007\u001a\u00020\u0004H\u0007J\u0016\u0010\u0011\u001a\u00020\u00002\u0006\u0010\u0012\u001a\u00020\u00042\u0006\u0010\u0013\u001a\u00020\u0001J*\u0010\u0014\u001a\u00020\u00002\"\u0010\u0015\u001a\u001e\u0012\u0004\u0012\u00020\u0004\u0012\u0004\u0012\u00020\u00010\u0003j\u000e\u0012\u0004\u0012\u00020\u0004\u0012\u0004\u0012\u00020\u0001`\u0005J\u000e\u0010\u0016\u001a\u00020\u00002\u0006\u0010\u0017\u001a\u00020\tJ\b\u0010\u0018\u001a\u00020\u0004H\u0002J\u001a\u0010\u0019\u001a\u00020\u00002\u0010\b\u0002\u0010\u001a\u001a\n\u0012\u0004\u0012\u00020\u0004\u0018\u00010\u001bH\u0007J\u000e\u0010\u001c\u001a\n\u0012\u0004\u0012\u00020\u0004\u0018\u00010\u001dJ\u000e\u0010\u001e\u001a\n\u0012\u0004\u0012\u00020\u0004\u0018\u00010\u001dR*\u0010\u0002\u001a\u001e\u0012\u0004\u0012\u00020\u0004\u0012\u0004\u0012\u00020\u00010\u0003j\u000e\u0012\u0004\u0012\u00020\u0004\u0012\u0004\u0012\u00020\u0001`\u0005X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\u0004X\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010\b\u001a\u0004\u0018\u00010\tX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\n\u001a\u00020\u0004X\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010\u000b\u001a\u0004\u0018\u00010\fX\u0082\u000e¢\u0006\u0002\n\u0000¨\u0006\u001f"}, d2 = {"Lcom/tdo/showbox/http/HttpUploadBBsRequest;", "", "data", "Ljava/util/HashMap;", "", "Lkotlin/collections/HashMap;", "(Ljava/util/HashMap;)V", "formName", "mLifecycleOwner", "Landroidx/lifecycle/LifecycleOwner;", "mediaType", "uploadFile", "Ljava/io/File;", "addBaseParams", g.d, "type", IDataSource.SCHEME_FILE_TAG, "addParam", CampaignEx.LOOPBACK_KEY, "value", "addParams", "param", "bindLifecycle", "lifecycleOwner", "buildData", "executeUpload", "callback", "Lcom/tdo/showbox/http/ResponseCallback;", "executeUploadObservable", "Lio/reactivex/Observable;", "executeUploadObservable2", "app_webRelease"}, k = 1, mv = {1, 1, 16})
/* loaded from: classes3.dex */
public final class HttpUploadBBsRequest {
    private HashMap<String, Object> data;
    private String formName;
    private LifecycleOwner mLifecycleOwner;
    private String mediaType;
    private File uploadFile;

    public HttpUploadBBsRequest() {
        this(null, 1, null);
    }

    public final HttpUploadBBsRequest addBaseParams(String str, File file) {
        return addBaseParams$default(this, str, null, file, null, 10, null);
    }

    public final HttpUploadBBsRequest addBaseParams(String str, String str2, File file) {
        return addBaseParams$default(this, str, str2, file, null, 8, null);
    }

    public final HttpUploadBBsRequest executeUpload() {
        return executeUpload$default(this, null, 1, null);
    }

    public HttpUploadBBsRequest(HashMap<String, Object> data) {
        Intrinsics.checkParameterIsNotNull(data, "data");
        this.data = data;
        this.mediaType = "";
        this.formName = "";
    }

    public /* synthetic */ HttpUploadBBsRequest(HashMap hashMap, int i, DefaultConstructorMarker defaultConstructorMarker) {
        this((i & 1) != 0 ? new HashMap() : hashMap);
    }

    public final HttpUploadBBsRequest addParams(HashMap<String, Object> param) {
        Intrinsics.checkParameterIsNotNull(param, "param");
        this.data = param;
        return this;
    }

    public final HttpUploadBBsRequest addParam(String key, Object value) {
        Intrinsics.checkParameterIsNotNull(key, "key");
        Intrinsics.checkParameterIsNotNull(value, "value");
        this.data.put(key, value);
        return this;
    }

    public static /* synthetic */ HttpUploadBBsRequest addBaseParams$default(HttpUploadBBsRequest httpUploadBBsRequest, String str, String str2, File file, String str3, int i, Object obj) {
        if ((i & 2) != 0) {
            str2 = "text/plain";
        }
        if ((i & 8) != 0) {
            str3 = IDataSource.SCHEME_FILE_TAG;
        }
        return httpUploadBBsRequest.addBaseParams(str, str2, file, str3);
    }

    public final HttpUploadBBsRequest addBaseParams(String module, String type, File file, String formName) {
        Intrinsics.checkParameterIsNotNull(module, "module");
        Intrinsics.checkParameterIsNotNull(type, "type");
        Intrinsics.checkParameterIsNotNull(file, "file");
        Intrinsics.checkParameterIsNotNull(formName, "formName");
        this.data.put(g.d, module);
        this.mediaType = type;
        this.uploadFile = file;
        this.formName = formName;
        return this;
    }

    public final HttpUploadBBsRequest bindLifecycle(LifecycleOwner lifecycleOwner) {
        Intrinsics.checkParameterIsNotNull(lifecycleOwner, "lifecycleOwner");
        this.mLifecycleOwner = lifecycleOwner;
        return this;
    }

    /* JADX WARN: Multi-variable type inference failed */
    public static /* synthetic */ HttpUploadBBsRequest executeUpload$default(HttpUploadBBsRequest httpUploadBBsRequest, ResponseCallback responseCallback, int i, Object obj) {
        if ((i & 1) != 0) {
            responseCallback = null;
        }
        return httpUploadBBsRequest.executeUpload(responseCallback);
    }

    public final HttpUploadBBsRequest executeUpload(final ResponseCallback<String> responseCallback) {
        if (this.mLifecycleOwner == null) {
            throw new RuntimeException("not bind LifecycleOwner");
        }
        MultipartBody.Part part = null;
        MediaType parse = MediaType.parse(this.mediaType);
        File file = this.uploadFile;
        if (file == null) {
            Intrinsics.throwNpe();
        }
        RequestBody create = RequestBody.create(parse, file);
        try {
            String str = this.formName;
            File file2 = this.uploadFile;
            if (file2 == null) {
                Intrinsics.throwNpe();
            }
            part = MultipartBody.Part.createFormData(str, URLEncoder.encode(file2.getName(), "UTF-8"), create);
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
        ((ObservableSubscribeProxy) Http.getService().Upload_Request(API.BBS_URL, MultipartBody.Part.createFormData("data", buildData()), MultipartBody.Part.createFormData("appid", "27"), part).compose(RxUtils.rxTranslateMsg()).compose(RxUtils.rxSchedulerHelper()).as(RxUtils.bindLifecycleOwner(this.mLifecycleOwner))).subscribe(new BaseObserver<String>() { // from class: com.tdo.showbox.http.HttpUploadBBsRequest$executeUpload$1
            @Override // com.tdo.showbox.base.BaseObserver, io.reactivex.Observer
            public void onSubscribe(Disposable d) {
                Intrinsics.checkParameterIsNotNull(d, "d");
                super.onSubscribe(d);
                ResponseCallback responseCallback2 = ResponseCallback.this;
                if (responseCallback2 != null) {
                    responseCallback2.onStart();
                }
            }

            @Override // com.tdo.showbox.base.BaseObserver, io.reactivex.Observer
            public void onNext(String s) {
                Intrinsics.checkParameterIsNotNull(s, "s");
                super.onNext((HttpUploadBBsRequest$executeUpload$1) s);
                ResponseCallback responseCallback2 = ResponseCallback.this;
                if (responseCallback2 != null) {
                    responseCallback2.onSuccess(s);
                }
            }

            @Override // com.tdo.showbox.base.BaseObserver
            public void onError(ApiException e2) {
                Intrinsics.checkParameterIsNotNull(e2, "e");
                ResponseCallback responseCallback2 = ResponseCallback.this;
                if (responseCallback2 != null) {
                    responseCallback2.onFailure(e2.getCode(), e2.getMessage());
                }
            }
        });
        return this;
    }

    public final Observable<String> executeUploadObservable() {
        if (this.mLifecycleOwner == null) {
            throw new RuntimeException("not bind LifecycleOwner");
        }
        MultipartBody.Part part = null;
        MediaType parse = MediaType.parse(this.mediaType);
        File file = this.uploadFile;
        if (file == null) {
            Intrinsics.throwNpe();
        }
        RequestBody create = RequestBody.create(parse, file);
        try {
            String str = this.formName;
            File file2 = this.uploadFile;
            if (file2 == null) {
                Intrinsics.throwNpe();
            }
            part = MultipartBody.Part.createFormData(str, URLEncoder.encode(file2.getName(), "UTF-8"), create);
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
        MultipartBody.Part createFormData = MultipartBody.Part.createFormData("data", buildData());
        MultipartBody.Part createFormData2 = MultipartBody.Part.createFormData("appid", "27");
        if (part == null) {
            return null;
        }
        return Http.getService().Upload_Request(API.BBS_URL, createFormData, createFormData2, part).compose(RxUtils.rxTranslate2Bean(String.class));
    }

    public final Observable<String> executeUploadObservable2() {
        MultipartBody.Part part = null;
        MediaType parse = MediaType.parse(this.mediaType);
        File file = this.uploadFile;
        if (file == null) {
            Intrinsics.throwNpe();
        }
        RequestBody create = RequestBody.create(parse, file);
        try {
            String str = this.formName;
            File file2 = this.uploadFile;
            if (file2 == null) {
                Intrinsics.throwNpe();
            }
            part = MultipartBody.Part.createFormData(str, URLEncoder.encode(file2.getName(), "UTF-8"), create);
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
        MultipartBody.Part createFormData = MultipartBody.Part.createFormData("data", buildData());
        MultipartBody.Part createFormData2 = MultipartBody.Part.createFormData("appid", "27");
        if (part != null) {
            return Http.getService().Upload_Request(API.BBS_URL, createFormData, createFormData2, part);
        }
        return null;
    }

    private final String buildData() {
        String str = App.versionName;
        Intrinsics.checkExpressionValueIsNotNull(str, "App.versionName");
        this.data.put("app_version", str);
        UserModel.BBsInfo bBsInfo = App.getBBsInfo();
        Intrinsics.checkExpressionValueIsNotNull(bBsInfo, "App.getBBsInfo()");
        String bbs_uid = bBsInfo.getBbs_uid();
        Intrinsics.checkExpressionValueIsNotNull(bbs_uid, "App.getBBsInfo().bbs_uid");
        this.data.put("uid", bbs_uid);
        String str2 = App.deviceToken;
        Intrinsics.checkExpressionValueIsNotNull(str2, "App.deviceToken");
        this.data.put("token", str2);
        this.data.put(TinkerUtils.PLATFORM, "android");
        String str3 = App.deviceLang;
        Intrinsics.checkExpressionValueIsNotNull(str3, "App.deviceLang");
        this.data.put("lang", str3);
        String str4 = App.channel;
        Intrinsics.checkExpressionValueIsNotNull(str4, "App.channel");
        this.data.put(FirebaseAnalytics.Param.MEDIUM, str4);
        this.data.put("expired_date", Long.valueOf((TimeUtils.getCurrentTime() / 1000) + 43200));
        String encodeBody = HttpUtils.encodeBody(JSONObject.toJSONString(this.data));
        Intrinsics.checkExpressionValueIsNotNull(encodeBody, "HttpUtils.encodeBody(JSO…bject.toJSONString(data))");
        return encodeBody;
    }
}
