package com.tdo.showbox.http;
/* loaded from: classes3.dex */
public class StoneCipherKeys extends CipherKeys {
    private static final String APP_KEY = "moviebox";
    private static final String IV = "wEiphTn!";
    private static final String KEY = "123d6cedf626dy54233aa1w6";

    public StoneCipherKeys() {
        super(APP_KEY, KEY, IV);
    }
}
