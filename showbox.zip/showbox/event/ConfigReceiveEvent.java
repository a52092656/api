package com.tdo.showbox.event;
/* loaded from: classes.dex */
public class ConfigReceiveEvent extends BaseEvent {
}
