package com.tdo.showbox.event;
/* loaded from: classes3.dex */
public class EventBusElement {
    public int offset;

    public int getAppBarOffset() {
        return this.offset;
    }

    public void setAppBarOffset(int i) {
        this.offset = i;
    }
}
