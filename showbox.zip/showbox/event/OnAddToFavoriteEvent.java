package com.tdo.showbox.event;
/* loaded from: classes3.dex */
public class OnAddToFavoriteEvent {
    private boolean isFavorite;

    public OnAddToFavoriteEvent(boolean z) {
        this.isFavorite = z;
    }

    public boolean isFavorite() {
        return this.isFavorite;
    }

    public void setFavorite(boolean z) {
        this.isFavorite = z;
    }
}
