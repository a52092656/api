package com.tdo.showbox.event;
/* loaded from: classes3.dex */
public class MovieMoreEvent {
    private int gener;
    private int sortby;
    private int year;

    public MovieMoreEvent(int i, int i2, int i3) {
        this.sortby = i;
        this.year = i2;
        this.gener = i3;
    }
}
