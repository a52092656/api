package com.tdo.showbox.event;
/* loaded from: classes.dex */
public class BaseEvent {
}
