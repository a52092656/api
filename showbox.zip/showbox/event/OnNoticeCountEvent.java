package com.tdo.showbox.event;
/* loaded from: classes3.dex */
public class OnNoticeCountEvent {
    private int count;

    public OnNoticeCountEvent(int i) {
        this.count = i;
    }

    public int getCount() {
        return this.count;
    }

    public void setCount(int i) {
        this.count = i;
    }
}
