package com.tdo.showbox.event;
/* loaded from: classes3.dex */
public class LogoutEvent extends BaseEvent {
}
