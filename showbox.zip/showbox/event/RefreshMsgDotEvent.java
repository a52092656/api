package com.tdo.showbox.event;
/* loaded from: classes3.dex */
public class RefreshMsgDotEvent {
    private int position;

    public RefreshMsgDotEvent(int i) {
        this.position = i;
    }

    public int getPosition() {
        return this.position;
    }

    public void setPosition(int i) {
        this.position = i;
    }
}
