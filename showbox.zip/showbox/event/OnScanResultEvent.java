package com.tdo.showbox.event;
/* loaded from: classes3.dex */
public class OnScanResultEvent {
    private String result;

    public OnScanResultEvent(String str) {
        this.result = str;
    }

    public String getResult() {
        return this.result;
    }

    public void setResult(String str) {
        this.result = str;
    }
}
