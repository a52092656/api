package com.tdo.showbox.presenter;
/* loaded from: classes3.dex */
public interface IPresenter {
    void detachView();

    void loadData();
}
