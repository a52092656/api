package com.tdo.showbox.presenter.setting;
/* loaded from: classes3.dex */
public class historyPresenterImpl implements historyPresenter {
    @Override // com.tdo.showbox.presenter.setting.historyPresenter
    public void open() {
    }
}
