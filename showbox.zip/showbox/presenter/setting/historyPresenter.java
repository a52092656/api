package com.tdo.showbox.presenter.setting;

import com.tdo.showbox.presenter.BasePresenter;
/* loaded from: classes3.dex */
public interface historyPresenter extends BasePresenter {
    void open();
}
