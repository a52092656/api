package com.tdo.showbox.presenter.setting;

import com.dl7.player.model.SRTModel;
import java.util.LinkedHashMap;
import java.util.List;
/* loaded from: classes3.dex */
public interface SRTPresenter {
    LinkedHashMap<String, List<SRTModel.subTitles>> getSRTList();
}
