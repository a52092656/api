package com.tdo.showbox.presenter.activity;

import com.tdo.showbox.model.detail.AbstractVideoBean;
import com.tdo.showbox.presenter.IPresenter;
import com.tdo.showbox.view.activity.detail.IMovieDetail;
/* loaded from: classes3.dex */
public abstract class PSVideoInfo implements IPresenter {
    AbstractVideoBean abstractVideoBean;
    public IMovieDetail mViewController;

    public abstract void getInfo(String str, String str2);

    @Override // com.tdo.showbox.presenter.IPresenter
    public void loadData() {
    }

    private PSVideoInfo() {
    }

    public PSVideoInfo(IMovieDetail iMovieDetail) {
        this.mViewController = iMovieDetail;
    }

    @Override // com.tdo.showbox.presenter.IPresenter
    public void detachView() {
        this.mViewController = null;
    }
}
