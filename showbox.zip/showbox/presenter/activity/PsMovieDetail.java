package com.tdo.showbox.presenter.activity;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.tdo.showbox.app.App;
import com.tdo.showbox.app.RxManager;
import com.tdo.showbox.base.BaseObserver;
import com.tdo.showbox.base.HttpResponseObserver;
import com.tdo.showbox.db.entity.PlayRecode;
import com.tdo.showbox.http.API;
import com.tdo.showbox.http.ApiException;
import com.tdo.showbox.http.Http;
import com.tdo.showbox.model.ActorModel;
import com.tdo.showbox.model.common.Feedback;
import com.tdo.showbox.model.detail.MovieBean;
import com.tdo.showbox.model.movie.MovieDetail;
import com.tdo.showbox.model.movie.MovieListModel;
import com.tdo.showbox.service.UploadErrorInfoService;
import com.tdo.showbox.utils.RxUtils;
import com.tdo.showbox.utils.ToastUtils;
import com.tdo.showbox.view.activity.detail.IMovieDetail;
import io.reactivex.Observer;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.Disposable;
import io.reactivex.functions.Function;
import io.reactivex.schedulers.Schedulers;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
/* loaded from: classes3.dex */
public class PsMovieDetail extends PSVideoInfo {
    private static final String TAG = "PsMovieDetail";

    public PsMovieDetail(IMovieDetail iMovieDetail) {
        super(iMovieDetail);
        this.abstractVideoBean = new MovieBean();
    }

    @Override // com.tdo.showbox.presenter.activity.PSVideoInfo
    public void getInfo(final String str, String str2) {
        if (this.abstractVideoBean == null || this.mViewController == null) {
            return;
        }
        this.mViewController.switchPlayButtonStage(0);
        this.abstractVideoBean.getDetailInfo(str, str2).map(new Function<String, MovieDetail>() { // from class: com.tdo.showbox.presenter.activity.PsMovieDetail.2
            @Override // io.reactivex.functions.Function
            /* renamed from: apply  reason: avoid collision after fix types in other method */
            public MovieDetail mo704apply(String str3) throws Exception {
                JSONObject jSONObject = (JSONObject) JSONObject.parse(str3);
                if (jSONObject.getInteger("code").intValue() == 1) {
                    return (MovieDetail) jSONObject.getJSONObject("data").toJavaObject((Class<Object>) MovieDetail.class);
                }
                return null;
            }
        }).subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread()).subscribe(new HttpResponseObserver<MovieDetail>() { // from class: com.tdo.showbox.presenter.activity.PsMovieDetail.1
            @Override // com.tdo.showbox.base.HttpResponseObserver
            public void onStart(Disposable disposable) {
                RxManager.addDisposable(PsMovieDetail.TAG, disposable);
            }

            @Override // com.tdo.showbox.base.HttpResponseObserver
            public void onSuccess(MovieDetail movieDetail) {
                if (PsMovieDetail.this.mViewController == null) {
                    return;
                }
                PsMovieDetail.this.mViewController.getVideoInfo(movieDetail);
                PsMovieDetail.this.mViewController.switchPlayButtonStage(1);
                PsMovieDetail.this.mViewController.switchPlayButtonStage(1);
            }

            @Override // com.tdo.showbox.base.HttpResponseObserver
            public void onException(Throwable th) {
                UploadErrorInfoService.Companion.startUploadService(App.getContext(), th, str, API.Movie.MOVE_DETAIL, 1, "获取电影详情");
            }

            @Override // com.tdo.showbox.base.HttpResponseObserver
            public void onError(ApiException apiException) {
                if (PsMovieDetail.this.mViewController == null) {
                    return;
                }
                ToastUtils.showShort("Load failed:" + apiException.getMessage());
                PsMovieDetail.this.mViewController.switchPlayButtonStage(2);
            }
        });
    }

    public void getReviewNum(String str, boolean z) {
        Http.getService().getReviewNum(API.BBS_URL, "get_threadlist_videoid_count", str, 1, z ? 57 : 2).compose(RxUtils.rxTranslate2Bean(HashMap.class)).compose(RxUtils.rxSchedulerHelper()).subscribe(new Observer<HashMap>() { // from class: com.tdo.showbox.presenter.activity.PsMovieDetail.3
            @Override // io.reactivex.Observer
            public void onComplete() {
            }

            @Override // io.reactivex.Observer
            public void onError(Throwable th) {
            }

            @Override // io.reactivex.Observer
            public void onSubscribe(Disposable disposable) {
                RxManager.addDisposable(PsMovieDetail.TAG, disposable);
            }

            @Override // io.reactivex.Observer
            public void onNext(HashMap hashMap) {
                if (PsMovieDetail.this.mViewController == null) {
                    return;
                }
                PsMovieDetail.this.mViewController.showReviewCount((String) hashMap.get("count"));
            }
        });
    }

    public void getVideoPoster(String str, String str2) {
        this.abstractVideoBean.getDetailInfo(str, str2).compose(RxUtils.rxTranslate2Bean(MovieDetail.class)).subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread()).subscribe(new Observer<MovieDetail>() { // from class: com.tdo.showbox.presenter.activity.PsMovieDetail.4
            @Override // io.reactivex.Observer
            public void onComplete() {
            }

            @Override // io.reactivex.Observer
            public void onSubscribe(Disposable disposable) {
                RxManager.addDisposable(PsMovieDetail.TAG, disposable);
                if (PsMovieDetail.this.mViewController != null) {
                    PsMovieDetail.this.mViewController.showLoading();
                }
            }

            @Override // io.reactivex.Observer
            public void onNext(MovieDetail movieDetail) {
                if (PsMovieDetail.this.mViewController != null) {
                    PsMovieDetail.this.mViewController.showPoster(movieDetail.poster);
                    PsMovieDetail.this.mViewController.hideLoading();
                }
            }

            @Override // io.reactivex.Observer
            public void onError(Throwable th) {
                ToastUtils.showShort("Load failed:" + th.getMessage());
                if (PsMovieDetail.this.mViewController != null) {
                    PsMovieDetail.this.mViewController.hideLoading();
                }
            }
        });
    }

    public void requestActors(String str) {
        this.abstractVideoBean.actorList(str).compose(RxUtils.rxTranslate2List(ActorModel.class)).compose(RxUtils.rxSchedulerHelper()).subscribe(new BaseObserver<List<ActorModel>>() { // from class: com.tdo.showbox.presenter.activity.PsMovieDetail.5
            @Override // com.tdo.showbox.base.BaseObserver, io.reactivex.Observer
            public void onComplete() {
            }

            @Override // com.tdo.showbox.base.BaseObserver
            public void onError(ApiException apiException) {
            }

            @Override // com.tdo.showbox.base.BaseObserver, io.reactivex.Observer
            public void onSubscribe(Disposable disposable) {
                RxManager.addDisposable(PsMovieDetail.TAG, disposable);
            }

            @Override // com.tdo.showbox.base.BaseObserver, io.reactivex.Observer
            public void onNext(List<ActorModel> list) {
                if (PsMovieDetail.this.mViewController != null) {
                    PsMovieDetail.this.mViewController.showActors(list);
                }
            }
        });
    }

    public void SaveInDao(MovieDetail movieDetail) {
        PlayRecode findByTypeid = App.getDB().playRecodeDao().findByTypeid(movieDetail.box_type, movieDetail.id);
        if (findByTypeid == null) {
            PlayRecode playRecode = new PlayRecode();
            playRecode.setMovieId(movieDetail.id);
            playRecode.setBox_type(movieDetail.box_type);
            playRecode.setImdb_id(movieDetail.imdb_id);
            playRecode.setTitle(movieDetail.title);
            playRecode.setQuality(-1);
            playRecode.setStart_time(movieDetail.seconds * 1000);
            playRecode.setSeason(1);
            playRecode.setEpisode(1);
            App.getDB().playRecodeDao().insert(playRecode);
            return;
        }
        findByTypeid.setStart_time(movieDetail.seconds * 1000);
        App.getDB().playRecodeDao().update(findByTypeid);
    }

    public void addFavorite(String str, final boolean z) {
        if (this.mViewController == null) {
            return;
        }
        this.mViewController.showLoading();
        ArrayList arrayList = new ArrayList();
        arrayList.add(str);
        JSONArray parseArray = JSONArray.parseArray(JSON.toJSONString(arrayList));
        JSONObject jSONObject = new JSONObject();
        jSONObject.put("mid", (Object) parseArray);
        this.abstractVideoBean.addFavorite(str, jSONObject, z).subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread()).subscribe(new Observer<String>() { // from class: com.tdo.showbox.presenter.activity.PsMovieDetail.6
            @Override // io.reactivex.Observer
            public void onSubscribe(Disposable disposable) {
                RxManager.addDisposable(PsMovieDetail.TAG, disposable);
            }

            @Override // io.reactivex.Observer
            public void onNext(String str2) {
                if (PsMovieDetail.this.mViewController == null) {
                    return;
                }
                if (((JSONObject) JSONObject.parse(str2)).getInteger("code").intValue() == 1) {
                    PsMovieDetail.this.mViewController.setFavorite(true ^ z);
                } else {
                    PsMovieDetail.this.mViewController.setFavorite(z);
                }
            }

            @Override // io.reactivex.Observer
            public void onError(Throwable th) {
                if (PsMovieDetail.this.mViewController == null) {
                    return;
                }
                PsMovieDetail.this.mViewController.hideLoading();
            }

            @Override // io.reactivex.Observer
            public void onComplete() {
                if (PsMovieDetail.this.mViewController == null) {
                    return;
                }
                PsMovieDetail.this.mViewController.hideLoading();
            }
        });
    }

    public void getPath(final String str) {
        this.abstractVideoBean.getPath(str, 0, 0).compose(RxUtils.rxTranslate2Bean(MovieDetail.class)).compose(RxUtils.rxSchedulerHelper()).subscribe(new HttpResponseObserver<MovieDetail>() { // from class: com.tdo.showbox.presenter.activity.PsMovieDetail.7
            @Override // com.tdo.showbox.base.HttpResponseObserver
            public void onStart(Disposable disposable) {
                RxManager.addDisposable(PsMovieDetail.TAG, disposable);
                if (PsMovieDetail.this.mViewController != null) {
                    PsMovieDetail.this.mViewController.showLoading();
                }
            }

            @Override // com.tdo.showbox.base.HttpResponseObserver
            public void onSuccess(MovieDetail movieDetail) {
                if (PsMovieDetail.this.mViewController == null) {
                    return;
                }
                if (movieDetail != null) {
                    PsMovieDetail.this.mViewController.ChoosePlayer(movieDetail);
                }
                if (PsMovieDetail.this.mViewController == null) {
                    return;
                }
                PsMovieDetail.this.mViewController.hideLoading();
            }

            @Override // com.tdo.showbox.base.HttpResponseObserver
            public void onException(Throwable th) {
                UploadErrorInfoService.Companion.startUploadService(App.getContext(), th, str, API.Movie.MOVE_DOWNLAOD, 1, "play");
            }

            @Override // com.tdo.showbox.base.HttpResponseObserver
            public void onError(ApiException apiException) {
                if (PsMovieDetail.this.mViewController == null) {
                    return;
                }
                ToastUtils.showShort("Load failed:code " + apiException.getCode() + apiException.getMessage());
                PsMovieDetail.this.mViewController.hideLoading();
            }
        });
    }

    public void getFeedBack() {
        this.abstractVideoBean.getFeedBackType(1).subscribeOn(Schedulers.io()).map(new Function<String, List<Feedback>>() { // from class: com.tdo.showbox.presenter.activity.PsMovieDetail.9
            @Override // io.reactivex.functions.Function
            /* renamed from: apply  reason: avoid collision after fix types in other method */
            public List<Feedback> mo704apply(String str) throws Exception {
                JSONObject jSONObject = (JSONObject) JSONObject.parse(str);
                if (jSONObject.getInteger("code").intValue() == 1) {
                    return jSONObject.getJSONArray("data").toJavaList(Feedback.class);
                }
                return null;
            }
        }).observeOn(AndroidSchedulers.mainThread()).subscribe(new Observer<List<Feedback>>() { // from class: com.tdo.showbox.presenter.activity.PsMovieDetail.8
            @Override // io.reactivex.Observer
            public void onComplete() {
            }

            @Override // io.reactivex.Observer
            public void onError(Throwable th) {
            }

            @Override // io.reactivex.Observer
            public void onSubscribe(Disposable disposable) {
                RxManager.addDisposable(PsMovieDetail.TAG, disposable);
            }

            @Override // io.reactivex.Observer
            public void onNext(List<Feedback> list) {
                if (PsMovieDetail.this.mViewController == null || list == null) {
                    return;
                }
                PsMovieDetail.this.mViewController.getFeedBack(list);
            }
        });
    }

    public void setFeedBack(int i, int i2, String str, String str2, int i3, String str3) {
        if (this.mViewController == null) {
            return;
        }
        this.mViewController.showLoading();
        this.abstractVideoBean.setFeedBack(i, i2, str, str2, i3, str3, 0, 0).subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread()).subscribe(new Observer<String>() { // from class: com.tdo.showbox.presenter.activity.PsMovieDetail.10
            @Override // io.reactivex.Observer
            public void onSubscribe(Disposable disposable) {
                RxManager.addDisposable(PsMovieDetail.TAG, disposable);
            }

            @Override // io.reactivex.Observer
            public void onNext(String str4) {
                if (PsMovieDetail.this.mViewController == null) {
                    return;
                }
                PsMovieDetail.this.mViewController.showToast(((JSONObject) JSONObject.parse(str4)).getString("msg"));
            }

            @Override // io.reactivex.Observer
            public void onError(Throwable th) {
                if (PsMovieDetail.this.mViewController == null) {
                    return;
                }
                PsMovieDetail.this.mViewController.hideLoading();
            }

            @Override // io.reactivex.Observer
            public void onComplete() {
                if (PsMovieDetail.this.mViewController == null) {
                    return;
                }
                PsMovieDetail.this.mViewController.hideLoading();
            }
        });
    }

    public void getMovieList(String str) {
        this.abstractVideoBean.Playlists_list(str).compose(RxUtils.rxTranslate2List(MovieListModel.MovieListItem.class)).compose(RxUtils.rxSchedulerHelper()).subscribe(new BaseObserver<List<MovieListModel.MovieListItem>>() { // from class: com.tdo.showbox.presenter.activity.PsMovieDetail.11
            @Override // com.tdo.showbox.base.BaseObserver, io.reactivex.Observer
            public void onSubscribe(Disposable disposable) {
                super.onSubscribe(disposable);
                if (PsMovieDetail.this.mViewController != null) {
                    PsMovieDetail.this.mViewController.showLoading();
                }
            }

            @Override // com.tdo.showbox.base.BaseObserver, io.reactivex.Observer
            public void onNext(List<MovieListModel.MovieListItem> list) {
                super.onNext((AnonymousClass11) list);
                if (PsMovieDetail.this.mViewController != null) {
                    PsMovieDetail.this.mViewController.showBottomMovieListDialog(list);
                }
            }

            @Override // com.tdo.showbox.base.BaseObserver, io.reactivex.Observer
            public void onComplete() {
                super.onComplete();
                if (PsMovieDetail.this.mViewController != null) {
                    PsMovieDetail.this.mViewController.hideLoading();
                }
            }

            @Override // com.tdo.showbox.base.BaseObserver
            public void onError(ApiException apiException) {
                if (PsMovieDetail.this.mViewController != null) {
                    PsMovieDetail.this.mViewController.hideLoading();
                }
            }
        });
    }

    @Override // com.tdo.showbox.presenter.activity.PSVideoInfo, com.tdo.showbox.presenter.IPresenter
    public void detachView() {
        RxManager.remove(TAG);
        super.detachView();
    }
}
