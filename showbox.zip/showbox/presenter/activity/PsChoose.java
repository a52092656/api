package com.tdo.showbox.presenter.activity;

import android.content.Context;
import com.alibaba.fastjson.JSONObject;
import com.tdo.showbox.app.App;
import com.tdo.showbox.app.RxManager;
import com.tdo.showbox.base.HttpResponseObserver;
import com.tdo.showbox.http.API;
import com.tdo.showbox.http.APIService;
import com.tdo.showbox.http.ApiException;
import com.tdo.showbox.http.Http;
import com.tdo.showbox.model.BaseMediaModel;
import com.tdo.showbox.model.DownloadInfo;
import com.tdo.showbox.model.common.Srt;
import com.tdo.showbox.model.detail.AbstractVideoBean;
import com.tdo.showbox.presenter.IPresenter;
import com.tdo.showbox.service.UploadErrorInfoService;
import com.tdo.showbox.utils.RxUtils;
import com.tdo.showbox.view.activity.choose.IChoose;
import io.reactivex.Observable;
import io.reactivex.Observer;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.Disposable;
import io.reactivex.functions.Function;
import io.reactivex.schedulers.Schedulers;
import java.util.ArrayList;
import java.util.List;
/* loaded from: classes3.dex */
public class PsChoose implements IPresenter {
    private static final String TAG = "PsChoose";
    private AbstractVideoBean abstractVideoBean;
    private Context mContext;
    private IChoose mViewController;

    @Override // com.tdo.showbox.presenter.IPresenter
    public void detachView() {
    }

    @Override // com.tdo.showbox.presenter.IPresenter
    public void loadData() {
    }

    public PsChoose() {
    }

    public PsChoose(Context context, IChoose iChoose) {
        this.mContext = context;
        this.mViewController = iChoose;
    }

    public void setFactory(AbstractVideoBean abstractVideoBean) {
        this.abstractVideoBean = abstractVideoBean;
    }

    public void getPath(final String str, final int i, final int i2) {
        IChoose iChoose = this.mViewController;
        if (iChoose == null) {
            return;
        }
        iChoose.showLoading();
        this.abstractVideoBean.getPath(str, i, i2).subscribeOn(Schedulers.io()).map(new Function<String, BaseMediaModel>() { // from class: com.tdo.showbox.presenter.activity.PsChoose.2
            @Override // io.reactivex.functions.Function
            /* renamed from: apply  reason: avoid collision after fix types in other method */
            public BaseMediaModel mo704apply(String str2) throws Exception {
                JSONObject jSONObject = (JSONObject) JSONObject.parse(str2);
                if (jSONObject.getInteger("code").intValue() == 1) {
                    return (BaseMediaModel) jSONObject.getJSONObject("data").toJavaObject((Class<Object>) BaseMediaModel.class);
                }
                return null;
            }
        }).observeOn(AndroidSchedulers.mainThread()).subscribe(new HttpResponseObserver<BaseMediaModel>() { // from class: com.tdo.showbox.presenter.activity.PsChoose.1
            @Override // com.tdo.showbox.base.HttpResponseObserver
            public void onStart(Disposable disposable) {
                RxManager.addDisposable(PsChoose.TAG, disposable);
            }

            @Override // com.tdo.showbox.base.HttpResponseObserver
            public void onSuccess(BaseMediaModel baseMediaModel) {
                if (PsChoose.this.mViewController == null) {
                    return;
                }
                PsChoose.this.mViewController.setPath(baseMediaModel);
                PsChoose.this.mViewController.hideLoading();
            }

            @Override // com.tdo.showbox.base.HttpResponseObserver
            public void onException(Throwable th) {
                if (i > 0 && i2 > 0) {
                    UploadErrorInfoService.Companion.startUploadService(App.getContext(), th, str, API.Tv.TV_DOWNLAODURL, 2, DownloadInfo.DOWNLOAD, i, i2);
                } else {
                    UploadErrorInfoService.Companion.startUploadService(App.getContext(), th, str, API.Movie.MOVE_DOWNLAOD, 1, DownloadInfo.DOWNLOAD);
                }
            }

            @Override // com.tdo.showbox.base.HttpResponseObserver
            public void onError(ApiException apiException) {
                if (PsChoose.this.mViewController == null) {
                    return;
                }
                PsChoose.this.mViewController.showToast("NETWORK ERROR");
                PsChoose.this.mViewController.hideLoading();
            }
        });
    }

    public void get_DownaloadSrt(String str, int i, int i2, final String str2) {
        Observable<String> Movie_srt_auto;
        String str3 = "";
        if (i > 0 && i2 > 0) {
            APIService service = Http.getService();
            String str4 = API.BASE_URL;
            String str5 = App.deviceLang;
            if (App.isLogin()) {
                str3 = App.getUserData().uid;
            }
            Movie_srt_auto = service.Tv_srt_auto(str4, API.Tv.TV_SRT_AUTO_V2, str, i, i2, str5, str3);
        } else {
            APIService service2 = Http.getService();
            String str6 = API.BASE_URL;
            String str7 = App.deviceLang;
            if (App.isLogin()) {
                str3 = App.getUserData().uid;
            }
            Movie_srt_auto = service2.Movie_srt_auto(str6, API.Movie.MOVIE_SRT_AUTO_V2, str, str7, str3);
        }
        Movie_srt_auto.compose(RxUtils.rxTranslate2List(Srt.class)).compose(RxUtils.rxSchedulerHelper()).subscribe(new Observer<List<Srt>>() { // from class: com.tdo.showbox.presenter.activity.PsChoose.3
            @Override // io.reactivex.Observer
            public void onSubscribe(Disposable disposable) {
                RxManager.addDisposable(PsChoose.TAG, disposable);
                if (PsChoose.this.mViewController != null) {
                    PsChoose.this.mViewController.showLoading();
                }
            }

            @Override // io.reactivex.Observer
            public void onNext(List<Srt> list) {
                if (PsChoose.this.mViewController != null) {
                    PsChoose.this.mViewController.getSrt(list, str2);
                }
            }

            @Override // io.reactivex.Observer
            public void onError(Throwable th) {
                if (PsChoose.this.mViewController != null) {
                    PsChoose.this.mViewController.hideLoading();
                }
                if (PsChoose.this.mViewController != null) {
                    PsChoose.this.mViewController.getSrt(new ArrayList(), str2);
                }
            }

            @Override // io.reactivex.Observer
            public void onComplete() {
                if (PsChoose.this.mViewController != null) {
                    PsChoose.this.mViewController.hideLoading();
                }
            }
        });
    }
}
