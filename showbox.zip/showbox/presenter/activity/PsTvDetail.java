package com.tdo.showbox.presenter.activity;

import android.content.Context;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.tdo.showbox.app.App;
import com.tdo.showbox.app.RxManager;
import com.tdo.showbox.base.BaseObserver;
import com.tdo.showbox.base.HttpResponseObserver;
import com.tdo.showbox.db.entity.PlayRecode;
import com.tdo.showbox.http.API;
import com.tdo.showbox.http.ApiException;
import com.tdo.showbox.http.Http;
import com.tdo.showbox.model.ActorModel;
import com.tdo.showbox.model.common.Feedback;
import com.tdo.showbox.model.detail.AbstractVideoBean;
import com.tdo.showbox.model.detail.TvBean;
import com.tdo.showbox.model.movie.MovieListModel;
import com.tdo.showbox.model.tv.TvDetail;
import com.tdo.showbox.presenter.IPresenter;
import com.tdo.showbox.service.UploadErrorInfoService;
import com.tdo.showbox.utils.RxUtils;
import com.tdo.showbox.utils.ToastUtils;
import com.tdo.showbox.view.activity.detail.ITvDetail;
import io.reactivex.Observer;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.Disposable;
import io.reactivex.functions.Function;
import io.reactivex.schedulers.Schedulers;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
/* loaded from: classes3.dex */
public class PsTvDetail implements IPresenter {
    private static final String TAG = "PsTvDetail";
    private AbstractVideoBean abstractVideoBean = new TvBean();
    private Context mContext;
    private ITvDetail mViewController;

    @Override // com.tdo.showbox.presenter.IPresenter
    public void loadData() {
    }

    public PsTvDetail(Context context, ITvDetail iTvDetail) {
        this.mContext = context;
        this.mViewController = iTvDetail;
    }

    @Override // com.tdo.showbox.presenter.IPresenter
    public void detachView() {
        this.mContext = null;
        this.mViewController = null;
        RxManager.remove(TAG);
    }

    public void getInfo(final String str, String str2) {
        ITvDetail iTvDetail = this.mViewController;
        if (iTvDetail == null || this.abstractVideoBean == null) {
            return;
        }
        iTvDetail.switchPlayButtonStage(0);
        this.abstractVideoBean.getDetailInfo(str, str2).subscribeOn(Schedulers.io()).compose(RxUtils.rxTranslate2Bean(TvDetail.class)).subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread()).subscribe(new HttpResponseObserver<TvDetail>() { // from class: com.tdo.showbox.presenter.activity.PsTvDetail.1
            @Override // com.tdo.showbox.base.HttpResponseObserver
            public void onStart(Disposable disposable) {
                RxManager.addDisposable(PsTvDetail.TAG, disposable);
            }

            @Override // com.tdo.showbox.base.HttpResponseObserver
            public void onSuccess(TvDetail tvDetail) {
                if (PsTvDetail.this.mViewController == null) {
                    return;
                }
                PsTvDetail.this.mViewController.getVideoInfo(tvDetail);
                PsTvDetail.this.mViewController.switchPlayButtonStage(1);
                PsTvDetail.this.mViewController.switchPlayButtonStage(1);
            }

            @Override // com.tdo.showbox.base.HttpResponseObserver
            public void onException(Throwable th) {
                UploadErrorInfoService.Companion.startUploadService(App.getContext(), th, str, API.Tv.TV_DETAIL, 2, "获取电视详情");
            }

            @Override // com.tdo.showbox.base.HttpResponseObserver
            public void onError(ApiException apiException) {
                if (PsTvDetail.this.mViewController == null) {
                    return;
                }
                PsTvDetail.this.mViewController.switchPlayButtonStage(2);
            }
        });
        this.abstractVideoBean.getReviewNum(str, 2).compose(RxUtils.rxTranslate2Bean(HashMap.class)).compose(RxUtils.rxSchedulerHelper()).subscribe(new Observer<HashMap>() { // from class: com.tdo.showbox.presenter.activity.PsTvDetail.2
            @Override // io.reactivex.Observer
            public void onComplete() {
            }

            @Override // io.reactivex.Observer
            public void onError(Throwable th) {
            }

            @Override // io.reactivex.Observer
            public void onSubscribe(Disposable disposable) {
                RxManager.addDisposable(PsTvDetail.TAG, disposable);
            }

            @Override // io.reactivex.Observer
            public void onNext(HashMap hashMap) {
                if (PsTvDetail.this.mViewController == null) {
                    return;
                }
                PsTvDetail.this.mViewController.showReviewCount((String) hashMap.get("count"));
            }
        });
    }

    public void getVideoPoster(String str, String str2) {
        this.abstractVideoBean.getDetailInfo(str, str2).subscribeOn(Schedulers.io()).compose(RxUtils.rxTranslate2Bean(TvDetail.class)).subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread()).subscribe(new Observer<TvDetail>() { // from class: com.tdo.showbox.presenter.activity.PsTvDetail.3
            @Override // io.reactivex.Observer
            public void onComplete() {
            }

            @Override // io.reactivex.Observer
            public void onSubscribe(Disposable disposable) {
                RxManager.addDisposable(PsTvDetail.TAG, disposable);
                if (PsTvDetail.this.mViewController != null) {
                    PsTvDetail.this.mViewController.showLoading();
                }
            }

            @Override // io.reactivex.Observer
            public void onNext(TvDetail tvDetail) {
                if (PsTvDetail.this.mViewController != null) {
                    PsTvDetail.this.mViewController.showPoster(tvDetail.poster);
                    PsTvDetail.this.mViewController.hideLoading();
                }
            }

            @Override // io.reactivex.Observer
            public void onError(Throwable th) {
                ToastUtils.showShort("Load failed:" + th.getMessage());
                if (PsTvDetail.this.mViewController != null) {
                    PsTvDetail.this.mViewController.hideLoading();
                }
            }
        });
    }

    public void requestActors(String str) {
        this.abstractVideoBean.actorList(str).compose(RxUtils.rxTranslate2List(ActorModel.class)).compose(RxUtils.rxSchedulerHelper()).subscribe(new BaseObserver<List<ActorModel>>() { // from class: com.tdo.showbox.presenter.activity.PsTvDetail.4
            @Override // com.tdo.showbox.base.BaseObserver, io.reactivex.Observer
            public void onComplete() {
            }

            @Override // com.tdo.showbox.base.BaseObserver
            public void onError(ApiException apiException) {
            }

            @Override // com.tdo.showbox.base.BaseObserver, io.reactivex.Observer
            public void onSubscribe(Disposable disposable) {
                RxManager.addDisposable(PsTvDetail.TAG, disposable);
            }

            @Override // com.tdo.showbox.base.BaseObserver, io.reactivex.Observer
            public void onNext(List<ActorModel> list) {
                if (PsTvDetail.this.mViewController != null) {
                    PsTvDetail.this.mViewController.showActors(list);
                }
            }
        });
    }

    public void SaveInDao(TvDetail tvDetail, int i, int i2, int i3) {
        PlayRecode findByEpisode = App.getDB().playRecodeDao().findByEpisode(tvDetail.box_type, tvDetail.id, i2, i3);
        if (findByEpisode == null) {
            PlayRecode playRecode = new PlayRecode();
            playRecode.setMovieId(tvDetail.id);
            playRecode.setBox_type(tvDetail.box_type);
            playRecode.setImdb_id(tvDetail.imdb_id);
            playRecode.setTitle(tvDetail.title);
            playRecode.setQuality(-1);
            playRecode.setStart_time(i * 1000);
            playRecode.setSeason(i2);
            playRecode.setEpisode(i3);
            App.getDB().playRecodeDao().insert(playRecode);
            return;
        }
        findByEpisode.setStart_time(i * 1000);
        App.getDB().playRecodeDao().update(findByEpisode);
    }

    public void addFavorite(String str, final boolean z) {
        ITvDetail iTvDetail;
        if (App.isLogin() && (iTvDetail = this.mViewController) != null) {
            iTvDetail.showLoading();
            ArrayList arrayList = new ArrayList();
            arrayList.add(str);
            JSONArray parseArray = JSONArray.parseArray(JSON.toJSONString(arrayList));
            JSONObject jSONObject = new JSONObject();
            jSONObject.put("tid", (Object) parseArray);
            this.abstractVideoBean.addFavorite(str, jSONObject, z).subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread()).subscribe(new Observer<String>() { // from class: com.tdo.showbox.presenter.activity.PsTvDetail.5
                @Override // io.reactivex.Observer
                public void onSubscribe(Disposable disposable) {
                    RxManager.addDisposable(PsTvDetail.TAG, disposable);
                }

                @Override // io.reactivex.Observer
                public void onNext(String str2) {
                    if (PsTvDetail.this.mViewController == null) {
                        return;
                    }
                    if (((JSONObject) JSONObject.parse(str2)).getInteger("code").intValue() == 1) {
                        PsTvDetail.this.mViewController.setFavorite(true ^ z);
                    } else {
                        PsTvDetail.this.mViewController.setFavorite(z);
                    }
                }

                @Override // io.reactivex.Observer
                public void onError(Throwable th) {
                    if (PsTvDetail.this.mViewController == null) {
                        return;
                    }
                    PsTvDetail.this.mViewController.hideLoading();
                }

                @Override // io.reactivex.Observer
                public void onComplete() {
                    if (PsTvDetail.this.mViewController == null) {
                        return;
                    }
                    PsTvDetail.this.mViewController.hideLoading();
                }
            });
        }
    }

    public void getFeedBack() {
        this.abstractVideoBean.getFeedBackType(1).subscribeOn(Schedulers.io()).map(new Function<String, List<Feedback>>() { // from class: com.tdo.showbox.presenter.activity.PsTvDetail.7
            @Override // io.reactivex.functions.Function
            /* renamed from: apply  reason: avoid collision after fix types in other method */
            public List<Feedback> mo704apply(String str) throws Exception {
                JSONObject jSONObject = (JSONObject) JSONObject.parse(str);
                if (jSONObject.getInteger("code").intValue() == 1) {
                    return jSONObject.getJSONArray("data").toJavaList(Feedback.class);
                }
                return null;
            }
        }).observeOn(AndroidSchedulers.mainThread()).subscribe(new Observer<List<Feedback>>() { // from class: com.tdo.showbox.presenter.activity.PsTvDetail.6
            @Override // io.reactivex.Observer
            public void onComplete() {
            }

            @Override // io.reactivex.Observer
            public void onError(Throwable th) {
            }

            @Override // io.reactivex.Observer
            public void onSubscribe(Disposable disposable) {
                RxManager.addDisposable(PsTvDetail.TAG, disposable);
            }

            @Override // io.reactivex.Observer
            public void onNext(List<Feedback> list) {
                if (PsTvDetail.this.mViewController == null || list == null) {
                    return;
                }
                PsTvDetail.this.mViewController.getFeedBack(list);
            }
        });
    }

    public void setFeedBack(int i, int i2, String str, String str2, int i3, String str3, int i4, int i5) {
        this.mViewController.showLoading();
        this.abstractVideoBean.setFeedBack(i, i2, str, str2, i3, str3, i4, i5).subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread()).subscribe(new Observer<String>() { // from class: com.tdo.showbox.presenter.activity.PsTvDetail.8
            @Override // io.reactivex.Observer
            public void onSubscribe(Disposable disposable) {
                RxManager.addDisposable(PsTvDetail.TAG, disposable);
            }

            @Override // io.reactivex.Observer
            public void onNext(String str4) {
                if (PsTvDetail.this.mViewController == null) {
                    return;
                }
                PsTvDetail.this.mViewController.showToast(((JSONObject) JSONObject.parse(str4)).getString("msg"));
            }

            @Override // io.reactivex.Observer
            public void onError(Throwable th) {
                if (PsTvDetail.this.mViewController == null) {
                    return;
                }
                PsTvDetail.this.mViewController.hideLoading();
            }

            @Override // io.reactivex.Observer
            public void onComplete() {
                if (PsTvDetail.this.mViewController == null) {
                    return;
                }
                PsTvDetail.this.mViewController.hideLoading();
            }
        });
    }

    public void getPath(final String str, final int i, final int i2, final int i3, final boolean z) {
        ITvDetail iTvDetail = this.mViewController;
        if (iTvDetail == null) {
            return;
        }
        iTvDetail.showLoading();
        this.abstractVideoBean.getPath(str, i2, i).compose(RxUtils.rxTranslate2Bean(TvDetail.class)).compose(RxUtils.rxSchedulerHelper()).subscribe(new HttpResponseObserver<TvDetail>() { // from class: com.tdo.showbox.presenter.activity.PsTvDetail.9
            @Override // com.tdo.showbox.base.HttpResponseObserver
            public void onStart(Disposable disposable) {
                RxManager.addDisposable(PsTvDetail.TAG, disposable);
            }

            @Override // com.tdo.showbox.base.HttpResponseObserver
            public void onSuccess(TvDetail tvDetail) {
                if (PsTvDetail.this.mViewController == null) {
                    return;
                }
                PsTvDetail.this.mViewController.ChoosePlayer(tvDetail, i3, i, z);
                PsTvDetail.this.mViewController.hideLoading();
            }

            @Override // com.tdo.showbox.base.HttpResponseObserver
            public void onException(Throwable th) {
                UploadErrorInfoService.Companion.startUploadService(App.getContext(), th, str, API.Tv.TV_DOWNLAODURL, 2, "play", i2, i);
            }

            @Override // com.tdo.showbox.base.HttpResponseObserver
            public void onError(ApiException apiException) {
                if (PsTvDetail.this.mViewController == null) {
                    return;
                }
                ToastUtils.showShort("Load failed:" + apiException.getMessage());
                PsTvDetail.this.mViewController.hideLoading();
            }
        });
    }

    public void getSeason(String str, int i, String str2, final int i2, String str3) {
        this.abstractVideoBean.TV_episode(str, i, str2, str3).subscribeOn(Schedulers.io()).map(new Function<String, List<TvDetail.SeasonDetail>>() { // from class: com.tdo.showbox.presenter.activity.PsTvDetail.11
            @Override // io.reactivex.functions.Function
            /* renamed from: apply  reason: avoid collision after fix types in other method */
            public List<TvDetail.SeasonDetail> mo704apply(String str4) throws Exception {
                JSONObject jSONObject = (JSONObject) JSONObject.parse(str4);
                if (jSONObject.getInteger("code").intValue() == 1) {
                    return jSONObject.getJSONArray("data").toJavaList(TvDetail.SeasonDetail.class);
                }
                return null;
            }
        }).observeOn(AndroidSchedulers.mainThread()).subscribe(new Observer<List<TvDetail.SeasonDetail>>() { // from class: com.tdo.showbox.presenter.activity.PsTvDetail.10
            @Override // io.reactivex.Observer
            public void onComplete() {
            }

            @Override // io.reactivex.Observer
            public void onError(Throwable th) {
            }

            @Override // io.reactivex.Observer
            public void onSubscribe(Disposable disposable) {
                RxManager.addDisposable(PsTvDetail.TAG, disposable);
            }

            @Override // io.reactivex.Observer
            public void onNext(List<TvDetail.SeasonDetail> list) {
                if (list == null || PsTvDetail.this.mViewController == null) {
                    return;
                }
                int i3 = i2;
                if (i3 == 0) {
                    PsTvDetail.this.mViewController.setDateList(list);
                } else if (i3 != 1) {
                } else {
                    PsTvDetail.this.mViewController.getProblem(list);
                }
            }
        });
    }

    public void addWatchedFlag(String str, int i, String str2, String str3) {
        Http.getService().AddWatchedFlag(API.BASE_URL, API.Tv.TV_over_v2, App.getUserData().uid, i, str, str2, str3).compose(RxUtils.rxTranslateMsg()).compose(RxUtils.rxSchedulerHelper()).subscribe(new BaseObserver<String>() { // from class: com.tdo.showbox.presenter.activity.PsTvDetail.12
            @Override // com.tdo.showbox.base.BaseObserver, io.reactivex.Observer
            public void onSubscribe(Disposable disposable) {
                RxManager.addDisposable(PsTvDetail.TAG, disposable);
                if (PsTvDetail.this.mViewController != null) {
                    PsTvDetail.this.mViewController.showLoading();
                }
            }

            @Override // com.tdo.showbox.base.BaseObserver, io.reactivex.Observer
            public void onNext(String str4) {
                ToastUtils.showShort("Mark successfully");
                if (PsTvDetail.this.mViewController != null) {
                    PsTvDetail.this.mViewController.markWatchedComplete();
                }
            }

            @Override // com.tdo.showbox.base.BaseObserver, io.reactivex.Observer
            public void onComplete() {
                if (PsTvDetail.this.mViewController != null) {
                    PsTvDetail.this.mViewController.hideLoading();
                }
            }

            @Override // com.tdo.showbox.base.BaseObserver
            public void onError(ApiException apiException) {
                if (PsTvDetail.this.mViewController != null) {
                    PsTvDetail.this.mViewController.hideLoading();
                }
                ToastUtils.showShort("Mark failed:" + apiException.getMessage());
            }
        });
    }

    public void getMovieList(String str) {
        this.abstractVideoBean.Playlists_list(str).compose(RxUtils.rxTranslate2List(MovieListModel.MovieListItem.class)).compose(RxUtils.rxSchedulerHelper()).subscribe(new BaseObserver<List<MovieListModel.MovieListItem>>() { // from class: com.tdo.showbox.presenter.activity.PsTvDetail.13
            @Override // com.tdo.showbox.base.BaseObserver, io.reactivex.Observer
            public void onSubscribe(Disposable disposable) {
                super.onSubscribe(disposable);
                RxManager.addDisposable(PsTvDetail.TAG, disposable);
                if (PsTvDetail.this.mViewController != null) {
                    PsTvDetail.this.mViewController.showLoading();
                }
            }

            @Override // com.tdo.showbox.base.BaseObserver, io.reactivex.Observer
            public void onNext(List<MovieListModel.MovieListItem> list) {
                super.onNext((AnonymousClass13) list);
                if (PsTvDetail.this.mViewController != null) {
                    PsTvDetail.this.mViewController.showBottomMovieListDialog(list);
                }
            }

            @Override // com.tdo.showbox.base.BaseObserver, io.reactivex.Observer
            public void onComplete() {
                super.onComplete();
                if (PsTvDetail.this.mViewController != null) {
                    PsTvDetail.this.mViewController.hideLoading();
                }
            }

            @Override // com.tdo.showbox.base.BaseObserver
            public void onError(ApiException apiException) {
                if (PsTvDetail.this.mViewController != null) {
                    PsTvDetail.this.mViewController.hideLoading();
                }
            }
        });
    }
}
