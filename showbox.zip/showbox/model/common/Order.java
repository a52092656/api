package com.tdo.showbox.model.common;

import java.io.Serializable;
/* loaded from: classes3.dex */
public class Order implements Serializable {
    public long dateline;
    public String money;
    public String num;
    public String orderid;
    public int state;
    public String total;
    public String unit;
}
