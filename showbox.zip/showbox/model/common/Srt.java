package com.tdo.showbox.model.common;
/* loaded from: classes3.dex */
public class Srt {
    public String count;
    public String delay;
    public String episode;
    public String file_path;
    public String format;
    public String lang;
    public String language;
    public String mb_id;
    public String mid;
    public String path;
    public String rating;
    public String season;
    public String sid;
    public String source_file;
    public String srt_id;
    public String status;
    public String tid;
    public String url;
}
