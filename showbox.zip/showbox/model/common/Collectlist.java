package com.tdo.showbox.model.common;
/* loaded from: classes3.dex */
public class Collectlist {
    public String actors;
    public String banner_mini;
    public int box_type;
    private String collect_id;
    public String id;
    private String imdb_rating;
    public int isChecked;
    private boolean isEdit;
    private boolean isSelected;
    public String poster;
    public String quality_tag;
    public String season_episode;
    public String title;
    public int updateCount;
    public String update_title;
    public String year;

    public String getCollect_id() {
        return this.collect_id;
    }

    public void setCollect_id(String str) {
        this.collect_id = str;
    }

    public String getImdb_rating() {
        return this.imdb_rating;
    }

    public void setImdb_rating(String str) {
        this.imdb_rating = str;
    }

    public boolean isSelected() {
        return this.isSelected;
    }

    public void setSelected(boolean z) {
        this.isSelected = z;
    }

    public boolean isEdit() {
        return this.isEdit;
    }

    public void setEdit(boolean z) {
        this.isEdit = z;
    }

    public String getId() {
        return this.id;
    }

    public void setId(String str) {
        this.id = str;
    }

    public String getTitle() {
        return this.title;
    }

    public void setTitle(String str) {
        this.title = str;
    }

    public String getPoster() {
        return this.poster;
    }

    public void setPoster(String str) {
        this.poster = str;
    }

    public int getBox_type() {
        return this.box_type;
    }

    public void setBox_type(int i) {
        this.box_type = i;
    }

    public String getYear() {
        return this.year;
    }

    public void setYear(String str) {
        this.year = str;
    }

    public String getActors() {
        return this.actors;
    }

    public void setActors(String str) {
        this.actors = str;
    }

    public int getUpdateCount() {
        return this.updateCount;
    }

    public void setUpdateCount(int i) {
        this.updateCount = i;
    }

    public String getSeason_episode() {
        return this.season_episode;
    }

    public void setSeason_episode(String str) {
        this.season_episode = str;
    }

    public String getUpdate_title() {
        return this.update_title;
    }

    public void setUpdate_title(String str) {
        this.update_title = str;
    }

    public String getQuality_tag() {
        return this.quality_tag;
    }

    public void setQuality_tag(String str) {
        this.quality_tag = str;
    }

    public String getBanner_mini() {
        return this.banner_mini;
    }

    public void setBanner_mini(String str) {
        this.banner_mini = str;
    }

    public int getIsChecked() {
        return this.isChecked;
    }

    public void setIsChecked(int i) {
        this.isChecked = i;
    }
}
