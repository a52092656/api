package com.tdo.showbox.model.common;

import java.io.Serializable;
/* loaded from: classes3.dex */
public class Feedback implements Serializable {
    public int ftid;
    public String name;
    public String remarks;
    public int state;

    public int getFtid() {
        return this.ftid;
    }

    public void setFtid(int i) {
        this.ftid = i;
    }

    public int getState() {
        return this.state;
    }

    public void setState(int i) {
        this.state = i;
    }

    public String getName() {
        return this.name;
    }

    public void setName(String str) {
        this.name = str;
    }

    public String getRemarks() {
        return this.remarks;
    }

    public void setRemarks(String str) {
        this.remarks = str;
    }
}
