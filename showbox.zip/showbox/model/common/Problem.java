package com.tdo.showbox.model.common;
/* loaded from: classes3.dex */
public class Problem {
    public String Season;
    public int codeFile;
    public int episode;
    public boolean isSelected;
    public long releasedTime;
    public int season;
    public int viewtype;
}
