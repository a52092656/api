package com.tdo.showbox.model.common;
/* loaded from: classes3.dex */
public class UpdateInfo {
    public String apkPath;
    public String apkSize;
    public String apkUrl;
    public String description;
    public String md5;
    public String title;
    public String updateTime;
    public String version;
}
