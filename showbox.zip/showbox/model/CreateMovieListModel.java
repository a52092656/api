package com.tdo.showbox.model;
/* loaded from: classes3.dex */
public class CreateMovieListModel {
    private int box_type;
    private String mark;
    private String mid;

    public int getBox_type() {
        return this.box_type;
    }

    public void setBox_type(int i) {
        this.box_type = i;
    }

    public String getMid() {
        return this.mid;
    }

    public void setMid(String str) {
        this.mid = str;
    }

    public String getMark() {
        return this.mark;
    }

    public void setMark(String str) {
        this.mark = str;
    }
}
