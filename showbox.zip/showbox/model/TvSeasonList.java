package com.tdo.showbox.model;

import android.os.Parcel;
import android.os.Parcelable;
/* loaded from: classes3.dex */
public class TvSeasonList implements Parcelable {
    public static final Parcelable.Creator<TvSeasonList> CREATOR = new Parcelable.Creator<TvSeasonList>() { // from class: com.tdo.showbox.model.TvSeasonList.1
        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        /* renamed from: createFromParcel */
        public TvSeasonList mo591createFromParcel(Parcel parcel) {
            return new TvSeasonList(parcel);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        /* renamed from: newArray */
        public TvSeasonList[] mo592newArray(int i) {
            return new TvSeasonList[i];
        }
    };
    private int episode;
    private String id;
    private int season;
    private String tid;

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    public String getId() {
        return this.id;
    }

    public void setId(String str) {
        this.id = str;
    }

    public String getTid() {
        return this.tid;
    }

    public void setTid(String str) {
        this.tid = str;
    }

    public int getSeason() {
        return this.season;
    }

    public void setSeason(int i) {
        this.season = i;
    }

    public int getEpisode() {
        return this.episode;
    }

    public void setEpisode(int i) {
        this.episode = i;
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(this.tid);
        parcel.writeInt(this.season);
        parcel.writeInt(this.episode);
        parcel.writeString(this.id);
    }

    public TvSeasonList() {
    }

    protected TvSeasonList(Parcel parcel) {
        this.tid = parcel.readString();
        this.season = parcel.readInt();
        this.episode = parcel.readInt();
        this.id = parcel.readString();
    }
}
