package com.tdo.showbox.model;

import com.tdo.showbox.model.common.NetTestModel;
import java.util.List;
/* loaded from: classes3.dex */
public class TestSpeedModel {
    private List<NetTestModel> our;
    private List<NetTestModel> third;

    public List<NetTestModel> getOur() {
        return this.our;
    }

    public void setOur(List<NetTestModel> list) {
        this.our = list;
    }

    public List<NetTestModel> getThird() {
        return this.third;
    }

    public void setThird(List<NetTestModel> list) {
        this.third = list;
    }
}
