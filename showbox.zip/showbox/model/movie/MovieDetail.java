package com.tdo.showbox.model.movie;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import com.tdo.showbox.app.App;
import com.tdo.showbox.app.Constant;
import com.tdo.showbox.db.entity.Download;
import com.tdo.showbox.http.API;
import com.tdo.showbox.http.APIService;
import com.tdo.showbox.http.Http;
import com.tdo.showbox.model.BaseMediaModel;
import com.tdo.showbox.model.DownloadModel;
import com.tdo.showbox.model.movie.MovieListModel;
import com.tdo.showbox.service.DownloadService;
import com.tdo.showbox.utils.ParamsUtils;
import com.tdo.showbox.utils.PrefsUtils;
import io.reactivex.Observable;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
/* loaded from: classes3.dex */
public class MovieDetail extends BaseMediaModel implements Serializable {
    public String actors;
    public String content_rating;
    public List<MovieFile> file;
    public List<MovieListModel.MovieListItem> playlists;
    public String[] quality;
    public List<Recommend> recommend;
    public String runtime;
    public int seconds;
    public String source_file;
    public String trailer;
    public String writer;

    /* loaded from: classes3.dex */
    public static class MovieFile implements Serializable {
        public String bitstream;
        public String count;
        public long dateline;
        public String filename;
        public String format;
        public String mmfid;
        public String path;
        public String quality;
        public String size;
        public String vip_only;
    }

    /* loaded from: classes3.dex */
    public static class Recommend implements Serializable {
        public String imdb_rating;
        public String mid;
        public String poster;
        public String quality_tag;
        public String title;
    }

    @Override // com.tdo.showbox.model.BaseMediaModel, com.tdo.showbox.model.MediaFunction
    public int getBoxType() {
        return 1;
    }

    public MovieDetail() {
        this.runtime = "";
        this.content_rating = "";
        this.file = new ArrayList();
    }

    public MovieDetail(DownloadModel downloadModel) {
        this.runtime = "";
        this.content_rating = "";
        this.file = new ArrayList();
        this.privateId = downloadModel.getPrivateid();
        this.id = downloadModel.getMovieId();
        this.mb_id = downloadModel.getMbId();
        this.box_type = downloadModel.getBox_type();
        this.title = downloadModel.getTitle();
        this.display = Integer.parseInt(downloadModel.getDisplay());
        this.poster = downloadModel.getPoster();
        this.runtime = downloadModel.getRuntime();
        this.add_time = Long.parseLong(downloadModel.getAdd_time());
        this.is_collect = downloadModel.getIs_collect();
        this.download = downloadModel.getDownloads();
        this.fileName = downloadModel.getFileName();
        this.path = downloadModel.getPath();
        this.qualitys = downloadModel.getQuality();
        this.size = downloadModel.getSize();
        this.format = downloadModel.getFormat();
        this.vip_only = Integer.valueOf(downloadModel.getVip_only()).intValue();
        this.count = downloadModel.getCount();
        this.dateline = downloadModel.getDateline();
        this.fileLength = downloadModel.getFileLength();
        this.statue = downloadModel.getStatue();
        this.progress = downloadModel.getProgress();
        this.speed = downloadModel.getSpeed();
        this.mmfid = downloadModel.getMmfid();
        this.content_rating = downloadModel.content_rating;
        BaseMediaModel.DownloadFile downloadFile = new BaseMediaModel.DownloadFile();
        downloadFile.path = downloadModel.getPath();
        downloadFile.quality = downloadModel.getQuality();
        downloadFile.format = downloadModel.getFormat();
        downloadFile.size = downloadModel.getSize();
        downloadFile.vip_only = Integer.valueOf(downloadModel.getVip_only()).intValue();
        downloadFile.count = downloadModel.getCount();
        downloadFile.dateline = downloadModel.getDateline();
        downloadFile.filename = downloadModel.getFileName();
        downloadFile.real_quality = downloadModel.quality;
        downloadFile.mmfid = downloadModel.mmfid;
        this.list.add(downloadFile);
    }

    @Override // com.tdo.showbox.model.BaseMediaModel, com.tdo.showbox.model.MediaFunction
    public boolean saveInDao(int i, Activity activity) {
        super.saveInDao(i, activity);
        if (this.list.get(i).path == null) {
            return false;
        }
        Download download = new Download();
        download.setMovieId(this.id);
        download.setMbId(this.mb_id);
        download.setBox_type(this.box_type);
        download.setTitle(this.title);
        download.setDisplay(String.valueOf(this.display));
        download.setPoster(this.poster);
        download.setRuntime(this.runtime);
        download.setAdd_time(String.valueOf(this.add_time));
        download.setIs_collect(this.is_collect);
        download.setDownload(this.download);
        download.setFileName(this.list.get(i).filename);
        download.setPath(getDownloadPath(this.list.get(i).path));
        download.setQuality(this.list.get(i).quality);
        download.setSize(this.list.get(i).size);
        download.setFormat(this.list.get(i).format);
        download.setVip_only(this.list.get(i).vip_only + "");
        download.setCount(this.list.get(i).count);
        download.setDateline(this.list.get(i).dateline);
        download.setMmfid(this.list.get(i).tmfid);
        download.setFileLength(this.fileLength);
        download.setStatue(0);
        download.setProgress(this.progress);
        download.setSpeed(this.speed);
        download.setPrivateid(this.id);
        download.setFid(String.valueOf(this.list.get(i).fid));
        download.setMmfid(this.list.get(i).mmfid);
        download.setContent_rating(this.content_rating);
        App.getDB().downloadDao().insert(download);
        startService(Constant.ACTION.MOVIE_DOWNLOAD, activity);
        return true;
    }

    private String getDownloadPath(String str) {
        String string = PrefsUtils.getInstance().getString(Constant.Prefs.NETWORK_STATE, "Error");
        if (!string.equals("Error")) {
            String[] split = str.split("/");
            StringBuilder sb = new StringBuilder();
            if (split.length <= 2) {
                return str;
            }
            split[2] = string;
            for (int i = 2; i < split.length; i++) {
                if (i != split.length - 1) {
                    sb.append(split[i]);
                    sb.append("/");
                } else {
                    sb.append(split[i]);
                }
            }
            return sb.toString();
        }
        return str;
    }

    @Override // com.tdo.showbox.model.BaseMediaModel, com.tdo.showbox.model.MediaFunction
    public String getId() {
        return this.id;
    }

    @Override // com.tdo.showbox.model.BaseMediaModel, com.tdo.showbox.model.MediaFunction
    public String getTid() {
        return this.id;
    }

    @Override // com.tdo.showbox.model.BaseMediaModel, com.tdo.showbox.model.MediaFunction
    public Observable<String> getUrl() {
        String str;
        String str2;
        String str3 = "";
        String string = PrefsUtils.getInstance().getString(Constant.Prefs.NETWORK_GROUP, str3);
        if (!TextUtils.isEmpty(string) && "0".equalsIgnoreCase(string)) {
            str2 = str3;
            str = str2;
        } else {
            str = string;
            str2 = "1";
        }
        APIService service = Http.getService();
        String str4 = API.BASE_URL;
        if (App.isLogin()) {
            str3 = App.getUserData().uid;
        }
        return service.Movie_detail(str4, API.Movie.MOVE_DOWNLAOD, str3, this.id, "", str2, str);
    }

    @Override // com.tdo.showbox.model.BaseMediaModel, com.tdo.showbox.model.MediaFunction
    public Observable<String> getSrt() {
        return Http.getService().Movie_srt_auto(API.BASE_URL, API.Movie.MOVIE_SRT_AUTO, this.id, Locale.getDefault().getLanguage(), App.isLogin() ? App.getUserData().uid : "");
    }

    @Override // com.tdo.showbox.model.BaseMediaModel, com.tdo.showbox.model.MediaFunction
    public void startService(String str, Activity activity) {
        Intent intent = new Intent(activity, DownloadService.class);
        Bundle build = ParamsUtils.newBuilder().addParam(Constant.Download.PARAMS_KEY_MOVIE, this.id).addParam(Constant.Download.PARAMS_KEY_TYPE, this.box_type).build();
        intent.setAction(str);
        intent.putExtras(build);
        activity.startService(intent);
    }
}
