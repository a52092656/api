package com.tdo.showbox.model;

import java.util.List;
/* loaded from: classes3.dex */
public class ChatMsgResponseModel {
    private List<ChatMsgModel> list;

    public List<ChatMsgModel> getList() {
        return this.list;
    }

    public void setList(List<ChatMsgModel> list) {
        this.list = list;
    }
}
