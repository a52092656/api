package com.tdo.showbox.model.tv;
/* loaded from: classes3.dex */
public class TvDetailModel {
    public String actors;
    public long add_time;
    public String banner_mini;
    public int box_type;
    public String cats;
    public int code_file;
    public String collect;
    public String description;
    public String director;
    public int display;
    public String download;
    public String id;
    public String imdb_id;
    public String imdb_rating;
    public int is_collect;
    public String mb_id;
    public String poster;
    public String released;
    public int released_timestamp;
    public String season_episode;
    public int state;
    public String title;
    public String trailer_url;
    public String update_time;
    public String update_title;
    public String view;
    public int vip_only;
    public String writer;
    public String year;
}
