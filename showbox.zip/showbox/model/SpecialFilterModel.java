package com.tdo.showbox.model;
/* loaded from: classes3.dex */
public class SpecialFilterModel {
    private int bgId;
    private String display_name;
    private String id;
    private boolean isSelect;

    public String getDisplay_name() {
        return this.display_name;
    }

    public void setDisplay_name(String str) {
        this.display_name = str;
    }

    public String getId() {
        return this.id;
    }

    public void setId(String str) {
        this.id = str;
    }

    public int getBgId() {
        return this.bgId;
    }

    public void setBgId(int i) {
        this.bgId = i;
    }

    public boolean isSelect() {
        return this.isSelect;
    }

    public void setSelect(boolean z) {
        this.isSelect = z;
    }
}
