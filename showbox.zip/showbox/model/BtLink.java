package com.tdo.showbox.model;
/* loaded from: classes3.dex */
public class BtLink {
    private long dateline;
    private String file;
    private String size;
    private String torrent_magnet;

    public String getFile() {
        return this.file;
    }

    public void setFile(String str) {
        this.file = str;
    }

    public String getSize() {
        return this.size;
    }

    public void setSize(String str) {
        this.size = str;
    }

    public String getTorrent_magnet() {
        return this.torrent_magnet;
    }

    public void setTorrent_magnet(String str) {
        this.torrent_magnet = str;
    }

    public long getDateline() {
        return this.dateline;
    }

    public void setDateline(long j) {
        this.dateline = j;
    }
}
