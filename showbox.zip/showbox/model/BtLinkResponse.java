package com.tdo.showbox.model;

import java.util.ArrayList;
/* loaded from: classes3.dex */
public class BtLinkResponse {
    private ArrayList<BtLink> list;

    public ArrayList<BtLink> getList() {
        return this.list;
    }

    public void setList(ArrayList<BtLink> arrayList) {
        this.list = arrayList;
    }
}
