package com.tdo.showbox.model;
/* loaded from: classes3.dex */
public class TvShowsUpdateModel {
    private String banner_mini;
    private String cats;
    private String id;
    private String poster;
    private String season_episode;
    private String title;

    public String getId() {
        return this.id;
    }

    public void setId(String str) {
        this.id = str;
    }

    public String getBanner_mini() {
        return this.banner_mini;
    }

    public void setBanner_mini(String str) {
        this.banner_mini = str;
    }

    public String getPoster() {
        return this.poster;
    }

    public void setPoster(String str) {
        this.poster = str;
    }

    public String getTitle() {
        return this.title;
    }

    public void setTitle(String str) {
        this.title = str;
    }

    public String getCats() {
        return this.cats;
    }

    public void setCats(String str) {
        this.cats = str;
    }

    public String getSeason_episode() {
        return this.season_episode;
    }

    public void setSeason_episode(String str) {
        this.season_episode = str;
    }
}
