package com.tdo.showbox.model;
/* loaded from: classes3.dex */
public class NoticeCountModel {
    private int like_newCount;
    private int list_newCount;
    private int pm_newCount;
    private int reply_newCount;
    private int total;

    public int getList_newCount() {
        return this.list_newCount;
    }

    public void setList_newCount(int i) {
        this.list_newCount = i;
    }

    public int getPm_newCount() {
        return this.pm_newCount;
    }

    public void setPm_newCount(int i) {
        this.pm_newCount = i;
    }

    public int getReply_newCount() {
        return this.reply_newCount;
    }

    public void setReply_newCount(int i) {
        this.reply_newCount = i;
    }

    public int getLike_newCount() {
        return this.like_newCount;
    }

    public void setLike_newCount(int i) {
        this.like_newCount = i;
    }

    public int getTotal() {
        return this.total;
    }

    public void setTotal(int i) {
        this.total = i;
    }
}
