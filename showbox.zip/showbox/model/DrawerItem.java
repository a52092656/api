package com.tdo.showbox.model;
/* loaded from: classes3.dex */
public class DrawerItem {
    public static final int ADD_TICKET = 4;
    public static final int DEVICE = 10;
    public static final int EMAIL = 1;
    public static final int EMAIL_US = 9;
    public static final int FAQ = 7;
    public static final int INVITAION_CODE = 2;
    public static final int MY_ORDER = 6;
    public static final int MY_TICKETS = 5;
    public static final int SERVER_SPEED_TEST = 3;
    public static final int SETTING = 8;
    private boolean isLast;
    private String title;
    private int type;

    public DrawerItem(String str, int i, boolean z) {
        this.title = str;
        this.type = i;
        this.isLast = z;
    }

    public boolean isLast() {
        return this.isLast;
    }

    public void setLast(boolean z) {
        this.isLast = z;
    }

    public DrawerItem(String str, int i) {
        this.title = str;
        this.type = i;
    }

    public String getTitle() {
        return this.title;
    }

    public void setTitle(String str) {
        this.title = str;
    }

    public int getType() {
        return this.type;
    }

    public void setType(int i) {
        this.type = i;
    }
}
