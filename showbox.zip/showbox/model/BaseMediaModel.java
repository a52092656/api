package com.tdo.showbox.model;

import android.app.Activity;
import android.text.TextUtils;
import com.tdo.showbox.app.Constant;
import com.tdo.showbox.utils.CheckUtils;
import io.reactivex.Observable;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
/* loaded from: classes3.dex */
public class BaseMediaModel implements MediaFunction, Serializable {
    public long add_time;
    public String[] audio_lang;
    public int box_type;
    public String cats;
    public int code_file;
    public String collect;
    public String count;
    public long dateline;
    public String description;
    public String director;
    public int display;
    public String download;
    public int episode;
    public long fileLength;
    public String fileName;
    public String format;
    public String id;
    public String imdb_id;
    public String imdb_link;
    public int is_collect;
    public List<MoreLanguage> language;
    public String mb_id;
    public String mmfid;
    public String path;
    public String poster;
    public String privateId;
    public String[] quality;
    public String quality_tag;
    public String[] quality_tags;
    public String qualitys;
    public String released;
    public long released_timestamp;
    public int season;
    public int seconds;
    public String size;
    public long speed;
    public int state;
    public String title;
    public int tmfid;
    public int tomato_meter;
    public String tomato_url;
    public String trailer_url;
    public long update_time;
    public String view;
    public int vip_only;
    public String year = "";
    public int isChecked = 0;
    public String imdb_rating = "";
    public int statue = 0;
    public int progress = 0;
    public List<DownloadFile> list = new ArrayList();

    /* loaded from: classes3.dex */
    public static class MoreLanguage implements Serializable {
        public String lang;
        public String title;
    }

    @Override // com.tdo.showbox.model.MediaFunction
    public int getBoxType() {
        return 0;
    }

    @Override // com.tdo.showbox.model.MediaFunction
    public int getEpisode() {
        return 0;
    }

    @Override // com.tdo.showbox.model.MediaFunction
    public String getId() {
        return "";
    }

    @Override // com.tdo.showbox.model.MediaFunction
    public int getSeason() {
        return 0;
    }

    @Override // com.tdo.showbox.model.MediaFunction
    public Observable<String> getSrt() {
        return null;
    }

    @Override // com.tdo.showbox.model.MediaFunction
    public String getTid() {
        return null;
    }

    @Override // com.tdo.showbox.model.MediaFunction
    public Observable<String> getUrl() {
        return null;
    }

    @Override // com.tdo.showbox.model.MediaFunction
    public void startService(String str, Activity activity) {
    }

    public boolean isFileExists() {
        return CheckUtils.checkFileExists(getFilePath(), "");
    }

    public String getFilePath() {
        if (getFileName() != null) {
            return Constant.DIR_DOWNLOAD;
        }
        return null;
    }

    private String getFileName() {
        if (this.title != null) {
            return this.title + ".MP4";
        }
        return null;
    }

    @Override // com.tdo.showbox.model.MediaFunction
    public void addDonwload(BaseMediaModel baseMediaModel) {
        this.seconds = baseMediaModel.seconds;
        this.quality = baseMediaModel.quality;
        this.list = baseMediaModel.list;
    }

    @Override // com.tdo.showbox.model.MediaFunction
    public int ChoosePlayer() {
        for (int i = 0; i < this.list.size(); i++) {
            if (this.list.get(i).path != null && !TextUtils.isEmpty(this.list.get(i).path)) {
                if (i <= 4) {
                    return i;
                }
                return 4;
            }
        }
        return 0;
    }

    @Override // com.tdo.showbox.model.MediaFunction
    public boolean saveInDao(int i, Activity activity) {
        List<DownloadFile> list = this.list;
        return list != null && list.size() <= i;
    }

    /* loaded from: classes3.dex */
    public static class DownloadFile implements Serializable {
        public String bitstream;
        public int colorbit;
        public String count;
        public long dateline;
        public int fid;
        public String filename;
        public String format;
        public int h265;
        public int hdr;
        private boolean lastItem;
        public String mmfid;
        public int original;
        public String path;
        public String[] path2;
        public String quality;
        public String real_quality;
        public String size;
        private int success;
        private int timeout;
        public String tmfid;
        private int viewType;
        public int vip_only;

        public int getSuccess() {
            return this.success;
        }

        public void setSuccess(int i) {
            this.success = i;
        }

        public int getTimeout() {
            return this.timeout;
        }

        public void setTimeout(int i) {
            this.timeout = i;
        }

        public boolean isLastItem() {
            return this.lastItem;
        }

        public void setLastItem(boolean z) {
            this.lastItem = z;
        }

        public int getViewType() {
            return this.viewType;
        }

        public void setViewType(int i) {
            this.viewType = i;
        }

        public String getReal_quality() {
            return this.real_quality;
        }

        public void setReal_quality(String str) {
            this.real_quality = str;
        }

        public int getOriginal() {
            return this.original;
        }

        public void setOriginal(int i) {
            this.original = i;
        }

        public int getHdr() {
            return this.hdr;
        }

        public void setHdr(int i) {
            this.hdr = i;
        }

        public int getColorbit() {
            return this.colorbit;
        }

        public void setColorbit(int i) {
            this.colorbit = i;
        }

        public String getPath() {
            return this.path;
        }

        public void setPath(String str) {
            this.path = str;
        }

        public String[] getPath2() {
            return this.path2;
        }

        public void setPath2(String[] strArr) {
            this.path2 = strArr;
        }

        public String getQuality() {
            return this.quality;
        }

        public void setQuality(String str) {
            this.quality = str;
        }

        public String getFormat() {
            return this.format;
        }

        public void setFormat(String str) {
            this.format = str;
        }

        public String getSize() {
            return this.size;
        }

        public void setSize(String str) {
            this.size = str;
        }

        public int getVip_only() {
            return this.vip_only;
        }

        public void setVip_only(int i) {
            this.vip_only = i;
        }

        public String getCount() {
            return this.count;
        }

        public void setCount(String str) {
            this.count = str;
        }

        public long getDateline() {
            return this.dateline;
        }

        public void setDateline(long j) {
            this.dateline = j;
        }

        public String getTmfid() {
            return this.tmfid;
        }

        public void setTmfid(String str) {
            this.tmfid = str;
        }

        public String getMmfid() {
            return this.mmfid;
        }

        public void setMmfid(String str) {
            this.mmfid = str;
        }

        public int getH265() {
            return this.h265;
        }

        public void setH265(int i) {
            this.h265 = i;
        }

        public int getFid() {
            return this.fid;
        }

        public void setFid(int i) {
            this.fid = i;
        }

        public String getFilename() {
            return this.filename;
        }

        public void setFilename(String str) {
            this.filename = str;
        }

        public String getBitstream() {
            return this.bitstream;
        }

        public void setBitstream(String str) {
            this.bitstream = str;
        }
    }
}
