package com.tdo.showbox.model;
/* loaded from: classes3.dex */
public class ExtractInfo {
    private String magnet_link;
    private int success;
    private int timeout;

    public int getSuccess() {
        return this.success;
    }

    public void setSuccess(int i) {
        this.success = i;
    }

    public int getTimeout() {
        return this.timeout;
    }

    public void setTimeout(int i) {
        this.timeout = i;
    }

    public String getMagnet_link() {
        return this.magnet_link;
    }

    public void setMagnet_link(String str) {
        this.magnet_link = str;
    }
}
