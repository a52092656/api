package com.tdo.showbox.model.detail;
/* loaded from: classes3.dex */
public abstract class BaseVideoBean implements AbstractVideoBean {
}
