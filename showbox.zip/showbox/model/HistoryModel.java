package com.tdo.showbox.model;
/* loaded from: classes3.dex */
public class HistoryModel {
    private String actors;
    private int box_type;
    private String description;
    private HistoryBean history;
    private int id;
    private String poster;
    private int seconds;
    private String title;
    private int year;

    public int getSeconds() {
        return this.seconds;
    }

    public void setSeconds(int i) {
        this.seconds = i;
    }

    public int getId() {
        return this.id;
    }

    public void setId(int i) {
        this.id = i;
    }

    public String getTitle() {
        return this.title;
    }

    public void setTitle(String str) {
        this.title = str;
    }

    public String getPoster() {
        return this.poster;
    }

    public void setPoster(String str) {
        this.poster = str;
    }

    public int getBox_type() {
        return this.box_type;
    }

    public void setBox_type(int i) {
        this.box_type = i;
    }

    public int getYear() {
        return this.year;
    }

    public void setYear(int i) {
        this.year = i;
    }

    public String getActors() {
        return this.actors;
    }

    public void setActors(String str) {
        this.actors = str;
    }

    public String getDescription() {
        return this.description;
    }

    public void setDescription(String str) {
        this.description = str;
    }

    public HistoryBean getHistory() {
        return this.history;
    }

    public void setHistory(HistoryBean historyBean) {
        this.history = historyBean;
    }

    /* loaded from: classes3.dex */
    public static class HistoryBean {
        private int episode;
        private int season;
        private int seconds;

        public int getSeason() {
            return this.season;
        }

        public void setSeason(int i) {
            this.season = i;
        }

        public int getEpisode() {
            return this.episode;
        }

        public void setEpisode(int i) {
            this.episode = i;
        }

        public int getSeconds() {
            return this.seconds;
        }

        public void setSeconds(int i) {
            this.seconds = i;
        }
    }
}
