package com.tdo.showbox.model;
/* loaded from: classes3.dex */
public class VideoTagModel {
    private int imgId;
    private String rate;
    private int type;

    public String getRate() {
        return this.rate;
    }

    public void setRate(String str) {
        this.rate = str;
    }

    public int getType() {
        return this.type;
    }

    public void setType(int i) {
        this.type = i;
    }

    public int getImgId() {
        return this.imgId;
    }

    public void setImgId(int i) {
        this.imgId = i;
    }
}
