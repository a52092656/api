package com.tdo.showbox.model;

import java.util.List;
/* loaded from: classes3.dex */
public class SingleReviewModel {
    private List<ReviewModel> list;

    public List<ReviewModel> getList() {
        return this.list;
    }

    public void setList(List<ReviewModel> list) {
        this.list = list;
    }
}
