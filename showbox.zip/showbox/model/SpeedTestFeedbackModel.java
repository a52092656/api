package com.tdo.showbox.model;
/* loaded from: classes3.dex */
public class SpeedTestFeedbackModel {
    private int average;
    private String group;
    private String test_url_id;

    public String getTest_url_id() {
        return this.test_url_id;
    }

    public void setTest_url_id(String str) {
        this.test_url_id = str;
    }

    public String getGroup() {
        return this.group;
    }

    public void setGroup(String str) {
        this.group = str;
    }

    public int getAverage() {
        return this.average;
    }

    public void setAverage(int i) {
        this.average = i;
    }
}
