package com.tdo.showbox.db.dao;

import com.tdo.showbox.db.entity.Chart;
/* loaded from: classes3.dex */
public interface ChartDao {
    void clear();

    void clearNull();

    void delete(Chart chart);

    void deleteByBookID(String str);

    void insert(Chart chart);

    Chart loadByID(String str);

    void update(Chart chart);
}
