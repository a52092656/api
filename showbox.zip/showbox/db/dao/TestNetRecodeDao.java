package com.tdo.showbox.db.dao;

import com.tdo.showbox.db.entity.TestNetRecode;
/* loaded from: classes3.dex */
public interface TestNetRecodeDao {
    void clear();

    void delete(TestNetRecode testNetRecode);

    void deleteById(int i);

    TestNetRecode findAll(int i);

    void insert(TestNetRecode testNetRecode);

    void update(TestNetRecode testNetRecode);
}
