package com.tdo.showbox.db.entity;
/* loaded from: classes3.dex */
public class SubtitleDelayRecord {
    private int delaySecond;
    private String sid = "";

    public int getDelaySecond() {
        return this.delaySecond;
    }

    public void setDelaySecond(int i) {
        this.delaySecond = i;
    }

    public String getSid() {
        return this.sid;
    }

    public void setSid(String str) {
        this.sid = str;
    }
}
