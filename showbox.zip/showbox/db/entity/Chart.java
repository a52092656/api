package com.tdo.showbox.db.entity;
/* loaded from: classes3.dex */
public class Chart {
    private String bookId;
    private String id;
    private String userId;

    public void setUserId(String str) {
        this.userId = str;
    }

    public String getBookId() {
        return this.bookId;
    }

    public void setBookId(String str) {
        this.bookId = str;
    }

    public String getId() {
        return this.id;
    }

    public void setId(String str) {
        this.id = str;
    }

    public String getUserId() {
        return this.userId;
    }
}
