package com.tdo.showbox.app;

import android.app.Activity;
import com.billy.android.swipe.SmartSwipeBack;
/* compiled from: lambda */
/* renamed from: com.tdo.showbox.app.-$$Lambda$App$K5uDUy9OusO6E9w1mGmLNR-kibg  reason: invalid class name */
/* loaded from: classes.dex */
public final /* synthetic */ class $$Lambda$App$K5uDUy9OusO6E9w1mGmLNRkibg implements SmartSwipeBack.ActivitySwipeBackFilter {
    public static final /* synthetic */ $$Lambda$App$K5uDUy9OusO6E9w1mGmLNRkibg INSTANCE = new $$Lambda$App$K5uDUy9OusO6E9w1mGmLNRkibg();

    private /* synthetic */ $$Lambda$App$K5uDUy9OusO6E9w1mGmLNRkibg() {
    }

    @Override // com.billy.android.swipe.SmartSwipeBack.ActivitySwipeBackFilter
    public final boolean onFilter(Activity activity) {
        return App.lambda$initSwipeBack$0(activity);
    }
}
