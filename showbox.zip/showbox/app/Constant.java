package com.tdo.showbox.app;

import android.os.Environment;
import com.koushikdutta.async.http.cache.ResponseCacheMiddleware;
import com.tdo.showbox.BuildConfig;
import com.tdo.showbox.model.DownloadInfo;
import com.tdo.showbox.utils.HexDump;
import com.tdo.showbox.utils.MD5Util;
import java.io.File;
/* loaded from: classes.dex */
public class Constant {
    public static final String APPNEXT_INTERSTITIAL_KEY = "3fb0812b-78b9-4d0c-9039-5b3b9ac83027";
    public static final int BBS_ID_ACTOR = 41;
    public static final int BBS_ID_MOVIE = 2;
    public static final int BBS_ID_MOVIE_LIST = 37;
    public static final int BBS_ID_MOVIE_MUSIC = 57;
    public static final int BBS_ID_TV = 36;
    public static final String CHANNEL_KEY = "UMENG_CHANNEL";
    public static String CLICK_EVENT_JS = "";
    public static final String CLOUDMOBI_INTERSTITIAL_KEY = "33728081";
    public static final String[] DIRS;
    public static final String[] DIRS_CLEAR;
    public static final String DIR_CACHE;
    public static final String DIR_NOVEL;
    public static final String GENER = "gener";
    public static final String GOOGLE_APP_ID = "ca-app-pub-2446756197279868~5168103062";
    public static final String GOOGLE_BANNER_AD_KEY = "ca-app-pub-2446756197279868/3285546619";
    public static final String GOOGLE_FULLSCREEN_AD_KEY = "ca-app-pub-2446756197279868/9093662362";
    public static final String GOOGLE_SEARCH_AD_KEY = "ca-app-pub-2446756197279868/7635475889";
    public static final int HTTP_PORT = 8888;
    public static final int IMG_COMMON_CORNER = 8;
    public static final String LECAST_APPID = "12469";
    public static final String LECAST_APPSECRET = "db1c1d748a3f30d6a6e2fa55957acd35";
    public static final String MAX_DOWNLOAD_COUNT = "max_download_count";
    public static final String MINTEGRAL_IMAGE_INTERSTITIAL_KEY = "181760";
    public static final String MINTEGRAL_VIDEO_INTERSTITIAL_KEY = "181677";
    public static final String PANDA_BBS_URL = "https://www.kfpanda.club";
    public static final String SUFFIX_ZIP = ".zip";
    public static final String TEST_USERINFO = "{\"member\":{\"add_time\":1580789107,\"appid\":\"com.feng.MovieBox\",\"avatar\":\"https://mbpface.jiaodafu.net/avatar/014/71/05/08_avatar_middle.jpg\",\"bbs_bind\":{\"add_time\":1581572234,\"auth\":\"7bd56znO3kDofQrLhBtzWYj8rA4ukWvP+Vvla9Xivyh1DMajNTycKAcfEm4PrwmJfDnsm3O+uiJM/MqVcTds\",\"authkey\":\"5dd450129239e3504dfe6c86b410356e\",\"author\":\"MJ_Lee\",\"avatar\":\"https://face.kfpanda.net/avatar.php?uid=4&size=middle\",\"bbs_uid\":\"4\",\"formhash\":\"34b2b705\",\"id\":\"5308\",\"uid\":\"14710508\"},\"bind\":[{\"email\":\"767321403lmj@gmail.com\",\"id\":\"4575691\",\"lock\":\"1\",\"name\":\"\",\"nick\":\"\",\"openid\":\"112597894395450584738\",\"token\":\"0\",\"type\":\"google\",\"uid\":\"14710508\",\"validtime\":\"1580789107\"}],\"dead_time\":1612155600,\"email\":\"767321403lmj@gmail.com\",\"id\":\"3506333\",\"invite_code_count\":0,\"invite_count\":11,\"isvip\":1,\"last_time\":1581572708,\"movie_update_remind_status\":1,\"nickname\":\"MJ_Leeliw\",\"uid\":\"14710508\",\"username\":\"MJ_Leeliw\"}}";
    public static final String DIR = Environment.getExternalStorageDirectory().getPath() + File.separator + "Android/data" + File.separator + BuildConfig.APPLICATION_ID;
    public static final String DIR_NET_DATA_CACHE = DIR + File.separator + "netcache";
    public static final String DIR_LOG = DIR + File.separator + "log";
    public static final String DIR_CONFIG = DIR + File.separator + "config";
    public static final String DIR_DOWNLOAD = DIR + File.separator + DownloadInfo.DOWNLOAD;
    public static final String DIR_DOWNLOAD_TEST_SPEED = DIR + File.separator + "testspeed";
    public static final String DIR_PICTURE = DIR + File.separator + "picture";
    public static final String DIR_CROP = DIR + File.separator + "crop";
    public static final String DIR_THUMB = DIR + File.separator + "thumb";
    public static final String DIR_VIDEO = DIR + File.separator + "video";
    public static final String DIR_TRANS_CODE_SUBTITLE = DIR + File.separator + "TransSubtitle";
    public static final String DIR_TXT = DIR + File.separator + "txt";
    public static final String DIR_FONT = DIR + File.separator + "font";
    public static final String DIR_SUBTITLE = DIR + File.separator + "Subtitle";
    public static final String DIR_UPLOAD_SUBTITLE = DIR_SUBTITLE + File.separator + "uploadSubtitles";
    public static final String DIR_DOLOAD_SUBTITLE = DIR_SUBTITLE + File.separator + "downloadSubtitles";
    public static final String DIR_UPLOAD_MOVIE_SUBTITLE = DIR_UPLOAD_SUBTITLE + File.separator + "movie";
    public static final String DIR_UPLOAD_TV_SUBTITLE = DIR_UPLOAD_SUBTITLE + File.separator + "tv";
    public static final String DIR_DOWNLOAD_MOVIE_SUBTITLE = DIR_DOLOAD_SUBTITLE + File.separator + "movie";
    public static final String DIR_DOWNLOAD_TV_SUBTITLE = DIR_DOLOAD_SUBTITLE + File.separator + "tv";
    public static final String DIR_WEB_DOWNLOAD_SUBTITLE = DIR_DOWNLOAD + File.separator + "webDownload";

    /* loaded from: classes3.dex */
    public static final class ACTION {
        public static final String DELETE_DOWNLOADED_TV = "com.tdo.showbox.ACTION_DELETE_DOWNLOADED_TV";
        public static final String DOWNLOAD_FILE = "com.tdo.showbox.ACTION_DOWNLOAD_FILE";
        public static final String DOWNLOAD_FILE_COMPLETE = "com.tdo.showbox.DOWNLOAD_FILE_COMPLETE";
        public static final String DOWNLOAD_FILE_FAILURE = "com.tdo.showbox.DOWNLOAD_FILE_FAILURE";
        public static final String DOWNLOAD_FILE_PROGRESS = "com.tdo.showbox.DOWNLOAD_FILE_PROGRESS";
        public static final String DOWNLOAD_FILE_STARTED = "com.tdo.showbox.DOWNLOAD_FILE_STARTED";
        public static final String DOWNLOAD_MOVIE_COMPLETE = "com.tdo.showbox.DOWNLOAD_MOVIE_COMPLETE";
        public static final String DOWNLOAD_MOVIE_DELETE = "com.tdo.showbox.DOWNLOAD_MOVIE_DELETE";
        public static final String DOWNLOAD_MOVIE_FAILURE = "com.tdo.showbox.DOWNLOAD_MOVIE_FAILURE";
        public static final String DOWNLOAD_MOVIE_PAUSED = "com.tdo.showbox.DOWNLOAD_MOVIE_PAUSED";
        public static final String DOWNLOAD_MOVIE_PROGRESS = "com.tdo.showbox.DOWNLOAD_MOVIE_PROGRESS";
        public static final String DOWNLOAD_MOVIE_READY = "com.tdo.showbox.DOWNLOAD_MOVIE_READY";
        public static final String DOWNLOAD_MOVIE_STARTED = "com.tdo.showbox.DOWNLOAD_MOVIE_STARTED";
        public static final String DOWNLOAD_NOTIFY_DELETE = "com.tdo.showbox.ACTION_NOTIFY_DELETE";
        public static final String DOWNLOAD_NOTIFY_FAIL = "com.tdo.showbox.ACTION_NOTIFY_FAIL";
        public static final String DOWNLOAD_NOTIFY_PAUSE = "com.tdo.showbox.ACTION_NOTIFY_PAUSE";
        public static final String DOWNLOAD_NOTIFY_PROGRESS = "com.tdo.showbox.ACTION_NOTIFY_PROGRESS";
        public static final String DOWNLOAD_NOTIFY_START = "com.tdo.showbox.ACTION_NOTIFY_START";
        public static final String DOWNLOAD_NOTIFY_SUCCESS = "com.tdo.showbox.ACTION_NOTIFY_SUCCESS";
        public static final String MOVIE_ALLDOWNLOAD = "com.tdo.showbox.ACTION_DOWNLOAD_ALLMOVIE";
        public static final String MOVIE_DELETE = "com.tdo.showbox.ACTION_DOWNLOAD_DELETE";
        public static final String MOVIE_DOWNLOAD = "com.tdo.showbox.ACTION_DOWNLOAD_MOVIE";
        public static final String MOVIE_ERROR = "com.tdo.showbox.ACTION_DOWNLOAD_ERROR";
        public static final String MOVIE_PAUSED = "com.tdo.showbox.ACTION_DOWNLOAD_PAUSED";
        public static final String MOVIE_PAUSEDALL = "com.tdo.showbox.ACTION_DOWNLOAD_PAUSEDALL";
        public static final String MOVIE_RESET_MAX_COUNT = "com.tdo.showbox.ACTION_DOWNLOAD_RESET_MAX_COUNT";
        public static final String MOVIE_STARTALL = "com.tdo.showbox.ACTION_DOWNLOAD_STARTALL";
        public static final String MOVIE_TV_DELETE = "com.tdo.showbox.ACTION_DOWNLOAD_TV_DELETE";
    }

    /* loaded from: classes3.dex */
    public static final class Bugly {
        public static final String APP_ID = "de5d255deb";
        public static final String APP_KEY = "18cea59a-23de-41a6-9209-0edb1d477db1";
    }

    /* loaded from: classes3.dex */
    public static final class Download {
        public static final String PARAMS_KEY_EPISODE = "params_key_episode";
        public static final String PARAMS_KEY_MOVIE = "params_key_movie";
        public static final String PARAMS_KEY_MOVIE_ID = "params_key_movie_id";
        public static final String PARAMS_KEY_MOVIE_TYPE = "params_key_movie_type";
        public static final String PARAMS_KEY_PATH = "params_key_path";
        public static final String PARAMS_KEY_PROGRESS = "params_key_progress";
        public static final String PARAMS_KEY_REASON = "params_key_reason";
        public static final String PARAMS_KEY_SEASON = "params_key_season";
        public static final String PARAMS_KEY_SIZE = "params_key_size";
        public static final String PARAMS_KEY_TYPE = "params_key_type";
        public static final int STATUS_DELETE = 5;
        public static final int STATUS_DOWNLOADED = 2;
        public static final int STATUS_DOWNLOADING = 1;
        public static final int STATUS_ERROR = 4;
        public static final int STATUS_IDLE = 0;
        public static final int STATUS_PASUED = 3;
    }

    /* loaded from: classes3.dex */
    public static final class Prefs {
        public static final String CHAPTER_PRICE = "chapter_price";
        public static final String CHECK_TIME_REMIND = "check_time_remind";
        public static final String CHILD_MODE = "child_mode";
        public static final String CHILD_MODE_PASSWORD = "child_mode_password";
        public static final float DEFAULT_CHAPTER_PRICE = 0.1f;
        public static final String DLNA_CAST_SEARCH_TIME = "dlna_cast_search_time";
        public static final String ENTER_BACK_TIME = "enter_back_time";
        public static final String FLIP_STYLE = "flipStyle";
        public static final int FLIP_STYLE_NONE = 0;
        public static final int FLIP_STYLE_OVERFLOW = 2;
        public static final int FLIP_STYLE_SCROLL = 3;
        public static final int FLIP_STYLE_SIMULATE = 1;
        public static final String FULLSCREEN_PLAY = "fullscreen_play";
        public static final String ISNIGHT = "isNight";
        public static final String IS_FIRST_OPEN = "is_first_open";
        public static final String IS_FIRST_SHORTCUT = "is_first_shorcut";
        public static final String LANGUAGE = "language";
        public static final String NETWORK_GROUP = "network_group";
        public static final String NETWORK_STATE = "network_state";
        public static final String PLAY_SCALE_VALUE = "play_scale_value";
        public static final String SETTING = "setting";
        public static final String SHOW_ADVERT_FRIST = "show_advert_frist";
        public static final String SHOW_BDYY_FRIST = "show_bdyy_frist";
        public static final String SHOW_FLOAT = "show_float";
        public static final String SHOW_H265 = "show_h265";
        public static final String SHOW_READ_TIPS = "showReadTips";
        public static final String SUBTITLE_COLOR = "subtitle_color";
        public static final String SUBTITLE_FONT = "subtitle_font";
        public static final String SUBTITLE_POS = "subtitle_pos";
        public static final String SUBTITLE_SIZE = "subtitle_size";
        public static final String TVDETAIL_SORT = "tvdetail_sort";
        public static final String TVDETAIL_YEARS = "tvdetail_year";
        public static final String USER_CELLUAR_DOWNLOAD = "user_celluar_download";
    }

    /* loaded from: classes3.dex */
    public static final class Video {
        public static final String VIDEO_EPISODE = "videoplayer_episode";
        public static final String VIDEO_ID_MOVIE = "videoplayer_id_movie";
        public static final String VIDEO_ID_TV = "videoplayer_id_tv";
        public static final String VIDEO_PARAMS = "videoplayer_params";
        public static final String VIDEO_SEASON = "videoplayer_season";
    }

    static {
        StringBuilder sb = new StringBuilder();
        sb.append(DIR);
        sb.append(File.separator);
        sb.append(ResponseCacheMiddleware.CACHE);
        DIR_CACHE = sb.toString();
        DIR_NOVEL = DIR_CACHE + File.separator + HexDump.toHexString(MD5Util.md5(App.packageName));
        String str = DIR_CACHE;
        String str2 = DIR_LOG;
        String str3 = DIR_CONFIG;
        String str4 = DIR_PICTURE;
        String str5 = DIR_CROP;
        String str6 = DIR_THUMB;
        String str7 = DIR_VIDEO;
        String str8 = DIR_TXT;
        String str9 = DIR_NOVEL;
        DIRS = new String[]{DIR, str, str2, str3, DIR_DOWNLOAD, str4, str5, str6, str7, str8, str9, DIR_FONT};
        DIRS_CLEAR = new String[]{str, str2, str3, str4, str5, str6, str7, str8, str9};
    }
}
