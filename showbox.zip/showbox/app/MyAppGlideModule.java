package com.tdo.showbox.app;

import android.content.Context;
import com.bumptech.glide.GlideBuilder;
import com.bumptech.glide.module.AppGlideModule;
/* loaded from: classes3.dex */
public class MyAppGlideModule extends AppGlideModule {
    @Override // com.bumptech.glide.module.AppGlideModule, com.bumptech.glide.module.AppliesOptions
    public void applyOptions(Context context, GlideBuilder glideBuilder) {
        super.applyOptions(context, glideBuilder);
    }
}
