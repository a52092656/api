package com.tdo.showbox.app;

import android.app.Activity;
import android.app.Application;
import android.content.ComponentCallbacks2;
import android.content.Context;
import android.database.sqlite.SQLiteFullException;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.LocaleList;
import android.provider.Settings;
import android.text.TextUtils;
import androidx.multidex.MultiDex;
import androidx.multidex.MultiDexApplication;
import androidx.room.Room;
import com.alibaba.fastjson.JSONObject;
import com.ares.downloader.jarvis.Jarvis;
import com.ares.downloader.jarvis.db.DefaultDownloadHistoryDBHelper;
import com.billy.android.swipe.SmartSwipeBack;
import com.bumptech.glide.Glide;
import com.chad.library.adapter.base.module.LoadMoreModuleConfig;
import com.google.android.gms.ads.AdActivity;
import com.google.android.gms.common.GooglePlayServicesNotAvailableException;
import com.google.android.gms.common.GooglePlayServicesRepairableException;
import com.google.android.gms.security.ProviderInstaller;
import com.hpplay.cybergarage.xml.XML;
import com.hpplay.sdk.source.browse.api.LelinkServiceManager;
import com.hpplay.sdk.source.browse.api.LelinkSetting;
import com.kingja.loadsir.core.LoadSir;
import com.orhanobut.logger.AndroidLogAdapter;
import com.orhanobut.logger.Logger;
import com.tdo.showbox.BuildConfig;
import com.tdo.showbox.app.Constant;
import com.tdo.showbox.cache.ACache;
import com.tdo.showbox.config.ConfigKey;
import com.tdo.showbox.config.ConfigUtils;
import com.tdo.showbox.config.OnlineConfigAgent;
import com.tdo.showbox.db.Migrations;
import com.tdo.showbox.db.ReaderDB;
import com.tdo.showbox.event.ConfigReceiveEvent;
import com.tdo.showbox.http.API;
import com.tdo.showbox.http.CallManager;
import com.tdo.showbox.http.CipherKeys;
import com.tdo.showbox.http.Http;
import com.tdo.showbox.model.user.OldUserModel;
import com.tdo.showbox.model.user.UserModel;
import com.tdo.showbox.utils.AdInitUtils;
import com.tdo.showbox.utils.CipherUtils;
import com.tdo.showbox.utils.FileUtil;
import com.tdo.showbox.utils.FileUtils;
import com.tdo.showbox.utils.FontsUtils;
import com.tdo.showbox.utils.GlideUtils;
import com.tdo.showbox.utils.MLog;
import com.tdo.showbox.utils.PrefsUtils;
import com.tdo.showbox.utils.SystemUtils;
import com.tdo.showbox.utils.TimeUtils;
import com.tdo.showbox.utils.ToastUtils;
import com.tdo.showbox.utils.Utils;
import com.tdo.showbox.view.activity.MainActivity;
import com.tdo.showbox.view.activity.SplashActivity;
import com.tdo.showbox.view.activity.user.Login2Activity;
import com.tdo.showbox.view.activity.videoplayer.VideoActivityFactory;
import com.tdo.showbox.view.widget.CustomLoadMoreView;
import com.tdo.showbox.view.widget.loadcallback.EmptyCallbackView;
import com.tdo.showbox.view.widget.loadcallback.ErrorCallbackView;
import com.tdo.showbox.view.widget.loadcallback.LoadingCallbackView;
import com.tencent.bugly.Bugly;
import com.tencent.bugly.beta.Beta;
import com.tencent.bugly.crashreport.CrashReport;
import com.umeng.analytics.MobclickAgent;
import com.umeng.commonsdk.UMConfigure;
import java.io.File;
import java.io.IOException;
import java.util.Locale;
import java.util.Observer;
import org.greenrobot.eventbus.EventBus;
/* loaded from: classes.dex */
public class App extends MultiDexApplication implements Application.ActivityLifecycleCallbacks, OnlineConfigAgent.OnlineConfigListener, ComponentCallbacks2 {
    public static int DEBUG_LEVEL = 0;
    private static final String TAG = "App";
    private static int activityCount = 0;
    public static String channel = null;
    private static ReaderDB db = null;
    public static String deviceLang = null;
    public static String deviceToken = "";
    private static boolean hasExitCall = false;
    private static App instance = null;
    public static boolean isDebug = false;
    private static boolean isLogin = false;
    private static ACache mCache = null;
    public static String netGroupId = "";
    private static AppObservable observable = null;
    public static String osType = "android";
    public static String packageName = null;
    private static UserModel user = null;
    public static int versionCode = 1;
    public static String versionName;

    private void configSpash() {
    }

    @Override // android.app.Application.ActivityLifecycleCallbacks
    public void onActivityCreated(Activity activity, Bundle bundle) {
    }

    @Override // android.app.Application.ActivityLifecycleCallbacks
    public void onActivityPaused(Activity activity) {
    }

    @Override // android.app.Application.ActivityLifecycleCallbacks
    public void onActivityResumed(Activity activity) {
    }

    @Override // android.app.Application.ActivityLifecycleCallbacks
    public void onActivitySaveInstanceState(Activity activity, Bundle bundle) {
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* loaded from: classes.dex */
    public static class MkDirTask extends AsyncTask<String, Integer, Boolean> {
        private MkDirTask() {
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // android.os.AsyncTask
        public Boolean doInBackground(String... strArr) {
            if (strArr != null && strArr.length > 0) {
                for (String str : strArr) {
                    try {
                        FileUtils.forceMkdir(new File(str));
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
            return true;
        }
    }

    @Override // android.app.Application
    public void onCreate() {
        super.onCreate();
        FontsUtils.setDefaultFont(this, "SANS", "font/roboto_regular.ttf");
        try {
            ProviderInstaller.installIfNeeded(this);
        } catch (GooglePlayServicesNotAvailableException e) {
            e.printStackTrace();
        } catch (GooglePlayServicesRepairableException e2) {
            e2.printStackTrace();
        }
        configLog();
        MLog.d(TAG, "onCreate");
        registerActivityLifecycleCallbacks(this);
        instance = this;
        mCache = ACache.get(this);
        osType = SystemUtils.getOSType();
        deviceToken = SystemUtils.getUniqueId(this);
        String processName = SystemUtils.getProcessName(this);
        packageName = getPackageName();
        MLog.d(TAG, "package:" + packageName + ",process:" + processName);
        if (packageName.equals(processName)) {
            getVersions();
            mkDirs();
            initPrefs();
            autoLogin();
            initDB();
            configUmeng();
            configJarvis();
            configTokne();
            initSwipeBack();
            initLoadSir();
            Utils.init((Application) this);
            initLogger();
            initLeBoYun();
            initBaseAdapter();
        }
    }

    private void initBaseAdapter() {
        LoadMoreModuleConfig.setDefLoadMoreView(new CustomLoadMoreView());
    }

    private void initAd() {
        new AdInitUtils().init(this);
    }

    private void initLeBoYun() {
        LelinkServiceManager.getInstance(this).setLelinkSetting(new LelinkSetting.LelinkSettingBuilder(Constant.LECAST_APPID, Constant.LECAST_APPSECRET).build());
    }

    private void initLogger() {
        Logger.addLogAdapter(new AndroidLogAdapter() { // from class: com.tdo.showbox.app.App.1
            @Override // com.orhanobut.logger.AndroidLogAdapter, com.orhanobut.logger.LogAdapter
            public boolean isLoggable(int i, String str) {
                return false;
            }
        });
    }

    private void initSwipeBack() {
        SmartSwipeBack.activitySlidingBack(this, $$Lambda$App$K5uDUy9OusO6E9w1mGmLNRkibg.INSTANCE);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static /* synthetic */ boolean lambda$initSwipeBack$0(Activity activity) {
        return !(activity instanceof MainActivity) && !(activity instanceof VideoActivityFactory) && !(activity instanceof SplashActivity) && !(activity instanceof Login2Activity) && !(activity instanceof AdActivity);
    }

    private void initLanguage() {
        Locale locale;
        if (Build.VERSION.SDK_INT >= 24) {
            locale = LocaleList.getDefault().get(0);
        } else {
            locale = Locale.getDefault();
        }
        if (locale != null) {
            String language = locale.getLanguage();
            String country = locale.getCountry();
            if ("zh".equalsIgnoreCase(language)) {
                if ("CN".equalsIgnoreCase(country)) {
                    deviceLang = "zh-CN";
                    return;
                } else {
                    deviceLang = "zh-TW";
                    return;
                }
            }
            deviceLang = language;
            return;
        }
        deviceLang = XML.DEFAULT_CONTENT_LANGUAGE;
    }

    private void initLoadSir() {
        LoadSir.beginBuilder().addCallback(new ErrorCallbackView()).addCallback(new EmptyCallbackView()).addCallback(new LoadingCallbackView()).setDefaultCallback(LoadingCallbackView.class).commit();
    }

    private void configLog() {
        MLog.config(isDebug);
    }

    private void getVersions() {
        channel = BuildConfig.CHANNEL;
        versionName = SystemUtils.getVersionName(this);
        versionCode = SystemUtils.getVersionCode(this);
    }

    private void mkDirs() {
        if (Environment.getExternalStorageState().equals("mounted")) {
            new MkDirTask().execute(Constant.DIRS);
        }
    }

    private void autoLogin() {
        MLog.d(TAG, "autoLogin");
        ACache old = ACache.getOld(this);
        OldUserModel oldUserModel = (OldUserModel) old.getAsObject("user");
        if (oldUserModel != null) {
            MLog.d(TAG, "autoLogin: old cache");
            login((UserModel) JSONObject.parseObject(JSONObject.toJSONString(oldUserModel)).toJavaObject((Class<Object>) UserModel.class));
            old.remove("user");
            ACache.clearOldCache(this);
            return;
        }
        ACache.clearOldCache(this);
        UserModel userModel = null;
        File userFile = getUserFile();
        if (userFile.exists() && userFile.isFile()) {
            userModel = (UserModel) JSONObject.toJavaObject(JSONObject.parseObject(CipherUtils.decrypt(FileUtil.getFileOutputString(userFile.getAbsolutePath()), CipherKeys.getDefaultKeys())), UserModel.class);
        }
        if (userModel != null && userModel.member != null) {
            login(userModel);
        } else {
            logout();
        }
    }

    private void initPrefs() {
        PrefsUtils.init(getContext(), Constant.Prefs.SETTING, 4);
        if (!PrefsUtils.getInstance().getBoolean("app_48", false)) {
            PrefsUtils.getInstance().putBoolean("app_48", true);
            PrefsUtils.getInstance().remove(Constant.Prefs.SHOW_READ_TIPS);
        }
        String string = PrefsUtils.getInstance().getString("language", "");
        if (!TextUtils.isEmpty(string)) {
            deviceLang = string;
        } else {
            initLanguage();
        }
    }

    private static void initDB() {
        db = (ReaderDB) Room.databaseBuilder(getContext(), ReaderDB.class, "movie_box.db").addMigrations(Migrations.migration1_2, Migrations.migration4_5, Migrations.migration5_6, Migrations.migration6_7, Migrations.migration7_8).fallbackToDestructiveMigration().allowMainThreadQueries().build();
    }

    private void configUmeng() {
        UMConfigure.init(this, BuildConfig.UM_APP_KEY, BuildConfig.CHANNEL, 1, null);
        MobclickAgent.setCatchUncaughtExceptions(false);
        MobclickAgent.setScenarioType(this, MobclickAgent.EScenarioType.E_UM_NORMAL);
        MobclickAgent.setCheckDevice(false);
    }

    private void configBugly() {
        MLog.d(TAG, "configBugly");
        MLog.d(TAG, "configBuglyde5d255deb");
        Beta.canShowUpgradeActs.add(MainActivity.class);
        Beta.autoInit = true;
        Beta.autoDownloadOnWifi = false;
        Beta.autoCheckUpgrade = true;
        Bugly.init(getApplicationContext(), "de5d255deb", false);
    }

    @Override // androidx.multidex.MultiDexApplication, android.content.ContextWrapper
    protected void attachBaseContext(Context context) {
        super.attachBaseContext(context);
        MultiDex.install(context);
    }

    private void configLeakCanary() {
        MLog.d(TAG, "configLeakCanary");
    }

    private void configJarvis() {
        MLog.d(TAG, "configJarvis");
        Jarvis.init(new DefaultDownloadHistoryDBHelper(this));
    }

    private void configTokne() {
        MLog.d(TAG, "configTokne" + (Settings.Secure.getString(getContentResolver(), "android_id") + Build.SERIAL));
    }

    public static App getInstance() {
        return instance;
    }

    public static Context getContext() {
        return instance.getApplicationContext();
    }

    public static ReaderDB getDB() {
        ReaderDB readerDB = db;
        if (readerDB == null || !readerDB.isOpen()) {
            initDB();
        }
        return db;
    }

    public static ACache getCache() {
        if (mCache == null) {
            mCache = ACache.get(getContext());
        }
        return mCache;
    }

    public static boolean isLogin() {
        UserModel userModel;
        return (!isLogin || (userModel = user) == null || userModel.member == null) ? false : true;
    }

    public static UserModel.UserData getUserData() {
        if (isLogin()) {
            return user.member;
        }
        return new UserModel.UserData();
    }

    public static UserModel.BBsInfo getBBsInfo() {
        if (isLogin()) {
            return user.member.getBbs_bind();
        }
        return null;
    }

    public static UserModel getUserModel() {
        if (isLogin()) {
            return user;
        }
        return new UserModel();
    }

    public static void login(UserModel userModel) {
        isLogin = true;
        user = userModel;
        saveUser();
        CrashReport.setUserId(user.member.nickname + "[" + versionCode + "]");
        if (observable == null) {
            observable = new AppObservable();
        }
    }

    private static void saveUser() {
        FileUtils.write(getUserFile(), CipherUtils.encrypt(JSONObject.toJSONString(user), CipherKeys.getDefaultKeys()), false);
    }

    private static File getUserFile() {
        return new File(getContext().getFilesDir(), "user.json");
    }

    public void addObserver(Observer observer) {
        MLog.d(TAG, "addObserver");
        AppObservable appObservable = observable;
        if (appObservable == null || observer == null) {
            return;
        }
        appObservable.addObserver(observer);
    }

    public void delObserver(Observer observer) {
        MLog.d(TAG, "delObserver");
        AppObservable appObservable = observable;
        if (appObservable == null || observer == null) {
            return;
        }
        appObservable.deleteObserver(observer);
    }

    public static void updateUser(UserModel.UserData userData) {
        MLog.d(TAG, "updateUser");
        if (isLogin()) {
            user.member = userData;
            saveUser();
            if (observable == null) {
                return;
            }
            MLog.d(TAG, "updateUser: notifyObservers");
            observable.notifyObservers();
            return;
        }
        logout();
    }

    public static void updateUser(UserModel.BBsInfo bBsInfo) {
        MLog.d(TAG, "updateUser");
        if (isLogin()) {
            user.member.setBbs_bind(bBsInfo);
            saveUser();
            if (observable == null) {
                return;
            }
            MLog.d(TAG, "updateUser: notifyObservers");
            observable.notifyObservers();
            return;
        }
        logout();
    }

    public static void updateUser(String str) {
        MLog.d(TAG, "updateUser");
        if (isLogin()) {
            user.member.avatar = str;
            saveUser();
            if (observable == null) {
                return;
            }
            MLog.d(TAG, "updateUser: notifyObservers");
            observable.notifyObservers();
            return;
        }
        logout();
    }

    public static void updateUser(String str, int i) {
        MLog.d(TAG, "updateUser");
        if (isLogin()) {
            user.member.email = str;
            saveUser();
            if (observable == null) {
                return;
            }
            MLog.d(TAG, "updateUser: notifyObservers");
            observable.notifyObservers();
            return;
        }
        logout();
    }

    public static void updateUsername(String str, int i) {
        MLog.d(TAG, "updateUser");
        if (isLogin()) {
            user.member.username = str;
            saveUser();
            if (observable == null) {
                return;
            }
            MLog.d(TAG, "updateUser: notifyObservers");
            observable.notifyObservers();
            return;
        }
        logout();
    }

    public static void logout() {
        CrashReport.setUserId("unknown[" + versionCode + "]");
        delUser();
        clearDatas();
        isLogin = false;
    }

    private static void delUser() {
        user = null;
        FileUtils.deleteFile(getUserFile());
    }

    private static void clearDatas() {
        AsyncTask.execute(new Runnable() { // from class: com.tdo.showbox.app.App.2
            @Override // java.lang.Runnable
            public void run() {
                try {
                    App.getDB().clearPlayRecord();
                } catch (Exception e) {
                    e.printStackTrace();
                    if (e instanceof SQLiteFullException) {
                        ToastUtils.showShort("disk is full");
                    }
                }
                PrefsUtils.getInstance().removeAll();
                GlideUtils.clearImageAllCache(App.getContext());
                for (String str : Constant.DIRS_CLEAR) {
                    FileUtils.deleteFile(new File(str));
                }
                for (String str2 : Constant.DIRS_CLEAR) {
                    try {
                        FileUtils.forceMkdir(new File(str2));
                    } catch (IOException e2) {
                        e2.printStackTrace();
                    }
                }
            }
        });
    }

    public static void clearCache() {
        AsyncTask.execute(new Runnable() { // from class: com.tdo.showbox.app.App.3
            @Override // java.lang.Runnable
            public void run() {
                PrefsUtils.getInstance().removeAll();
                GlideUtils.clearImageAllCache(App.getContext());
            }
        });
    }

    public static void clearMemory() {
        AsyncTask.execute(new Runnable() { // from class: com.tdo.showbox.app.App.4
            @Override // java.lang.Runnable
            public void run() {
                GlideUtils.clearImageAllCache(App.getContext());
            }
        });
    }

    public void updateOnline() {
        MLog.d(TAG, "updateOnline");
        OnlineConfigAgent.getInstance().setOnlineConfigListener(this);
        OnlineConfigAgent.getInstance().updateOnlineConfig();
    }

    @Override // com.tdo.showbox.config.OnlineConfigAgent.OnlineConfigListener
    public void onDataReceived(String str) {
        MLog.d(TAG, "onDataReceived: " + str);
        if (!TextUtils.isEmpty(str)) {
            readOnline();
        }
        EventBus.getDefault().post(new ConfigReceiveEvent());
    }

    public void readOnline() {
        MLog.d(TAG, "readOnline");
        String readStringConfig = ConfigUtils.readStringConfig(ConfigKey.URL_VALUE);
        if (!TextUtils.isEmpty(readStringConfig)) {
            String[] split = readStringConfig.split("\\|");
            if (split.length == 1) {
                if (!API.MOVIE_HOST.equals(split[0])) {
                    MLog.d(TAG, "readOnline: base url changed");
                    API.MOVIE_HOST = split[0];
                    API.REAL_MOVIE_HOST = "";
                    API.BASE_URL = API.MOVIE_HOST + API.STONE_MOVIE_SUFFIX;
                    API.TRANSLATE_URL = API.MOVIE_HOST + "/api/srttrans/index/";
                    Http.baseUrlChanged();
                }
            } else if (split.length == 2) {
                String str = split[0];
                String str2 = split[1];
                if (!API.MOVIE_HOST.equals(str) || !API.REAL_MOVIE_HOST.equals(str2)) {
                    API.MOVIE_HOST = str;
                    API.REAL_MOVIE_HOST = str2;
                    API.BASE_URL = API.MOVIE_HOST + API.STONE_MOVIE_SUFFIX;
                    API.TRANSLATE_URL = API.MOVIE_HOST + "/api/srttrans/index/";
                    Http.baseUrlChanged();
                }
            }
        }
        String readStringConfig2 = ConfigUtils.readStringConfig(ConfigKey.BBS_URL);
        if (!TextUtils.isEmpty(readStringConfig2)) {
            API.BBS_URL = readStringConfig2;
        }
    }

    public static void exit() {
        MLog.d(TAG, "exit");
        hasExitCall = true;
        AppManager.finishAll();
        CallManager.cancelAll();
        RxManager.removeAll();
    }

    @Override // android.app.Application, android.content.ComponentCallbacks
    public void onLowMemory() {
        super.onLowMemory();
        Glide.get(this).clearMemory();
        MLog.d(TAG, "onLowMemory");
    }

    @Override // android.app.Application
    public void onTerminate() {
        super.onTerminate();
        MLog.d(TAG, "onTerminate");
        ReaderDB readerDB = db;
        if (readerDB != null) {
            readerDB.close();
            db = null;
        }
    }

    @Override // android.app.Application.ActivityLifecycleCallbacks
    public void onActivityStarted(Activity activity) {
        activityCount++;
        MLog.d(TAG, "onActivityStarted: " + activityCount + ", " + activity.getClass().getSimpleName());
        if (activityCount <= 1) {
            MLog.d(TAG, "onActivityStarted: app enter from background: " + TimeUtils.getFormatedTime(TimeUtils.DETAULT_PATTERN));
            MobclickAgent.onEvent(this, "app_enter_from_back", activity.getClass().getSimpleName());
            return;
        }
        MLog.d(TAG, "onActivityStarted: app jump internal");
        PrefsUtils.getInstance().putLong(Constant.Prefs.ENTER_BACK_TIME, TimeUtils.getCurrentTime());
    }

    @Override // android.app.Application.ActivityLifecycleCallbacks
    public void onActivityStopped(Activity activity) {
        activityCount--;
        MLog.d(TAG, "onActivityStopped: " + activityCount + ", " + activity.getClass().getSimpleName());
        if (activityCount == 0) {
            if (hasExitCall) {
                MLog.d(TAG, "onActivityStopped: app going to finish");
                PrefsUtils.getInstance().putLong(Constant.Prefs.ENTER_BACK_TIME, 0L);
                return;
            }
            PrefsUtils.getInstance().putLong(Constant.Prefs.ENTER_BACK_TIME, TimeUtils.getCurrentTime());
            MLog.d(TAG, "onActivityStopped: app enter background: " + TimeUtils.getFormatedTime(TimeUtils.DETAULT_PATTERN));
            MobclickAgent.onEvent(this, "app_enter_back", activity.getClass().getSimpleName());
        }
    }

    @Override // android.app.Application.ActivityLifecycleCallbacks
    public void onActivityDestroyed(Activity activity) {
        if (activityCount == 0) {
            MLog.d(TAG, "onActivityDestroyed: app has finished");
            MobclickAgent.onEvent(this, "app_finish");
        }
        hasExitCall = false;
    }

    @Override // android.app.Application, android.content.ComponentCallbacks2
    public void onTrimMemory(int i) {
        super.onTrimMemory(i);
        if (i == 20) {
            Glide.get(getContext()).clearMemory();
        }
        Glide.get(getContext()).trimMemory(i);
    }
}
