package com.tdo.showbox.app;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import com.bumptech.glide.Glide;
import com.bumptech.glide.Priority;
import com.bumptech.glide.RequestBuilder;
import com.bumptech.glide.RequestManager;
import com.bumptech.glide.TransitionOptions;
import com.bumptech.glide.load.DecodeFormat;
import com.bumptech.glide.load.Key;
import com.bumptech.glide.load.Option;
import com.bumptech.glide.load.Transformation;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.load.resource.bitmap.DownsampleStrategy;
import com.bumptech.glide.request.BaseRequestOptions;
import com.bumptech.glide.request.RequestListener;
import java.io.File;
import java.net.URL;
/* loaded from: classes3.dex */
public class GlideRequest<TranscodeType> extends RequestBuilder<TranscodeType> implements Cloneable {
    @Override // com.bumptech.glide.RequestBuilder, com.bumptech.glide.request.BaseRequestOptions
    /* renamed from: apply */
    public /* bridge */ /* synthetic */ RequestBuilder mo507apply(BaseRequestOptions baseRequestOptions) {
        return mo507apply((BaseRequestOptions<?>) baseRequestOptions);
    }

    @Override // com.bumptech.glide.RequestBuilder, com.bumptech.glide.request.BaseRequestOptions
    /* renamed from: apply  reason: collision with other method in class */
    public /* bridge */ /* synthetic */ BaseRequestOptions mo507apply(BaseRequestOptions baseRequestOptions) {
        return mo507apply((BaseRequestOptions<?>) baseRequestOptions);
    }

    @Override // com.bumptech.glide.request.BaseRequestOptions
    /* renamed from: decode */
    public /* bridge */ /* synthetic */ BaseRequestOptions mo513decode(Class cls) {
        return mo513decode((Class<?>) cls);
    }

    @Override // com.bumptech.glide.request.BaseRequestOptions
    /* renamed from: optionalTransform */
    public /* bridge */ /* synthetic */ BaseRequestOptions mo545optionalTransform(Transformation transformation) {
        return mo545optionalTransform((Transformation<Bitmap>) transformation);
    }

    @Override // com.bumptech.glide.request.BaseRequestOptions
    /* renamed from: set */
    public /* bridge */ /* synthetic */ BaseRequestOptions mo552set(Option option, Object obj) {
        return mo552set((Option<Option>) option, (Option) obj);
    }

    @Override // com.bumptech.glide.request.BaseRequestOptions
    /* renamed from: transform */
    public /* bridge */ /* synthetic */ BaseRequestOptions mo561transform(Transformation transformation) {
        return mo561transform((Transformation<Bitmap>) transformation);
    }

    @Override // com.bumptech.glide.request.BaseRequestOptions
    /* renamed from: transform */
    public /* bridge */ /* synthetic */ BaseRequestOptions mo563transform(Transformation[] transformationArr) {
        return mo563transform((Transformation<Bitmap>[]) transformationArr);
    }

    @Override // com.bumptech.glide.request.BaseRequestOptions
    @Deprecated
    /* renamed from: transforms */
    public /* bridge */ /* synthetic */ BaseRequestOptions mo564transforms(Transformation[] transformationArr) {
        return mo564transforms((Transformation<Bitmap>[]) transformationArr);
    }

    GlideRequest(Class<TranscodeType> cls, RequestBuilder<?> requestBuilder) {
        super(cls, requestBuilder);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public GlideRequest(Glide glide, RequestManager requestManager, Class<TranscodeType> cls, Context context) {
        super(glide, requestManager, cls, context);
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // com.bumptech.glide.RequestBuilder
    /* renamed from: getDownloadOnlyRequest  reason: collision with other method in class */
    public GlideRequest<File> mo529getDownloadOnlyRequest() {
        return new GlideRequest(File.class, this).mo507apply((BaseRequestOptions<?>) DOWNLOAD_ONLY_OPTIONS);
    }

    @Override // com.bumptech.glide.request.BaseRequestOptions
    /* renamed from: sizeMultiplier  reason: collision with other method in class */
    public GlideRequest<TranscodeType> mo554sizeMultiplier(float f) {
        return (GlideRequest) super.sizeMultiplier(f);
    }

    @Override // com.bumptech.glide.request.BaseRequestOptions
    /* renamed from: useUnlimitedSourceGeneratorsPool  reason: collision with other method in class */
    public GlideRequest<TranscodeType> mo567useUnlimitedSourceGeneratorsPool(boolean z) {
        return (GlideRequest) super.useUnlimitedSourceGeneratorsPool(z);
    }

    @Override // com.bumptech.glide.request.BaseRequestOptions
    /* renamed from: useAnimationPool  reason: collision with other method in class */
    public GlideRequest<TranscodeType> mo566useAnimationPool(boolean z) {
        return (GlideRequest) super.useAnimationPool(z);
    }

    @Override // com.bumptech.glide.request.BaseRequestOptions
    /* renamed from: onlyRetrieveFromCache  reason: collision with other method in class */
    public GlideRequest<TranscodeType> mo540onlyRetrieveFromCache(boolean z) {
        return (GlideRequest) super.onlyRetrieveFromCache(z);
    }

    @Override // com.bumptech.glide.request.BaseRequestOptions
    /* renamed from: diskCacheStrategy  reason: collision with other method in class */
    public GlideRequest<TranscodeType> mo515diskCacheStrategy(DiskCacheStrategy diskCacheStrategy) {
        return (GlideRequest) super.diskCacheStrategy(diskCacheStrategy);
    }

    @Override // com.bumptech.glide.request.BaseRequestOptions
    /* renamed from: priority  reason: collision with other method in class */
    public GlideRequest<TranscodeType> mo551priority(Priority priority) {
        return (GlideRequest) super.priority(priority);
    }

    @Override // com.bumptech.glide.request.BaseRequestOptions
    /* renamed from: placeholder  reason: collision with other method in class */
    public GlideRequest<TranscodeType> mo550placeholder(Drawable drawable) {
        return (GlideRequest) super.placeholder(drawable);
    }

    @Override // com.bumptech.glide.request.BaseRequestOptions
    /* renamed from: placeholder  reason: collision with other method in class */
    public GlideRequest<TranscodeType> mo549placeholder(int i) {
        return (GlideRequest) super.placeholder(i);
    }

    @Override // com.bumptech.glide.request.BaseRequestOptions
    /* renamed from: fallback  reason: collision with other method in class */
    public GlideRequest<TranscodeType> mo525fallback(Drawable drawable) {
        return (GlideRequest) super.fallback(drawable);
    }

    @Override // com.bumptech.glide.request.BaseRequestOptions
    /* renamed from: fallback  reason: collision with other method in class */
    public GlideRequest<TranscodeType> mo524fallback(int i) {
        return (GlideRequest) super.fallback(i);
    }

    @Override // com.bumptech.glide.request.BaseRequestOptions
    /* renamed from: error  reason: collision with other method in class */
    public GlideRequest<TranscodeType> mo522error(Drawable drawable) {
        return (GlideRequest) super.error(drawable);
    }

    @Override // com.bumptech.glide.request.BaseRequestOptions
    /* renamed from: error  reason: collision with other method in class */
    public GlideRequest<TranscodeType> mo521error(int i) {
        return (GlideRequest) super.error(i);
    }

    @Override // com.bumptech.glide.request.BaseRequestOptions
    /* renamed from: theme  reason: collision with other method in class */
    public GlideRequest<TranscodeType> mo556theme(Resources.Theme theme) {
        return (GlideRequest) super.theme(theme);
    }

    @Override // com.bumptech.glide.request.BaseRequestOptions
    /* renamed from: skipMemoryCache  reason: collision with other method in class */
    public GlideRequest<TranscodeType> mo555skipMemoryCache(boolean z) {
        return (GlideRequest) super.skipMemoryCache(z);
    }

    @Override // com.bumptech.glide.request.BaseRequestOptions
    /* renamed from: override  reason: collision with other method in class */
    public GlideRequest<TranscodeType> mo548override(int i, int i2) {
        return (GlideRequest) super.override(i, i2);
    }

    @Override // com.bumptech.glide.request.BaseRequestOptions
    /* renamed from: override  reason: collision with other method in class */
    public GlideRequest<TranscodeType> mo547override(int i) {
        return (GlideRequest) super.override(i);
    }

    @Override // com.bumptech.glide.request.BaseRequestOptions
    /* renamed from: signature  reason: collision with other method in class */
    public GlideRequest<TranscodeType> mo553signature(Key key) {
        return (GlideRequest) super.signature(key);
    }

    @Override // com.bumptech.glide.request.BaseRequestOptions
    /* renamed from: set  reason: collision with other method in class */
    public <Y> GlideRequest<TranscodeType> mo552set(Option<Y> option, Y y) {
        return (GlideRequest) super.set((Option<Option<Y>>) option, (Option<Y>) y);
    }

    @Override // com.bumptech.glide.request.BaseRequestOptions
    /* renamed from: decode  reason: collision with other method in class */
    public GlideRequest<TranscodeType> mo513decode(Class<?> cls) {
        return (GlideRequest) super.decode(cls);
    }

    @Override // com.bumptech.glide.request.BaseRequestOptions
    /* renamed from: encodeFormat  reason: collision with other method in class */
    public GlideRequest<TranscodeType> mo519encodeFormat(Bitmap.CompressFormat compressFormat) {
        return (GlideRequest) super.encodeFormat(compressFormat);
    }

    @Override // com.bumptech.glide.request.BaseRequestOptions
    /* renamed from: encodeQuality  reason: collision with other method in class */
    public GlideRequest<TranscodeType> mo520encodeQuality(int i) {
        return (GlideRequest) super.encodeQuality(i);
    }

    @Override // com.bumptech.glide.request.BaseRequestOptions
    /* renamed from: frame  reason: collision with other method in class */
    public GlideRequest<TranscodeType> mo528frame(long j) {
        return (GlideRequest) super.frame(j);
    }

    @Override // com.bumptech.glide.request.BaseRequestOptions
    /* renamed from: format  reason: collision with other method in class */
    public GlideRequest<TranscodeType> mo527format(DecodeFormat decodeFormat) {
        return (GlideRequest) super.format(decodeFormat);
    }

    @Override // com.bumptech.glide.request.BaseRequestOptions
    /* renamed from: disallowHardwareConfig  reason: collision with other method in class */
    public GlideRequest<TranscodeType> mo514disallowHardwareConfig() {
        return (GlideRequest) super.disallowHardwareConfig();
    }

    @Override // com.bumptech.glide.request.BaseRequestOptions
    /* renamed from: downsample  reason: collision with other method in class */
    public GlideRequest<TranscodeType> mo518downsample(DownsampleStrategy downsampleStrategy) {
        return (GlideRequest) super.downsample(downsampleStrategy);
    }

    @Override // com.bumptech.glide.request.BaseRequestOptions
    /* renamed from: timeout  reason: collision with other method in class */
    public GlideRequest<TranscodeType> mo560timeout(int i) {
        return (GlideRequest) super.timeout(i);
    }

    @Override // com.bumptech.glide.request.BaseRequestOptions
    /* renamed from: optionalCenterCrop  reason: collision with other method in class */
    public GlideRequest<TranscodeType> mo541optionalCenterCrop() {
        return (GlideRequest) super.optionalCenterCrop();
    }

    @Override // com.bumptech.glide.request.BaseRequestOptions
    /* renamed from: centerCrop  reason: collision with other method in class */
    public GlideRequest<TranscodeType> mo508centerCrop() {
        return (GlideRequest) super.centerCrop();
    }

    @Override // com.bumptech.glide.request.BaseRequestOptions
    /* renamed from: optionalFitCenter  reason: collision with other method in class */
    public GlideRequest<TranscodeType> mo544optionalFitCenter() {
        return (GlideRequest) super.optionalFitCenter();
    }

    @Override // com.bumptech.glide.request.BaseRequestOptions
    /* renamed from: fitCenter  reason: collision with other method in class */
    public GlideRequest<TranscodeType> mo526fitCenter() {
        return (GlideRequest) super.fitCenter();
    }

    @Override // com.bumptech.glide.request.BaseRequestOptions
    /* renamed from: optionalCenterInside  reason: collision with other method in class */
    public GlideRequest<TranscodeType> mo542optionalCenterInside() {
        return (GlideRequest) super.optionalCenterInside();
    }

    @Override // com.bumptech.glide.request.BaseRequestOptions
    /* renamed from: centerInside  reason: collision with other method in class */
    public GlideRequest<TranscodeType> mo509centerInside() {
        return (GlideRequest) super.centerInside();
    }

    @Override // com.bumptech.glide.request.BaseRequestOptions
    /* renamed from: optionalCircleCrop  reason: collision with other method in class */
    public GlideRequest<TranscodeType> mo543optionalCircleCrop() {
        return (GlideRequest) super.optionalCircleCrop();
    }

    @Override // com.bumptech.glide.request.BaseRequestOptions
    /* renamed from: circleCrop  reason: collision with other method in class */
    public GlideRequest<TranscodeType> mo510circleCrop() {
        return (GlideRequest) super.circleCrop();
    }

    @Override // com.bumptech.glide.request.BaseRequestOptions
    /* renamed from: transform  reason: collision with other method in class */
    public GlideRequest<TranscodeType> mo561transform(Transformation<Bitmap> transformation) {
        return (GlideRequest) super.transform(transformation);
    }

    @Override // com.bumptech.glide.request.BaseRequestOptions
    /* renamed from: transform  reason: collision with other method in class */
    public GlideRequest<TranscodeType> mo563transform(Transformation<Bitmap>... transformationArr) {
        return (GlideRequest) super.transform(transformationArr);
    }

    @Override // com.bumptech.glide.request.BaseRequestOptions
    @Deprecated
    /* renamed from: transforms  reason: collision with other method in class */
    public GlideRequest<TranscodeType> mo564transforms(Transformation<Bitmap>... transformationArr) {
        return (GlideRequest) super.transforms(transformationArr);
    }

    @Override // com.bumptech.glide.request.BaseRequestOptions
    /* renamed from: optionalTransform  reason: collision with other method in class */
    public GlideRequest<TranscodeType> mo545optionalTransform(Transformation<Bitmap> transformation) {
        return (GlideRequest) super.optionalTransform(transformation);
    }

    @Override // com.bumptech.glide.request.BaseRequestOptions
    /* renamed from: optionalTransform  reason: collision with other method in class */
    public <Y> GlideRequest<TranscodeType> mo546optionalTransform(Class<Y> cls, Transformation<Y> transformation) {
        return (GlideRequest) super.optionalTransform((Class) cls, (Transformation) transformation);
    }

    @Override // com.bumptech.glide.request.BaseRequestOptions
    /* renamed from: transform  reason: collision with other method in class */
    public <Y> GlideRequest<TranscodeType> mo562transform(Class<Y> cls, Transformation<Y> transformation) {
        return (GlideRequest) super.transform((Class) cls, (Transformation) transformation);
    }

    @Override // com.bumptech.glide.request.BaseRequestOptions
    /* renamed from: dontTransform  reason: collision with other method in class */
    public GlideRequest<TranscodeType> mo517dontTransform() {
        return (GlideRequest) super.dontTransform();
    }

    @Override // com.bumptech.glide.request.BaseRequestOptions
    /* renamed from: dontAnimate  reason: collision with other method in class */
    public GlideRequest<TranscodeType> mo516dontAnimate() {
        return (GlideRequest) super.dontAnimate();
    }

    @Override // com.bumptech.glide.RequestBuilder, com.bumptech.glide.request.BaseRequestOptions
    /* renamed from: apply */
    public GlideRequest<TranscodeType> mo507apply(BaseRequestOptions<?> baseRequestOptions) {
        return (GlideRequest) super.mo507apply(baseRequestOptions);
    }

    @Override // com.bumptech.glide.RequestBuilder
    /* renamed from: transition  reason: collision with other method in class */
    public GlideRequest<TranscodeType> mo565transition(TransitionOptions<?, ? super TranscodeType> transitionOptions) {
        return (GlideRequest) super.mo565transition((TransitionOptions) transitionOptions);
    }

    @Override // com.bumptech.glide.RequestBuilder
    /* renamed from: listener  reason: collision with other method in class */
    public GlideRequest<TranscodeType> mo530listener(RequestListener<TranscodeType> requestListener) {
        return (GlideRequest) super.mo530listener((RequestListener) requestListener);
    }

    @Override // com.bumptech.glide.RequestBuilder
    /* renamed from: addListener  reason: collision with other method in class */
    public GlideRequest<TranscodeType> mo506addListener(RequestListener<TranscodeType> requestListener) {
        return (GlideRequest) super.mo506addListener((RequestListener) requestListener);
    }

    @Override // com.bumptech.glide.RequestBuilder
    /* renamed from: error  reason: collision with other method in class */
    public GlideRequest<TranscodeType> mo523error(RequestBuilder<TranscodeType> requestBuilder) {
        return (GlideRequest) super.mo523error((RequestBuilder) requestBuilder);
    }

    @Override // com.bumptech.glide.RequestBuilder
    /* renamed from: thumbnail  reason: collision with other method in class */
    public GlideRequest<TranscodeType> mo558thumbnail(RequestBuilder<TranscodeType> requestBuilder) {
        return (GlideRequest) super.mo558thumbnail((RequestBuilder) requestBuilder);
    }

    @Override // com.bumptech.glide.RequestBuilder
    @SafeVarargs
    /* renamed from: thumbnail  reason: collision with other method in class */
    public final GlideRequest<TranscodeType> mo559thumbnail(RequestBuilder<TranscodeType>... requestBuilderArr) {
        return (GlideRequest) super.mo559thumbnail((RequestBuilder[]) requestBuilderArr);
    }

    @Override // com.bumptech.glide.RequestBuilder
    /* renamed from: thumbnail  reason: collision with other method in class */
    public GlideRequest<TranscodeType> mo557thumbnail(float f) {
        return (GlideRequest) super.mo557thumbnail(f);
    }

    @Override // com.bumptech.glide.RequestBuilder, com.bumptech.glide.ModelTypes
    /* renamed from: load  reason: collision with other method in class */
    public GlideRequest<TranscodeType> mo582load(Object obj) {
        return (GlideRequest) super.mo582load(obj);
    }

    @Override // com.bumptech.glide.RequestBuilder, com.bumptech.glide.ModelTypes
    /* renamed from: load  reason: collision with other method in class */
    public GlideRequest<TranscodeType> mo577load(Bitmap bitmap) {
        return (GlideRequest) super.mo577load(bitmap);
    }

    @Override // com.bumptech.glide.RequestBuilder, com.bumptech.glide.ModelTypes
    /* renamed from: load  reason: collision with other method in class */
    public GlideRequest<TranscodeType> mo578load(Drawable drawable) {
        return (GlideRequest) super.mo578load(drawable);
    }

    @Override // com.bumptech.glide.RequestBuilder, com.bumptech.glide.ModelTypes
    /* renamed from: load  reason: collision with other method in class */
    public GlideRequest<TranscodeType> mo583load(String str) {
        return (GlideRequest) super.mo583load(str);
    }

    @Override // com.bumptech.glide.RequestBuilder, com.bumptech.glide.ModelTypes
    /* renamed from: load  reason: collision with other method in class */
    public GlideRequest<TranscodeType> mo579load(Uri uri) {
        return (GlideRequest) super.mo579load(uri);
    }

    @Override // com.bumptech.glide.RequestBuilder, com.bumptech.glide.ModelTypes
    /* renamed from: load  reason: collision with other method in class */
    public GlideRequest<TranscodeType> mo580load(File file) {
        return (GlideRequest) super.mo580load(file);
    }

    @Override // com.bumptech.glide.RequestBuilder, com.bumptech.glide.ModelTypes
    /* renamed from: load  reason: collision with other method in class */
    public GlideRequest<TranscodeType> mo581load(Integer num) {
        return (GlideRequest) super.mo581load(num);
    }

    @Override // com.bumptech.glide.RequestBuilder, com.bumptech.glide.ModelTypes
    @Deprecated
    /* renamed from: load  reason: collision with other method in class */
    public GlideRequest<TranscodeType> mo584load(URL url) {
        return (GlideRequest) super.mo584load(url);
    }

    @Override // com.bumptech.glide.RequestBuilder, com.bumptech.glide.ModelTypes
    /* renamed from: load  reason: collision with other method in class */
    public GlideRequest<TranscodeType> mo585load(byte[] bArr) {
        return (GlideRequest) super.mo585load(bArr);
    }

    @Override // com.bumptech.glide.RequestBuilder, com.bumptech.glide.request.BaseRequestOptions
    /* renamed from: clone */
    public GlideRequest<TranscodeType> mo512clone() {
        return (GlideRequest) super.mo512clone();
    }
}
