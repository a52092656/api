package com.tdo.showbox.app;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import com.bumptech.glide.Glide;
import com.bumptech.glide.RequestBuilder;
import com.bumptech.glide.RequestManager;
import com.bumptech.glide.load.resource.gif.GifDrawable;
import com.bumptech.glide.manager.Lifecycle;
import com.bumptech.glide.manager.RequestManagerTreeNode;
import com.bumptech.glide.request.BaseRequestOptions;
import com.bumptech.glide.request.RequestListener;
import com.bumptech.glide.request.RequestOptions;
import java.io.File;
import java.net.URL;
/* loaded from: classes3.dex */
public class GlideRequests extends RequestManager {
    @Override // com.bumptech.glide.RequestManager
    /* renamed from: addDefaultRequestListener */
    public /* bridge */ /* synthetic */ RequestManager mo568addDefaultRequestListener(RequestListener requestListener) {
        return mo568addDefaultRequestListener((RequestListener<Object>) requestListener);
    }

    public GlideRequests(Glide glide, Lifecycle lifecycle, RequestManagerTreeNode requestManagerTreeNode, Context context) {
        super(glide, lifecycle, requestManagerTreeNode, context);
    }

    @Override // com.bumptech.glide.RequestManager
    /* renamed from: as  reason: collision with other method in class */
    public <ResourceType> GlideRequest<ResourceType> mo570as(Class<ResourceType> cls) {
        return new GlideRequest<>(this.glide, this, cls, this.context);
    }

    @Override // com.bumptech.glide.RequestManager
    /* renamed from: applyDefaultRequestOptions  reason: collision with other method in class */
    public synchronized GlideRequests mo569applyDefaultRequestOptions(RequestOptions requestOptions) {
        return (GlideRequests) super.mo569applyDefaultRequestOptions(requestOptions);
    }

    @Override // com.bumptech.glide.RequestManager
    /* renamed from: setDefaultRequestOptions  reason: collision with other method in class */
    public synchronized GlideRequests mo586setDefaultRequestOptions(RequestOptions requestOptions) {
        return (GlideRequests) super.mo586setDefaultRequestOptions(requestOptions);
    }

    @Override // com.bumptech.glide.RequestManager
    /* renamed from: addDefaultRequestListener  reason: collision with other method in class */
    public GlideRequests mo568addDefaultRequestListener(RequestListener<Object> requestListener) {
        return (GlideRequests) super.mo568addDefaultRequestListener(requestListener);
    }

    @Override // com.bumptech.glide.RequestManager
    /* renamed from: asBitmap  reason: collision with other method in class */
    public GlideRequest<Bitmap> mo571asBitmap() {
        return (GlideRequest) super.mo571asBitmap();
    }

    @Override // com.bumptech.glide.RequestManager
    /* renamed from: asGif  reason: collision with other method in class */
    public GlideRequest<GifDrawable> mo574asGif() {
        return (GlideRequest) super.mo574asGif();
    }

    @Override // com.bumptech.glide.RequestManager
    /* renamed from: asDrawable  reason: collision with other method in class */
    public GlideRequest<Drawable> mo572asDrawable() {
        return (GlideRequest) super.mo572asDrawable();
    }

    @Override // com.bumptech.glide.RequestManager, com.bumptech.glide.ModelTypes
    /* renamed from: load  reason: collision with other method in class */
    public RequestBuilder<Drawable> mo577load(Bitmap bitmap) {
        return (GlideRequest) super.mo577load(bitmap);
    }

    @Override // com.bumptech.glide.RequestManager, com.bumptech.glide.ModelTypes
    /* renamed from: load  reason: collision with other method in class */
    public RequestBuilder<Drawable> mo578load(Drawable drawable) {
        return (GlideRequest) super.mo578load(drawable);
    }

    @Override // com.bumptech.glide.RequestManager, com.bumptech.glide.ModelTypes
    /* renamed from: load  reason: collision with other method in class */
    public RequestBuilder<Drawable> mo583load(String str) {
        return (GlideRequest) super.mo583load(str);
    }

    @Override // com.bumptech.glide.RequestManager, com.bumptech.glide.ModelTypes
    /* renamed from: load  reason: collision with other method in class */
    public RequestBuilder<Drawable> mo579load(Uri uri) {
        return (GlideRequest) super.mo579load(uri);
    }

    @Override // com.bumptech.glide.RequestManager, com.bumptech.glide.ModelTypes
    /* renamed from: load  reason: collision with other method in class */
    public RequestBuilder<Drawable> mo580load(File file) {
        return (GlideRequest) super.mo580load(file);
    }

    @Override // com.bumptech.glide.RequestManager, com.bumptech.glide.ModelTypes
    /* renamed from: load  reason: collision with other method in class */
    public RequestBuilder<Drawable> mo581load(Integer num) {
        return (GlideRequest) super.mo581load(num);
    }

    @Override // com.bumptech.glide.RequestManager, com.bumptech.glide.ModelTypes
    @Deprecated
    /* renamed from: load  reason: collision with other method in class */
    public RequestBuilder<Drawable> mo584load(URL url) {
        return (GlideRequest) super.mo584load(url);
    }

    @Override // com.bumptech.glide.RequestManager, com.bumptech.glide.ModelTypes
    /* renamed from: load  reason: collision with other method in class */
    public RequestBuilder<Drawable> mo585load(byte[] bArr) {
        return (GlideRequest) super.mo585load(bArr);
    }

    @Override // com.bumptech.glide.RequestManager, com.bumptech.glide.ModelTypes
    /* renamed from: load  reason: collision with other method in class */
    public RequestBuilder<Drawable> mo582load(Object obj) {
        return (GlideRequest) super.mo582load(obj);
    }

    @Override // com.bumptech.glide.RequestManager
    /* renamed from: downloadOnly  reason: collision with other method in class */
    public GlideRequest<File> mo576downloadOnly() {
        return (GlideRequest) super.mo576downloadOnly();
    }

    @Override // com.bumptech.glide.RequestManager
    /* renamed from: download  reason: collision with other method in class */
    public GlideRequest<File> mo575download(Object obj) {
        return (GlideRequest) super.mo575download(obj);
    }

    @Override // com.bumptech.glide.RequestManager
    /* renamed from: asFile  reason: collision with other method in class */
    public GlideRequest<File> mo573asFile() {
        return (GlideRequest) super.mo573asFile();
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // com.bumptech.glide.RequestManager
    public void setRequestOptions(RequestOptions requestOptions) {
        if (requestOptions instanceof GlideOptions) {
            super.setRequestOptions(requestOptions);
        } else {
            super.setRequestOptions(new GlideOptions().mo507apply((BaseRequestOptions<?>) requestOptions));
        }
    }
}
