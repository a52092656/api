package com.tdo.showbox.timroes.axmlrpc;
/* loaded from: classes3.dex */
public class XMLRPCTimeoutException extends XMLRPCException {
    /* JADX INFO: Access modifiers changed from: package-private */
    public XMLRPCTimeoutException(String str) {
        super(str);
    }
}
