package com.tdo.showbox.timroes.axmlrpc.serializer;

import com.tdo.showbox.timroes.axmlrpc.XMLRPCException;
import com.tdo.showbox.timroes.axmlrpc.XMLUtil;
import com.tdo.showbox.timroes.axmlrpc.xmlcreator.XmlElement;
import java.math.BigDecimal;
import org.w3c.dom.Element;
/* loaded from: classes3.dex */
public class DoubleSerializer implements Serializer {
    @Override // com.tdo.showbox.timroes.axmlrpc.serializer.Serializer
    public Object deserialize(Element element) throws XMLRPCException {
        return Double.valueOf(XMLUtil.getOnlyTextContent(element.getChildNodes()));
    }

    @Override // com.tdo.showbox.timroes.axmlrpc.serializer.Serializer
    public String deserialize2(Element element) throws XMLRPCException {
        return Double.valueOf(XMLUtil.getOnlyTextContent(element.getChildNodes())) + "";
    }

    @Override // com.tdo.showbox.timroes.axmlrpc.serializer.Serializer
    public XmlElement serialize(Object obj) {
        return XMLUtil.makeXmlTag(SerializerHandler.TYPE_DOUBLE, BigDecimal.valueOf(((Number) obj).doubleValue()).toPlainString());
    }
}
