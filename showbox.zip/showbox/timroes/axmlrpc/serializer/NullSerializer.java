package com.tdo.showbox.timroes.axmlrpc.serializer;

import com.tdo.showbox.timroes.axmlrpc.XMLRPCException;
import com.tdo.showbox.timroes.axmlrpc.xmlcreator.XmlElement;
import org.w3c.dom.Element;
/* loaded from: classes3.dex */
public class NullSerializer implements Serializer {
    @Override // com.tdo.showbox.timroes.axmlrpc.serializer.Serializer
    public Object deserialize(Element element) throws XMLRPCException {
        return null;
    }

    @Override // com.tdo.showbox.timroes.axmlrpc.serializer.Serializer
    public String deserialize2(Element element) throws XMLRPCException {
        return null;
    }

    @Override // com.tdo.showbox.timroes.axmlrpc.serializer.Serializer
    public XmlElement serialize(Object obj) {
        return new XmlElement(SerializerHandler.TYPE_NULL);
    }
}
