package com.tdo.showbox.timroes.axmlrpc.serializer;

import com.tdo.showbox.timroes.axmlrpc.XMLRPCException;
import com.tdo.showbox.timroes.axmlrpc.XMLUtil;
import com.tdo.showbox.timroes.axmlrpc.xmlcreator.XmlElement;
import org.seamless.xml.DOM;
import org.w3c.dom.Element;
/* loaded from: classes3.dex */
public class StringSerializer implements Serializer {
    private boolean decodeStrings;
    private boolean encodeStrings;

    public StringSerializer(boolean z, boolean z2) {
        this.decodeStrings = z2;
        this.encodeStrings = z;
    }

    @Override // com.tdo.showbox.timroes.axmlrpc.serializer.Serializer
    public Object deserialize(Element element) throws XMLRPCException {
        String onlyTextContent = XMLUtil.getOnlyTextContent(element.getChildNodes());
        return this.decodeStrings ? onlyTextContent.replaceAll("&lt;", "<").replaceAll("&amp;", "&") : onlyTextContent;
    }

    @Override // com.tdo.showbox.timroes.axmlrpc.serializer.Serializer
    public String deserialize2(Element element) throws XMLRPCException {
        String onlyTextContent = XMLUtil.getOnlyTextContent(element.getChildNodes());
        return this.decodeStrings ? onlyTextContent.replaceAll("&lt;", "<").replaceAll("&amp;", "&") : onlyTextContent;
    }

    @Override // com.tdo.showbox.timroes.axmlrpc.serializer.Serializer
    public XmlElement serialize(Object obj) {
        String obj2 = obj.toString();
        if (this.encodeStrings) {
            obj2 = obj2.replaceAll("&", "&amp;").replaceAll("<", "&lt;").replaceAll(DOM.CDATA_END, "]]&gt;");
        }
        return XMLUtil.makeXmlTag("string", obj2);
    }
}
