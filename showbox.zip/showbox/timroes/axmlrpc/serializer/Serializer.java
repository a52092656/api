package com.tdo.showbox.timroes.axmlrpc.serializer;

import com.tdo.showbox.timroes.axmlrpc.XMLRPCException;
import com.tdo.showbox.timroes.axmlrpc.xmlcreator.XmlElement;
import org.w3c.dom.Element;
/* loaded from: classes3.dex */
public interface Serializer {
    Object deserialize(Element element) throws XMLRPCException;

    String deserialize2(Element element) throws XMLRPCException;

    XmlElement serialize(Object obj);
}
