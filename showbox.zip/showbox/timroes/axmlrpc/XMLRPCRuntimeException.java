package com.tdo.showbox.timroes.axmlrpc;
/* loaded from: classes3.dex */
public class XMLRPCRuntimeException extends RuntimeException {
    public XMLRPCRuntimeException(String str) {
        super(str);
    }

    public XMLRPCRuntimeException(Exception exc) {
        super(exc);
    }
}
