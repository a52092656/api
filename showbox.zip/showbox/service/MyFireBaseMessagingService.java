package com.tdo.showbox.service;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.media.AudioAttributes;
import android.media.RingtoneManager;
import android.os.Build;
import android.util.Log;
import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;
import com.mintegral.msdk.base.entity.CampaignEx;
import com.tdo.showbox.R;
import com.tdo.showbox.receiver.PushMessageClickReceiver;
import com.umeng.analytics.pro.b;
import java.util.Map;
import kotlin.Metadata;
import kotlin.TypeCastException;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
/* compiled from: MyFireBaseMessagingService.kt */
@Metadata(bv = {1, 0, 3}, d1 = {"\u00008\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u0003\n\u0002\u0010%\n\u0002\b\u0002\u0018\u0000 \u00132\u00020\u0001:\u0001\u0013B\u0005¢\u0006\u0002\u0010\u0002J\b\u0010\u0007\u001a\u00020\bH\u0016J\u0010\u0010\t\u001a\u00020\b2\u0006\u0010\n\u001a\u00020\u000bH\u0016J\u0010\u0010\f\u001a\u00020\b2\u0006\u0010\r\u001a\u00020\u000eH\u0016J&\u0010\u000f\u001a\u00020\b2\b\u0010\u0010\u001a\u0004\u0018\u00010\u000e2\u0012\u0010\u0011\u001a\u000e\u0012\u0004\u0012\u00020\u000e\u0012\u0004\u0012\u00020\u000e0\u0012H\u0002R\u000e\u0010\u0003\u001a\u00020\u0004X\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010\u0005\u001a\u00020\u0006X\u0082\u000e¢\u0006\u0002\n\u0000¨\u0006\u0014"}, d2 = {"Lcom/tdo/showbox/service/MyFireBaseMessagingService;", "Lcom/google/firebase/messaging/FirebaseMessagingService;", "()V", "mNotifyManager", "Landroid/app/NotificationManager;", "msgId", "", "onCreate", "", "onMessageReceived", "remoteMessage", "Lcom/google/firebase/messaging/RemoteMessage;", "onNewToken", "p0", "", "sendNotification", "body", "data", "", "Companion", "app_webRelease"}, k = 1, mv = {1, 1, 16})
/* loaded from: classes3.dex */
public final class MyFireBaseMessagingService extends FirebaseMessagingService {
    public static final Companion Companion = new Companion(null);
    private NotificationManager mNotifyManager;
    private int msgId;

    /* compiled from: MyFireBaseMessagingService.kt */
    @Metadata(bv = {1, 0, 3}, d1 = {"\u0000\u0018\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\b\u0086\u0003\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J\u000e\u0010\u0003\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\u0006¨\u0006\u0007"}, d2 = {"Lcom/tdo/showbox/service/MyFireBaseMessagingService$Companion;", "", "()V", CampaignEx.JSON_NATIVE_VIDEO_START, "", b.M, "Landroid/content/Context;", "app_webRelease"}, k = 1, mv = {1, 1, 16})
    /* loaded from: classes3.dex */
    public static final class Companion {
        private Companion() {
        }

        public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        public final void start(Context context) {
            Intrinsics.checkParameterIsNotNull(context, "context");
            Intent intent = new Intent(context, MyFireBaseMessagingService.class);
            intent.setAction("com.google.firebase.MESSAGING_EVENT");
            context.startService(intent);
        }
    }

    @Override // android.app.Service
    public void onCreate() {
        super.onCreate();
        Object systemService = getSystemService("notification");
        if (systemService != null) {
            this.mNotifyManager = (NotificationManager) systemService;
            return;
        }
        throw new TypeCastException("null cannot be cast to non-null type android.app.NotificationManager");
    }

    @Override // com.google.firebase.messaging.FirebaseMessagingService
    public void onNewToken(String p0) {
        Intrinsics.checkParameterIsNotNull(p0, "p0");
        super.onNewToken(p0);
        Log.d("MyFireBaseMessaging", "new Token:" + p0);
    }

    @Override // com.google.firebase.messaging.FirebaseMessagingService
    public void onMessageReceived(RemoteMessage remoteMessage) {
        Intrinsics.checkParameterIsNotNull(remoteMessage, "remoteMessage");
        super.onMessageReceived(remoteMessage);
        RemoteMessage.Notification notification = remoteMessage.getNotification();
        String body = notification != null ? notification.getBody() : null;
        Map<String, String> data = remoteMessage.getData();
        Intrinsics.checkExpressionValueIsNotNull(data, "remoteMessage.data");
        sendNotification(body, data);
    }

    private final void sendNotification(String str, Map<String, String> map) {
        MyFireBaseMessagingService myFireBaseMessagingService = this;
        Intent intent = new Intent(myFireBaseMessagingService, PushMessageClickReceiver.class);
        intent.putExtra("type", map.get("type"));
        intent.putExtra("tid", map.get("tid"));
        intent.putExtra("mid", map.get("mid"));
        intent.putExtra("ticket_id", map.get("ticket_id"));
        intent.putExtra("url", map.get("url"));
        intent.setAction("Handle_Push_Msg");
        PendingIntent broadcast = PendingIntent.getBroadcast(myFireBaseMessagingService, (int) System.currentTimeMillis(), intent, 1073741824);
        this.msgId++;
        Notification.Builder builder = new Notification.Builder(myFireBaseMessagingService);
        if (Build.VERSION.SDK_INT >= 26) {
            AudioAttributes build = new AudioAttributes.Builder().setUsage(5).setContentType(3).build();
            NotificationChannel notificationChannel = new NotificationChannel("push_msg", "push_msg_name", 3);
            notificationChannel.setSound(RingtoneManager.getDefaultUri(2), build);
            notificationChannel.enableVibration(true);
            builder.setChannelId("push_msg");
            NotificationManager notificationManager = this.mNotifyManager;
            if (notificationManager == null) {
                Intrinsics.throwUninitializedPropertyAccessException("mNotifyManager");
            }
            notificationManager.createNotificationChannel(notificationChannel);
        }
        builder.setContentTitle("ShowBox").setSmallIcon(R.drawable.logo).setContentText(str).setAutoCancel(true).setProgress(0, 0, false);
        builder.setSound(RingtoneManager.getDefaultUri(2));
        builder.setContentIntent(broadcast);
        NotificationManager notificationManager2 = this.mNotifyManager;
        if (notificationManager2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("mNotifyManager");
        }
        notificationManager2.notify(this.msgId, builder.build());
    }
}
