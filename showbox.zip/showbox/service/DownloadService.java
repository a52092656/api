package com.tdo.showbox.service;

import android.app.IntentService;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;
import com.ares.downloader.jarvis.Jarvis;
import com.ares.downloader.jarvis.core.DownloadListener;
import com.ares.downloader.jarvis.core.RemoteFileUtil;
import com.hpplay.cybergarage.soap.SOAP;
import com.huantansheng.easyphotos.EasyPhotos;
import com.mintegral.msdk.base.entity.CampaignEx;
import com.tdo.showbox.app.App;
import com.tdo.showbox.app.Constant;
import com.tdo.showbox.db.entity.Download;
import com.tdo.showbox.event.ChangeToPauseEvent;
import com.tdo.showbox.event.DownloadChangedEvent;
import com.tdo.showbox.model.DownloadModel;
import com.tdo.showbox.utils.FileUtils;
import com.tdo.showbox.utils.MLog;
import com.tdo.showbox.utils.PrefsUtils;
import com.tdo.showbox.utils.StringUtils;
import java.io.File;
import java.util.LinkedHashMap;
import java.util.List;
import org.greenrobot.eventbus.EventBus;
/* loaded from: classes3.dex */
public class DownloadService extends IntentService {
    static final /* synthetic */ boolean $assertionsDisabled = false;
    private static final String TAG = "MovieDownLoaderService";
    private static volatile LinkedHashMap<String, DownloadModel> list = new LinkedHashMap<>();

    public DownloadService() {
        super("DownloadService");
    }

    @Override // android.app.IntentService, android.app.Service
    public void onCreate() {
        super.onCreate();
    }

    private void startDownloadNotifyService() {
        startService(new Intent(this, DownloadNotifyService.class));
    }

    @Override // android.app.IntentService
    protected void onHandleIntent(Intent intent) {
        List<Download> all;
        if (intent != null) {
            String action = intent.getAction();
            if (Constant.ACTION.MOVIE_DOWNLOAD.equals(action)) {
                Bundle extras = intent.getExtras();
                String string = extras.getString(Constant.Download.PARAMS_KEY_MOVIE, "");
                int i = extras.getInt(Constant.Download.PARAMS_KEY_TYPE, 1);
                MLog.d(TAG, "开始下载" + string + SOAP.DELIM + i);
                Download findByType = App.getDB().downloadDao().findByType(i, string);
                if (findByType == null) {
                    return;
                }
                if (canDownload(findByType.getPrivateid(), findByType.getBox_type())) {
                    doDownload(findByType, 1);
                } else {
                    onDownloadReady(findByType);
                }
            } else if (Constant.ACTION.MOVIE_ALLDOWNLOAD.equals(action)) {
                List<Download> all2 = App.getDB().downloadDao().getAll();
                if (all2 == null || all2.size() <= 0) {
                    return;
                }
                for (Download download : all2) {
                    if (download.getStatue() != 2) {
                        if (canDownload(download.getPrivateid(), download.getBox_type())) {
                            doDownload(download, download.getStatue());
                        } else {
                            onDownloadReady(download);
                        }
                    }
                }
            } else if (Constant.ACTION.MOVIE_RESET_MAX_COUNT.equals(action)) {
                for (Download download2 : App.getDB().downloadDao().findByStatue(0)) {
                    if (canDownload(download2.getPrivateid(), download2.getBox_type())) {
                        doDownload(download2, 1);
                    }
                }
            } else if (Constant.ACTION.MOVIE_PAUSED.equals(action)) {
                Bundle extras2 = intent.getExtras();
                String string2 = extras2.getString(Constant.Download.PARAMS_KEY_MOVIE, "");
                Download findByType2 = App.getDB().downloadDao().findByType(extras2.getInt(Constant.Download.PARAMS_KEY_TYPE, 1), string2);
                MLog.d(TAG, "下载进度 ： " + list.containsKey(string2) + "," + list.size());
                if (findByType2 == null) {
                    return;
                }
                doDownload(findByType2, 3);
            } else if (Constant.ACTION.MOVIE_ERROR.equals(action)) {
                Bundle extras3 = intent.getExtras();
                String string3 = extras3.getString(Constant.Download.PARAMS_KEY_MOVIE, "");
                int i2 = extras3.getInt(Constant.Download.PARAMS_KEY_TYPE, 1);
                MLog.d(TAG, "下载错误 ： " + list.containsKey(string3) + "," + list.size());
                if (!list.containsKey(string3)) {
                    return;
                }
                list.get(string3).downloader.pause();
                Download findByType3 = App.getDB().downloadDao().findByType(i2, string3);
                if (findByType3 == null) {
                    return;
                }
                doDownload(findByType3, 1);
            } else if (Constant.ACTION.MOVIE_DELETE.equals(action)) {
                getAllDownloadModel();
                Bundle extras4 = intent.getExtras();
                String string4 = extras4.getString(Constant.Download.PARAMS_KEY_MOVIE, "");
                int i3 = extras4.getInt(Constant.Download.PARAMS_KEY_TYPE, 1);
                MLog.d(TAG, "下载删除 ： " + list.containsKey(string4) + "," + list.size());
                if (i3 == 1) {
                    FileUtils.deleteDir(new File(Constant.DIR_UPLOAD_MOVIE_SUBTITLE + File.separator + string4));
                    deleteDownloadTask(string4);
                } else if (i3 == 2) {
                    if (App.getDB().downloadDao().findByType(i3, string4) != null) {
                        if (list.get(string4) == null) {
                            return;
                        }
                        deleteDownloadTask(string4);
                        return;
                    }
                    for (Download download3 : App.getDB().downloadDao().selectByTvId(string4, i3)) {
                        FileUtils.deleteDir(new File(Constant.DIR_UPLOAD_TV_SUBTITLE + File.separator + download3.getMovieId() + File.separator + download3.getTitle() + File.separator + "Season " + download3.getSeason() + File.separator + "Episode " + download3.getEpisode()));
                        deleteDownloadTask(download3.getPrivateid());
                    }
                }
            } else if (Constant.ACTION.DELETE_DOWNLOADED_TV.equals(action)) {
                getAllDownloadModel();
                for (Download download4 : App.getDB().downloadDao().selectByTvId(intent.getExtras().getString(Constant.Download.PARAMS_KEY_MOVIE, ""), 2, 2)) {
                    FileUtils.deleteDir(new File(Constant.DIR_UPLOAD_TV_SUBTITLE + File.separator + download4.getMovieId() + File.separator + download4.getTitle() + File.separator + "Season " + download4.getSeason() + File.separator + "Episode " + download4.getEpisode()));
                    deleteDownloadTask(download4.getPrivateid());
                }
            } else if (Constant.ACTION.MOVIE_TV_DELETE.equals(action)) {
                Bundle extras5 = intent.getExtras();
                for (Download download5 : App.getDB().downloadDao().selectByTvId(extras5.getString(Constant.Download.PARAMS_KEY_MOVIE, ""), extras5.getInt(Constant.Download.PARAMS_KEY_TYPE, 1))) {
                    deleteDownloadTask(download5.getPrivateid());
                }
            } else if (Constant.ACTION.MOVIE_STARTALL.equals(action)) {
                List<Download> all3 = App.getDB().downloadDao().getAll();
                if (all3 == null || all3.size() <= 0) {
                    return;
                }
                for (Download download6 : all3) {
                    if (download6.getStatue() != 2) {
                        if (canDownload(download6.getPrivateid(), download6.getBox_type())) {
                            doDownload(download6, 1);
                        } else {
                            onDownloadReady(download6);
                        }
                    }
                }
            } else if (Constant.ACTION.MOVIE_PAUSEDALL.equals(action) && (all = App.getDB().downloadDao().getAll()) != null && all.size() > 0) {
                for (Download download7 : all) {
                    if (download7.getStatue() != 2) {
                        if (download7.getStatue() == 0) {
                            EventBus.getDefault().post(new ChangeToPauseEvent(download7.getBox_type(), download7.getPrivateid()));
                        } else {
                            doDownload(download7, 3);
                        }
                    }
                }
            }
        }
    }

    private void deleteDownloadTask(String str) {
        String str2;
        DownloadModel downloadModel = list.get(str);
        if (downloadModel != null) {
            if (downloadModel.box_type == 1) {
                str2 = Constant.DIR_UPLOAD_MOVIE_SUBTITLE + File.separator + str + File.separator + downloadModel.title + File.separator + App.deviceLang;
            } else {
                str2 = Constant.DIR_UPLOAD_TV_SUBTITLE + File.separator + downloadModel.movieId + File.separator + downloadModel.title + File.separator + "Season " + downloadModel.season + File.separator + "Episode " + downloadModel.episode + downloadModel.episode + File.separator + App.deviceLang;
            }
            new File(str2).delete();
            downloadModel.downloader.pauseAndDelete();
            list.remove(str);
            App.getDB().downloadDao().deleteByTid(str);
        }
    }

    private boolean canDownload(String str, int i) {
        Download findByType = App.getDB().downloadDao().findByType(i, str);
        if (findByType == null || findByType.getStatue() != 1) {
            return App.getDB().downloadDao().findByStatue(1).size() < PrefsUtils.getInstance().getInt(Constant.MAX_DOWNLOAD_COUNT, 1);
        }
        return true;
    }

    private void getAllDownloadModel() {
        List<Download> all = App.getDB().downloadDao().getAll();
        if (all == null || all.size() <= 0) {
            return;
        }
        for (Download download : all) {
            doDownload(download, download.getStatue());
        }
    }

    private void doDownload(final Download download, int i) {
        MLog.d(TAG, "onDownloaddownloading" + list.containsKey(download.getPrivateid()));
        if (!list.containsKey(download.getPrivateid())) {
            if (TextUtils.isEmpty(download.getPath())) {
                App.getDB().downloadDao().deleteByTid(download.getPrivateid());
                return;
            }
            Jarvis.Downloader downloadListener = Jarvis.with(App.getContext()).withUrl(download.getPath()).fileName(RemoteFileUtil.getFileName(download.getPath(), download.getTitle(), Constant.DIR_DOWNLOAD)).filePath(Constant.DIR_DOWNLOAD).allowBackgroundDownload(true).threadCount(1).refreshTime(1000L).setDownloadListener(new DownloadListener() { // from class: com.tdo.showbox.service.DownloadService.1
                @Override // com.ares.downloader.jarvis.core.DownloadListener
                public void onSuccess(File file) {
                    MLog.d(DownloadService.TAG, "下载 ：success");
                    DownloadService.this.onDownloadSuccess(download);
                    DownloadService.this.sendDownloadBroadcast(Constant.ACTION.DOWNLOAD_NOTIFY_SUCCESS, download, "", 0);
                    DownloadService.this.downloadNextVideo();
                    EasyPhotos.notifyMedia(App.getContext(), file);
                }

                @Override // com.ares.downloader.jarvis.core.DownloadListener
                public void onProgress(long j, float f) {
                    MLog.d(DownloadService.TAG, "下载 ：process");
                    int i2 = (int) (f * 100.0f);
                    DownloadService.this.onDownloadProgress(download, i2, j);
                    DownloadService downloadService = DownloadService.this;
                    Download download2 = download;
                    downloadService.sendDownloadBroadcast(Constant.ACTION.DOWNLOAD_NOTIFY_PROGRESS, download2, StringUtils.getPrintSize(j - download2.getFileLength()), i2);
                    download.setFileLength(j);
                }

                @Override // com.ares.downloader.jarvis.core.DownloadListener
                public void onStart() {
                    MLog.d(DownloadService.TAG, "下载 ：start");
                    DownloadService.this.onDownloadStarted(download);
                    DownloadService.this.sendDownloadBroadcast(Constant.ACTION.DOWNLOAD_NOTIFY_START, download, "", 0);
                }

                @Override // com.ares.downloader.jarvis.core.DownloadListener
                public void onPause() {
                    MLog.d(DownloadService.TAG, "下载 ：pause");
                    DownloadService.this.onDownloadPaused(download);
                    DownloadService.this.sendDownloadBroadcast(Constant.ACTION.DOWNLOAD_NOTIFY_PAUSE, download, "", 0);
                    DownloadService.this.downloadNextVideo();
                }

                @Override // com.ares.downloader.jarvis.core.DownloadListener
                public void onFail() {
                    MLog.d(DownloadService.TAG, "下载 ：fail");
                    DownloadService.this.onDownloadFailure(download, "DownLoad ERROR");
                    DownloadService.this.sendDownloadBroadcast(Constant.ACTION.DOWNLOAD_NOTIFY_FAIL, download, "", 0);
                }

                @Override // com.ares.downloader.jarvis.core.DownloadListener
                public void onDelete(boolean z) {
                    MLog.d(DownloadService.TAG, "下载 ：delete" + z);
                    DownloadService.this.onDownloadDelete(download);
                    DownloadService.this.sendDownloadBroadcast(Constant.ACTION.DOWNLOAD_NOTIFY_DELETE, download, "", 0);
                }
            });
            DownloadModel downloadModel = new DownloadModel(download);
            downloadModel.downloader = downloadListener;
            list.put(download.getPrivateid(), downloadModel);
            excute(downloadModel, i);
            return;
        }
        excute(list.get(download.getPrivateid()), i);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void sendDownloadBroadcast(String str, Download download, String str2, int i) {
        Intent intent = new Intent(str);
        intent.putExtra("speedText", str2);
        intent.putExtra("id", download.getId());
        intent.putExtra(CampaignEx.JSON_KEY_TITLE, download.getTitle());
        intent.putExtra("season", download.getSeason());
        intent.putExtra("episode", download.getEpisode());
        intent.putExtra("boxType", download.getBox_type());
        intent.putExtra("progress", i);
        LocalBroadcastManager.getInstance(this).sendBroadcast(intent);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void downloadNextVideo() {
        for (Download download : App.getDB().downloadDao().findByStatue(0)) {
            if (canDownload(download.getPrivateid(), download.getBox_type())) {
                doDownload(download, 1);
            }
        }
    }

    private void excute(DownloadModel downloadModel, int i) {
        if (i == 1) {
            downloadModel.downloader.download();
            startDownloadNotifyService();
        } else if (i == 3) {
            downloadModel.downloader.pause();
            startDownloadNotifyService();
        } else if (i == 4) {
            downloadModel.downloader.recovery();
            startDownloadNotifyService();
        } else if (i != 5) {
        } else {
            downloadModel.downloader.deleteCacheFile();
            startDownloadNotifyService();
        }
    }

    @Override // android.app.IntentService, android.app.Service
    public void onDestroy() {
        super.onDestroy();
    }

    private void onDownloadReady(Download download) {
        if (download.getStatue() == 2) {
            return;
        }
        MLog.d(TAG, "onDownloadReady");
        download.setStatue(0);
        download.setSpeed(0L);
        App.getDB().downloadDao().update(download);
        Intent intent = new Intent(Constant.ACTION.DOWNLOAD_MOVIE_READY);
        intent.putExtra(Constant.Download.PARAMS_KEY_MOVIE_ID, download.getPrivateid());
        intent.putExtra(Constant.Download.PARAMS_KEY_MOVIE_TYPE, download.getBox_type());
        LocalBroadcastManager.getInstance(this).sendBroadcast(intent);
        EventBus.getDefault().post(new DownloadChangedEvent());
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void onDownloadStarted(Download download) {
        MLog.d(TAG, "onDownloadStarted");
        download.setStatue(1);
        download.setProgress(0);
        App.getDB().downloadDao().update(download);
        Intent intent = new Intent(Constant.ACTION.DOWNLOAD_MOVIE_STARTED);
        intent.putExtra(Constant.Download.PARAMS_KEY_MOVIE_ID, download.getPrivateid());
        intent.putExtra(Constant.Download.PARAMS_KEY_MOVIE_TYPE, download.getBox_type());
        LocalBroadcastManager.getInstance(this).sendBroadcast(intent);
        EventBus.getDefault().post(new DownloadChangedEvent());
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void onDownloadPaused(Download download) {
        MLog.d(TAG, "onDownloadPaused");
        download.setStatue(3);
        download.setSpeed(0L);
        App.getDB().downloadDao().update(download);
        Intent intent = new Intent(Constant.ACTION.DOWNLOAD_MOVIE_PAUSED);
        intent.putExtra(Constant.Download.PARAMS_KEY_MOVIE_ID, download.getPrivateid());
        intent.putExtra(Constant.Download.PARAMS_KEY_MOVIE_TYPE, download.getBox_type());
        LocalBroadcastManager.getInstance(this).sendBroadcast(intent);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void onDownloadProgress(Download download, int i, long j) {
        MLog.d(TAG, "onDownloadProgress: " + i);
        if (i == 100) {
            onDownloadSuccess(download);
            return;
        }
        download.setStatue(1);
        download.setProgress(i);
        App.getDB().downloadDao().update(download);
        Intent intent = new Intent(Constant.ACTION.DOWNLOAD_MOVIE_PROGRESS);
        intent.putExtra(Constant.Download.PARAMS_KEY_MOVIE_ID, download.getPrivateid());
        intent.putExtra(Constant.Download.PARAMS_KEY_MOVIE_TYPE, download.getBox_type());
        intent.putExtra(Constant.Download.PARAMS_KEY_PROGRESS, i);
        intent.putExtra(Constant.Download.PARAMS_KEY_SIZE, j);
        LocalBroadcastManager.getInstance(this).sendBroadcast(intent);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void onDownloadFailure(Download download, String str) {
        MLog.d(TAG, "onDownloadFailure: " + str);
        download.setStatue(4);
        App.getDB().downloadDao().update(download);
        Intent intent = new Intent(Constant.ACTION.DOWNLOAD_MOVIE_FAILURE);
        intent.putExtra(Constant.Download.PARAMS_KEY_MOVIE_ID, download.getPrivateid());
        intent.putExtra(Constant.Download.PARAMS_KEY_MOVIE_TYPE, download.getBox_type());
        intent.putExtra(Constant.Download.PARAMS_KEY_REASON, str);
        LocalBroadcastManager.getInstance(this).sendBroadcast(intent);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void onDownloadSuccess(Download download) {
        MLog.d(TAG, "onDownloadSuccess: ");
        download.setStatue(2);
        download.setProgress(100);
        App.getDB().downloadDao().update(download);
        Intent intent = new Intent(Constant.ACTION.DOWNLOAD_MOVIE_COMPLETE);
        intent.putExtra(Constant.Download.PARAMS_KEY_MOVIE_ID, download.getPrivateid());
        intent.putExtra(Constant.Download.PARAMS_KEY_MOVIE_TYPE, download.getBox_type());
        LocalBroadcastManager.getInstance(this).sendBroadcast(intent);
        list.remove(download.getPrivateid());
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void onDownloadDelete(Download download) {
        Intent intent = new Intent(Constant.ACTION.DOWNLOAD_MOVIE_DELETE);
        intent.putExtra(Constant.Download.PARAMS_KEY_MOVIE_ID, download.getPrivateid());
        intent.putExtra(Constant.Download.PARAMS_KEY_MOVIE_TYPE, download.getBox_type());
        LocalBroadcastManager.getInstance(this).sendBroadcast(intent);
    }
}
