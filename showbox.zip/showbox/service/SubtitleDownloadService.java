package com.tdo.showbox.service;

import android.app.IntentService;
import android.content.Intent;
import com.tdo.showbox.app.App;
import com.tdo.showbox.app.Constant;
import com.tdo.showbox.base.HttpResponseObserver;
import com.tdo.showbox.event.SubtitleDownloadEvent;
import com.tdo.showbox.http.API;
import com.tdo.showbox.http.APIService;
import com.tdo.showbox.http.ApiException;
import com.tdo.showbox.http.Http;
import com.tdo.showbox.model.common.Srt;
import com.tdo.showbox.service.SubtitleDownloadService;
import com.tdo.showbox.utils.CommonExtKt;
import com.tdo.showbox.utils.FileUtils;
import com.tdo.showbox.utils.ReaderUtils;
import com.tdo.showbox.utils.RxUtils;
import com.tencent.tinker.loader.shareutil.SharePatchInfo;
import io.reactivex.Observable;
import io.reactivex.ObservableSource;
import io.reactivex.disposables.Disposable;
import io.reactivex.functions.Function;
import java.io.File;
import java.util.ArrayList;
import java.util.List;
import kotlin.Metadata;
import kotlin.Pair;
import kotlin.TypeCastException;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;
import okhttp3.ResponseBody;
import org.greenrobot.eventbus.EventBus;
/* compiled from: SubtitleDownloadService.kt */
@Metadata(bv = {1, 0, 3}, d1 = {"\u00000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u000e\n\u0002\b\u0004\n\u0002\u0010 \n\u0002\b\u0004\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\u0018\u0000 \u00132\u00020\u0001:\u0001\u0013B\u0005¢\u0006\u0002\u0010\u0002J&\u0010\u0003\u001a\b\u0012\u0004\u0012\u00020\u00050\u00042\u0006\u0010\u0006\u001a\u00020\u00052\u0006\u0010\u0007\u001a\u00020\u00052\u0006\u0010\b\u001a\u00020\u0005H\u0002J8\u0010\t\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00050\n0\u00042\f\u0010\u000b\u001a\b\u0012\u0004\u0012\u00020\u00050\n2\f\u0010\f\u001a\b\u0012\u0004\u0012\u00020\u00050\n2\u0006\u0010\r\u001a\u00020\u0005H\u0002J\b\u0010\u000e\u001a\u00020\u000fH\u0016J\u0012\u0010\u0010\u001a\u00020\u000f2\b\u0010\u0011\u001a\u0004\u0018\u00010\u0012H\u0014¨\u0006\u0014"}, d2 = {"Lcom/tdo/showbox/service/SubtitleDownloadService;", "Landroid/app/IntentService;", "()V", "downloadSubtitleObservable", "Lio/reactivex/Observable;", "", "sid", "url", SharePatchInfo.OAT_DIR, "downloadSubtitles", "", "urls", "sidList", "downloadDir", "onDestroy", "", "onHandleIntent", "intent", "Landroid/content/Intent;", "Companion", "app_webRelease"}, k = 1, mv = {1, 1, 16})
/* loaded from: classes3.dex */
public final class SubtitleDownloadService extends IntentService {
    public static final Companion Companion = new Companion(null);
    public static final String EPISODE = "episode";
    public static final String ID = "id";
    public static final String NAME = "name";
    public static final String SEASON = "season";

    public SubtitleDownloadService() {
        super("SubtitleDownloadService");
    }

    /* compiled from: SubtitleDownloadService.kt */
    @Metadata(bv = {1, 0, 3}, d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u0004\b\u0086\u0003\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002R\u000e\u0010\u0003\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0005\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000¨\u0006\b"}, d2 = {"Lcom/tdo/showbox/service/SubtitleDownloadService$Companion;", "", "()V", UploadErrorInfoService.EPISODE, "", UploadErrorInfoService.ID, "NAME", UploadErrorInfoService.SEASON, "app_webRelease"}, k = 1, mv = {1, 1, 16})
    /* loaded from: classes3.dex */
    public static final class Companion {
        private Companion() {
        }

        public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }
    }

    @Override // android.app.IntentService
    protected void onHandleIntent(Intent intent) {
        if (intent != null) {
            String stringExtra = intent.getStringExtra("id");
            int intExtra = intent.getIntExtra("season", 0);
            int intExtra2 = intent.getIntExtra("episode", 0);
            String stringExtra2 = intent.getStringExtra("name");
            String str = "";
            if (intExtra == 0) {
                final String str2 = Constant.DIR_UPLOAD_MOVIE_SUBTITLE + File.separator + stringExtra + File.separator + stringExtra2 + File.separator + App.deviceLang;
                APIService service = Http.getService();
                String str3 = API.BASE_URL;
                String str4 = App.deviceLang;
                if (App.isLogin()) {
                    str = App.getUserData().uid;
                }
                service.Movie_srt_auto(str3, API.Movie.MOVIE_SRT_AUTO_V2, stringExtra, str4, str).compose(RxUtils.rxTranslate2List(Srt.class)).flatMap(new Function<T, ObservableSource<? extends R>>() { // from class: com.tdo.showbox.service.SubtitleDownloadService$onHandleIntent$$inlined$let$lambda$1
                    @Override // io.reactivex.functions.Function
                    /* renamed from: apply */
                    public final Observable<List<String>> mo704apply(ArrayList<Srt> list) {
                        Observable<List<String>> downloadSubtitles;
                        Intrinsics.checkParameterIsNotNull(list, "list");
                        ArrayList arrayList = new ArrayList();
                        ArrayList arrayList2 = new ArrayList();
                        for (Srt srt : list) {
                            arrayList.add(srt.file_path);
                            arrayList2.add(srt.sid);
                        }
                        downloadSubtitles = this.downloadSubtitles(arrayList, arrayList2, str2);
                        return downloadSubtitles;
                    }
                }).compose(RxUtils.rxSchedulerHelper()).subscribe(new HttpResponseObserver<List<? extends String>>() { // from class: com.tdo.showbox.service.SubtitleDownloadService$onHandleIntent$1$2
                    @Override // com.tdo.showbox.base.HttpResponseObserver
                    public void onError(ApiException e) {
                        Intrinsics.checkParameterIsNotNull(e, "e");
                    }

                    @Override // com.tdo.showbox.base.HttpResponseObserver
                    public void onStart(Disposable d) {
                        Intrinsics.checkParameterIsNotNull(d, "d");
                    }

                    /* renamed from: onSuccess  reason: avoid collision after fix types in other method */
                    public void onSuccess2(List<String> model) {
                        Intrinsics.checkParameterIsNotNull(model, "model");
                    }

                    @Override // com.tdo.showbox.base.HttpResponseObserver
                    public /* bridge */ /* synthetic */ void onSuccess(List<? extends String> list) {
                        onSuccess2((List<String>) list);
                    }
                });
                return;
            }
            final String str5 = Constant.DIR_UPLOAD_TV_SUBTITLE + File.separator + stringExtra + File.separator + stringExtra2 + File.separator + "Season " + intExtra + File.separator + "Episode " + intExtra2 + File.separator + App.deviceLang;
            APIService service2 = Http.getService();
            String str6 = API.BASE_URL;
            String str7 = App.deviceLang;
            if (App.isLogin()) {
                str = App.getUserData().uid;
            }
            service2.Tv_srt_auto(str6, API.Tv.TV_SRT_AUTO_V2, stringExtra, intExtra, intExtra2, str7, str).compose(RxUtils.rxTranslate2List(Srt.class)).flatMap(new Function<T, ObservableSource<? extends R>>() { // from class: com.tdo.showbox.service.SubtitleDownloadService$onHandleIntent$$inlined$let$lambda$2
                @Override // io.reactivex.functions.Function
                /* renamed from: apply */
                public final Observable<List<String>> mo704apply(ArrayList<Srt> list) {
                    Observable<List<String>> downloadSubtitles;
                    Intrinsics.checkParameterIsNotNull(list, "list");
                    ArrayList arrayList = new ArrayList();
                    ArrayList arrayList2 = new ArrayList();
                    for (Srt srt : list) {
                        arrayList.add(srt.file_path);
                        arrayList2.add(srt.sid);
                    }
                    downloadSubtitles = this.downloadSubtitles(arrayList, arrayList2, str5);
                    return downloadSubtitles;
                }
            }).compose(RxUtils.rxSchedulerHelper()).subscribe(new HttpResponseObserver<List<? extends String>>() { // from class: com.tdo.showbox.service.SubtitleDownloadService$onHandleIntent$1$4
                @Override // com.tdo.showbox.base.HttpResponseObserver
                public void onError(ApiException e) {
                    Intrinsics.checkParameterIsNotNull(e, "e");
                }

                @Override // com.tdo.showbox.base.HttpResponseObserver
                public void onStart(Disposable d) {
                    Intrinsics.checkParameterIsNotNull(d, "d");
                }

                @Override // com.tdo.showbox.base.HttpResponseObserver
                public /* bridge */ /* synthetic */ void onSuccess(List<? extends String> list) {
                    onSuccess2((List<String>) list);
                }

                /* renamed from: onSuccess  reason: avoid collision after fix types in other method */
                public void onSuccess2(List<String> model) {
                    Intrinsics.checkParameterIsNotNull(model, "model");
                    EventBus.getDefault().post(new SubtitleDownloadEvent());
                }
            });
        }
    }

    @Override // android.app.IntentService, android.app.Service
    public void onDestroy() {
        CommonExtKt.logD(this, "onDestroy");
        super.onDestroy();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final Observable<List<String>> downloadSubtitles(List<String> list, List<String> list2, final String str) {
        Observable<List<String>> observable = Observable.zip(Observable.fromIterable(list), Observable.fromIterable(list2), SubtitleDownloadService$downloadSubtitles$1.INSTANCE).flatMap(new Function<T, ObservableSource<? extends R>>() { // from class: com.tdo.showbox.service.SubtitleDownloadService$downloadSubtitles$2
            @Override // io.reactivex.functions.Function
            /* renamed from: apply */
            public final Observable<String> mo704apply(Pair<String, String> it) {
                Observable<String> downloadSubtitleObservable;
                Intrinsics.checkParameterIsNotNull(it, "it");
                downloadSubtitleObservable = SubtitleDownloadService.this.downloadSubtitleObservable(it.getSecond(), it.getFirst(), str);
                return downloadSubtitleObservable;
            }
        }).toList().toObservable();
        Intrinsics.checkExpressionValueIsNotNull(observable, "Observable.zip(Observabl…          .toObservable()");
        return observable;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final Observable<String> downloadSubtitleObservable(final String str, final String str2, final String str3) {
        Observable map = Http.getService().strlist(str2).map((Function) new Function<T, R>() { // from class: com.tdo.showbox.service.SubtitleDownloadService$downloadSubtitleObservable$1
            @Override // io.reactivex.functions.Function
            /* renamed from: apply */
            public final String mo704apply(ResponseBody it) {
                Intrinsics.checkParameterIsNotNull(it, "it");
                StringBuilder sb = new StringBuilder();
                sb.append(str3);
                sb.append("/");
                sb.append(str);
                sb.append("_");
                String str4 = str2;
                int lastIndexOf$default = StringsKt.lastIndexOf$default((CharSequence) str4, "/", 0, false, 6, (Object) null) + 1;
                if (str4 == null) {
                    throw new TypeCastException("null cannot be cast to non-null type java.lang.String");
                }
                String substring = str4.substring(lastIndexOf$default);
                Intrinsics.checkExpressionValueIsNotNull(substring, "(this as java.lang.String).substring(startIndex)");
                sb.append(substring);
                String sb2 = sb.toString();
                SubtitleDownloadService.Companion companion = SubtitleDownloadService.Companion;
                CommonExtKt.logD(companion, "Download subtitle path:" + sb2);
                FileUtils.writeFileFromBytesByStream(ReaderUtils.getChapterFile(sb2), it.bytes());
                return str;
            }
        });
        Intrinsics.checkExpressionValueIsNotNull(map, "Http.getService().strlis…    sid\n                }");
        return map;
    }
}
