package com.tdo.showbox.service;

import com.tdo.showbox.app.Constant;
import com.tdo.showbox.service.DLNACastService;
import com.tdo.showbox.utils.CommonExtKt;
import com.tdo.showbox.utils.PrefsUtils;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.Lambda;
/* JADX INFO: Access modifiers changed from: package-private */
/* compiled from: DLNACastService.kt */
@Metadata(bv = {1, 0, 3}, d1 = {"\u0000\b\n\u0000\n\u0002\u0010\u0002\n\u0000\u0010\u0000\u001a\u00020\u0001H\n¢\u0006\u0002\b\u0002"}, d2 = {"<anonymous>", "", "invoke"}, k = 3, mv = {1, 1, 16})
/* loaded from: classes3.dex */
public final class DLNACastService$startTimer$2 extends Lambda implements Function0<Unit> {
    final /* synthetic */ boolean $stopSelf;
    final /* synthetic */ DLNACastService this$0;

    /* JADX INFO: Access modifiers changed from: package-private */
    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public DLNACastService$startTimer$2(DLNACastService dLNACastService, boolean z) {
        super(0);
        this.this$0 = dLNACastService;
        this.$stopSelf = z;
    }

    @Override // kotlin.jvm.functions.Function0
    /* renamed from: invoke */
    public /* bridge */ /* synthetic */ Unit mo1726invoke() {
        mo1726invoke();
        return Unit.INSTANCE;
    }

    @Override // kotlin.jvm.functions.Function0
    /* renamed from: invoke  reason: collision with other method in class */
    public final void mo1726invoke() {
        try {
            if (DLNACastService.access$getMDeviceInfoList$p(this.this$0).isEmpty()) {
                DLNACastService.access$getMDLNAManager$p(this.this$0).stopBrowser();
                if (this.$stopSelf) {
                    PrefsUtils.getInstance().putInt(Constant.Prefs.DLNA_CAST_SEARCH_TIME, PrefsUtils.getInstance().getInt(Constant.Prefs.DLNA_CAST_SEARCH_TIME, 0) + 1);
                    this.this$0.stopSelf();
                }
            } else {
                DLNACastService.access$getMDLNAManager$p(this.this$0).stopBrowser();
            }
            DLNACastService.CastListener castListener = this.this$0.castListener;
            if (castListener != null) {
                castListener.searchCompleted();
            }
            CommonExtKt.logD(this.this$0, "Search complete");
        } catch (Exception unused) {
        }
    }
}
