package com.tdo.showbox.service;

import io.reactivex.functions.BiFunction;
import kotlin.Metadata;
import kotlin.Pair;
import kotlin.jvm.internal.Intrinsics;
/* compiled from: SubtitleDownloadService.kt */
@Metadata(bv = {1, 0, 3}, d1 = {"\u0000\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u000e\n\u0002\b\u0003\u0010\u0000\u001a\u000e\u0012\u0004\u0012\u00020\u0002\u0012\u0004\u0012\u00020\u00020\u00012\u0006\u0010\u0003\u001a\u00020\u00022\u0006\u0010\u0004\u001a\u00020\u0002H\n¢\u0006\u0002\b\u0005"}, d2 = {"<anonymous>", "Lkotlin/Pair;", "", "url", "sid", "apply"}, k = 3, mv = {1, 1, 16})
/* loaded from: classes3.dex */
final class SubtitleDownloadService$downloadSubtitles$1<T1, T2, R> implements BiFunction<String, String, Pair<? extends String, ? extends String>> {
    public static final SubtitleDownloadService$downloadSubtitles$1 INSTANCE = new SubtitleDownloadService$downloadSubtitles$1();

    SubtitleDownloadService$downloadSubtitles$1() {
    }

    @Override // io.reactivex.functions.BiFunction
    /* renamed from: apply  reason: avoid collision after fix types in other method */
    public final Pair<String, String> mo714apply(String url, String sid) {
        Intrinsics.checkParameterIsNotNull(url, "url");
        Intrinsics.checkParameterIsNotNull(sid, "sid");
        return new Pair<>(url, sid);
    }
}
