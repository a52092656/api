package com.tdo.showbox.service;

import android.app.Service;
import android.content.Intent;
import android.os.Binder;
import android.os.IBinder;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.gms.common.internal.ServiceSpecificExtraArgs;
import com.hpplay.sdk.source.browse.api.LelinkServiceInfo;
import com.mintegral.msdk.base.entity.CampaignEx;
import com.tdo.showbox.app.App;
import com.tdo.showbox.service.LeCastService;
import com.tdo.showbox.utils.CommonExtKt;
import com.tdo.showbox.utils.RxSubscribersKt;
import com.tdo.showbox.utils.RxUtils;
import com.tdo.showbox.utils.ToastUtils;
import com.tdo.showbox.view.activity.videoplayer.cast.IUIUpdateListener;
import com.tdo.showbox.view.activity.videoplayer.cast.LelinkHelper;
import com.tdo.showbox.view.activity.videoplayer.cast.MessageDeatail;
import com.tencent.tinker.loader.hotplug.EnvConsts;
import com.umeng.commonsdk.proguard.g;
import io.reactivex.Observable;
import io.reactivex.disposables.Disposable;
import java.lang.ref.WeakReference;
import java.util.List;
import java.util.concurrent.TimeUnit;
import kotlin.Metadata;
import kotlin.TypeCastException;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import tv.danmaku.ijk.media.player.IjkMediaMeta;
/* compiled from: LeCastService.kt */
@Metadata(bv = {1, 0, 3}, d1 = {"\u0000X\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\t\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\t\u0018\u0000 \"2\u00020\u0001:\u0003\"#$B\u0005¢\u0006\u0002\u0010\u0002J\u0010\u0010\u0017\u001a\u00020\u00182\u0006\u0010\u0019\u001a\u00020\u001aH\u0016J\b\u0010\u001b\u001a\u00020\u001cH\u0016J\b\u0010\u001d\u001a\u00020\u001cH\u0016J\u0012\u0010\u001e\u001a\u00020\b2\b\u0010\u0019\u001a\u0004\u0018\u00010\u001aH\u0016J\u0010\u0010\u001f\u001a\u00020\u001c2\b\u0010 \u001a\u0004\u0018\u00010\fJ\b\u0010!\u001a\u00020\u001cH\u0002R\u0010\u0010\u0003\u001a\u0004\u0018\u00010\u0004X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0005\u001a\u00020\u0006X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\bX\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010\t\u001a\u0004\u0018\u00010\nX\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010\u000b\u001a\u0004\u0018\u00010\fX\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010\r\u001a\u0004\u0018\u00010\u000eX\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010\u000f\u001a\u0004\u0018\u00010\u0010X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0011\u001a\u00020\u0006X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0012\u001a\u00020\u0006X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0013\u001a\u00020\u0014X\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010\u0015\u001a\u0004\u0018\u00010\u0016X\u0082\u000e¢\u0006\u0002\n\u0000¨\u0006%"}, d2 = {"Lcom/tdo/showbox/service/LeCastService;", "Landroid/app/Service;", "()V", "disposable", "Lio/reactivex/disposables/Disposable;", "duration", "", "isMirror", "", "lastConnectInfo", "Lcom/hpplay/sdk/source/browse/api/LelinkServiceInfo;", "lecastListener", "Lcom/tdo/showbox/service/LeCastService$LeCastListener;", "lelinkHelper", "Lcom/tdo/showbox/view/activity/videoplayer/cast/LelinkHelper;", "mUIUpdateListener", "Lcom/tdo/showbox/view/activity/videoplayer/cast/IUIUpdateListener;", "position", "searchDelay", "status", "", CampaignEx.JSON_KEY_TITLE, "", "onBind", "Landroid/os/IBinder;", "intent", "Landroid/content/Intent;", "onCreate", "", "onDestroy", "onUnbind", "setUpdateListener", ServiceSpecificExtraArgs.CastExtraArgs.LISTENER, "startTimer", "Companion", "LeCastBinder", "LeCastListener", "app_webRelease"}, k = 1, mv = {1, 1, 16})
/* loaded from: classes3.dex */
public final class LeCastService extends Service {
    public static final Companion Companion = new Companion(null);
    public static final int PAUSE = 2;
    public static final int PLAY = 1;
    public static final int STOP = 3;
    private Disposable disposable;
    private long duration;
    private boolean isMirror;
    private LelinkServiceInfo lastConnectInfo;
    private LeCastListener lecastListener;
    private LelinkHelper lelinkHelper;
    private long position;
    private int status;
    private long searchDelay = 10;
    private String title = "";
    private IUIUpdateListener mUIUpdateListener = new IUIUpdateListener() { // from class: com.tdo.showbox.service.LeCastService$mUIUpdateListener$1
        @Override // com.tdo.showbox.view.activity.videoplayer.cast.IUIUpdateListener
        public final void onUpdate(int i, MessageDeatail messageDeatail) {
            List<LelinkServiceInfo> infos;
            Integer num = null;
            Object obj = null;
            List<LelinkServiceInfo> list = null;
            LelinkServiceInfo lelinkServiceInfo = null;
            num = null;
            if (i == 1) {
                LeCastService leCastService = LeCastService.this;
                StringBuilder sb = new StringBuilder();
                sb.append("Search success:");
                LelinkHelper lelinkHelper = LeCastService.this.lelinkHelper;
                if (lelinkHelper != null && (infos = lelinkHelper.getInfos()) != null) {
                    num = Integer.valueOf(infos.size());
                }
                sb.append(num);
                CommonExtKt.logD(leCastService, sb.toString());
                LeCastService.LeCastListener leCastListener = LeCastService.this.lecastListener;
                if (leCastListener == null) {
                    return;
                }
                leCastListener.searchSuccess();
            } else if (i == 2) {
                ToastUtils.showShort("Auth error", new Object[0]);
                LeCastService.LeCastListener leCastListener2 = LeCastService.this.lecastListener;
                if (leCastListener2 == null) {
                    return;
                }
                leCastListener2.searchFailed();
            } else if (i != 29) {
                switch (i) {
                    case 10:
                        LelinkHelper lelinkHelper2 = LeCastService.this.lelinkHelper;
                        if (lelinkHelper2 != null) {
                            lelinkHelper2.disConnect(LeCastService.this.lastConnectInfo);
                        }
                        LeCastService leCastService2 = LeCastService.this;
                        Object obj2 = messageDeatail.obj;
                        if (obj2 instanceof LelinkServiceInfo) {
                            lelinkServiceInfo = obj2;
                        }
                        leCastService2.lastConnectInfo = lelinkServiceInfo;
                        LeCastService.LeCastListener leCastListener3 = LeCastService.this.lecastListener;
                        if (leCastListener3 == null) {
                            return;
                        }
                        leCastListener3.connectSuccess(LeCastService.this.lastConnectInfo);
                        return;
                    case 11:
                        LeCastService.LeCastListener leCastListener4 = LeCastService.this.lecastListener;
                        if (leCastListener4 == null) {
                            return;
                        }
                        LelinkHelper lelinkHelper3 = LeCastService.this.lelinkHelper;
                        if (lelinkHelper3 != null) {
                            list = lelinkHelper3.getInfos();
                        }
                        leCastListener4.disConnect(list);
                        return;
                    case 12:
                        LeCastService.LeCastListener leCastListener5 = LeCastService.this.lecastListener;
                        if (leCastListener5 == null) {
                            return;
                        }
                        Object obj3 = messageDeatail.obj;
                        if (obj3 instanceof LelinkServiceInfo) {
                            obj = obj3;
                        }
                        leCastListener5.connectFailed((LelinkServiceInfo) obj);
                        return;
                    default:
                        String str = "";
                        switch (i) {
                            case 20:
                                CommonExtKt.logD(LeCastService.this, "STATE_PLAY");
                                LeCastService.this.status = 1;
                                LeCastService.LeCastListener leCastListener6 = LeCastService.this.lecastListener;
                                if (leCastListener6 == null) {
                                    return;
                                }
                                String str2 = LeCastService.this.title;
                                if (str2 != null) {
                                    str = str2;
                                }
                                leCastListener6.playState(str);
                                return;
                            case 21:
                                CommonExtKt.logD(LeCastService.this, "STATE_PAUSE");
                                LeCastService.this.status = 2;
                                LeCastService.LeCastListener leCastListener7 = LeCastService.this.lecastListener;
                                if (leCastListener7 == null) {
                                    return;
                                }
                                leCastListener7.pauseState();
                                return;
                            case 22:
                                LeCastService.LeCastListener leCastListener8 = LeCastService.this.lecastListener;
                                if (leCastListener8 == null) {
                                    return;
                                }
                                leCastListener8.playComplete();
                                return;
                            case 23:
                                CommonExtKt.logD(LeCastService.this, "STATE_STOP");
                                LeCastService.this.status = 3;
                                LeCastService.LeCastListener leCastListener9 = LeCastService.this.lecastListener;
                                if (leCastListener9 == null) {
                                    return;
                                }
                                leCastListener9.stopState();
                                return;
                            default:
                                switch (i) {
                                    case 25:
                                        LeCastService.this.status = 1;
                                        Object obj4 = messageDeatail.obj;
                                        if (obj4 == null) {
                                            throw new TypeCastException("null cannot be cast to non-null type kotlin.LongArray");
                                        }
                                        long[] jArr = (long[]) obj4;
                                        long j = jArr[0];
                                        long j2 = jArr[1];
                                        LeCastService.this.duration = j;
                                        LeCastService.this.position = j2;
                                        LeCastService.LeCastListener leCastListener10 = LeCastService.this.lecastListener;
                                        if (leCastListener10 == null) {
                                            return;
                                        }
                                        String str3 = LeCastService.this.title;
                                        leCastListener10.positionUpdate(j, j2, str3 != null ? str3 : str);
                                        return;
                                    case 26:
                                        LeCastService.this.status = 0;
                                        LeCastService.LeCastListener leCastListener11 = LeCastService.this.lecastListener;
                                        if (leCastListener11 == null) {
                                            return;
                                        }
                                        leCastListener11.playFailed("Play error");
                                        return;
                                    case 27:
                                        LeCastService.LeCastListener leCastListener12 = LeCastService.this.lecastListener;
                                        if (leCastListener12 == null) {
                                            return;
                                        }
                                        leCastListener12.loadingState();
                                        return;
                                    default:
                                        return;
                                }
                        }
                }
            } else {
                ToastUtils.showShort("unsupport relevance data", new Object[0]);
                LeCastService.LeCastListener leCastListener13 = LeCastService.this.lecastListener;
                if (leCastListener13 == null) {
                    return;
                }
                leCastListener13.playFailed("unsupport relevance data");
            }
        }
    };

    /* compiled from: LeCastService.kt */
    @Metadata(bv = {1, 0, 3}, d1 = {"\u00000\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010!\n\u0002\b\u0005\n\u0002\u0010\u000e\n\u0002\b\u0004\n\u0002\u0010\t\n\u0002\b\u0007\bf\u0018\u00002\u00020\u0001J\u0012\u0010\u0002\u001a\u00020\u00032\b\u0010\u0004\u001a\u0004\u0018\u00010\u0005H&J\u0012\u0010\u0006\u001a\u00020\u00032\b\u0010\u0004\u001a\u0004\u0018\u00010\u0005H&J\u0018\u0010\u0007\u001a\u00020\u00032\u000e\u0010\u0004\u001a\n\u0012\u0004\u0012\u00020\u0005\u0018\u00010\bH&J\b\u0010\t\u001a\u00020\u0003H&J\b\u0010\n\u001a\u00020\u0003H&J\b\u0010\u000b\u001a\u00020\u0003H&J\u0010\u0010\f\u001a\u00020\u00032\u0006\u0010\r\u001a\u00020\u000eH&J\u0010\u0010\u000f\u001a\u00020\u00032\u0006\u0010\u0010\u001a\u00020\u000eH&J \u0010\u0011\u001a\u00020\u00032\u0006\u0010\u0012\u001a\u00020\u00132\u0006\u0010\u0014\u001a\u00020\u00132\u0006\u0010\u0010\u001a\u00020\u000eH&J\b\u0010\u0015\u001a\u00020\u0003H&J\b\u0010\u0016\u001a\u00020\u0003H&J\b\u0010\u0017\u001a\u00020\u0003H&J\b\u0010\u0018\u001a\u00020\u0003H&J\b\u0010\u0019\u001a\u00020\u0003H&¨\u0006\u001a"}, d2 = {"Lcom/tdo/showbox/service/LeCastService$LeCastListener;", "", "connectFailed", "", "info", "Lcom/hpplay/sdk/source/browse/api/LelinkServiceInfo;", "connectSuccess", "disConnect", "", "loadingState", "pauseState", "playComplete", "playFailed", "msg", "", "playState", CampaignEx.JSON_KEY_TITLE, "positionUpdate", "durationSeconds", "", "positionSeconds", "searchCompleted", "searchFailed", "searchSuccess", "startSearch", "stopState", "app_webRelease"}, k = 1, mv = {1, 1, 16})
    /* loaded from: classes3.dex */
    public interface LeCastListener {
        void connectFailed(LelinkServiceInfo lelinkServiceInfo);

        void connectSuccess(LelinkServiceInfo lelinkServiceInfo);

        void disConnect(List<LelinkServiceInfo> list);

        void loadingState();

        void pauseState();

        void playComplete();

        void playFailed(String str);

        void playState(String str);

        void positionUpdate(long j, long j2, String str);

        void searchCompleted();

        void searchFailed();

        void searchSuccess();

        void startSearch();

        void stopState();
    }

    /* compiled from: LeCastService.kt */
    @Metadata(bv = {1, 0, 3}, d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0003\b\u0086\u0003\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002R\u000e\u0010\u0003\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0005\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0004X\u0086T¢\u0006\u0002\n\u0000¨\u0006\u0007"}, d2 = {"Lcom/tdo/showbox/service/LeCastService$Companion;", "", "()V", "PAUSE", "", "PLAY", "STOP", "app_webRelease"}, k = 1, mv = {1, 1, 16})
    /* loaded from: classes3.dex */
    public static final class Companion {
        private Companion() {
        }

        public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }
    }

    @Override // android.app.Service
    public IBinder onBind(Intent intent) {
        Intrinsics.checkParameterIsNotNull(intent, "intent");
        CommonExtKt.logD(this, "onBind");
        Disposable disposable = this.disposable;
        if (disposable != null) {
            disposable.dispose();
        }
        return new LeCastBinder();
    }

    @Override // android.app.Service
    public void onCreate() {
        super.onCreate();
        CommonExtKt.logD(this, "onCreate");
        LelinkHelper lelinkHelper = LelinkHelper.getInstance(App.getContext());
        this.lelinkHelper = lelinkHelper;
        if (lelinkHelper != null) {
            lelinkHelper.setUIUpdateListener(this.mUIUpdateListener);
        }
        LelinkHelper lelinkHelper2 = this.lelinkHelper;
        if (lelinkHelper2 != null) {
            lelinkHelper2.browse(0);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void startTimer() {
        Observable<R> compose = Observable.timer(this.searchDelay, TimeUnit.SECONDS).compose(RxUtils.rxSchedulerHelper());
        Intrinsics.checkExpressionValueIsNotNull(compose, "Observable.timer(searchD…tils.rxSchedulerHelper())");
        RxSubscribersKt.subscribeTo$default(compose, null, new LeCastService$startTimer$2(this), new LeCastService$startTimer$1(this), null, 9, null);
    }

    @Override // android.app.Service
    public boolean onUnbind(Intent intent) {
        this.lecastListener = null;
        CommonExtKt.logD(this, "onUnbind");
        return super.onUnbind(intent);
    }

    @Override // android.app.Service
    public void onDestroy() {
        List<LelinkServiceInfo> infos;
        CommonExtKt.logD(this, "onDestroy");
        LelinkHelper lelinkHelper = this.lelinkHelper;
        if (lelinkHelper != null && (infos = lelinkHelper.getInfos()) != null) {
            for (LelinkServiceInfo lelinkServiceInfo : infos) {
                LelinkHelper lelinkHelper2 = this.lelinkHelper;
                if (lelinkHelper2 != null) {
                    lelinkHelper2.disConnect(lelinkServiceInfo);
                }
            }
        }
        LelinkHelper lelinkHelper3 = this.lelinkHelper;
        if (lelinkHelper3 != null) {
            lelinkHelper3.release();
        }
        LelinkHelper lelinkHelper4 = this.lelinkHelper;
        if (lelinkHelper4 != null) {
            lelinkHelper4.setUIUpdateListener(null);
        }
        this.mUIUpdateListener = null;
        this.lecastListener = null;
        this.lastConnectInfo = null;
        Disposable disposable = this.disposable;
        if (disposable != null) {
            disposable.dispose();
        }
        super.onDestroy();
    }

    public final void setUpdateListener(LeCastListener leCastListener) {
        this.lecastListener = leCastListener;
    }

    /* compiled from: LeCastService.kt */
    @Metadata(bv = {1, 0, 3}, d1 = {"\u0000R\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010 \n\u0000\n\u0002\u0010!\n\u0000\n\u0002\u0010\t\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0011\n\u0002\u0010\u000b\n\u0002\b\u0005\b\u0096\u0004\u0018\u00002\u00020\u0001B\u0005¢\u0006\u0002\u0010\u0002J\u000e\u0010\u0006\u001a\u00020\u00072\u0006\u0010\b\u001a\u00020\tJ\u000e\u0010\n\u001a\n\u0012\u0004\u0012\u00020\t\u0018\u00010\u000bJ\u000e\u0010\f\u001a\n\u0012\u0004\u0012\u00020\t\u0018\u00010\rJ\u0006\u0010\u000e\u001a\u00020\u000fJ\u0006\u0010\u0010\u001a\u00020\u000fJ\u0006\u0010\u0011\u001a\u00020\u0012J\u0006\u0010\u0013\u001a\u00020\u0014J\b\u0010\u0015\u001a\u0004\u0018\u00010\u0016J\u0006\u0010\u0017\u001a\u00020\u0007J\u001e\u0010\u0018\u001a\u00020\u00072\u0006\u0010\u0019\u001a\u00020\u00162\u0006\u0010\u001a\u001a\u00020\u00142\u0006\u0010\u001b\u001a\u00020\u0016J\u0006\u0010\u001c\u001a\u00020\u0007J\u0006\u0010\u001d\u001a\u00020\u0007J\u000e\u0010\u001e\u001a\u00020\u00072\u0006\u0010\u001f\u001a\u00020\u000fJ\u000e\u0010 \u001a\u00020\u00072\u0006\u0010!\u001a\u00020\u0005J\u000e\u0010\"\u001a\u00020\u00072\u0006\u0010#\u001a\u00020\u0014J\u001e\u0010$\u001a\u00020\u00072\u0006\u0010%\u001a\u00020\u00142\u0006\u0010&\u001a\u00020\u00142\u0006\u0010'\u001a\u00020(J\u0006\u0010)\u001a\u00020\u0007J\u0006\u0010*\u001a\u00020\u0007J\u0006\u0010+\u001a\u00020\u0007J\u0006\u0010,\u001a\u00020\u0007R\u0016\u0010\u0003\u001a\n\u0012\u0004\u0012\u00020\u0005\u0018\u00010\u0004X\u0082\u000e¢\u0006\u0002\n\u0000¨\u0006-"}, d2 = {"Lcom/tdo/showbox/service/LeCastService$LeCastBinder;", "Landroid/os/Binder;", "(Lcom/tdo/showbox/service/LeCastService;)V", "mReference", "Ljava/lang/ref/WeakReference;", "Landroidx/appcompat/app/AppCompatActivity;", "connect", "", "info", "Lcom/hpplay/sdk/source/browse/api/LelinkServiceInfo;", "getConnectInfo", "", "getDeviceInfo", "", "getDuration", "", "getPosition", "getService", "Lcom/tdo/showbox/service/LeCastService;", "getStatus", "", "getTitle", "", "pause", "play", "url", "position", "name", "release", CampaignEx.JSON_NATIVE_VIDEO_RESUME, "seekTo", "progress", "setActivity", EnvConsts.ACTIVITY_MANAGER_SRVNAME, "setVolume", "volume", "startMirror", g.y, IjkMediaMeta.IJKM_KEY_BITRATE, "audioEnable", "", "startSearch", "stopMirror", "stopPlay", "stopSearch", "app_webRelease"}, k = 1, mv = {1, 1, 16})
    /* loaded from: classes3.dex */
    public class LeCastBinder extends Binder {
        private WeakReference<AppCompatActivity> mReference;

        public LeCastBinder() {
        }

        public final long getDuration() {
            return LeCastService.this.duration;
        }

        public final long getPosition() {
            return LeCastService.this.position;
        }

        public final int getStatus() {
            return LeCastService.this.status;
        }

        public final String getTitle() {
            return LeCastService.this.title;
        }

        public final LeCastService getService() {
            return LeCastService.this;
        }

        public final void setActivity(AppCompatActivity activity) {
            Intrinsics.checkParameterIsNotNull(activity, "activity");
            this.mReference = new WeakReference<>(activity);
        }

        public final void connect(LelinkServiceInfo info) {
            Intrinsics.checkParameterIsNotNull(info, "info");
            LelinkHelper lelinkHelper = LeCastService.this.lelinkHelper;
            if (lelinkHelper != null) {
                lelinkHelper.connect(info);
            }
        }

        public final void startSearch() {
            LelinkHelper lelinkHelper = LeCastService.this.lelinkHelper;
            if (lelinkHelper != null) {
                lelinkHelper.browse(0);
            }
            LeCastService.this.startTimer();
            LeCastListener leCastListener = LeCastService.this.lecastListener;
            if (leCastListener != null) {
                leCastListener.startSearch();
            }
        }

        public final void stopSearch() {
            LelinkHelper lelinkHelper = LeCastService.this.lelinkHelper;
            if (lelinkHelper != null) {
                lelinkHelper.stopBrowse();
            }
        }

        public final void play(String url, int i, String name) {
            Intrinsics.checkParameterIsNotNull(url, "url");
            Intrinsics.checkParameterIsNotNull(name, "name");
            LelinkHelper lelinkHelper = LeCastService.this.lelinkHelper;
            if (lelinkHelper != null) {
                lelinkHelper.playNetMedia(url, 102, "", i);
            }
            LeCastService.this.title = name;
        }

        public final void pause() {
            LelinkHelper lelinkHelper = LeCastService.this.lelinkHelper;
            if (lelinkHelper != null) {
                lelinkHelper.pause();
            }
        }

        public final void resume() {
            LelinkHelper lelinkHelper = LeCastService.this.lelinkHelper;
            if (lelinkHelper != null) {
                lelinkHelper.resume();
            }
        }

        public final void stopPlay() {
            LelinkHelper lelinkHelper = LeCastService.this.lelinkHelper;
            if (lelinkHelper != null) {
                lelinkHelper.stop();
            }
        }

        public final void startMirror(int i, int i2, boolean z) {
            if (LeCastService.this.lastConnectInfo != null) {
                LelinkHelper lelinkHelper = LeCastService.this.lelinkHelper;
                if (lelinkHelper == null) {
                    return;
                }
                WeakReference<AppCompatActivity> weakReference = this.mReference;
                lelinkHelper.startMirror(weakReference != null ? weakReference.get() : null, LeCastService.this.lastConnectInfo, i, i2, z, "");
                return;
            }
            ToastUtils.showShort("Please select a device", new Object[0]);
        }

        public final void stopMirror() {
            LelinkHelper lelinkHelper = LeCastService.this.lelinkHelper;
            if (lelinkHelper != null) {
                lelinkHelper.stopMirror();
            }
        }

        public final void setVolume(int i) {
            LelinkHelper lelinkHelper = LeCastService.this.lelinkHelper;
            if (lelinkHelper != null) {
                lelinkHelper.setVolume(i);
            }
        }

        public final void seekTo(long j) {
            LelinkHelper lelinkHelper = LeCastService.this.lelinkHelper;
            if (lelinkHelper != null) {
                lelinkHelper.seekTo((int) j);
            }
        }

        public final List<LelinkServiceInfo> getDeviceInfo() {
            LelinkHelper lelinkHelper = LeCastService.this.lelinkHelper;
            if (lelinkHelper != null) {
                return lelinkHelper.getInfos();
            }
            return null;
        }

        public final List<LelinkServiceInfo> getConnectInfo() {
            LelinkHelper lelinkHelper = LeCastService.this.lelinkHelper;
            if (lelinkHelper != null) {
                return lelinkHelper.getConnectInfos();
            }
            return null;
        }

        public final void release() {
            WeakReference<AppCompatActivity> weakReference = this.mReference;
            if (weakReference != null) {
                weakReference.clear();
            }
            LeCastService.this.lecastListener = null;
            this.mReference = null;
        }
    }
}
