package com.tdo.showbox.service;

import com.koushikdutta.async.ByteBufferList;
import com.koushikdutta.async.DataEmitter;
import com.koushikdutta.async.callback.CompletedCallback;
import com.koushikdutta.async.callback.DataCallback;
import com.koushikdutta.async.http.body.AsyncHttpRequestBody;
import com.koushikdutta.async.http.body.MultipartFormDataBody;
import com.koushikdutta.async.http.body.Part;
import com.koushikdutta.async.http.server.AsyncHttpServerRequest;
import com.koushikdutta.async.http.server.AsyncHttpServerResponse;
import com.koushikdutta.async.http.server.HttpServerRequestCallback;
import com.tdo.showbox.event.LoadUploadSubtitleEvent;
import com.tdo.showbox.service.WebUploadService;
import com.tdo.showbox.utils.CommonExtKt;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import kotlin.Metadata;
import kotlin.TypeCastException;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.Charsets;
import org.greenrobot.eventbus.EventBus;
/* JADX INFO: Access modifiers changed from: package-private */
/* compiled from: WebUploadService.kt */
@Metadata(bv = {1, 0, 3}, d1 = {"\u0000\u0016\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\u0010\u0000\u001a\u00020\u00012\u000e\u0010\u0002\u001a\n \u0004*\u0004\u0018\u00010\u00030\u00032\u000e\u0010\u0005\u001a\n \u0004*\u0004\u0018\u00010\u00060\u0006H\n¢\u0006\u0002\b\u0007"}, d2 = {"<anonymous>", "", "request", "Lcom/koushikdutta/async/http/server/AsyncHttpServerRequest;", "kotlin.jvm.PlatformType", "response", "Lcom/koushikdutta/async/http/server/AsyncHttpServerResponse;", "onRequest"}, k = 3, mv = {1, 1, 16})
/* loaded from: classes3.dex */
public final class WebUploadService$startServer$8 implements HttpServerRequestCallback {
    final /* synthetic */ WebUploadService this$0;

    /* JADX INFO: Access modifiers changed from: package-private */
    public WebUploadService$startServer$8(WebUploadService webUploadService) {
        this.this$0 = webUploadService;
    }

    @Override // com.koushikdutta.async.http.server.HttpServerRequestCallback
    public final void onRequest(AsyncHttpServerRequest request, final AsyncHttpServerResponse asyncHttpServerResponse) {
        Intrinsics.checkExpressionValueIsNotNull(request, "request");
        AsyncHttpRequestBody body = request.getBody();
        if (body == null) {
            throw new TypeCastException("null cannot be cast to non-null type com.koushikdutta.async.http.body.MultipartFormDataBody");
        }
        final MultipartFormDataBody multipartFormDataBody = (MultipartFormDataBody) body;
        multipartFormDataBody.setMultipartCallback(new MultipartFormDataBody.MultipartCallback() { // from class: com.tdo.showbox.service.WebUploadService$startServer$8.1
            @Override // com.koushikdutta.async.http.body.MultipartFormDataBody.MultipartCallback
            public final void onPart(Part part) {
                Intrinsics.checkExpressionValueIsNotNull(part, "part");
                if (part.isFile()) {
                    multipartFormDataBody.setDataCallback(new DataCallback() { // from class: com.tdo.showbox.service.WebUploadService.startServer.8.1.1
                        @Override // com.koushikdutta.async.callback.DataCallback
                        public final void onDataAvailable(DataEmitter dataEmitter, ByteBufferList bb) {
                            WebUploadService.FileUploadHolder fileUploadHolder;
                            fileUploadHolder = WebUploadService$startServer$8.this.this$0.fileUploadHolder;
                            Intrinsics.checkExpressionValueIsNotNull(bb, "bb");
                            byte[] allByteArray = bb.getAllByteArray();
                            Intrinsics.checkExpressionValueIsNotNull(allByteArray, "bb.allByteArray");
                            fileUploadHolder.write(allByteArray);
                            bb.recycle();
                        }
                    });
                } else if (multipartFormDataBody.getDataCallback() != null) {
                } else {
                    multipartFormDataBody.setDataCallback(new DataCallback() { // from class: com.tdo.showbox.service.WebUploadService.startServer.8.1.2
                        @Override // com.koushikdutta.async.callback.DataCallback
                        public final void onDataAvailable(DataEmitter dataEmitter, ByteBufferList bb) {
                            WebUploadService.FileUploadHolder fileUploadHolder;
                            String str;
                            try {
                                Intrinsics.checkExpressionValueIsNotNull(bb, "bb");
                                byte[] allByteArray = bb.getAllByteArray();
                                Intrinsics.checkExpressionValueIsNotNull(allByteArray, "bb.allByteArray");
                                String fileName = URLDecoder.decode(new String(allByteArray, Charsets.UTF_8), "UTF-8");
                                fileUploadHolder = WebUploadService$startServer$8.this.this$0.fileUploadHolder;
                                Intrinsics.checkExpressionValueIsNotNull(fileName, "fileName");
                                str = WebUploadService$startServer$8.this.this$0.saveDir;
                                fileUploadHolder.setFileName(fileName, str);
                            } catch (UnsupportedEncodingException e) {
                                e.printStackTrace();
                            }
                            bb.recycle();
                        }
                    });
                }
            }
        });
        request.setEndCallback(new CompletedCallback() { // from class: com.tdo.showbox.service.WebUploadService$startServer$8.2
            @Override // com.koushikdutta.async.callback.CompletedCallback
            public final void onCompleted(Exception exc) {
                WebUploadService.FileUploadHolder fileUploadHolder;
                fileUploadHolder = WebUploadService$startServer$8.this.this$0.fileUploadHolder;
                fileUploadHolder.reset();
                asyncHttpServerResponse.end();
                CommonExtKt.onMobEvent(WebUploadService$startServer$8.this.this$0, "WiFiUploadSubtitles_Uploaded");
                EventBus.getDefault().post(new LoadUploadSubtitleEvent());
            }
        });
    }
}
