package com.tdo.showbox.service;

import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.IBinder;
import com.hpplay.cybergarage.xml.XML;
import com.koushikdutta.async.AsyncServer;
import com.koushikdutta.async.http.Headers;
import com.koushikdutta.async.http.body.AsyncHttpRequestBody;
import com.koushikdutta.async.http.body.UrlEncodedFormBody;
import com.koushikdutta.async.http.server.AsyncHttpServer;
import com.koushikdutta.async.http.server.AsyncHttpServerRequest;
import com.koushikdutta.async.http.server.AsyncHttpServerResponse;
import com.koushikdutta.async.http.server.HttpServerRequestCallback;
import com.mintegral.msdk.base.entity.CampaignEx;
import com.tdo.showbox.app.App;
import com.tdo.showbox.app.Constant;
import com.tdo.showbox.event.LoadUploadSubtitleEvent;
import com.tdo.showbox.service.WebUploadService;
import com.tencent.tinker.loader.shareutil.SharePatchInfo;
import com.umeng.analytics.pro.b;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.text.DecimalFormat;
import kotlin.Metadata;
import kotlin.TypeCastException;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;
import org.greenrobot.eventbus.EventBus;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
/* compiled from: WebUploadService.kt */
@Metadata(bv = {1, 0, 3}, d1 = {"\u0000P\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\u0018\u0000 \u001f2\u00020\u0001:\u0002\u001f B\u0005¢\u0006\u0002\u0010\u0002J\u0010\u0010\f\u001a\u00020\u00062\u0006\u0010\r\u001a\u00020\u0006H\u0002J\b\u0010\u000e\u001a\u00020\u0006H\u0002J\u0012\u0010\u000f\u001a\u0004\u0018\u00010\u00102\u0006\u0010\u0011\u001a\u00020\u0012H\u0016J\b\u0010\u0013\u001a\u00020\u0014H\u0016J\"\u0010\u0015\u001a\u00020\u00162\b\u0010\u0011\u001a\u0004\u0018\u00010\u00122\u0006\u0010\u0017\u001a\u00020\u00162\u0006\u0010\u0018\u001a\u00020\u0016H\u0016J\u001c\u0010\u0019\u001a\u00020\u00142\b\u0010\u001a\u001a\u0004\u0018\u00010\u001b2\b\u0010\u001c\u001a\u0004\u0018\u00010\u001dH\u0002J\b\u0010\u001e\u001a\u00020\u0014H\u0002R\u000e\u0010\u0003\u001a\u00020\u0004X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0005\u001a\u00020\u0006X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\bX\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\t\u001a\u00020\u0006X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\n\u001a\u00020\u000bX\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006!"}, d2 = {"Lcom/tdo/showbox/service/WebUploadService;", "Landroid/app/Service;", "()V", "fileUploadHolder", "Lcom/tdo/showbox/service/WebUploadService$FileUploadHolder;", "id", "", "mAsyncServer", "Lcom/koushikdutta/async/AsyncServer;", "saveDir", "server", "Lcom/koushikdutta/async/http/server/AsyncHttpServer;", "getContentTypeByResourceName", "resourceName", "getIndexContent", "onBind", "Landroid/os/IBinder;", "intent", "Landroid/content/Intent;", "onDestroy", "", "onStartCommand", "", "flags", "startId", "sendResources", "request", "Lcom/koushikdutta/async/http/server/AsyncHttpServerRequest;", "response", "Lcom/koushikdutta/async/http/server/AsyncHttpServerResponse;", "startServer", "Companion", "FileUploadHolder", "app_webRelease"}, k = 1, mv = {1, 1, 16})
/* loaded from: classes3.dex */
public final class WebUploadService extends Service {
    private static final String ACTION_START_WEB_SERVICE = "com.snowtop.moviebox.action.START_WEB_SERVICE";
    private static final String ACTION_STOP_WEB_SERVICE = "com.snowtop.moviebox.action.STOP_WEB_SERVICE";
    private static final String BINARY_CONTENT_TYPE = "application/octet-stream";
    private static final String CSS_CONTENT_TYPE = "text/css;charset=utf-8";
    public static final Companion Companion = new Companion(null);
    private static final String EOT_CONTENT_TYPE = "image/vnd.ms-fontobject";
    private static final String JPG_CONTENT_TYPE = "application/jpeg";
    private static final String JS_CONTENT_TYPE = "application/javascript";
    private static final String MP3_CONTENT_TYPE = "audio/mp3";
    private static final String MP4_CONTENT_TYPE = "video/mpeg4";
    private static final String PNG_CONTENT_TYPE = "application/x-png";
    private static final String SVG_CONTENT_TYPE = "image/svg+xml";
    private static final String SWF_CONTENT_TYPE = "application/x-shockwave-flash";
    private static final String TEXT_CONTENT_TYPE = "text/html;charset=utf-8";
    private static final String TTF_CONTENT_TYPE = "application/x-font-truetype";
    private static final String WOFF_CONTENT_TYPE = "application/x-font-woff";
    private final FileUploadHolder fileUploadHolder = new FileUploadHolder();
    private final AsyncHttpServer server = new AsyncHttpServer();
    private final AsyncServer mAsyncServer = new AsyncServer();
    private String id = "";
    private String saveDir = "";

    @Override // android.app.Service
    public IBinder onBind(Intent intent) {
        Intrinsics.checkParameterIsNotNull(intent, "intent");
        return null;
    }

    /* compiled from: WebUploadService.kt */
    @Metadata(bv = {1, 0, 3}, d1 = {"\u0000(\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u000f\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\b\u0086\u0003\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J\u0016\u0010\u0013\u001a\u00020\u00142\u0006\u0010\u0015\u001a\u00020\u00162\u0006\u0010\u0017\u001a\u00020\u0018J\u000e\u0010\u0019\u001a\u00020\u00142\u0006\u0010\u0015\u001a\u00020\u0016R\u000e\u0010\u0003\u001a\u00020\u0004X\u0082T¢\u0006\u0002\n\u0000R\u000e\u0010\u0005\u001a\u00020\u0004X\u0082T¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0004X\u0082T¢\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\u0004X\u0082T¢\u0006\u0002\n\u0000R\u000e\u0010\b\u001a\u00020\u0004X\u0082T¢\u0006\u0002\n\u0000R\u000e\u0010\t\u001a\u00020\u0004X\u0082T¢\u0006\u0002\n\u0000R\u000e\u0010\n\u001a\u00020\u0004X\u0082T¢\u0006\u0002\n\u0000R\u000e\u0010\u000b\u001a\u00020\u0004X\u0082T¢\u0006\u0002\n\u0000R\u000e\u0010\f\u001a\u00020\u0004X\u0082T¢\u0006\u0002\n\u0000R\u000e\u0010\r\u001a\u00020\u0004X\u0082T¢\u0006\u0002\n\u0000R\u000e\u0010\u000e\u001a\u00020\u0004X\u0082T¢\u0006\u0002\n\u0000R\u000e\u0010\u000f\u001a\u00020\u0004X\u0082T¢\u0006\u0002\n\u0000R\u000e\u0010\u0010\u001a\u00020\u0004X\u0082T¢\u0006\u0002\n\u0000R\u000e\u0010\u0011\u001a\u00020\u0004X\u0082T¢\u0006\u0002\n\u0000R\u000e\u0010\u0012\u001a\u00020\u0004X\u0082T¢\u0006\u0002\n\u0000¨\u0006\u001a"}, d2 = {"Lcom/tdo/showbox/service/WebUploadService$Companion;", "", "()V", "ACTION_START_WEB_SERVICE", "", "ACTION_STOP_WEB_SERVICE", "BINARY_CONTENT_TYPE", "CSS_CONTENT_TYPE", "EOT_CONTENT_TYPE", "JPG_CONTENT_TYPE", "JS_CONTENT_TYPE", "MP3_CONTENT_TYPE", "MP4_CONTENT_TYPE", "PNG_CONTENT_TYPE", "SVG_CONTENT_TYPE", "SWF_CONTENT_TYPE", "TEXT_CONTENT_TYPE", "TTF_CONTENT_TYPE", "WOFF_CONTENT_TYPE", CampaignEx.JSON_NATIVE_VIDEO_START, "", b.M, "Landroid/content/Context;", "bundle", "Landroid/os/Bundle;", "stop", "app_webRelease"}, k = 1, mv = {1, 1, 16})
    /* loaded from: classes3.dex */
    public static final class Companion {
        private Companion() {
        }

        public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        public final void start(Context context, Bundle bundle) {
            Intrinsics.checkParameterIsNotNull(context, "context");
            Intrinsics.checkParameterIsNotNull(bundle, "bundle");
            Intent intent = new Intent(context, WebUploadService.class);
            intent.setAction(WebUploadService.ACTION_START_WEB_SERVICE);
            intent.putExtras(bundle);
            context.startService(intent);
        }

        public final void stop(Context context) {
            Intrinsics.checkParameterIsNotNull(context, "context");
            Intent intent = new Intent(context, WebUploadService.class);
            intent.setAction(WebUploadService.ACTION_STOP_WEB_SERVICE);
            context.stopService(intent);
        }
    }

    @Override // android.app.Service
    public int onStartCommand(Intent intent, int i, int i2) {
        String str;
        String str2;
        String action = intent != null ? intent.getAction() : null;
        Bundle extras = intent != null ? intent.getExtras() : null;
        if (extras == null || (str = extras.getString("id")) == null) {
            str = "";
        }
        this.id = str;
        Integer valueOf = extras != null ? Integer.valueOf(extras.getInt("season")) : null;
        Integer valueOf2 = extras != null ? Integer.valueOf(extras.getInt("episode")) : null;
        String string = extras != null ? extras.getString("name") : null;
        if ((valueOf == null || valueOf.intValue() != 0) && (valueOf2 == null || valueOf2.intValue() != 0)) {
            str2 = Constant.DIR_UPLOAD_TV_SUBTITLE + File.separator + this.id + File.separator + string + File.separator + "Season " + valueOf + File.separator + "Episode " + valueOf2 + File.separator + App.deviceLang;
        } else {
            str2 = Constant.DIR_UPLOAD_MOVIE_SUBTITLE + File.separator + this.id + File.separator + string + File.separator + App.deviceLang;
        }
        this.saveDir = str2;
        if (StringsKt.equals$default(action, ACTION_START_WEB_SERVICE, false, 2, null)) {
            startServer();
        }
        return super.onStartCommand(intent, i, i2);
    }

    @Override // android.app.Service
    public void onDestroy() {
        super.onDestroy();
        this.server.stop();
        this.mAsyncServer.stop();
    }

    private final void startServer() {
        this.server.get("/images/.*", new HttpServerRequestCallback() { // from class: com.tdo.showbox.service.WebUploadService$startServer$1
            @Override // com.koushikdutta.async.http.server.HttpServerRequestCallback
            public final void onRequest(AsyncHttpServerRequest asyncHttpServerRequest, AsyncHttpServerResponse asyncHttpServerResponse) {
                WebUploadService.this.sendResources(asyncHttpServerRequest, asyncHttpServerResponse);
            }
        });
        this.server.get("/scripts/.*", new HttpServerRequestCallback() { // from class: com.tdo.showbox.service.WebUploadService$startServer$2
            @Override // com.koushikdutta.async.http.server.HttpServerRequestCallback
            public final void onRequest(AsyncHttpServerRequest asyncHttpServerRequest, AsyncHttpServerResponse asyncHttpServerResponse) {
                WebUploadService.this.sendResources(asyncHttpServerRequest, asyncHttpServerResponse);
            }
        });
        this.server.get("/css/.*", new HttpServerRequestCallback() { // from class: com.tdo.showbox.service.WebUploadService$startServer$3
            @Override // com.koushikdutta.async.http.server.HttpServerRequestCallback
            public final void onRequest(AsyncHttpServerRequest asyncHttpServerRequest, AsyncHttpServerResponse asyncHttpServerResponse) {
                WebUploadService.this.sendResources(asyncHttpServerRequest, asyncHttpServerResponse);
            }
        });
        this.server.get("/", new HttpServerRequestCallback() { // from class: com.tdo.showbox.service.WebUploadService$startServer$4
            @Override // com.koushikdutta.async.http.server.HttpServerRequestCallback
            public final void onRequest(AsyncHttpServerRequest asyncHttpServerRequest, AsyncHttpServerResponse asyncHttpServerResponse) {
                AsyncHttpServerResponse code;
                String indexContent;
                if (asyncHttpServerResponse != null) {
                    try {
                        indexContent = WebUploadService.this.getIndexContent();
                        asyncHttpServerResponse.send(indexContent);
                    } catch (IOException e) {
                        e.printStackTrace();
                        if (asyncHttpServerResponse == null || (code = asyncHttpServerResponse.code(500)) == null) {
                            return;
                        }
                        code.end();
                    }
                }
            }
        });
        this.server.get("/files", new HttpServerRequestCallback() { // from class: com.tdo.showbox.service.WebUploadService$startServer$5
            @Override // com.koushikdutta.async.http.server.HttpServerRequestCallback
            public final void onRequest(AsyncHttpServerRequest asyncHttpServerRequest, AsyncHttpServerResponse asyncHttpServerResponse) {
                String str;
                String[] list;
                JSONArray jSONArray = new JSONArray();
                str = WebUploadService.this.saveDir;
                File file = new File(str);
                if (file.exists() && file.isDirectory() && (list = file.list()) != null) {
                    for (String str2 : list) {
                        File file2 = new File(file, str2);
                        if (file2.exists() && file2.isFile()) {
                            try {
                                JSONObject jSONObject = new JSONObject();
                                jSONObject.put("name", str2);
                                long length = file2.length();
                                DecimalFormat decimalFormat = new DecimalFormat("0.00");
                                if (length > 1048576) {
                                    jSONObject.put("size", decimalFormat.format(((((float) length) * 1.0f) / 1024.0f) / 1024.0f) + "MB");
                                } else if (length > 1024) {
                                    jSONObject.put("size", decimalFormat.format((((float) length) * 1.0f) / 1024) + "KB");
                                } else {
                                    jSONObject.put("size", String.valueOf(length) + "B");
                                }
                                jSONArray.put(jSONObject);
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }
                    }
                }
                asyncHttpServerResponse.send(jSONArray.toString());
            }
        });
        this.server.post("/files/.*", new HttpServerRequestCallback() { // from class: com.tdo.showbox.service.WebUploadService$startServer$6
            @Override // com.koushikdutta.async.http.server.HttpServerRequestCallback
            public final void onRequest(AsyncHttpServerRequest request, AsyncHttpServerResponse asyncHttpServerResponse) {
                String str;
                Intrinsics.checkExpressionValueIsNotNull(request, "request");
                AsyncHttpRequestBody body = request.getBody();
                if (body == null) {
                    throw new TypeCastException("null cannot be cast to non-null type com.koushikdutta.async.http.body.UrlEncodedFormBody");
                }
                if (StringsKt.equals("delete", ((UrlEncodedFormBody) body).mo497get().getString("_method"), true)) {
                    String path = request.getPath();
                    Intrinsics.checkExpressionValueIsNotNull(path, "request.path");
                    String replace$default = StringsKt.replace$default(path, "/files/", "", false, 4, (Object) null);
                    try {
                        String decode = URLDecoder.decode(replace$default, XML.CHARSET_UTF8);
                        Intrinsics.checkExpressionValueIsNotNull(decode, "URLDecoder.decode(path, \"utf-8\")");
                        replace$default = decode;
                    } catch (UnsupportedEncodingException e) {
                        e.printStackTrace();
                    }
                    str = WebUploadService.this.saveDir;
                    File file = new File(str, replace$default);
                    if (file.exists() && file.isFile()) {
                        file.delete();
                        EventBus.getDefault().post(new LoadUploadSubtitleEvent());
                    }
                }
                asyncHttpServerResponse.end();
            }
        });
        this.server.get("/files/.*", new HttpServerRequestCallback() { // from class: com.tdo.showbox.service.WebUploadService$startServer$7
            @Override // com.koushikdutta.async.http.server.HttpServerRequestCallback
            public final void onRequest(AsyncHttpServerRequest asyncHttpServerRequest, AsyncHttpServerResponse response) {
                String str;
                String path;
                String replace$default = (asyncHttpServerRequest == null || (path = asyncHttpServerRequest.getPath()) == null) ? null : StringsKt.replace$default(path, "/files/", "", false, 4, (Object) null);
                try {
                    replace$default = URLEncoder.encode(replace$default, XML.CHARSET_UTF8);
                } catch (UnsupportedEncodingException e) {
                    e.printStackTrace();
                }
                str = WebUploadService.this.saveDir;
                File file = new File(str, replace$default);
                if (file.exists() && file.isFile()) {
                    try {
                        Intrinsics.checkExpressionValueIsNotNull(response, "response");
                        Headers headers = response.getHeaders();
                        if (headers != null) {
                            headers.add("Content-Disposition", "attachment;filename=" + URLEncoder.encode(file.getName(), XML.CHARSET_UTF8));
                        }
                    } catch (UnsupportedEncodingException e2) {
                        e2.printStackTrace();
                    }
                    response.sendFile(file);
                    return;
                }
                response.code(404).send("Not found");
            }
        });
        this.server.post("/files", new WebUploadService$startServer$8(this));
        this.server.get("/progress/.*", new HttpServerRequestCallback() { // from class: com.tdo.showbox.service.WebUploadService$startServer$9
            @Override // com.koushikdutta.async.http.server.HttpServerRequestCallback
            public final void onRequest(AsyncHttpServerRequest request, AsyncHttpServerResponse asyncHttpServerResponse) {
                WebUploadService.FileUploadHolder fileUploadHolder;
                WebUploadService.FileUploadHolder fileUploadHolder2;
                WebUploadService.FileUploadHolder fileUploadHolder3;
                WebUploadService.FileUploadHolder fileUploadHolder4;
                JSONObject jSONObject = new JSONObject();
                Intrinsics.checkExpressionValueIsNotNull(request, "request");
                String path = request.getPath();
                Intrinsics.checkExpressionValueIsNotNull(path, "request.path");
                String replace$default = StringsKt.replace$default(path, "/progress/", "", false, 4, (Object) null);
                fileUploadHolder = WebUploadService.this.fileUploadHolder;
                if (Intrinsics.areEqual(replace$default, fileUploadHolder.getFileName())) {
                    try {
                        fileUploadHolder2 = WebUploadService.this.fileUploadHolder;
                        jSONObject.put("fileName", fileUploadHolder2.getFileName());
                        fileUploadHolder3 = WebUploadService.this.fileUploadHolder;
                        jSONObject.put("size", fileUploadHolder3.getTotalSize());
                        fileUploadHolder4 = WebUploadService.this.fileUploadHolder;
                        jSONObject.put("progress", fileUploadHolder4.getOutPutStream() == null ? 1 : Double.valueOf(0.1d));
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
                asyncHttpServerResponse.send(jSONObject);
            }
        });
        this.server.listen(this.mAsyncServer, Constant.HTTP_PORT);
        this.server.getListenCallback();
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Removed duplicated region for block: B:25:0x0060 A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final java.lang.String getIndexContent() throws java.io.IOException {
        /*
            r6 = this;
            r0 = 0
            java.io.BufferedInputStream r0 = (java.io.BufferedInputStream) r0
            java.io.BufferedInputStream r1 = new java.io.BufferedInputStream     // Catch: java.lang.Throwable -> L4e java.io.IOException -> L53
            android.content.res.AssetManager r2 = r6.getAssets()     // Catch: java.lang.Throwable -> L4e java.io.IOException -> L53
            java.lang.String r3 = "wifi/index.html"
            java.io.InputStream r2 = r2.open(r3)     // Catch: java.lang.Throwable -> L4e java.io.IOException -> L53
            r1.<init>(r2)     // Catch: java.lang.Throwable -> L4e java.io.IOException -> L53
            java.io.ByteArrayOutputStream r0 = new java.io.ByteArrayOutputStream     // Catch: java.io.IOException -> L4c java.lang.Throwable -> L5d
            r0.<init>()     // Catch: java.io.IOException -> L4c java.lang.Throwable -> L5d
            r2 = 10240(0x2800, float:1.4349E-41)
            byte[] r2 = new byte[r2]     // Catch: java.io.IOException -> L4c java.lang.Throwable -> L5d
            int r3 = r1.read(r2)     // Catch: java.io.IOException -> L4c java.lang.Throwable -> L5d
        L1f:
            if (r3 <= 0) goto L2a
            r4 = 0
            r0.write(r2, r4, r3)     // Catch: java.io.IOException -> L4c java.lang.Throwable -> L5d
            int r3 = r1.read(r2)     // Catch: java.io.IOException -> L4c java.lang.Throwable -> L5d
            goto L1f
        L2a:
            byte[] r0 = r0.toByteArray()     // Catch: java.io.IOException -> L4c java.lang.Throwable -> L5d
            java.lang.String r2 = "baos.toByteArray()"
            kotlin.jvm.internal.Intrinsics.checkExpressionValueIsNotNull(r0, r2)     // Catch: java.io.IOException -> L4c java.lang.Throwable -> L5d
            java.lang.String r2 = "utf-8"
            java.nio.charset.Charset r2 = java.nio.charset.Charset.forName(r2)     // Catch: java.io.IOException -> L4c java.lang.Throwable -> L5d
            java.lang.String r3 = "Charset.forName(\"utf-8\")"
            kotlin.jvm.internal.Intrinsics.checkExpressionValueIsNotNull(r2, r3)     // Catch: java.io.IOException -> L4c java.lang.Throwable -> L5d
            java.lang.String r3 = new java.lang.String     // Catch: java.io.IOException -> L4c java.lang.Throwable -> L5d
            r3.<init>(r0, r2)     // Catch: java.io.IOException -> L4c java.lang.Throwable -> L5d
            r1.close()     // Catch: java.io.IOException -> L47
            goto L4b
        L47:
            r0 = move-exception
            r0.printStackTrace()
        L4b:
            return r3
        L4c:
            r0 = move-exception
            goto L57
        L4e:
            r1 = move-exception
            r5 = r1
            r1 = r0
            r0 = r5
            goto L5e
        L53:
            r1 = move-exception
            r5 = r1
            r1 = r0
            r0 = r5
        L57:
            r0.printStackTrace()     // Catch: java.lang.Throwable -> L5d
            java.lang.Throwable r0 = (java.lang.Throwable) r0     // Catch: java.lang.Throwable -> L5d
            throw r0     // Catch: java.lang.Throwable -> L5d
        L5d:
            r0 = move-exception
        L5e:
            if (r1 == 0) goto L68
            r1.close()     // Catch: java.io.IOException -> L64
            goto L68
        L64:
            r1 = move-exception
            r1.printStackTrace()
        L68:
            goto L6a
        L69:
            throw r0
        L6a:
            goto L69
        */
        throw new UnsupportedOperationException("Method not decompiled: com.tdo.showbox.service.WebUploadService.getIndexContent():java.lang.String");
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void sendResources(AsyncHttpServerRequest asyncHttpServerRequest, AsyncHttpServerResponse asyncHttpServerResponse) {
        String path;
        String str = null;
        if (asyncHttpServerRequest != null) {
            try {
                path = asyncHttpServerRequest.getPath();
            } catch (IOException e) {
                e.printStackTrace();
                return;
            }
        } else {
            path = null;
        }
        String replace$default = path != null ? StringsKt.replace$default(path, "%20", " ", false, 4, (Object) null) : null;
        boolean z = true;
        if (replace$default != null && StringsKt.startsWith$default(replace$default, "/", false, 2, (Object) null)) {
            replace$default = replace$default.substring(1);
            Intrinsics.checkExpressionValueIsNotNull(replace$default, "(this as java.lang.String).substring(startIndex)");
        }
        if ((replace$default != null ? StringsKt.indexOf$default((CharSequence) replace$default, "?", 0, false, 6, (Object) null) : -1) > 0) {
            if (replace$default != null) {
                int indexOf$default = StringsKt.indexOf$default((CharSequence) replace$default, "?", 0, false, 6, (Object) null);
                if (replace$default == null) {
                    throw new TypeCastException("null cannot be cast to non-null type java.lang.String");
                }
                str = replace$default.substring(0, indexOf$default);
                Intrinsics.checkExpressionValueIsNotNull(str, "(this as java.lang.Strin…ing(startIndex, endIndex)");
            }
            replace$default = str;
        }
        String str2 = "";
        if (getContentTypeByResourceName(replace$default != null ? replace$default : str2).length() <= 0) {
            z = false;
        }
        if (z && asyncHttpServerResponse != null) {
            if (replace$default != null) {
                str2 = replace$default;
            }
            asyncHttpServerResponse.setContentType(getContentTypeByResourceName(str2));
        }
        BufferedInputStream bufferedInputStream = new BufferedInputStream(getAssets().open("wifi/" + replace$default));
        if (asyncHttpServerResponse != null) {
            asyncHttpServerResponse.sendStream(bufferedInputStream, bufferedInputStream.available());
        }
    }

    private final String getContentTypeByResourceName(String str) {
        return StringsKt.endsWith$default(str, ".css", false, 2, (Object) null) ? CSS_CONTENT_TYPE : StringsKt.endsWith$default(str, ".js", false, 2, (Object) null) ? "application/javascript" : StringsKt.endsWith$default(str, ".swf", false, 2, (Object) null) ? SWF_CONTENT_TYPE : StringsKt.endsWith$default(str, ".png", false, 2, (Object) null) ? PNG_CONTENT_TYPE : (StringsKt.endsWith$default(str, ".jpg", false, 2, (Object) null) || StringsKt.endsWith$default(str, ".jpeg", false, 2, (Object) null)) ? JPG_CONTENT_TYPE : StringsKt.endsWith$default(str, ".woff", false, 2, (Object) null) ? WOFF_CONTENT_TYPE : StringsKt.endsWith$default(str, ".ttf", false, 2, (Object) null) ? TTF_CONTENT_TYPE : StringsKt.endsWith$default(str, ".svg", false, 2, (Object) null) ? SVG_CONTENT_TYPE : StringsKt.endsWith$default(str, ".eot", false, 2, (Object) null) ? EOT_CONTENT_TYPE : StringsKt.endsWith$default(str, ".mp3", false, 2, (Object) null) ? MP3_CONTENT_TYPE : StringsKt.endsWith$default(str, ".mp4", false, 2, (Object) null) ? MP4_CONTENT_TYPE : "";
    }

    /* compiled from: WebUploadService.kt */
    @Metadata(bv = {1, 0, 3}, d1 = {"\u00004\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\t\n\u0002\b\u0004\n\u0002\u0010\u0002\n\u0002\b\u0004\n\u0002\u0010\u0012\n\u0000\u0018\u00002\u00020\u0001B\u0005¢\u0006\u0002\u0010\u0002J\b\u0010\u000b\u001a\u0004\u0018\u00010\u0004J\b\u0010\f\u001a\u0004\u0018\u00010\u0006J\u0006\u0010\r\u001a\u00020\nJ\u0006\u0010\u000e\u001a\u00020\u000fJ\u0016\u0010\u0010\u001a\u00020\u000f2\u0006\u0010\u0003\u001a\u00020\u00042\u0006\u0010\u0011\u001a\u00020\u0004J\u000e\u0010\u0012\u001a\u00020\u000f2\u0006\u0010\u0013\u001a\u00020\u0014R\u0010\u0010\u0003\u001a\u0004\u0018\u00010\u0004X\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010\u0005\u001a\u0004\u0018\u00010\u0006X\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010\u0007\u001a\u0004\u0018\u00010\bX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\t\u001a\u00020\nX\u0082\u000e¢\u0006\u0002\n\u0000¨\u0006\u0015"}, d2 = {"Lcom/tdo/showbox/service/WebUploadService$FileUploadHolder;", "", "()V", "fileName", "", "fileOutPutStream", "Ljava/io/BufferedOutputStream;", "reveivedFile", "Ljava/io/File;", "totalSize", "", "getFileName", "getOutPutStream", "getTotalSize", "reset", "", "setFileName", SharePatchInfo.OAT_DIR, "write", "data", "", "app_webRelease"}, k = 1, mv = {1, 1, 16})
    /* loaded from: classes3.dex */
    public static final class FileUploadHolder {
        private String fileName;
        private BufferedOutputStream fileOutPutStream;
        private File reveivedFile;
        private long totalSize;

        public final void setFileName(String fileName, String dir) {
            Intrinsics.checkParameterIsNotNull(fileName, "fileName");
            Intrinsics.checkParameterIsNotNull(dir, "dir");
            this.fileName = fileName;
            this.totalSize = 0L;
            File file = new File(dir);
            if (!file.exists()) {
                file.mkdirs();
            }
            this.reveivedFile = new File(file, this.fileName);
            try {
                this.fileOutPutStream = new BufferedOutputStream(new FileOutputStream(this.reveivedFile));
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }
        }

        public final String getFileName() {
            return this.fileName;
        }

        public final long getTotalSize() {
            return this.totalSize;
        }

        public final BufferedOutputStream getOutPutStream() {
            return this.fileOutPutStream;
        }

        public final void reset() {
            try {
                BufferedOutputStream bufferedOutputStream = this.fileOutPutStream;
                if (bufferedOutputStream != null) {
                    bufferedOutputStream.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
            this.fileOutPutStream = null;
        }

        public final void write(byte[] data) {
            Intrinsics.checkParameterIsNotNull(data, "data");
            try {
                BufferedOutputStream bufferedOutputStream = this.fileOutPutStream;
                if (bufferedOutputStream != null) {
                    bufferedOutputStream.write(data);
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
            this.totalSize += data.length;
        }
    }
}
