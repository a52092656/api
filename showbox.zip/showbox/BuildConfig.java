package com.tdo.showbox;
/* loaded from: classes3.dex */
public final class BuildConfig {
    public static final String APPLICATION_ID = "com.tdo.showbox";
    public static final String BUGLY_APP_ID = "de5d255deb";
    public static final String BUGLY_APP_KEY = "18cea59a-23de-41a6-9209-0edb1d477db1";
    public static final String BUILD_TYPE = "release";
    public static final String CHANNEL = "Website";
    public static final boolean DEBUG = false;
    public static final String FLAVOR = "web";
    public static final String GOOGLE_APP_ID = "ca-app-pub-7057538472703038~1443445625";
    public static final String GOOGLE_APP_KEY = "ca-app-pub-7057538472703038/7008184374";
    public static final String GOOGLE_BANNER_APP_KEY = "ca-app-pub-2446756197279868/3285546619";
    public static final String GOOGLE_CLIENT_ID = "939879918880-jjuj402e4h5bh693825u7ef98ntkh6rc.apps.googleusercontent.com";
    public static final String ONLINE_PARAMS_URL = "https://www.mini-install.com/api/index/get_param_encryption_id.html?id=86";
    public static final String QQ_APP_ID = "1106286184";
    public static final String QQ_APP_KEY = "ibpaqfd57fxXL2vJ";
    public static final String UM_APP_KEY = "61c46e41e014255fcbc76393";
    public static final int VERSION_CODE = 129;
    public static final String VERSION_NAME = "11.5";
    public static final String WX_APP_ID = "wx345e83d55e7f0d3d";
    public static final String WX_APP_SECRET = "13bf7972d5b11ecab5df50d2b4d29c79";
    public static final boolean isDebug = false;
    public static final boolean isTest = false;
    public static final String password = "";
    public static final String username = "";
}
