package com.tdo.showbox.adapter;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.viewholder.BaseViewHolder;
import java.util.ArrayList;
/* loaded from: classes3.dex */
public class NothingAdapter extends BaseQuickAdapter<String, BaseViewHolder> {
    /* JADX INFO: Access modifiers changed from: protected */
    @Override // com.chad.library.adapter.base.BaseQuickAdapter
    public void convert(BaseViewHolder baseViewHolder, String str) {
    }

    public NothingAdapter(int i) {
        super(i);
    }

    public NothingAdapter(int i, int i2) {
        super(i);
        ArrayList arrayList = new ArrayList(i2);
        for (int i3 = 0; i3 < i2; i3++) {
            arrayList.add("");
        }
        setNewData(arrayList);
    }
}
