package com.tdo.showbox.adapter;

import android.view.View;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.delegate.BaseMultiTypeDelegate;
import com.chad.library.adapter.base.listener.OnItemChildClickListener;
import com.chad.library.adapter.base.listener.OnItemClickListener;
import com.chad.library.adapter.base.viewholder.BaseViewHolder;
import com.github.rubensousa.gravitysnaphelper.GravitySnapHelper;
import com.google.android.gms.common.internal.ServiceSpecificExtraArgs;
import com.hpplay.sdk.source.protocol.f;
import com.tdo.showbox.R;
import com.tdo.showbox.adapter.FeaturedAdapter;
import com.tdo.showbox.app.App;
import com.tdo.showbox.model.common.Homelist;
import com.tdo.showbox.utils.CommonExtKt;
import com.tdo.showbox.utils.CommonUtils;
import com.tdo.showbox.utils.DensityUtils;
import com.tdo.showbox.utils.GlideUtils;
import com.tdo.showbox.utils.LinearItemDecoration;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.StringCompanionObject;
/* compiled from: FeaturedAdapter.kt */
@Metadata(bv = {1, 0, 3}, d1 = {"\u0000\"\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0006\u0018\u00002\u000e\u0012\u0004\u0012\u00020\u0002\u0012\u0004\u0012\u00020\u00030\u0001:\u0002\f\rB\u0005¢\u0006\u0002\u0010\u0004J\u0018\u0010\u0007\u001a\u00020\b2\u0006\u0010\t\u001a\u00020\u00032\u0006\u0010\n\u001a\u00020\u0002H\u0014J\u000e\u0010\u000b\u001a\u00020\b2\u0006\u0010\u0005\u001a\u00020\u0006R\u0010\u0010\u0005\u001a\u0004\u0018\u00010\u0006X\u0082\u000e¢\u0006\u0002\n\u0000¨\u0006\u000e"}, d2 = {"Lcom/tdo/showbox/adapter/FeaturedAdapter;", "Lcom/chad/library/adapter/base/BaseQuickAdapter;", "Lcom/tdo/showbox/model/common/Homelist;", "Lcom/chad/library/adapter/base/viewholder/BaseViewHolder;", "()V", ServiceSpecificExtraArgs.CastExtraArgs.LISTENER, "Lcom/tdo/showbox/adapter/FeaturedAdapter$OnFeaturedItemClickListener;", "convert", "", "helper", f.g, "setFeaturedItemClickListener", "FeaturedListAdapter", "OnFeaturedItemClickListener", "app_webRelease"}, k = 1, mv = {1, 1, 16})
/* loaded from: classes3.dex */
public final class FeaturedAdapter extends BaseQuickAdapter<Homelist, BaseViewHolder> {
    private OnFeaturedItemClickListener listener;

    /* compiled from: FeaturedAdapter.kt */
    @Metadata(bv = {1, 0, 3}, d1 = {"\u0000\"\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\bf\u0018\u00002\u00020\u0001J$\u0010\u0002\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u00052\b\u0010\u0006\u001a\u0004\u0018\u00010\u00072\b\u0010\b\u001a\u0004\u0018\u00010\tH&¨\u0006\n"}, d2 = {"Lcom/tdo/showbox/adapter/FeaturedAdapter$OnFeaturedItemClickListener;", "", "onItemClicked", "", "itemType", "", f.g, "Lcom/tdo/showbox/model/common/Homelist$Typelist;", "view", "Landroid/view/View;", "app_webRelease"}, k = 1, mv = {1, 1, 16})
    /* loaded from: classes3.dex */
    public interface OnFeaturedItemClickListener {
        void onItemClicked(int i, Homelist.Typelist typelist, View view);
    }

    public FeaturedAdapter() {
        super(R.layout.adapter_featured_item, null, 2, null);
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // com.chad.library.adapter.base.BaseQuickAdapter
    public void convert(final BaseViewHolder helper, final Homelist item) {
        Intrinsics.checkParameterIsNotNull(helper, "helper");
        Intrinsics.checkParameterIsNotNull(item, "item");
        TextView textView = (TextView) helper.getView(R.id.tvName);
        RecyclerView recyclerView = (RecyclerView) helper.getView(R.id.recyclerView);
        String str = item.name;
        if (str == null || str.length() == 0) {
            CommonExtKt.gone(textView);
        } else {
            CommonExtKt.visible(textView);
            textView.setText(item.name);
        }
        TextView textView2 = (TextView) helper.getView(R.id.tvMore);
        if (item.ismore == 1) {
            CommonExtKt.visible(textView2);
        } else {
            CommonExtKt.gone(textView2);
        }
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext(), 0, false));
        recyclerView.setNestedScrollingEnabled(false);
        new GravitySnapHelper(8388611).attachToRecyclerView(recyclerView);
        ArrayList arrayList = item.list;
        if (arrayList == null) {
            arrayList = new ArrayList();
        }
        final FeaturedListAdapter featuredListAdapter = new FeaturedListAdapter(arrayList);
        if (recyclerView.getTag() == null) {
            recyclerView.addItemDecoration(new LinearItemDecoration(0, 10, true));
            recyclerView.setTag("added");
        }
        recyclerView.setAdapter(featuredListAdapter);
        CommonExtKt.disableRefreshAnimation(recyclerView);
        featuredListAdapter.setOnItemClickListener(new OnItemClickListener() { // from class: com.tdo.showbox.adapter.FeaturedAdapter$convert$$inlined$let$lambda$1
            @Override // com.chad.library.adapter.base.listener.OnItemClickListener
            public final void onItemClick(BaseQuickAdapter<Object, BaseViewHolder> baseQuickAdapter, View view, int i) {
                FeaturedAdapter.OnFeaturedItemClickListener onFeaturedItemClickListener;
                Intrinsics.checkParameterIsNotNull(baseQuickAdapter, "<anonymous parameter 0>");
                Intrinsics.checkParameterIsNotNull(view, "<anonymous parameter 1>");
                Homelist.Typelist item2 = FeaturedAdapter.FeaturedListAdapter.this.getItem(i);
                View viewByPosition = FeaturedAdapter.FeaturedListAdapter.this.getViewByPosition(i, R.id.movie_item_poster);
                onFeaturedItemClickListener = this.listener;
                if (onFeaturedItemClickListener != null) {
                    onFeaturedItemClickListener.onItemClicked(item2.itemType, item2, viewByPosition);
                }
            }
        });
        featuredListAdapter.setOnItemChildClickListener(new OnItemChildClickListener() { // from class: com.tdo.showbox.adapter.FeaturedAdapter$convert$$inlined$let$lambda$2
            @Override // com.chad.library.adapter.base.listener.OnItemChildClickListener
            public final void onItemChildClick(BaseQuickAdapter<Object, BaseViewHolder> baseQuickAdapter, View view, int i) {
                FeaturedAdapter.OnFeaturedItemClickListener onFeaturedItemClickListener;
                Intrinsics.checkParameterIsNotNull(baseQuickAdapter, "<anonymous parameter 0>");
                Intrinsics.checkParameterIsNotNull(view, "view");
                Homelist.Typelist item2 = FeaturedAdapter.FeaturedListAdapter.this.getItem(i);
                onFeaturedItemClickListener = this.listener;
                if (onFeaturedItemClickListener != null) {
                    onFeaturedItemClickListener.onItemClicked(-100, item2, view);
                }
            }
        });
    }

    public final void setFeaturedItemClickListener(OnFeaturedItemClickListener listener) {
        Intrinsics.checkParameterIsNotNull(listener, "listener");
        this.listener = listener;
    }

    /* compiled from: FeaturedAdapter.kt */
    @Metadata(bv = {1, 0, 3}, d1 = {"\u0000.\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010!\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0002\b\u0004\n\u0002\u0010\u0011\n\u0002\u0018\u0002\n\u0002\b\u0003\u0018\u00002\u000e\u0012\u0004\u0012\u00020\u0002\u0012\u0004\u0012\u00020\u00030\u0001B\u0013\u0012\f\u0010\u0004\u001a\b\u0012\u0004\u0012\u00020\u00020\u0005¢\u0006\u0002\u0010\u0006J\u0018\u0010\u0007\u001a\u00020\b2\u0006\u0010\t\u001a\u00020\u00032\u0006\u0010\n\u001a\u00020\u0002H\u0014J!\u0010\u000b\u001a\u00020\b2\u0012\u0010\f\u001a\n\u0012\u0006\b\u0001\u0012\u00020\u000e0\r\"\u00020\u000eH\u0002¢\u0006\u0002\u0010\u000fJ!\u0010\u0010\u001a\u00020\b2\u0012\u0010\f\u001a\n\u0012\u0006\b\u0001\u0012\u00020\u000e0\r\"\u00020\u000eH\u0002¢\u0006\u0002\u0010\u000f¨\u0006\u0011"}, d2 = {"Lcom/tdo/showbox/adapter/FeaturedAdapter$FeaturedListAdapter;", "Lcom/tdo/showbox/adapter/BaseLoadmoreDelegateMultiAdapter;", "Lcom/tdo/showbox/model/common/Homelist$Typelist;", "Lcom/chad/library/adapter/base/viewholder/BaseViewHolder;", "list", "", "(Ljava/util/List;)V", "convert", "", "helper", f.g, "setViewGone", "views", "", "Landroid/view/View;", "([Landroid/view/View;)V", "setViewVisible", "app_webRelease"}, k = 1, mv = {1, 1, 16})
    /* loaded from: classes3.dex */
    public static final class FeaturedListAdapter extends BaseLoadmoreDelegateMultiAdapter<Homelist.Typelist, BaseViewHolder> {
        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public FeaturedListAdapter(List<Homelist.Typelist> list) {
            super(list);
            Intrinsics.checkParameterIsNotNull(list, "list");
            setMultiTypeDelegate(new BaseMultiTypeDelegate<Homelist.Typelist>() { // from class: com.tdo.showbox.adapter.FeaturedAdapter.FeaturedListAdapter.1
                @Override // com.chad.library.adapter.base.delegate.BaseMultiTypeDelegate
                public int getItemType(List<? extends Homelist.Typelist> data, int i) {
                    Intrinsics.checkParameterIsNotNull(data, "data");
                    return data.get(i).itemType;
                }
            });
            BaseMultiTypeDelegate<Homelist.Typelist> multiTypeDelegate = getMultiTypeDelegate();
            if (multiTypeDelegate == null) {
                Intrinsics.throwNpe();
            }
            multiTypeDelegate.addItemType(1, R.layout.layout_tvlist_item2);
            BaseMultiTypeDelegate<Homelist.Typelist> multiTypeDelegate2 = getMultiTypeDelegate();
            if (multiTypeDelegate2 == null) {
                Intrinsics.throwNpe();
            }
            multiTypeDelegate2.addItemType(2, R.layout.layout_continue_play);
            BaseMultiTypeDelegate<Homelist.Typelist> multiTypeDelegate3 = getMultiTypeDelegate();
            if (multiTypeDelegate3 == null) {
                Intrinsics.throwNpe();
            }
            multiTypeDelegate3.addItemType(4, R.layout.layout_tvlist_item);
            BaseMultiTypeDelegate<Homelist.Typelist> multiTypeDelegate4 = getMultiTypeDelegate();
            if (multiTypeDelegate4 == null) {
                Intrinsics.throwNpe();
            }
            multiTypeDelegate4.addItemType(3, R.layout.layout_movelist_item);
            BaseMultiTypeDelegate<Homelist.Typelist> multiTypeDelegate5 = getMultiTypeDelegate();
            if (multiTypeDelegate5 == null) {
                Intrinsics.throwNpe();
            }
            multiTypeDelegate5.addItemType(5, R.layout.adapter_home_actor_item);
            BaseMultiTypeDelegate<Homelist.Typelist> multiTypeDelegate6 = getMultiTypeDelegate();
            if (multiTypeDelegate6 == null) {
                Intrinsics.throwNpe();
            }
            multiTypeDelegate6.addItemType(6, R.layout.adapter_cat_item);
            BaseMultiTypeDelegate<Homelist.Typelist> multiTypeDelegate7 = getMultiTypeDelegate();
            if (multiTypeDelegate7 == null) {
                Intrinsics.throwNpe();
            }
            multiTypeDelegate7.addItemType(7, R.layout.adapter_featured_movie_list_image_item);
            BaseMultiTypeDelegate<Homelist.Typelist> multiTypeDelegate8 = getMultiTypeDelegate();
            if (multiTypeDelegate8 == null) {
                Intrinsics.throwNpe();
            }
            multiTypeDelegate8.addItemType(8, R.layout.adapter_home_ad_item);
            addChildClickViewIds(R.id.ivDetail);
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // com.chad.library.adapter.base.BaseQuickAdapter
        public void convert(BaseViewHolder helper, Homelist.Typelist item) {
            Intrinsics.checkParameterIsNotNull(helper, "helper");
            Intrinsics.checkParameterIsNotNull(item, "item");
            boolean z = false;
            switch (item.itemType) {
                case 2:
                    ImageView imageView = (ImageView) helper.getView(R.id.ivPoster);
                    ProgressBar progressBar = (ProgressBar) helper.getView(R.id.progressBar);
                    ImageView imageView2 = (ImageView) helper.getView(R.id.ivContinue);
                    TextView textView = (TextView) helper.getView(R.id.tvSeasonEpisode);
                    ImageView imageView3 = (ImageView) helper.getView(R.id.ivDetail);
                    String str = item.id;
                    if (str == null || str.length() == 0) {
                        GlideUtils.load(getContext(), (int) R.drawable.ic_movie_more, imageView);
                        setViewGone(progressBar, imageView2, textView);
                        CommonExtKt.gone(imageView3);
                        return;
                    }
                    CommonExtKt.visible(imageView2);
                    GlideUtils.loadCornerPortraitGifHolder(getContext(), item.poster, imageView, 8);
                    CommonExtKt.visible(progressBar);
                    CommonExtKt.visible(imageView3);
                    if (item.box_type == 2) {
                        if (item.getHistory() != null) {
                            Homelist.History history = item.getHistory();
                            Intrinsics.checkExpressionValueIsNotNull(history, "item.history");
                            progressBar.setMax(history.getRuntime() * 60);
                            Homelist.History history2 = item.getHistory();
                            Intrinsics.checkExpressionValueIsNotNull(history2, "item.history");
                            progressBar.setProgress(history2.getSeconds());
                            StringCompanionObject stringCompanionObject = StringCompanionObject.INSTANCE;
                            Homelist.History history3 = item.getHistory();
                            Intrinsics.checkExpressionValueIsNotNull(history3, "item.history");
                            Homelist.History history4 = item.getHistory();
                            Intrinsics.checkExpressionValueIsNotNull(history4, "item.history");
                            String format = String.format("S%s E%s", Arrays.copyOf(new Object[]{Integer.valueOf(history3.getSeason()), Integer.valueOf(history4.getEpisode())}, 2));
                            Intrinsics.checkExpressionValueIsNotNull(format, "java.lang.String.format(format, *args)");
                            CommonExtKt.textShadow$default(textView, format, 0, 0, 6, null);
                            CommonExtKt.visible(textView);
                            return;
                        }
                        CommonExtKt.gone(textView);
                        progressBar.setMax(1);
                        progressBar.setProgress(0);
                        return;
                    }
                    CommonExtKt.gone(textView);
                    progressBar.setMax(item.getRuntime() * 60);
                    progressBar.setProgress(item.getSeconds());
                    return;
                case 3:
                    ImageView imageView4 = (ImageView) helper.getView(R.id.movie_item_poster);
                    ImageView imageView5 = (ImageView) helper.getView(R.id.ivStar);
                    TextView textView2 = (TextView) helper.getView(R.id.tvImdbRating);
                    ImageView imageView6 = (ImageView) helper.getView(R.id.movie_item_desc);
                    String str2 = item.id;
                    if (str2 == null || str2.length() == 0) {
                        setViewGone(imageView5, textView2, imageView6);
                        GlideUtils.load(getContext(), (int) R.drawable.ic_movie_more, imageView4);
                        return;
                    }
                    ImageView imageView7 = imageView6;
                    CommonExtKt.visible(imageView7);
                    String imdb_rating = item.getImdb_rating();
                    if ((imdb_rating == null || imdb_rating.length() == 0) || Intrinsics.areEqual(item.getImdb_rating(), "0")) {
                        setViewGone(textView2, imageView5);
                    } else {
                        setViewVisible(textView2, imageView5);
                        String imdb_rating2 = item.getImdb_rating();
                        Intrinsics.checkExpressionValueIsNotNull(imdb_rating2, "item.imdb_rating");
                        CommonExtKt.textShadow$default(textView2, imdb_rating2, 0, 0, 6, null);
                    }
                    String str3 = item.quality_tag;
                    if (str3 == null || str3.length() == 0) {
                        z = true;
                    }
                    if (z) {
                        CommonExtKt.gone(imageView7);
                    } else {
                        CommonExtKt.visible(imageView7);
                        imageView6.setImageResource(CommonUtils.getMovieTag(item.quality_tag));
                    }
                    GlideUtils.loadCornerPortraitGifHolder(getContext(), item.poster, imageView4, 8);
                    return;
                case 4:
                    TextView textView3 = (TextView) helper.getView(R.id.tv_item_season);
                    TextView textView4 = (TextView) helper.getView(R.id.tvImdbRating);
                    ImageView imageView8 = (ImageView) helper.getView(R.id.ivStar);
                    ImageView imageView9 = (ImageView) helper.getView(R.id.tv_item_poster);
                    String str4 = item.id;
                    if (str4 == null || str4.length() == 0) {
                        setViewGone(textView3, textView4, imageView8);
                        GlideUtils.load(getContext(), (int) R.drawable.ic_movie_more, imageView9);
                        return;
                    }
                    String str5 = item.season_episode;
                    if (!(str5 == null || str5.length() == 0)) {
                        textView3.setText(item.season_episode);
                        CommonExtKt.visible(textView3);
                    } else {
                        CommonExtKt.gone(textView3);
                    }
                    String imdb_rating3 = item.getImdb_rating();
                    if (imdb_rating3 == null || imdb_rating3.length() == 0) {
                        z = true;
                    }
                    if (z || Intrinsics.areEqual(item.getImdb_rating(), "0")) {
                        CommonExtKt.gone(textView4);
                        CommonExtKt.gone(imageView8);
                    } else {
                        CommonExtKt.visible(textView4);
                        CommonExtKt.visible(imageView8);
                        String imdb_rating4 = item.getImdb_rating();
                        Intrinsics.checkExpressionValueIsNotNull(imdb_rating4, "item.imdb_rating");
                        CommonExtKt.textShadow$default(textView4, imdb_rating4, 0, 0, 6, null);
                    }
                    GlideUtils.loadCornerPortraitGifHolder(getContext(), item.poster, imageView9, 8);
                    return;
                case 5:
                    helper.setText(R.id.tvName, item.getName());
                    GlideUtils.loadCornerPortraitGifHolder(getContext(), item.getAvatar(), (ImageView) helper.getView(R.id.imageView), 8);
                    return;
                case 6:
                    GlideUtils.loadWithCorner(getContext(), item.getImg(), (ImageView) helper.getView(R.id.imageView), DensityUtils.dp2px(App.getContext(), 4.0f));
                    return;
                case 7:
                    ImageView imageView10 = (ImageView) helper.getView(R.id.imageView);
                    TextView textView5 = (TextView) helper.getView(R.id.tv_num);
                    TextView textView6 = (TextView) helper.getView(R.id.tv_name);
                    if (item.getImgArr() != null) {
                        List<String> imgArr = item.getImgArr();
                        Intrinsics.checkExpressionValueIsNotNull(imgArr, "item.imgArr");
                        if (!imgArr.isEmpty()) {
                            GlideUtils.loadLandGifHolder(getContext(), item.getImgArr().get(0), imageView10);
                        }
                    }
                    StringCompanionObject stringCompanionObject2 = StringCompanionObject.INSTANCE;
                    String format2 = String.format("%s videos", Arrays.copyOf(new Object[]{item.getCount()}, 1));
                    Intrinsics.checkExpressionValueIsNotNull(format2, "java.lang.String.format(format, *args)");
                    textView5.setText(format2);
                    textView6.setText(item.getName());
                    return;
                default:
                    return;
            }
        }

        private final void setViewGone(View... viewArr) {
            for (View view : viewArr) {
                CommonExtKt.gone(view);
            }
        }

        private final void setViewVisible(View... viewArr) {
            for (View view : viewArr) {
                CommonExtKt.visible(view);
            }
        }
    }
}
