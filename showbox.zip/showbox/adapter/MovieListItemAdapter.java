package com.tdo.showbox.adapter;

import android.widget.ImageView;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.viewholder.BaseViewHolder;
import com.tdo.showbox.R;
import com.tdo.showbox.model.movie.MovieListModel;
import com.tdo.showbox.utils.GlideUtils;
import java.util.List;
/* loaded from: classes3.dex */
public class MovieListItemAdapter extends BaseQuickAdapter<MovieListModel.MovieListItem, BaseViewHolder> {
    public MovieListItemAdapter(List<MovieListModel.MovieListItem> list) {
        super(R.layout.adapter_detail_movie_list_image_item, list);
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // com.chad.library.adapter.base.BaseQuickAdapter
    public void convert(BaseViewHolder baseViewHolder, MovieListModel.MovieListItem movieListItem) {
        baseViewHolder.setText(R.id.tv_num, String.format("%s videos", Integer.valueOf(movieListItem.getCount())));
        List<String> imgArr = movieListItem.getImgArr();
        if (imgArr != null && imgArr.size() > 0) {
            GlideUtils.loadPost(getContext(), imgArr.get(0), (ImageView) baseViewHolder.getView(R.id.imageView), 4);
        }
        baseViewHolder.setText(R.id.tv_name, movieListItem.getName());
    }
}
