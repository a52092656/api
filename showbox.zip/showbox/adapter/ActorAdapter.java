package com.tdo.showbox.adapter;

import android.widget.ImageView;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.viewholder.BaseViewHolder;
import com.tdo.showbox.R;
import com.tdo.showbox.model.ActorModel;
import com.tdo.showbox.utils.GlideUtils;
import java.util.List;
/* loaded from: classes3.dex */
public class ActorAdapter extends BaseQuickAdapter<ActorModel, BaseViewHolder> {
    public ActorAdapter(List<ActorModel> list) {
        super(R.layout.adapter_actor_item, list);
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // com.chad.library.adapter.base.BaseQuickAdapter
    public void convert(BaseViewHolder baseViewHolder, ActorModel actorModel) {
        baseViewHolder.setText(R.id.tvName, actorModel.getName());
        GlideUtils.loadCornerPortraitGifHolder(getContext(), actorModel.getAvatar(), (ImageView) baseViewHolder.getView(R.id.imageView), 8);
    }
}
