package com.tdo.showbox.adapter;

import android.widget.ImageView;
import android.widget.TextView;
import com.chad.library.adapter.base.delegate.BaseMultiTypeDelegate;
import com.chad.library.adapter.base.viewholder.BaseViewHolder;
import com.hpplay.sdk.source.protocol.f;
import com.tdo.showbox.R;
import com.tdo.showbox.model.movie.MovieListModel;
import com.tdo.showbox.utils.GlideUtils;
import java.util.Arrays;
import java.util.List;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.StringCompanionObject;
/* compiled from: PlayListItemAdapter.kt */
@Metadata(bv = {1, 0, 3}, d1 = {"\u0000\"\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010!\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0002\b\u0003\u0018\u00002\u000e\u0012\u0004\u0012\u00020\u0002\u0012\u0004\u0012\u00020\u00030\u0001B\u0013\u0012\f\u0010\u0004\u001a\b\u0012\u0004\u0012\u00020\u00020\u0005¢\u0006\u0002\u0010\u0006J\u0018\u0010\u0007\u001a\u00020\b2\u0006\u0010\t\u001a\u00020\u00032\u0006\u0010\n\u001a\u00020\u0002H\u0014¨\u0006\u000b"}, d2 = {"Lcom/tdo/showbox/adapter/PlayListItemAdapter;", "Lcom/tdo/showbox/adapter/BaseLoadmoreDelegateMultiAdapter;", "Lcom/tdo/showbox/model/movie/MovieListModel$MovieListItem;", "Lcom/chad/library/adapter/base/viewholder/BaseViewHolder;", "list", "", "(Ljava/util/List;)V", "convert", "", "helper", f.g, "app_webRelease"}, k = 1, mv = {1, 1, 16})
/* loaded from: classes3.dex */
public final class PlayListItemAdapter extends BaseLoadmoreDelegateMultiAdapter<MovieListModel.MovieListItem, BaseViewHolder> {
    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public PlayListItemAdapter(List<MovieListModel.MovieListItem> list) {
        super(list);
        Intrinsics.checkParameterIsNotNull(list, "list");
        setMultiTypeDelegate(new BaseMultiTypeDelegate<MovieListModel.MovieListItem>() { // from class: com.tdo.showbox.adapter.PlayListItemAdapter.1
            @Override // com.chad.library.adapter.base.delegate.BaseMultiTypeDelegate
            public int getItemType(List<? extends MovieListModel.MovieListItem> data, int i) {
                Intrinsics.checkParameterIsNotNull(data, "data");
                return data.get(i).getItemType();
            }
        });
        BaseMultiTypeDelegate<MovieListModel.MovieListItem> multiTypeDelegate = getMultiTypeDelegate();
        if (multiTypeDelegate == null) {
            Intrinsics.throwNpe();
        }
        multiTypeDelegate.addItemType(1, R.layout.adapter_detail_movie_list_image_item);
        BaseMultiTypeDelegate<MovieListModel.MovieListItem> multiTypeDelegate2 = getMultiTypeDelegate();
        if (multiTypeDelegate2 == null) {
            Intrinsics.throwNpe();
        }
        multiTypeDelegate2.addItemType(2, R.layout.adapter_compilations_item);
        BaseMultiTypeDelegate<MovieListModel.MovieListItem> multiTypeDelegate3 = getMultiTypeDelegate();
        if (multiTypeDelegate3 == null) {
            Intrinsics.throwNpe();
        }
        multiTypeDelegate3.addItemType(3, R.layout.adapter_home_actor_item);
        BaseMultiTypeDelegate<MovieListModel.MovieListItem> multiTypeDelegate4 = getMultiTypeDelegate();
        if (multiTypeDelegate4 == null) {
            Intrinsics.throwNpe();
        }
        multiTypeDelegate4.addItemType(4, R.layout.adapter_special_movie_list_item);
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // com.chad.library.adapter.base.BaseQuickAdapter
    public void convert(BaseViewHolder helper, MovieListModel.MovieListItem item) {
        Intrinsics.checkParameterIsNotNull(helper, "helper");
        Intrinsics.checkParameterIsNotNull(item, "item");
        int itemType = item.getItemType();
        if (itemType == 1) {
            ImageView imageView = (ImageView) helper.getView(R.id.imageView);
            TextView textView = (TextView) helper.getView(R.id.tv_num);
            TextView textView2 = (TextView) helper.getView(R.id.tv_name);
            if (item.getImgArr() != null) {
                List<String> imgArr = item.getImgArr();
                Intrinsics.checkExpressionValueIsNotNull(imgArr, "item.imgArr");
                if (!imgArr.isEmpty()) {
                    GlideUtils.loadPost(getContext(), item.getImgArr().get(0), imageView, 0);
                }
            }
            StringCompanionObject stringCompanionObject = StringCompanionObject.INSTANCE;
            String format = String.format("%s Videos", Arrays.copyOf(new Object[]{String.valueOf(item.getCount())}, 1));
            Intrinsics.checkExpressionValueIsNotNull(format, "java.lang.String.format(format, *args)");
            textView.setText(format);
            textView2.setText(item.getName());
        } else if (itemType == 2) {
            GlideUtils.loadLandGifHolder(getContext(), item.getCover(), (ImageView) helper.getView(R.id.imageView));
        } else if (itemType == 3) {
            helper.setText(R.id.tvName, item.getName());
            GlideUtils.loadCornerPortraitGifHolder(getContext(), item.getAvatar(), (ImageView) helper.getView(R.id.imageView), 8);
        } else if (itemType != 4) {
        } else {
            ((TextView) helper.getView(R.id.tv_name)).setText(item.getName());
            StringCompanionObject stringCompanionObject2 = StringCompanionObject.INSTANCE;
            String format2 = String.format("%s Videos", Arrays.copyOf(new Object[]{String.valueOf(item.getCount())}, 1));
            Intrinsics.checkExpressionValueIsNotNull(format2, "java.lang.String.format(format, *args)");
            ((TextView) helper.getView(R.id.tv_num)).setText(format2);
            if (item.getImgArr() == null) {
                return;
            }
            List<String> imgArr2 = item.getImgArr();
            Intrinsics.checkExpressionValueIsNotNull(imgArr2, "item.imgArr");
            if (!(!imgArr2.isEmpty())) {
                return;
            }
            GlideUtils.loadLandGifHolder(getContext(), item.getImgArr().get(0), (ImageView) helper.getView(R.id.imageView));
        }
    }
}
