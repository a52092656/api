package com.tdo.showbox.adapter;

import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.viewholder.BaseViewHolder;
import com.hpplay.sdk.source.protocol.f;
import com.tdo.showbox.R;
import com.tdo.showbox.model.DownloadInfo;
import com.tdo.showbox.model.tv.TvDetail;
import com.tdo.showbox.utils.CommonExtKt;
import com.tdo.showbox.utils.CommonUtils;
import com.tdo.showbox.utils.GlideUtils;
import com.tdo.showbox.utils.TimeUtils;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.StringCompanionObject;
/* compiled from: TvEpisodeAdapter.kt */
@Metadata(bv = {1, 0, 3}, d1 = {"\u0000\"\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010!\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0002\b\u0003\u0018\u00002\u000e\u0012\u0004\u0012\u00020\u0002\u0012\u0004\u0012\u00020\u00030\u0001B\u0013\u0012\f\u0010\u0004\u001a\b\u0012\u0004\u0012\u00020\u00020\u0005¢\u0006\u0002\u0010\u0006J\u0018\u0010\u0007\u001a\u00020\b2\u0006\u0010\t\u001a\u00020\u00032\u0006\u0010\n\u001a\u00020\u0002H\u0015¨\u0006\u000b"}, d2 = {"Lcom/tdo/showbox/adapter/TvEpisodeAdapter;", "Lcom/chad/library/adapter/base/BaseQuickAdapter;", "Lcom/tdo/showbox/model/tv/TvDetail$SeasonDetail;", "Lcom/chad/library/adapter/base/viewholder/BaseViewHolder;", "list", "", "(Ljava/util/List;)V", "convert", "", "helper", f.g, "app_webRelease"}, k = 1, mv = {1, 1, 16})
/* loaded from: classes3.dex */
public final class TvEpisodeAdapter extends BaseQuickAdapter<TvDetail.SeasonDetail, BaseViewHolder> {
    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public TvEpisodeAdapter(List<TvDetail.SeasonDetail> list) {
        super(R.layout.layout_seasson_item, list);
        Intrinsics.checkParameterIsNotNull(list, "list");
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // com.chad.library.adapter.base.BaseQuickAdapter
    public void convert(BaseViewHolder helper, TvDetail.SeasonDetail item) {
        Long l;
        Long l2;
        Long l3;
        Long l4;
        Intrinsics.checkParameterIsNotNull(helper, "helper");
        Intrinsics.checkParameterIsNotNull(item, "item");
        ImageView imageView = (ImageView) helper.getView(R.id.ivTag);
        ImageView imageView2 = (ImageView) helper.getView(R.id.ivPoster);
        ImageView imageView3 = (ImageView) helper.getView(R.id.ivPlayStatus);
        ProgressBar progressBar = (ProgressBar) helper.getView(R.id.progressBar);
        TextView textView = (TextView) helper.getView(R.id.tvName);
        TextView textView2 = (TextView) helper.getView(R.id.tvRate);
        TextView textView3 = (TextView) helper.getView(R.id.tvTime);
        TextView textView4 = (TextView) helper.getView(R.id.tvDuration);
        TextView textView5 = (TextView) helper.getView(R.id.tvLastViewTime);
        TextView textView6 = (TextView) helper.getView(R.id.tvDesc);
        ImageView imageView4 = (ImageView) helper.getView(R.id.ivTomato);
        TextView textView7 = (TextView) helper.getView(R.id.tvTomato);
        String str = item.quality_tag;
        int i = 0;
        if (str == null || str.length() == 0) {
            CommonExtKt.gone(imageView);
        } else {
            CommonExtKt.visible(imageView);
            imageView.setImageResource(CommonUtils.getMovieTag(item.quality_tag));
        }
        if (item.tomato_meter == 0) {
            CommonExtKt.gone(textView7);
            CommonExtKt.gone(imageView4);
        } else {
            CommonExtKt.visible(textView7);
            CommonExtKt.visible(imageView4);
            StringBuilder sb = new StringBuilder();
            sb.append(item.tomato_meter);
            sb.append('%');
            textView7.setText(sb.toString());
            CommonExtKt.textColor(textView7, R.color.white);
            imageView4.setImageResource(CommonUtils.getTomatoImg(item.tomato_meter));
        }
        GlideUtils.loadLandGifHolder(getContext(), item.thumbs, imageView2);
        StringCompanionObject stringCompanionObject = StringCompanionObject.INSTANCE;
        String format = String.format("%s %s", Arrays.copyOf(new Object[]{Integer.valueOf(item.episode), item.title}, 2));
        Intrinsics.checkExpressionValueIsNotNull(format, "java.lang.String.format(format, *args)");
        textView.setText(format);
        textView3.setText(item.released);
        StringCompanionObject stringCompanionObject2 = StringCompanionObject.INSTANCE;
        String format2 = String.format("%s minutes", Arrays.copyOf(new Object[]{item.runtime}, 1));
        Intrinsics.checkExpressionValueIsNotNull(format2, "java.lang.String.format(format, *args)");
        textView4.setText(format2);
        String str2 = item.synopsis;
        if (str2 == null || str2.length() == 0) {
            CommonExtKt.gone(textView6);
        } else {
            CommonExtKt.visible(textView6);
            textView6.setText(item.synopsis);
        }
        String str3 = item.imdb_rating;
        if (str3 == null || str3.length() == 0) {
            textView2.setTextColor(CommonExtKt.colorInt(getContext(), (int) R.color.white_70alpha));
            textView2.setText("-.-");
        } else {
            textView2.setTextColor(CommonExtKt.colorInt(getContext(), (int) R.color.white));
            textView2.setText(item.imdb_rating);
        }
        HashMap<String, Long> hashMap = item.play_progress;
        if (hashMap == null || (l = hashMap.get(DownloadInfo.DOWNLOAD_OVER)) == null) {
            l = -1L;
        }
        Intrinsics.checkExpressionValueIsNotNull(l, "item.play_progress?.get(\"over\") ?: -1");
        long longValue = l.longValue();
        if (longValue == 1) {
            int colorInt = CommonExtKt.colorInt(getContext(), (int) R.color.white_70alpha);
            textView.setTextColor(colorInt);
            textView3.setTextColor(colorInt);
            textView4.setTextColor(colorInt);
            textView6.setTextColor(colorInt);
        } else {
            int colorInt2 = CommonExtKt.colorInt(getContext(), (int) R.color.white_30alpha);
            textView.setTextColor(CommonExtKt.colorInt(getContext(), (int) R.color.white));
            textView3.setTextColor(colorInt2);
            textView4.setTextColor(colorInt2);
            textView6.setTextColor(colorInt2);
        }
        if (longValue == 1) {
            CommonExtKt.gone(progressBar);
            CommonExtKt.visible(imageView3);
            TextView textView8 = textView5;
            CommonExtKt.visible(textView8);
            imageView3.setImageResource(R.mipmap.ic_tv_play_complete);
            HashMap<String, Long> hashMap2 = item.play_progress;
            if (hashMap2 == null || (l4 = hashMap2.get("last_time")) == null) {
                l4 = 0L;
            }
            Intrinsics.checkExpressionValueIsNotNull(l4, "item.play_progress?.get(\"last_time\") ?: 0");
            long longValue2 = l4.longValue();
            if (longValue2 > 0) {
                CommonExtKt.visible(textView8);
                textView5.setText(TimeUtils.formatTime(longValue2 * 1000));
                return;
            }
            CommonExtKt.gone(textView8);
        } else if (longValue != 0) {
            if (longValue != -1) {
                return;
            }
            CommonExtKt.gone(progressBar);
            CommonExtKt.gone(textView5);
            if (item.code_file != 1) {
                CommonExtKt.gone(imageView3);
                return;
            }
            CommonExtKt.visible(imageView3);
            imageView3.setImageResource(R.mipmap.ic_tv_play);
        } else {
            TextView textView9 = textView5;
            CommonExtKt.visible(textView9);
            CommonExtKt.gone(imageView3);
            CommonExtKt.visible(progressBar);
            HashMap<String, Long> hashMap3 = item.play_progress;
            if (hashMap3 == null || (l2 = hashMap3.get("last_time")) == null) {
                l2 = 0L;
            }
            Intrinsics.checkExpressionValueIsNotNull(l2, "item.play_progress?.get(\"last_time\") ?: 0");
            long longValue3 = l2.longValue();
            if (longValue3 > 0) {
                CommonExtKt.visible(textView9);
                textView5.setText(TimeUtils.formatTime(longValue3 * 1000));
            } else {
                CommonExtKt.gone(textView9);
            }
            String str4 = item.runtime;
            if (str4 != null) {
                i = Integer.parseInt(str4);
            }
            progressBar.setMax(i * 60);
            HashMap<String, Long> hashMap4 = item.play_progress;
            if (hashMap4 == null || (l3 = hashMap4.get("seconds")) == null) {
                l3 = 0L;
            }
            progressBar.setProgress((int) l3.longValue());
        }
    }
}
