package com.tdo.showbox.adapter;

import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import com.chad.library.adapter.base.viewholder.BaseViewHolder;
import com.tdo.showbox.R;
import com.tdo.showbox.model.movie.NormalFilmModel;
import com.tdo.showbox.utils.GlideUtils;
import java.util.List;
/* loaded from: classes3.dex */
public class AddMovieListDragAdapter extends BaseItemDraggableAdapter<NormalFilmModel, BaseViewHolder> {
    private OnAfterEditTextChangedListener onAfterEditTextChangedListener;

    /* loaded from: classes3.dex */
    public interface OnAfterEditTextChangedListener {
        void onTextChanged(int i, String str);
    }

    public AddMovieListDragAdapter(int i, List<NormalFilmModel> list) {
        super(i, list);
    }

    public void setOnAfterEditTextChangedListener(OnAfterEditTextChangedListener onAfterEditTextChangedListener) {
        this.onAfterEditTextChangedListener = onAfterEditTextChangedListener;
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // com.chad.library.adapter.base.BaseQuickAdapter
    public void convert(final BaseViewHolder baseViewHolder, NormalFilmModel normalFilmModel) {
        GlideUtils.loadPortraitGifHolder(getContext(), normalFilmModel.getPoster(), (ImageView) baseViewHolder.getView(R.id.iv_avatar));
        EditText editText = (EditText) baseViewHolder.getView(R.id.et_note);
        editText.addTextChangedListener(new TextWatcher() { // from class: com.tdo.showbox.adapter.AddMovieListDragAdapter.1
            @Override // android.text.TextWatcher
            public void beforeTextChanged(CharSequence charSequence, int i, int i2, int i3) {
            }

            @Override // android.text.TextWatcher
            public void onTextChanged(CharSequence charSequence, int i, int i2, int i3) {
            }

            @Override // android.text.TextWatcher
            public void afterTextChanged(Editable editable) {
                if (AddMovieListDragAdapter.this.onAfterEditTextChangedListener != null) {
                    AddMovieListDragAdapter.this.onAfterEditTextChangedListener.onTextChanged(baseViewHolder.getAdapterPosition() - AddMovieListDragAdapter.this.getHeaderLayoutCount(), editable.toString());
                }
            }
        });
        String mark = normalFilmModel.getMark();
        if (!TextUtils.isEmpty(mark)) {
            editText.setText(mark);
        } else {
            editText.setText("");
            editText.setHint("Add a note.");
        }
        ImageView imageView = (ImageView) baseViewHolder.getView(R.id.ivCheck);
        if (normalFilmModel.isSelected()) {
            imageView.setImageResource(R.drawable.ic_checkbox_checked);
        } else {
            imageView.setImageResource(R.drawable.ic_checkbox);
        }
        TextView textView = (TextView) baseViewHolder.getView(R.id.tv_name);
        textView.setMaxLines(100);
        textView.setText(normalFilmModel.getTitle());
        baseViewHolder.setText(R.id.tvTime, String.format("( %s )", Integer.valueOf(normalFilmModel.getYear())));
        baseViewHolder.setText(R.id.tv_desc, normalFilmModel.getDescription());
        textView.setMaxLines(1);
    }
}
