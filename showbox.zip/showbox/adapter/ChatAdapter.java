package com.tdo.showbox.adapter;

import android.widget.ImageView;
import android.widget.TextView;
import com.chad.library.adapter.base.delegate.BaseMultiTypeDelegate;
import com.chad.library.adapter.base.viewholder.BaseViewHolder;
import com.hpplay.sdk.source.protocol.f;
import com.tdo.showbox.R;
import com.tdo.showbox.model.ChatMsgModel;
import com.tdo.showbox.utils.CommonExtKt;
import com.tdo.showbox.utils.GlideUtils;
import com.tdo.showbox.utils.TimeUtils;
import java.util.List;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
/* compiled from: ChatAdapter.kt */
@Metadata(bv = {1, 0, 3}, d1 = {"\u0000\u001c\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0002\b\u0003\u0018\u00002\u000e\u0012\u0004\u0012\u00020\u0002\u0012\u0004\u0012\u00020\u00030\u0001B\u0005¢\u0006\u0002\u0010\u0004J\u0018\u0010\u0005\u001a\u00020\u00062\u0006\u0010\u0007\u001a\u00020\u00032\u0006\u0010\b\u001a\u00020\u0002H\u0014¨\u0006\t"}, d2 = {"Lcom/tdo/showbox/adapter/ChatAdapter;", "Lcom/tdo/showbox/adapter/BaseLoadmoreDelegateMultiAdapter;", "Lcom/tdo/showbox/model/ChatMsgModel;", "Lcom/chad/library/adapter/base/viewholder/BaseViewHolder;", "()V", "convert", "", "helper", f.g, "app_webRelease"}, k = 1, mv = {1, 1, 16})
/* loaded from: classes3.dex */
public final class ChatAdapter extends BaseLoadmoreDelegateMultiAdapter<ChatMsgModel, BaseViewHolder> {
    public ChatAdapter() {
        super(null);
        setMultiTypeDelegate(new BaseMultiTypeDelegate<ChatMsgModel>() { // from class: com.tdo.showbox.adapter.ChatAdapter.1
            @Override // com.chad.library.adapter.base.delegate.BaseMultiTypeDelegate
            public int getItemType(List<? extends ChatMsgModel> data, int i) {
                Intrinsics.checkParameterIsNotNull(data, "data");
                return data.get(i).getIsYou();
            }
        });
        BaseMultiTypeDelegate<ChatMsgModel> multiTypeDelegate = getMultiTypeDelegate();
        if (multiTypeDelegate == null) {
            Intrinsics.throwNpe();
        }
        multiTypeDelegate.addItemType(1, R.layout.adapter_chat_left_item);
        BaseMultiTypeDelegate<ChatMsgModel> multiTypeDelegate2 = getMultiTypeDelegate();
        if (multiTypeDelegate2 == null) {
            Intrinsics.throwNpe();
        }
        multiTypeDelegate2.addItemType(0, R.layout.adapter_chat_right_item);
        addChildClickViewIds(R.id.ivAvatar);
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // com.chad.library.adapter.base.BaseQuickAdapter
    public void convert(BaseViewHolder helper, ChatMsgModel item) {
        Intrinsics.checkParameterIsNotNull(helper, "helper");
        Intrinsics.checkParameterIsNotNull(item, "item");
        TextView textView = (TextView) helper.getView(R.id.tvTime);
        if (item.getDateline() - (helper.getAdapterPosition() > 0 ? getItem(helper.getAdapterPosition() - 1).getDateline() : 0L) > 300) {
            CommonExtKt.visible(textView);
            textView.setText(TimeUtils.formatTime(item.getDateline() * 1000));
        } else {
            CommonExtKt.gone(textView);
        }
        helper.setText(R.id.tvContent, item.getMessage());
        GlideUtils.load(getContext(), item.getAvatar(), (ImageView) helper.getView(R.id.ivAvatar), (int) R.mipmap.ic_panda_forum_default_avatar);
    }
}
