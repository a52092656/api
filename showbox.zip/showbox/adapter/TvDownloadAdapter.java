package com.tdo.showbox.adapter;

import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.viewholder.BaseViewHolder;
import com.hpplay.sdk.source.protocol.f;
import com.tdo.showbox.R;
import com.tdo.showbox.app.App;
import com.tdo.showbox.db.dao.DownloadDao;
import com.tdo.showbox.db.entity.Download;
import com.tdo.showbox.model.tv.TvDetail;
import com.tdo.showbox.utils.CommonExtKt;
import com.tdo.showbox.utils.GlideUtils;
import java.util.Arrays;
import java.util.List;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.StringCompanionObject;
/* compiled from: TvDownloadAdapter.kt */
@Metadata(bv = {1, 0, 3}, d1 = {"\u0000\"\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010!\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0002\b\u0003\u0018\u00002\u000e\u0012\u0004\u0012\u00020\u0002\u0012\u0004\u0012\u00020\u00030\u0001B\u0013\u0012\f\u0010\u0004\u001a\b\u0012\u0004\u0012\u00020\u00020\u0005¢\u0006\u0002\u0010\u0006J\u0018\u0010\u0007\u001a\u00020\b2\u0006\u0010\t\u001a\u00020\u00032\u0006\u0010\n\u001a\u00020\u0002H\u0014¨\u0006\u000b"}, d2 = {"Lcom/tdo/showbox/adapter/TvDownloadAdapter;", "Lcom/chad/library/adapter/base/BaseQuickAdapter;", "Lcom/tdo/showbox/model/tv/TvDetail$SeasonDetail;", "Lcom/chad/library/adapter/base/viewholder/BaseViewHolder;", "list", "", "(Ljava/util/List;)V", "convert", "", "helper", f.g, "app_webRelease"}, k = 1, mv = {1, 1, 16})
/* loaded from: classes3.dex */
public final class TvDownloadAdapter extends BaseQuickAdapter<TvDetail.SeasonDetail, BaseViewHolder> {
    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public TvDownloadAdapter(List<TvDetail.SeasonDetail> list) {
        super(R.layout.adapter_tv_download_item, list);
        Intrinsics.checkParameterIsNotNull(list, "list");
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // com.chad.library.adapter.base.BaseQuickAdapter
    public void convert(BaseViewHolder helper, TvDetail.SeasonDetail item) {
        Intrinsics.checkParameterIsNotNull(helper, "helper");
        Intrinsics.checkParameterIsNotNull(item, "item");
        ImageView imageView = (ImageView) helper.getView(R.id.ivDownload);
        ImageView imageView2 = (ImageView) helper.getView(R.id.ivLocal);
        TextView textView = (TextView) helper.getView(R.id.tvProgress);
        FrameLayout frameLayout = (FrameLayout) helper.getView(R.id.flDownload);
        GlideUtils.loadLandCornerGifHolder(getContext(), item.thumbs, (ImageView) helper.getView(R.id.imageView), 8);
        StringCompanionObject stringCompanionObject = StringCompanionObject.INSTANCE;
        String format = String.format("%s %s", Arrays.copyOf(new Object[]{Integer.valueOf(item.episode), item.title}, 2));
        Intrinsics.checkExpressionValueIsNotNull(format, "java.lang.String.format(format, *args)");
        helper.setText(R.id.tvName, format);
        StringCompanionObject stringCompanionObject2 = StringCompanionObject.INSTANCE;
        String format2 = String.format("%s\n%s minutes", Arrays.copyOf(new Object[]{item.released, item.runtime}, 2));
        Intrinsics.checkExpressionValueIsNotNull(format2, "java.lang.String.format(format, *args)");
        helper.setText(R.id.tvTime, format2);
        if (item.code_file != 1) {
            CommonExtKt.gone(frameLayout);
            return;
        }
        CommonExtKt.visible(frameLayout);
        DownloadDao downloadDao = App.getDB().downloadDao();
        Download findByType = downloadDao.findByType(2, item.tid + "_" + item.id);
        if (findByType != null) {
            int statue = findByType.getStatue();
            if (statue == 0) {
                textView.setText(String.valueOf(findByType.getProgress()));
                CommonExtKt.gone(imageView);
                CommonExtKt.gone(imageView2);
                CommonExtKt.visible(textView);
                return;
            } else if (statue == 1) {
                StringBuilder sb = new StringBuilder();
                sb.append(findByType.getProgress());
                sb.append('%');
                textView.setText(sb.toString());
                CommonExtKt.gone(imageView);
                CommonExtKt.gone(imageView2);
                CommonExtKt.visible(textView);
                return;
            } else if (statue == 2) {
                CommonExtKt.gone(imageView);
                CommonExtKt.visible(imageView2);
                CommonExtKt.gone(textView);
                return;
            } else if (statue == 3) {
                textView.setText(String.valueOf(findByType.getProgress()));
                CommonExtKt.gone(imageView);
                CommonExtKt.gone(imageView2);
                CommonExtKt.visible(textView);
                return;
            } else {
                CommonExtKt.visible(imageView);
                CommonExtKt.gone(imageView2);
                CommonExtKt.gone(textView);
                return;
            }
        }
        CommonExtKt.visible(imageView);
        CommonExtKt.gone(imageView2);
        CommonExtKt.gone(textView);
    }
}
