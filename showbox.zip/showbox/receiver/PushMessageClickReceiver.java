package com.tdo.showbox.receiver;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.text.TextUtils;
import com.alibaba.fastjson.JSONObject;
import com.tdo.showbox.app.App;
import com.tdo.showbox.http.HttpUtils;
import com.tdo.showbox.utils.SystemUtils;
import com.tdo.showbox.utils.TimeUtils;
import com.tdo.showbox.view.activity.detail.MoviesDetailActivity;
import com.tdo.showbox.view.activity.detail.TvShowDetailActivity;
import com.umeng.analytics.pro.b;
import java.util.Arrays;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.StringCompanionObject;
/* compiled from: PushMessageClickReceiver.kt */
@Metadata(bv = {1, 0, 3}, d1 = {"\u0000&\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\u0018\u00002\u00020\u0001B\u0005¢\u0006\u0002\u0010\u0002J\u0012\u0010\u0003\u001a\u0004\u0018\u00010\u00042\u0006\u0010\u0005\u001a\u00020\u0004H\u0002J\u001c\u0010\u0006\u001a\u00020\u00072\b\u0010\b\u001a\u0004\u0018\u00010\t2\b\u0010\n\u001a\u0004\u0018\u00010\u000bH\u0016¨\u0006\f"}, d2 = {"Lcom/tdo/showbox/receiver/PushMessageClickReceiver;", "Landroid/content/BroadcastReceiver;", "()V", "buildData", "", "env", "onReceive", "", b.M, "Landroid/content/Context;", "intent", "Landroid/content/Intent;", "app_webRelease"}, k = 1, mv = {1, 1, 16})
/* loaded from: classes3.dex */
public final class PushMessageClickReceiver extends BroadcastReceiver {
    @Override // android.content.BroadcastReceiver
    public void onReceive(Context context, Intent intent) {
        if (Intrinsics.areEqual(intent != null ? intent.getAction() : null, "Handle_Push_Msg")) {
            String stringExtra = intent.getStringExtra("type");
            String stringExtra2 = intent.getStringExtra("tid");
            String stringExtra3 = intent.getStringExtra("mid");
            String stringExtra4 = intent.getStringExtra("ticket_id");
            String stringExtra5 = intent.getStringExtra("url");
            if (TextUtils.isEmpty(stringExtra) || stringExtra == null) {
                return;
            }
            int hashCode = stringExtra.hashCode();
            if (hashCode == -873960692) {
                if (!stringExtra.equals("ticket")) {
                    return;
                }
                StringCompanionObject stringCompanionObject = StringCompanionObject.INSTANCE;
                String format = String.format("https://www.showbox.media/index/order/detail?auth=%s&id=%s", Arrays.copyOf(new Object[]{buildData(""), stringExtra4}, 2));
                Intrinsics.checkExpressionValueIsNotNull(format, "java.lang.String.format(format, *args)");
                SystemUtils.startBrowser(context, format);
            } else if (hashCode == 3714) {
                if (!stringExtra.equals("tv")) {
                    return;
                }
                TvShowDetailActivity.Companion.startWithFlag$default(TvShowDetailActivity.Companion, context, stringExtra2, null, 4, null);
            } else if (hashCode != 3377875) {
                if (hashCode != 104087344 || !stringExtra.equals("movie")) {
                    return;
                }
                MoviesDetailActivity.Companion.startWithFlag$default(MoviesDetailActivity.Companion, context, stringExtra3, null, 4, null);
            } else if (!stringExtra.equals("news")) {
            } else {
                SystemUtils.startBrowser(context, stringExtra5);
            }
        }
    }

    private final String buildData(String str) {
        JSONObject jSONObject = new JSONObject();
        JSONObject jSONObject2 = jSONObject;
        jSONObject2.put((JSONObject) "env", str);
        jSONObject2.put((JSONObject) "uid", App.isLogin() ? App.getUserData().uid : "");
        jSONObject2.put((JSONObject) "expired_date", (String) Long.valueOf((TimeUtils.getCurrentTime() / 1000) + 43200));
        return HttpUtils.encodeBody(jSONObject.toJSONString());
    }
}
