package com.tdo.showbox.base;
/* loaded from: classes3.dex */
public interface OnItemClickListener {
    void onItemClick(int i);
}
