package com.tdo.showbox.base;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewStub;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.delegate.BaseMultiTypeDelegate;
import com.chad.library.adapter.base.listener.OnItemChildClickListener;
import com.chad.library.adapter.base.listener.OnItemLongClickListener;
import com.chad.library.adapter.base.listener.OnLoadMoreListener;
import com.chad.library.adapter.base.listener.OnUpFetchListener;
import com.chad.library.adapter.base.module.BaseLoadMoreModule;
import com.chad.library.adapter.base.module.BaseUpFetchModule;
import com.scwang.smart.refresh.footer.ClassicsFooter;
import com.scwang.smart.refresh.layout.SmartRefreshLayout;
import com.tdo.showbox.R;
import com.tdo.showbox.adapter.BaseLoadMoreAdapter;
import com.tdo.showbox.adapter.BaseLoadmoreDelegateMultiAdapter;
import com.tdo.showbox.app.App;
import com.tdo.showbox.event.LowMemoryEvent;
import com.tdo.showbox.http.API;
import com.tdo.showbox.http.ApiException;
import com.tdo.showbox.utils.CommonUtils;
import com.tdo.showbox.utils.Network;
import com.tdo.showbox.utils.RxUtils;
import com.tdo.showbox.utils.ToastUtils;
import com.tdo.showbox.view.activity.user.Login2Activity;
import com.uber.autodispose.ObservableSubscribeProxy;
import com.umeng.analytics.MobclickAgent;
import io.reactivex.Observable;
import io.reactivex.disposables.Disposable;
import io.supercharge.shimmerlayout.ShimmerLayout;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Objects;
import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;
/* loaded from: classes.dex */
public abstract class BaseListFragment<T, P> extends BaseLazyFragment {
    private View emptyView;
    private ViewStub emptyViewStub;
    private View errorView;
    private ViewStub errorViewStub;
    private Disposable lastDisposable;
    private BaseLoadMoreModule loadMoreModule;
    protected BaseQuickAdapter<T, com.chad.library.adapter.base.viewholder.BaseViewHolder> mAdapter;
    protected Class<T> mClass;
    protected List<T> mData;
    protected Class<P> mPageClass;
    protected RecyclerView mRecyclerView;
    private ShimmerLayout shimmerLayout;
    private SwipeRefreshLayout swipeRefreshLayout;
    protected int mCurrentPage = 1;
    protected int mPageSize = 15;
    protected int mPreLoadNum = 9;
    private boolean isFirstLoad = true;

    private void enableRefresh(boolean z) {
    }

    private void initView() {
    }

    protected List<View> addHeaderView(RecyclerView recyclerView) {
        return null;
    }

    protected RecyclerView.ItemDecoration addItemDecoration() {
        return null;
    }

    protected void addOnItemClickViews(BaseQuickAdapter<T, com.chad.library.adapter.base.viewholder.BaseViewHolder> baseQuickAdapter) {
    }

    protected void doSomethingWithData(List<T> list) {
    }

    protected boolean enableEventBus() {
        return true;
    }

    protected boolean enableMultiAdapter() {
        return false;
    }

    protected boolean enableShimmer() {
        return false;
    }

    protected abstract void getBundle(Bundle bundle);

    protected List<T> getData(P p) {
        return null;
    }

    protected abstract Observable<String> getServiceData();

    protected int gridLayoutSpan() {
        return 2;
    }

    protected void initEmptyView(TextView textView, ImageView imageView) {
    }

    protected abstract void initHolder(com.chad.library.adapter.base.viewholder.BaseViewHolder baseViewHolder, T t);

    protected abstract int initItemLayout();

    protected int initItemType(T t) {
        return 0;
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public void initRecyclerView(RecyclerView recyclerView) {
    }

    protected int initShimmerLayoutId() {
        return -1;
    }

    protected View initShimmerView(ViewGroup viewGroup) {
        return null;
    }

    protected boolean isNeedLazyLoad() {
        return true;
    }

    protected boolean isNeedLogin() {
        return false;
    }

    protected boolean isNeedTest() {
        return false;
    }

    protected boolean isOpenLoadMore() {
        return true;
    }

    protected boolean isOpenRefresh() {
        return true;
    }

    protected boolean isUpFetchEnable() {
        return false;
    }

    protected boolean isVerticalLayout() {
        return true;
    }

    protected OnItemChildClickListener onItemChildClick() {
        return null;
    }

    protected com.chad.library.adapter.base.listener.OnItemClickListener onItemClick() {
        return null;
    }

    protected void onLoadComplete() {
    }

    protected void onLoadDataComplete(List list) {
    }

    protected OnItemLongClickListener onLongClick() {
        return null;
    }

    protected void onRequestLoadMoreComplete(List<T> list) {
    }

    protected void onSwipeRefresh() {
    }

    protected boolean openLowMemoryEmpty() {
        return false;
    }

    protected void registerItemType(BaseMultiTypeDelegate<T> baseMultiTypeDelegate) {
    }

    protected void test() {
    }

    protected void viewAttachedToWindow(com.chad.library.adapter.base.viewholder.BaseViewHolder baseViewHolder) {
    }

    protected void viewDetachedFromWindow(com.chad.library.adapter.base.viewholder.BaseViewHolder baseViewHolder) {
    }

    @Override // androidx.fragment.app.Fragment
    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        super.onCreateView(layoutInflater, viewGroup, bundle);
        View inflate = layoutInflater.inflate(R.layout.fragment_recycler_layout, viewGroup, false);
        this.mRecyclerView = (RecyclerView) inflate.findViewById(R.id.recyclerView);
        this.emptyViewStub = (ViewStub) inflate.findViewById(R.id.emptyViewStub);
        this.errorViewStub = (ViewStub) inflate.findViewById(R.id.errorViewStub);
        this.swipeRefreshLayout = (SwipeRefreshLayout) inflate.findViewById(R.id.swipeRefreshLayout);
        this.shimmerLayout = (ShimmerLayout) inflate.findViewById(R.id.shimmer);
        CommonUtils.initSwipeColor(this.swipeRefreshLayout);
        this.swipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() { // from class: com.tdo.showbox.base.-$$Lambda$BaseListFragment$fHGkQdEPp0P5CdVDsUpjkmuImGM
            @Override // androidx.swiperefreshlayout.widget.SwipeRefreshLayout.OnRefreshListener
            public final void onRefresh() {
                BaseListFragment.this.swipeRefreshData();
            }
        });
        SmartRefreshLayout smartRefreshLayout = (SmartRefreshLayout) inflate.findViewById(R.id.smartRefreshLayout);
        smartRefreshLayout.setEnablePureScrollMode(true);
        smartRefreshLayout.setEnableRefresh(false);
        smartRefreshLayout.setEnableLoadMore(true);
        smartRefreshLayout.setRefreshFooter(new ClassicsFooter((Context) Objects.requireNonNull(getContext())));
        return inflate;
    }

    @Override // androidx.fragment.app.Fragment
    public void onViewCreated(View view, Bundle bundle) {
        super.onViewCreated(view, bundle);
        if (!isNeedLazyLoad()) {
            init();
            swipeRefreshData();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void startRefreshView() {
        this.swipeRefreshLayout.setRefreshing(true);
    }

    private void init() {
        this.mData = new ArrayList();
        getBundle(getArguments());
        if (enableMultiAdapter()) {
            this.mAdapter = new MultiItemAdapter();
        } else {
            this.mAdapter = new BaseLoadMoreAdapter<T, com.chad.library.adapter.base.viewholder.BaseViewHolder>(initItemLayout(), this.mData) { // from class: com.tdo.showbox.base.BaseListFragment.1
                @Override // com.chad.library.adapter.base.BaseQuickAdapter
                protected void convert(com.chad.library.adapter.base.viewholder.BaseViewHolder baseViewHolder, T t) {
                    BaseListFragment.this.initHolder(baseViewHolder, t);
                }
            };
        }
        this.loadMoreModule = this.mAdapter.getLoadMoreModule();
        BaseUpFetchModule upFetchModule = this.mAdapter.getUpFetchModule();
        this.loadMoreModule.setPreLoadNumber(this.mPreLoadNum);
        if (isVerticalLayout()) {
            this.mRecyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        } else {
            this.mRecyclerView.setLayoutManager(new GridLayoutManager(getContext(), gridLayoutSpan()));
        }
        if (addHeaderView(this.mRecyclerView) != null) {
            for (View view : addHeaderView(this.mRecyclerView)) {
                this.mAdapter.addHeaderView(view, 0);
            }
        }
        if (addItemDecoration() != null) {
            this.mRecyclerView.addItemDecoration(addItemDecoration());
        }
        initRecyclerView(this.mRecyclerView);
        RecyclerView.ItemAnimator itemAnimator = this.mRecyclerView.getItemAnimator();
        if (itemAnimator instanceof DefaultItemAnimator) {
            ((DefaultItemAnimator) itemAnimator).setSupportsChangeAnimations(false);
        }
        addOnItemClickViews(this.mAdapter);
        this.mRecyclerView.setAdapter(this.mAdapter);
        initView();
        if (onItemClick() != null) {
            this.mAdapter.setOnItemClickListener(onItemClick());
        }
        if (onItemChildClick() != null) {
            this.mAdapter.setOnItemChildClickListener(onItemChildClick());
        }
        if (onLongClick() != null) {
            this.mAdapter.setOnItemLongClickListener(onLongClick());
        }
        this.mAdapter.setAnimationWithDefault(BaseQuickAdapter.AnimationType.AlphaIn);
        if (isOpenLoadMore()) {
            this.loadMoreModule.setOnLoadMoreListener(new OnLoadMoreListener() { // from class: com.tdo.showbox.base.-$$Lambda$BaseListFragment$G5C7WQU8F1bFIUt-6Xiu0t95vTY
                @Override // com.chad.library.adapter.base.listener.OnLoadMoreListener
                public final void onLoadMore() {
                    BaseListFragment.this.lambda$init$0$BaseListFragment();
                }
            });
        }
        if (isUpFetchEnable()) {
            upFetchModule.setOnUpFetchListener(new OnUpFetchListener() { // from class: com.tdo.showbox.base.-$$Lambda$BaseListFragment$xKuBfrPc2EQ1JJXKQbSb5VA1Q9w
                @Override // com.chad.library.adapter.base.listener.OnUpFetchListener
                public final void onUpFetch() {
                    BaseListFragment.this.lambda$init$1$BaseListFragment();
                }
            });
        }
        if (enableShimmer()) {
            this.shimmerLayout.setVisibility(0);
            if (initShimmerLayoutId() != -1) {
                this.shimmerLayout.addView(getLayoutInflater().inflate(initShimmerLayoutId(), (ViewGroup) this.shimmerLayout, false));
            } else if (initShimmerView(this.shimmerLayout) != null) {
                ShimmerLayout shimmerLayout = this.shimmerLayout;
                shimmerLayout.addView(initShimmerView(shimmerLayout));
            }
        } else {
            this.shimmerLayout.setVisibility(8);
        }
        test();
    }

    public /* synthetic */ void lambda$init$0$BaseListFragment() {
        if (Network.isConnected(getContext())) {
            this.mCurrentPage++;
            if (this.mPageClass == null) {
                loadMoreDataPage();
                return;
            } else {
                loadMoreDataPageModel();
                return;
            }
        }
        this.mCurrentPage--;
        this.loadMoreModule.loadMoreFail();
        ToastUtils.showShort("no network");
    }

    public /* synthetic */ void lambda$init$1$BaseListFragment() {
        int i;
        if (!Network.isConnected(getContext()) || (i = this.mCurrentPage) == 1) {
            return;
        }
        int i2 = i - 1;
        this.mCurrentPage = i2;
        refreshPageData(i2);
    }

    private void enableLoadMore(boolean z) {
        this.loadMoreModule.setEnableLoadMore(z);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void endRefreshView() {
        this.swipeRefreshLayout.setRefreshing(false);
    }

    private void loadData() {
        ((ObservableSubscribeProxy) getServiceData().compose(RxUtils.rxTranslate2List(this.mClass)).compose(RxUtils.rxSchedulerHelper()).as(RxUtils.bindLifecycleOwner(this))).subscribe(new BaseObserver<List<T>>() { // from class: com.tdo.showbox.base.BaseListFragment.2
            @Override // com.tdo.showbox.base.BaseObserver, io.reactivex.Observer
            public /* bridge */ /* synthetic */ void onNext(Object obj) {
                onNext((List) ((List) obj));
            }

            @Override // com.tdo.showbox.base.BaseObserver, io.reactivex.Observer
            public void onSubscribe(Disposable disposable) {
                super.onSubscribe(disposable);
                BaseListFragment.this.startRefreshView();
                BaseListFragment.this.showShimmerLayout();
            }

            public void onNext(List<T> list) {
                super.onNext((AnonymousClass2) list);
                if (list == null || list.size() == 0) {
                    BaseListFragment.this.setEmptyView();
                    return;
                }
                BaseListFragment.this.doSomethingWithData(list);
                BaseListFragment.this.mAdapter.setNewData(list);
            }

            @Override // com.tdo.showbox.base.BaseObserver, io.reactivex.Observer
            public void onComplete() {
                super.onComplete();
                BaseListFragment.this.endRefreshView();
                BaseListFragment.this.onLoadComplete();
                BaseListFragment.this.hideShimmerLayout();
            }

            @Override // com.tdo.showbox.base.BaseObserver
            public void onError(ApiException apiException) {
                BaseListFragment.this.endRefreshView();
                BaseListFragment.this.setErrorView(apiException.getMessage());
                BaseListFragment.this.hideShimmerLayout();
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void hideShimmerLayout() {
        if (!enableShimmer() || !this.isFirstLoad) {
            return;
        }
        this.shimmerLayout.stopShimmerAnimation();
        this.shimmerLayout.setVisibility(8);
        this.shimmerLayout.removeAllViews();
        this.isFirstLoad = false;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void showShimmerLayout() {
        if (!enableShimmer() || !this.isFirstLoad) {
            return;
        }
        this.shimmerLayout.setVisibility(0);
        this.shimmerLayout.startShimmerAnimation();
    }

    private void loadDataWithModel() {
        Disposable disposable = this.lastDisposable;
        if (disposable != null && !disposable.isDisposed()) {
            this.lastDisposable.dispose();
        }
        ((ObservableSubscribeProxy) getServiceData().compose(RxUtils.rxTranslate2Bean(this.mPageClass)).compose(RxUtils.rxSchedulerHelper()).as(RxUtils.bindLifecycleOwner(this))).subscribe(new BaseObserver<P>() { // from class: com.tdo.showbox.base.BaseListFragment.3
            @Override // com.tdo.showbox.base.BaseObserver, io.reactivex.Observer
            public void onSubscribe(Disposable disposable2) {
                super.onSubscribe(disposable2);
                BaseListFragment.this.lastDisposable = disposable2;
                BaseListFragment.this.startRefreshView();
                BaseListFragment.this.showShimmerLayout();
            }

            @Override // com.tdo.showbox.base.BaseObserver, io.reactivex.Observer
            public void onNext(P p) {
                super.onNext(p);
                List<T> data = BaseListFragment.this.getData(p);
                if (data == null || data.size() == 0) {
                    BaseListFragment.this.setEmptyView();
                    return;
                }
                BaseListFragment.this.doSomethingWithData(data);
                BaseListFragment.this.mAdapter.setNewData(data);
            }

            @Override // com.tdo.showbox.base.BaseObserver, io.reactivex.Observer
            public void onComplete() {
                super.onComplete();
                BaseListFragment.this.endRefreshView();
                BaseListFragment.this.onLoadComplete();
                BaseListFragment.this.hideShimmerLayout();
            }

            @Override // com.tdo.showbox.base.BaseObserver
            public void onError(ApiException apiException) {
                BaseListFragment.this.endRefreshView();
                BaseListFragment.this.setErrorView(apiException.getMessage());
                BaseListFragment.this.hideShimmerLayout();
            }
        });
    }

    private void loadMoreDataPage() {
        ((ObservableSubscribeProxy) getServiceData().compose(RxUtils.rxTranslate2List(this.mClass)).compose(RxUtils.rxSchedulerHelper()).as(RxUtils.bindLifecycleOwner(this))).subscribe(new BaseObserver<List<T>>() { // from class: com.tdo.showbox.base.BaseListFragment.4
            @Override // com.tdo.showbox.base.BaseObserver, io.reactivex.Observer
            public /* bridge */ /* synthetic */ void onNext(Object obj) {
                onNext((List) ((List) obj));
            }

            @Override // com.tdo.showbox.base.BaseObserver, io.reactivex.Observer
            public void onSubscribe(Disposable disposable) {
                super.onSubscribe(disposable);
                if (BaseListFragment.this.mCurrentPage == 1) {
                    BaseListFragment.this.setLoadMoreViewEnable(false);
                } else {
                    BaseListFragment.this.setRefreshViewEnable(false);
                }
                BaseListFragment.this.showShimmerLayout();
            }

            public void onNext(List<T> list) {
                super.onNext((AnonymousClass4) list);
                BaseListFragment.this.doSomethingWithData(list);
                if (BaseListFragment.this.mCurrentPage == 1) {
                    if (list == null || list.size() == 0) {
                        BaseListFragment.this.mAdapter.setNewData(null);
                        BaseListFragment.this.setEmptyView();
                        return;
                    }
                    BaseListFragment.this.mAdapter.setNewData(list);
                    return;
                }
                BaseListFragment.this.doSomethingWithData(list);
                BaseListFragment.this.mAdapter.addData((Collection) list);
                if (list.size() == 0) {
                    BaseListFragment.this.loadMoreModule.loadMoreEnd();
                } else {
                    BaseListFragment.this.loadMoreModule.loadMoreComplete();
                }
            }

            @Override // com.tdo.showbox.base.BaseObserver, io.reactivex.Observer
            public void onComplete() {
                super.onComplete();
                if (BaseListFragment.this.mCurrentPage == 1) {
                    BaseListFragment.this.endRefreshView();
                }
                BaseListFragment.this.setLoadMoreViewEnable(true);
                BaseListFragment.this.setRefreshViewEnable(true);
                BaseListFragment.this.onLoadComplete();
                BaseListFragment.this.hideShimmerLayout();
            }

            @Override // com.tdo.showbox.base.BaseObserver
            public void onError(ApiException apiException) {
                if (BaseListFragment.this.mCurrentPage == 1) {
                    BaseListFragment.this.setErrorView(apiException.getMessage());
                    BaseListFragment.this.endRefreshView();
                } else {
                    ToastUtils.showShort("Load failed");
                    BaseListFragment.this.loadMoreModule.loadMoreFail();
                    BaseListFragment.this.mCurrentPage--;
                }
                BaseListFragment.this.setLoadMoreViewEnable(true);
                BaseListFragment.this.setRefreshViewEnable(true);
                BaseListFragment.this.hideShimmerLayout();
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void setLoadMoreViewEnable(boolean z) {
        this.loadMoreModule.setEnableLoadMore(z);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void setRefreshViewEnable(boolean z) {
        this.swipeRefreshLayout.setEnabled(z);
    }

    private void loadMoreDataPageModel() {
        ((ObservableSubscribeProxy) getServiceData().compose(RxUtils.rxTranslate2Bean(this.mPageClass)).compose(RxUtils.rxSchedulerHelper()).as(RxUtils.bindLifecycleOwner(this))).subscribe(new BaseObserver<P>() { // from class: com.tdo.showbox.base.BaseListFragment.5
            @Override // com.tdo.showbox.base.BaseObserver, io.reactivex.Observer
            public void onSubscribe(Disposable disposable) {
                super.onSubscribe(disposable);
                if (BaseListFragment.this.mCurrentPage == 1) {
                    BaseListFragment.this.setLoadMoreViewEnable(false);
                } else {
                    BaseListFragment.this.setRefreshViewEnable(false);
                }
                BaseListFragment.this.showShimmerLayout();
            }

            @Override // com.tdo.showbox.base.BaseObserver, io.reactivex.Observer
            public void onNext(P p) {
                super.onNext(p);
                List<T> data = BaseListFragment.this.getData(p);
                BaseListFragment.this.doSomethingWithData(data);
                if (BaseListFragment.this.mCurrentPage == 1) {
                    if (data == null || data.size() == 0) {
                        BaseListFragment.this.mAdapter.setNewData(null);
                        BaseListFragment.this.setEmptyView();
                        return;
                    }
                    BaseListFragment.this.mAdapter.setNewData(data);
                    if (data.size() >= BaseListFragment.this.mPageSize) {
                        return;
                    }
                    BaseListFragment.this.loadMoreModule.loadMoreEnd(true);
                    return;
                }
                BaseListFragment.this.doSomethingWithData(data);
                if (data != null) {
                    BaseListFragment.this.mAdapter.addData((Collection) data);
                    if (data.size() < BaseListFragment.this.mPageSize) {
                        BaseListFragment.this.loadMoreModule.loadMoreEnd();
                        return;
                    } else {
                        BaseListFragment.this.loadMoreModule.loadMoreComplete();
                        return;
                    }
                }
                BaseListFragment.this.mAdapter.addData((Collection) new ArrayList());
                BaseListFragment.this.loadMoreModule.loadMoreEnd();
            }

            @Override // com.tdo.showbox.base.BaseObserver, io.reactivex.Observer
            public void onComplete() {
                super.onComplete();
                if (BaseListFragment.this.mCurrentPage == 1) {
                    BaseListFragment.this.endRefreshView();
                }
                BaseListFragment.this.setLoadMoreViewEnable(true);
                BaseListFragment.this.setRefreshViewEnable(true);
                BaseListFragment.this.onLoadComplete();
                BaseListFragment.this.hideShimmerLayout();
            }

            @Override // com.tdo.showbox.base.BaseObserver
            public void onError(ApiException apiException) {
                if (BaseListFragment.this.mCurrentPage == 1) {
                    BaseListFragment.this.setErrorView(apiException.getMessage());
                    BaseListFragment.this.endRefreshView();
                } else {
                    ToastUtils.showShort("Load failed");
                    BaseListFragment.this.loadMoreModule.loadMoreFail();
                    BaseListFragment.this.mCurrentPage--;
                }
                BaseListFragment.this.setLoadMoreViewEnable(true);
                BaseListFragment.this.setRefreshViewEnable(true);
                BaseListFragment.this.hideShimmerLayout();
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void setErrorView(String str) {
        if (this.errorView == null) {
            this.errorView = this.errorViewStub.inflate();
        }
        ((TextView) this.errorView.findViewById(R.id.empty_text)).setText(String.format("Load failed:%s", str));
        TextView textView = (TextView) this.errorView.findViewById(R.id.tvTryAgain);
        textView.setOnClickListener(new View.OnClickListener() { // from class: com.tdo.showbox.base.BaseListFragment.6
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                BaseListFragment.this.startRefresh();
            }
        });
        textView.setText("Try again");
        ((ImageView) this.errorView.findViewById(R.id.empty_image)).setImageResource(R.drawable.ic_load_error);
        this.errorView.setVisibility(0);
    }

    private void setNotLoginError() {
        View view = this.errorView;
        if (view == null) {
            View inflate = this.errorViewStub.inflate();
            this.errorView = inflate;
            TextView textView = (TextView) inflate.findViewById(R.id.tvTryAgain);
            textView.setOnClickListener(new View.OnClickListener() { // from class: com.tdo.showbox.base.BaseListFragment.7
                @Override // android.view.View.OnClickListener
                public void onClick(View view2) {
                    Login2Activity.start(BaseListFragment.this.getContext());
                }
            });
            ((ImageView) this.errorView.findViewById(R.id.empty_image)).setImageResource(R.mipmap.ic_no_login);
            ((TextView) this.errorView.findViewById(R.id.empty_text)).setText("Please login first.");
            textView.setText(API.USER.LOGIN);
        } else {
            ((TextView) view.findViewById(R.id.empty_text)).setText(String.format("Load failed:%s", "No login"));
            TextView textView2 = (TextView) this.errorView.findViewById(R.id.tvTryAgain);
            textView2.setOnClickListener(new View.OnClickListener() { // from class: com.tdo.showbox.base.BaseListFragment.8
                @Override // android.view.View.OnClickListener
                public void onClick(View view2) {
                    Login2Activity.start(BaseListFragment.this.getContext());
                }
            });
            ((ImageView) this.errorView.findViewById(R.id.empty_image)).setImageResource(R.mipmap.ic_no_login);
            ((TextView) this.errorView.findViewById(R.id.empty_text)).setText("Please login first.");
            textView2.setText(API.USER.LOGIN);
        }
        this.errorView.setVisibility(0);
    }

    private void hideErrorView() {
        View view = this.errorView;
        if (view != null) {
            view.setVisibility(8);
        }
    }

    protected void setEmptyView() {
        if (this.emptyView == null) {
            this.emptyView = this.emptyViewStub.inflate();
        }
        this.emptyView.setVisibility(0);
    }

    private void hideEmptyView() {
        View view = this.emptyView;
        if (view != null) {
            view.setVisibility(8);
        }
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public void startRefresh() {
        if (this.mAdapter == null) {
            return;
        }
        swipeRefreshData();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void swipeRefreshData() {
        onSwipeRefresh();
        startRefreshView();
        this.mCurrentPage = 1;
        if (!isNeedTest()) {
            refreshData();
        }
    }

    public void refreshData() {
        hideEmptyView();
        hideErrorView();
        if (isNeedLogin()) {
            if (App.isLogin()) {
                startLoad();
                return;
            }
            setNotLoginError();
            this.mAdapter.setNewData(new ArrayList());
            endRefreshView();
            return;
        }
        startLoad();
    }

    public void refreshPageData(int i) {
        this.mCurrentPage = i;
        hideEmptyView();
        hideErrorView();
        if (Network.isConnected(getContext())) {
            if (this.mPageClass == null) {
                loadData();
                return;
            } else {
                loadDataWithModel();
                return;
            }
        }
        endRefreshView();
        setErrorView("no internet");
    }

    private void startLoad() {
        if (Network.isConnected(getContext())) {
            if (isOpenLoadMore()) {
                this.mCurrentPage = 1;
                if (this.mPageClass == null) {
                    loadMoreDataPage();
                    return;
                } else {
                    loadMoreDataPageModel();
                    return;
                }
            } else if (this.mPageClass == null) {
                loadData();
                return;
            } else {
                loadDataWithModel();
                return;
            }
        }
        endRefreshView();
        setErrorView("no internet");
    }

    @Override // com.tdo.showbox.base.BaseLazyFragment
    public void onFragmentFirstVisible() {
        if (isNeedLazyLoad()) {
            init();
            swipeRefreshData();
        }
    }

    @Override // com.tdo.showbox.base.BaseLazyFragment, androidx.fragment.app.Fragment
    public void onDestroyView() {
        super.onDestroyView();
    }

    @Override // com.tdo.showbox.base.BaseLazyFragment
    public void onFragmentResumeNoFirst() {
        BaseQuickAdapter<T, com.chad.library.adapter.base.viewholder.BaseViewHolder> baseQuickAdapter;
        super.onFragmentResumeNoFirst();
        if (!openLowMemoryEmpty() || (baseQuickAdapter = this.mAdapter) == null || baseQuickAdapter.getData().size() != 0 || this.swipeRefreshLayout.isRefreshing()) {
            return;
        }
        startRefresh();
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onLowMemory(LowMemoryEvent lowMemoryEvent) {
        BaseQuickAdapter<T, com.chad.library.adapter.base.viewholder.BaseViewHolder> baseQuickAdapter;
        if (!openLowMemoryEmpty() || this.isVisibleToUser || (baseQuickAdapter = this.mAdapter) == null) {
            return;
        }
        baseQuickAdapter.setNewData(new ArrayList());
    }

    @Override // androidx.fragment.app.Fragment
    public void onStart() {
        super.onStart();
        if (!enableEventBus() || EventBus.getDefault().isRegistered(this)) {
            return;
        }
        EventBus.getDefault().register(this);
    }

    @Override // androidx.fragment.app.Fragment
    public void onDestroy() {
        if (enableEventBus() && EventBus.getDefault().isRegistered(this)) {
            EventBus.getDefault().unregister(this);
        }
        super.onDestroy();
    }

    @Override // com.tdo.showbox.base.BaseLazyFragment, androidx.fragment.app.Fragment
    public void onResume() {
        super.onResume();
        MobclickAgent.onPageStart("BaseListFragment");
    }

    @Override // com.tdo.showbox.base.BaseLazyFragment, androidx.fragment.app.Fragment
    public void onPause() {
        super.onPause();
        MobclickAgent.onPageEnd("BaseListFragment");
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: classes3.dex */
    public class MultiItemAdapter extends BaseLoadmoreDelegateMultiAdapter<T, com.chad.library.adapter.base.viewholder.BaseViewHolder> {
        MultiItemAdapter() {
            super(null);
            BaseMultiTypeDelegate<T> baseMultiTypeDelegate = new BaseMultiTypeDelegate<T>() { // from class: com.tdo.showbox.base.BaseListFragment.MultiItemAdapter.1
                @Override // com.chad.library.adapter.base.delegate.BaseMultiTypeDelegate
                public int getItemType(List<? extends T> list, int i) {
                    return BaseListFragment.this.initItemType(list.get(i));
                }
            };
            setMultiTypeDelegate(baseMultiTypeDelegate);
            BaseListFragment.this.registerItemType(baseMultiTypeDelegate);
        }

        @Override // com.chad.library.adapter.base.BaseQuickAdapter
        protected void convert(com.chad.library.adapter.base.viewholder.BaseViewHolder baseViewHolder, T t) {
            BaseListFragment.this.initHolder(baseViewHolder, t);
        }
    }
}
