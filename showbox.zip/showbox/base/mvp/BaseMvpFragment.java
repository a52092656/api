package com.tdo.showbox.base.mvp;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import butterknife.ButterKnife;
import butterknife.Unbinder;
import com.kaopiz.kprogresshud.KProgressHUD;
import com.tdo.showbox.base.BaseLazyFragment;
import com.tdo.showbox.base.mvp.BaseContract;
import com.tdo.showbox.base.mvp.BaseContract.BasePresenter;
import com.umeng.analytics.MobclickAgent;
import org.greenrobot.eventbus.EventBus;
/* loaded from: classes.dex */
public abstract class BaseMvpFragment<T extends BaseContract.BasePresenter> extends BaseLazyFragment implements BaseContract.BaseView {
    private KProgressHUD hud;
    protected T mPresenter;
    Unbinder unbinder;

    protected abstract int bindLayout();

    protected abstract T bindPresenter();

    protected boolean enableEventBus() {
        return false;
    }

    @Override // com.tdo.showbox.base.mvp.BaseContract.BaseView
    public void hideLoadingView() {
    }

    protected abstract void initData();

    protected abstract void initListener();

    protected abstract void initView();

    protected abstract void loadData();

    @Override // com.tdo.showbox.base.mvp.BaseContract.BaseView
    public void showEmptyState() {
    }

    @Override // com.tdo.showbox.base.mvp.BaseContract.BaseView
    public void showError(String str) {
    }

    @Override // com.tdo.showbox.base.mvp.BaseContract.BaseView
    public void showErrorPage() {
    }

    @Override // com.tdo.showbox.base.mvp.BaseContract.BaseView
    public void showFinish(String str) {
    }

    @Override // com.tdo.showbox.base.mvp.BaseContract.BaseView
    public void showLoadingView() {
    }

    @Override // androidx.fragment.app.Fragment
    public void onAttach(Context context) {
        super.onAttach(context);
        T bindPresenter = bindPresenter();
        this.mPresenter = bindPresenter;
        if (bindPresenter != null) {
            bindPresenter.attachView(this);
        }
    }

    @Override // androidx.fragment.app.Fragment
    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        View inflate = layoutInflater.inflate(bindLayout(), viewGroup, false);
        this.unbinder = ButterKnife.bind(this, inflate);
        return inflate;
    }

    @Override // androidx.fragment.app.Fragment
    public void onViewCreated(View view, Bundle bundle) {
        super.onViewCreated(view, bundle);
        initData();
        initView();
        initListener();
    }

    @Override // com.tdo.showbox.base.BaseLazyFragment
    public void onFragmentFirstVisible() {
        loadData();
    }

    @Override // com.tdo.showbox.base.mvp.BaseContract.BaseView
    public void showLoading() {
        KProgressHUD kProgressHUD = this.hud;
        if (kProgressHUD == null || !kProgressHUD.isShowing()) {
            KProgressHUD kProgressHUD2 = this.hud;
            if (kProgressHUD2 != null && kProgressHUD2.isShowing()) {
                return;
            }
            this.hud = KProgressHUD.create(getContext()).setStyle(KProgressHUD.Style.SPIN_INDETERMINATE).setCancellable(true).setAnimationSpeed(1).setDimAmount(0.5f).show();
        }
    }

    @Override // com.tdo.showbox.base.mvp.BaseContract.BaseView
    public void hideLoading() {
        KProgressHUD kProgressHUD = this.hud;
        if (kProgressHUD == null || !kProgressHUD.isShowing()) {
            return;
        }
        this.hud.dismiss();
    }

    @Override // androidx.fragment.app.Fragment
    public void onStart() {
        super.onStart();
        if (!enableEventBus() || EventBus.getDefault().isRegistered(this)) {
            return;
        }
        EventBus.getDefault().register(this);
    }

    @Override // com.tdo.showbox.base.BaseLazyFragment, androidx.fragment.app.Fragment
    public void onResume() {
        super.onResume();
        MobclickAgent.onPageStart("BaseMvpFragment");
    }

    @Override // com.tdo.showbox.base.BaseLazyFragment, androidx.fragment.app.Fragment
    public void onPause() {
        super.onPause();
        MobclickAgent.onPageEnd("BaseMvpFragment");
    }

    @Override // androidx.fragment.app.Fragment
    public void onDestroy() {
        if (enableEventBus() && EventBus.getDefault().isRegistered(this)) {
            EventBus.getDefault().unregister(this);
        }
        T t = this.mPresenter;
        if (t != null) {
            t.detachView();
        }
        KProgressHUD kProgressHUD = this.hud;
        if (kProgressHUD != null && kProgressHUD.isShowing()) {
            this.hud.dismiss();
        }
        super.onDestroy();
    }

    @Override // com.tdo.showbox.base.BaseLazyFragment, androidx.fragment.app.Fragment
    public void onDestroyView() {
        super.onDestroyView();
        this.unbinder.unbind();
    }
}
