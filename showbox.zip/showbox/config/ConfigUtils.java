package com.tdo.showbox.config;

import android.content.Context;
import android.text.TextUtils;
import com.tdo.showbox.app.App;
import com.tdo.showbox.utils.MLog;
/* loaded from: classes.dex */
public class ConfigUtils {
    private static final String TAG = "ConfigUtils";

    public static boolean containsConfig(String str) {
        String format = String.format("%s_%s_%s", str, App.channel, App.versionName);
        boolean containsKey = OnlineConfigAgent.getInstance().containsKey(App.getContext(), format);
        MLog.d(TAG, format + ": " + containsKey);
        if (!containsKey) {
            format = String.format("%s_%s", str, App.channel);
            containsKey = OnlineConfigAgent.getInstance().containsKey(App.getContext(), format);
        }
        MLog.d(TAG, format + ": " + containsKey);
        if (!containsKey) {
            format = String.format("%s_%s", str, App.versionName);
            containsKey = OnlineConfigAgent.getInstance().containsKey(App.getContext(), format);
        }
        MLog.d(TAG, format + ": " + containsKey);
        if (!containsKey) {
            format = String.format("%s_%s", App.versionName, str);
            containsKey = OnlineConfigAgent.getInstance().containsKey(App.getContext(), format);
        }
        MLog.d(TAG, format + ": " + containsKey);
        if (!containsKey) {
            containsKey = OnlineConfigAgent.getInstance().containsKey(App.getContext(), str);
        } else {
            str = format;
        }
        MLog.d(TAG, str + ": " + containsKey);
        return containsKey;
    }

    public static String readStringConfig(String str) {
        String format = String.format("%s_%s_%s", str, App.channel, App.versionName);
        String configParam = OnlineConfigAgent.getInstance().getConfigParam(App.getContext(), format);
        if (TextUtils.isEmpty(configParam)) {
            format = String.format("%s_%s", str, App.channel);
            configParam = OnlineConfigAgent.getInstance().getConfigParam(App.getContext(), format);
            MLog.d(TAG, "readOnline: " + format + ": " + configParam);
        }
        if (TextUtils.isEmpty(configParam)) {
            format = String.format("%s_%s", str, App.versionName);
            configParam = OnlineConfigAgent.getInstance().getConfigParam(App.getContext(), format);
            MLog.d(TAG, "readOnline: " + format + ": " + configParam);
        }
        if (TextUtils.isEmpty(format)) {
            String format2 = String.format("%s_%s", App.versionName, str);
            configParam = OnlineConfigAgent.getInstance().getConfigParam(App.getContext(), format2);
            MLog.d(TAG, "readOnline: " + format2 + ": " + configParam);
        }
        if (TextUtils.isEmpty(configParam)) {
            String configParam2 = OnlineConfigAgent.getInstance().getConfigParam(App.getContext(), str);
            MLog.d(TAG, "readOnline: " + str + ": " + configParam2);
            return configParam2;
        }
        return configParam;
    }

    public static int readIntBoolConfig(String str) {
        return readIntBoolConfig(str, 0);
    }

    public static int readIntBoolConfig(String str, int i) {
        String readStringConfig = readStringConfig(str);
        if (readStringConfig == null || !readStringConfig.matches("[01]")) {
            return i > 0 ? 1 : 0;
        }
        return Integer.parseInt(readStringConfig);
    }

    public static boolean readBooleanConfig(String str) {
        return readBooleanConfig(str, false);
    }

    public static boolean readBooleanConfig(String str, boolean z) {
        String readStringConfig = readStringConfig(str);
        return (readStringConfig == null || !readStringConfig.matches("[01]")) ? z : Integer.parseInt(readStringConfig) == 1;
    }

    public static int readIntegerConfig(String str) {
        return readIntegerConfig(str, -1);
    }

    public static int readIntegerConfig(String str, int i) {
        String readStringConfig = readStringConfig(str);
        return (readStringConfig == null || !readStringConfig.matches("\\d+")) ? i : Integer.parseInt(readStringConfig);
    }

    public static void writeIntgerConfig(String str, int i) {
        OnlineConfigAgent onlineConfigAgent = OnlineConfigAgent.getInstance();
        Context context = App.getContext();
        onlineConfigAgent.setConfigParam(context, str, i + "");
    }
}
