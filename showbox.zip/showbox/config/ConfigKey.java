package com.tdo.showbox.config;
/* loaded from: classes3.dex */
public class ConfigKey {
    public static final String AD_INTERSTITIAL_APPNEXT_PORTION = "ad_interstitial_appnext_portion";
    public static final String AD_INTERSTITIAL_CLOUDMOBI_PORTION = "ad_interstitial_cloudmobi_portion";
    public static final String AD_INTERSTITIAL_CLOUDMOBI_PORTION_NEW = "ad_interstitial_cloudmobi_portion_new";
    public static final String AD_INTERSTITIAL_GOOGLE_PORTION = "ad_interstitial_google_portion";
    public static final String AD_INTERSTITIAL_MINTEGRAL_IMAGE_PORTION = "ad_interstitial_mintegral_image_portion";
    public static final String AD_INTERSTITIAL_MINTEGRAL_PORTION = "ad_interstitial_mintegral_portion";
    public static final String APK_INFO = "apk_info";
    public static final String APK_INFO_MIN = "apk_info_min";
    public static final String APK_INFO_NEW = "apk_info_new";
    public static final String APK_LATEST_VERSION = "apk_latest_version";
    public static final String APK_MD5 = "apk_md5";
    public static final String APK_SIZE = "apk_size";
    public static final String APK_TIME = "apk_time";
    public static final String APK_TITLE = "apk_title";
    public static final String APK_URL = "apk_url";
    public static final String APK_VERSION = "apk_version";
    public static final String APK_VERSION_CODE_MIN = "apk_version_code_min";
    public static final String BBS_URL = "bbs_url";
    public static final String CHECK_CHAPTER_STATUS = "check_chapter_status";
    public static final String FENG_BBS_URL = "feng_bbs_url";
    public static final String OPENSUBTITLE_AGENT = "openSubtitle_agent";
    public static final String PAY_URL = "pay_url";
    public static final String READ_TIME_INTERVAL = "read_time_interval";
    public static final String SEARCH_URL = "search_url";
    public static final String SHARE_QQ_QZONE = "share_qq_qzone";
    public static final String SHOW_NEWS_MODULE = "show_news_module";
    public static final String SHOW_ONLY_BBS = "show_only_bbs";
    public static final String SHOW_SPLASH_AD = "show_splash_ad";
    public static final String SHOW_SPLASH_ADVERT = "show_splash_advert";
    public static final String SPLASH_AD_INTERVAL = "splash_ad_interval";
    public static final String STONE_BBS_URL = "stone_bbs_url";
    public static final String URL = "url";
    public static final String URL_VALUE = "url_value";
}
